/* PDFDesk Phase 2 tools: sign, forms (+ mupdf & OCR tools appended later) */
"use strict";

Object.assign(ICONS, {
  sign: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="m14 5 5 5L8 21H3v-5z"/><path d="m12.5 6.5 5 5"/><path d="M3 21h18" opacity="0.5"/></svg>',
  forms: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="3" width="16" height="18" rx="2"/><path d="M8 8h8M8 12h8M8 16h4"/></svg>',
  lock: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="10" width="14" height="10" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/><circle cx="12" cy="15" r="1.4" fill="currentColor" stroke="none"/></svg>',
  unlock: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="10" width="14" height="10" rx="2"/><path d="M8 10V7a4 4 0 0 1 7.8-1.2"/><circle cx="12" cy="15" r="1.4" fill="currentColor" stroke="none"/></svg>',
  repair: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M14.5 6.5a4 4 0 0 0-5.6 4.7L3 17.1V21h3.9l5.9-5.9a4 4 0 0 0 4.7-5.6l-2.8 2.8-2.1-2.1z"/></svg>',
  ocr: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 8V5a1 1 0 0 1 1-1h3M16 4h3a1 1 0 0 1 1 1v3M20 16v3a1 1 0 0 1-1 1h-3M8 20H5a1 1 0 0 1-1-1v-3"/><path d="M8 9h8M8 12.5h8M8 16h5"/></svg>',
});

/* ---------------- SIGN ---------------- */
registerTool({
  id: "sign", name: "Sign", icon: "sign",
  desc: "Draw or upload a signature",
  hint: "Draw it, click where it goes, done",
  build(ctx) {
    singlePdfTool(ctx, {}, async (rec, pages) => {
      const bar = actionBar(pages + " pages", "Sign PDF", run);
      ctx.setCleanup(() => bar.el.remove());
      document.body.append(bar.el);

      let sig = null; // {bytes, isPng, w, h, url}
      let placement = null; // {cx, cy} display pts
      let curPage = 1, pageW = 595, pageH = 842;

      /* --- signature sources --- */
      let mode = "draw";
      // draw pad
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const padW = 440, padH = 150;
      const pad = h("canvas", { style: "width:" + padW + "px;max-width:100%;height:" + padH + "px;border:1.5px dashed var(--line-strong);border-radius:10px;background:white;cursor:crosshair;touch-action:none" });
      pad.width = padW * dpr; pad.height = padH * dpr;
      const pctx = pad.getContext("2d");
      pctx.scale(dpr, dpr);
      pctx.lineCap = "round"; pctx.lineJoin = "round";
      let inkColor = "#1b2a52", inkW = 2.4, drawn = false, strokes = 0;
      let last = null;
      pad.addEventListener("pointerdown", e => {
        e.preventDefault();
        pad.setPointerCapture(e.pointerId);
        const r = pad.getBoundingClientRect();
        last = [e.clientX - r.left, e.clientY - r.top];
        pctx.strokeStyle = inkColor; pctx.lineWidth = inkW;
        pctx.beginPath(); pctx.moveTo(last[0], last[1]); pctx.lineTo(last[0] + 0.01, last[1]); pctx.stroke();
        drawn = true; strokes++;
        const move = ev => {
          const p = [ev.clientX - r.left, ev.clientY - r.top];
          pctx.beginPath(); pctx.moveTo(last[0], last[1]);
          pctx.quadraticCurveTo(last[0], last[1], (last[0] + p[0]) / 2, (last[1] + p[1]) / 2);
          pctx.lineTo(p[0], p[1]); pctx.stroke();
          last = p;
        };
        const up = () => { pad.removeEventListener("pointermove", move); pad.removeEventListener("pointerup", up); sigFromPad(); };
        pad.addEventListener("pointermove", move);
        pad.addEventListener("pointerup", up);
      });
      function clearPad() { pctx.save(); pctx.setTransform(1, 0, 0, 1, 0, 0); pctx.clearRect(0, 0, pad.width, pad.height); pctx.restore(); drawn = false; setSig(null); }
      async function sigFromPad() {
        if (!drawn) return;
        // trim to content bbox
        const raw = pad.getContext("2d").getImageData(0, 0, pad.width, pad.height);
        let minX = pad.width, minY = pad.height, maxX = 0, maxY = 0;
        for (let y = 0; y < pad.height; y++) for (let x = 0; x < pad.width; x++) {
          if (raw.data[(y * pad.width + x) * 4 + 3] > 10) {
            if (x < minX) minX = x; if (x > maxX) maxX = x;
            if (y < minY) minY = y; if (y > maxY) maxY = y;
          }
        }
        if (maxX <= minX) return;
        const p = 6 * dpr;
        minX = Math.max(0, minX - p); minY = Math.max(0, minY - p);
        maxX = Math.min(pad.width, maxX + p); maxY = Math.min(pad.height, maxY + p);
        const c = document.createElement("canvas");
        c.width = maxX - minX; c.height = maxY - minY;
        c.getContext("2d").drawImage(pad, minX, minY, c.width, c.height, 0, 0, c.width, c.height);
        const blob = await new Promise(r => c.toBlob(r, "image/png"));
        setSig({ bytes: new Uint8Array(await blob.arrayBuffer()), isPng: true, w: c.width, h: c.height, url: URL.createObjectURL(blob) });
      }
      const inkSw = swatches(["#1b2a52", "#17181a"], inkColor, v => { inkColor = v; });

      // type mode
      const typeInput = h("input", { type: "text", placeholder: "Type your name", style: "width:min(280px,70vw);padding:9px 12px;border:1px solid var(--line);border-radius:8px;background:var(--surface);font-style:italic;font-size:17px" });
      const typeFont = h("select", null,
        h("option", { value: "italic 600 52px Georgia, 'Times New Roman', serif" }, "Serif italic"),
        h("option", { value: "italic 52px Helvetica, Arial, sans-serif" }, "Clean italic"),
        h("option", { value: "52px 'Comic Sans MS', 'Segoe Script', cursive" }, "Handwritten"));
      const typeGo = debounce(async () => {
        const text = typeInput.value.trim();
        if (!text) { setSig(null); return; }
        const c = document.createElement("canvas");
        const m = c.getContext("2d");
        m.font = typeFont.value;
        const w = Math.ceil(m.measureText(text).width) + 40;
        c.width = w; c.height = 110;
        const m2 = c.getContext("2d");
        m2.font = typeFont.value; m2.fillStyle = inkColor;
        m2.textBaseline = "middle";
        m2.fillText(text, 20, 58);
        const blob = await new Promise(r => c.toBlob(r, "image/png"));
        setSig({ bytes: new Uint8Array(await blob.arrayBuffer()), isPng: true, w: c.width, h: c.height, url: URL.createObjectURL(blob) });
      }, 250);
      typeInput.addEventListener("input", typeGo);
      typeFont.addEventListener("change", typeGo);

      // upload mode
      const upDrop = makeDrop({ accept: "image", compact: true, big: "Choose signature image", sub: "PNG with transparent background works best", onFiles: async ([r]) => {
        const isPng = !/\.jpe?g$/i.test(r.name);
        const url = URL.createObjectURL(new Blob([r.buf]));
        const img = new Image();
        await new Promise((res, rej) => { img.onload = res; img.onerror = rej; img.src = url; });
        setSig({ bytes: new Uint8Array(r.buf.slice(0)), isPng, w: img.naturalWidth, h: img.naturalHeight, url });
        upDrop.querySelector(".big").textContent = r.name;
      }});

      const drawUI = h("div", null, pad, h("div", { class: "opt-row", style: "margin-top:10px" },
        inkSw.el,
        h("button", { class: "btn secondary", style: "height:32px;padding:0 12px;font-size:12.5px", onclick: clearPad }, "Clear")));
      const typeUI = h("div", { class: "hidden" }, h("div", { class: "opt-row" }, typeInput, typeFont));
      const upUI = h("div", { class: "hidden" }, upDrop);
      const modeSeg = segmented([{ v: "draw", label: "Draw" }, { v: "type", label: "Type" }, { v: "image", label: "Upload" }], mode, v => {
        mode = v;
        drawUI.classList.toggle("hidden", v !== "draw");
        typeUI.classList.toggle("hidden", v !== "type");
        upUI.classList.toggle("hidden", v !== "image");
      });

      /* --- placement preview --- */
      const pageCanvas = document.createElement("canvas");
      const sigImg = h("img", { style: "position:absolute;display:none;cursor:grab;filter:drop-shadow(0 1px 4px rgba(0,0,0,0.25))", draggable: "false" });
      const overlay = h("div", { style: "position:absolute;inset:0;cursor:copy" }, sigImg);
      const pvFrame = h("div", { class: "frame", style: "position:relative;width:max-content;max-width:100%" }, pageCanvas, overlay);
      const pvWrap = h("div", { class: "preview-wrap" }, pvFrame, h("div", { class: "cap" }, "Click where the signature should go, drag to adjust"));
      const pageField = h("input", { type: "number", min: 1, max: pages, value: 1, style: "width:64px;padding:6px 9px;border:1px solid var(--line);border-radius:8px;background:var(--surface);text-align:center" });
      const sizeS = slider(8, 60, 1, 25, v => v + "%", () => positionSig());
      const dateC = checkbox("Add today's date below", false, () => {});

      let pvScale = 1; // rendering scale only; CSS may shrink the canvas further
      const liveScale = () => {
        const r = pageCanvas.getBoundingClientRect();
        return r.width > 0 ? r.width / pageW : pvScale;
      };
      async function renderPreviewPage() {
        try {
          const doc = await openPdf(rec);
          const page = await doc.getPage(curPage);
          const vp1 = page.getViewport({ scale: 1 });
          pageW = vp1.width; pageH = vp1.height;
          const cssW = Math.min(500, Math.max(320, window.innerWidth * 0.5));
          pvScale = cssW / vp1.width;
          const rdpr = Math.min(window.devicePixelRatio || 1, 2);
          const vp = page.getViewport({ scale: pvScale * rdpr });
          pageCanvas.width = Math.round(vp.width); pageCanvas.height = Math.round(vp.height);
          pageCanvas.style.width = cssW + "px";
          const c2 = pageCanvas.getContext("2d", { alpha: false });
          c2.fillStyle = "#fff"; c2.fillRect(0, 0, pageCanvas.width, pageCanvas.height);
          await page.render({ canvasContext: c2, viewport: vp }).promise;
          closePdf(doc);
          positionSig();
        } catch (e) { toast("Could not preview that page", "err"); }
      }
      pageField.addEventListener("change", () => {
        curPage = Math.max(1, Math.min(pages, parseInt(pageField.value, 10) || 1));
        pageField.value = curPage;
        renderPreviewPage();
      });

      function sigDims() {
        if (!sig) return null;
        const wPt = pageW * sizeS.get() / 100;
        return { wPt, hPt: wPt * sig.h / sig.w };
      }
      function positionSig() {
        if (!sig || !placement) { sigImg.style.display = "none"; updateBar(); return; }
        const s = liveScale();
        const d = sigDims();
        const cssW = d.wPt * s, cssH = d.hPt * s;
        sigImg.src = sig.url;
        sigImg.style.display = "block";
        sigImg.style.width = cssW + "px";
        sigImg.style.left = (placement.cx * s - cssW / 2) + "px";
        sigImg.style.top = ((pageH - placement.cy) * s - cssH / 2) + "px";
        updateBar();
      }
      window.addEventListener("resize", positionSig);
      overlay.addEventListener("pointerdown", e => {
        if (!sig) { toast("Create a signature first (draw, type or upload)"); return; }
        const r = overlay.getBoundingClientRect();
        const s = liveScale();
        const set = ev => {
          const x = Math.max(0, Math.min(r.width, ev.clientX - r.left));
          const y = Math.max(0, Math.min(r.height, ev.clientY - r.top));
          placement = { cx: x / s, cy: pageH - y / s };
          positionSig();
        };
        set(e);
        const move = ev => set(ev);
        const up = () => { window.removeEventListener("pointermove", move); window.removeEventListener("pointerup", up); };
        window.addEventListener("pointermove", move);
        window.addEventListener("pointerup", up);
      });

      function setSig(s) {
        if (sig && sig.url && (!s || s.url !== sig.url)) { try { URL.revokeObjectURL(sig.url); } catch (e) {} }
        sig = s;
        if (!placement && s) placement = { cx: pageW * 0.68, cy: pageH * 0.18 };
        positionSig();
      }
      function updateBar() {
        bar.enable(!!(sig && placement));
        bar.setSummary(sig ? (placement ? "Page " + curPage + " · signature ready" : "Click the page preview to place it") : "Create a signature to begin");
      }

      ctx.body.append(
        filePill(rec, pages + " pages", ctx.restart),
        h("div", { class: "preview-cols" },
          h("div", { class: "opts" },
            optSection("Signature", h("div", { class: "opt-row" }, modeSeg.el), h("div", { style: "margin-top:12px" }, drawUI, typeUI, upUI)),
            optSection("Placement", h("div", { class: "opt-row" }, h("span", { class: "field" }, "Page", pageField, "of " + pages), sizeS.el), h("div", { class: "opt-row", style: "margin-top:8px" }, dateC.el)),
            h("div", { class: "opt-note" }, "This places a signature image — quick and universally accepted for everyday paperwork. Certificate-based digital signatures are a Phase 3 candidate.")),
          pvWrap));
      updateBar();
      renderPreviewPage();

      function run() {
        if (!sig || !placement) return;
        const d = sigDims();
        const dateStr = dateC.get() ? new Date().toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" }) : null;
        runJob(ctx, "Signing", async prog => {
          prog.set(0.5, "Placing signature on page " + curPage);
          return await PDCore.placeSignature(bytesOf(rec), sig.bytes, sig.isPng, {
            pageIdx: curPage - 1, cx: placement.cx, cy: placement.cy, wPt: d.wPt, dateStr });
        }, bytes => ({
          files: [{ name: PDCore.baseName(rec.name) + "-signed.pdf", bytes, mime: "application/pdf" }],
          opts: { title: "Signed" },
        }));
      }
    });
  },
});

/* ---------------- FILL FORMS ---------------- */
registerTool({
  id: "forms", name: "Fill a form", icon: "forms",
  desc: "Fill and flatten PDF forms",
  build(ctx) {
    singlePdfTool(ctx, {}, async (rec, pages) => {
      const fields = await PDCore.listFormFields(bytesOf(rec));
      if (!fields.length) {
        ctx.body.append(
          filePill(rec, pages + " pages", ctx.restart),
          h("div", { class: "result" },
            h("h2", null, "No fillable fields"),
            h("div", { class: "rmeta", style: "max-width:52ch;margin:8px auto 0" },
              "This PDF has no interactive form fields. If it's a scanned or flat form, you can use the Sign tool to stamp text and signatures onto it instead."),
            h("div", { class: "btns" },
              h("button", { class: "btn primary", onclick: () => showView("sign", rec) }, "Open in Sign"),
              h("button", { class: "btn secondary", onclick: () => showView("home") }, "All tools"))));
        return;
      }
      const bar = actionBar(fields.length + " fields", "Save filled PDF", run);
      ctx.setCleanup(() => bar.el.remove());
      document.body.append(bar.el);
      bar.enable(true);

      const controls = []; // {field, get()}
      const pretty = n => n.replace(/[_.\[\]]+/g, " ").replace(/\s+/g, " ").trim() || n;
      const rows = fields.map(f => {
        let control, get;
        if (f.kind === "text" && f.multiline) {
          control = h("textarea", { rows: 3, style: "width:min(420px,80vw);padding:8px 11px;border:1px solid var(--line);border-radius:8px;background:var(--surface);resize:vertical" }, f.value || "");
          get = () => control.value;
        } else if (f.kind === "text") {
          control = h("input", { type: "text", value: f.value || "", style: "width:min(340px,75vw);padding:8px 11px;border:1px solid var(--line);border-radius:8px;background:var(--surface)" });
          get = () => control.value;
        } else if (f.kind === "check") {
          const c = checkbox("", f.value, () => {});
          control = c.el; get = () => c.get();
        } else if (f.kind === "radio" || f.kind === "dropdown") {
          control = h("select", null,
            h("option", { value: "" }, "—"),
            (f.options || []).map(o => { const opt = h("option", { value: o }, o); if (o === f.value) opt.setAttribute("selected", ""); return opt; }));
          get = () => control.value;
        } else if (f.kind === "optionlist") {
          control = h("select", { multiple: "", size: Math.min(4, (f.options || []).length || 2), style: "min-width:200px" },
            (f.options || []).map(o => { const opt = h("option", { value: o }, o); if ((f.value || []).includes(o)) opt.setAttribute("selected", ""); return opt; }));
          get = () => Array.from(control.selectedOptions).map(o => o.value);
        } else {
          control = h("span", { class: "muted", style: "font-size:12.5px" }, "unsupported field type");
          get = null;
        }
        if (get) controls.push({ field: f, get });
        return h("div", { class: "opt-row", style: "padding:9px 0;border-bottom:1px solid var(--line);align-items:flex-start" },
          h("div", { style: "flex:0 0 200px;font-size:13px;font-weight:600;padding-top:7px;overflow-wrap:anywhere" }, pretty(f.name)),
          control);
      });
      const flatC = checkbox("Flatten the form (answers become permanent, fields are removed)", false, () => {});
      ctx.body.append(
        filePill(rec, pages + " pages · " + fields.length + " fields", ctx.restart),
        h("div", { class: "opt-section" }, rows),
        optSection("Output", h("div", { class: "opt-row" }, flatC.el)));

      function run() {
        const entries = controls.map(c => ({ name: c.field.name, kind: c.field.kind, value: c.get() }));
        const flatten = flatC.get();
        runJob(ctx, "Filling", async prog => {
          prog.set(0.5, "Writing field values");
          return await PDCore.fillForm(bytesOf(rec), entries, { flatten });
        }, res => {
          if (res.problems.length) toast(res.problems.length + " field(s) could not be set: " + res.problems[0], "err", 6000);
          return {
            files: [{ name: PDCore.baseName(rec.name) + "-filled.pdf", bytes: res.bytes, mime: "application/pdf" }],
            opts: { title: flatten ? "Filled & flattened" : "Form filled", meta: res.problems.length ? res.problems.length + " field(s) skipped — see message" : null },
          };
        });
      }
    });
  },
});

/* ---------------- PROTECT ---------------- */
registerTool({
  id: "protect", name: "Protect", icon: "lock",
  desc: "Password-protect with AES-256",
  build(ctx) {
    singlePdfTool(ctx, { needProbe: false }, async (rec) => {
      const bar = actionBar(PDCore.fmtBytes(rec.size), "Protect PDF", run);
      ctx.setCleanup(() => bar.el.remove());
      document.body.append(bar.el);
      const pwInput = h("input", { type: "password", placeholder: "Password to open", autocomplete: "new-password", style: "width:min(240px,60vw);padding:8px 11px;border:1px solid var(--line);border-radius:8px;background:var(--surface)" });
      const ownInput = h("input", { type: "password", placeholder: "Owner password (optional)", autocomplete: "new-password", style: "width:min(240px,60vw);padding:8px 11px;border:1px solid var(--line);border-radius:8px;background:var(--surface)" });
      const cPrint = checkbox("Allow printing", true, null);
      const cCopy = checkbox("Allow copying text & images", true, null);
      const cModify = checkbox("Allow editing", false, null);
      const cAnnot = checkbox("Allow comments & form filling", true, null);
      const upd = () => {
        const pw = pwInput.value;
        const bad = /[,=]/.test(pw) || /[,=]/.test(ownInput.value);
        bar.enable(pw.length > 0 && !bad);
        bar.setSummary(bad ? "Passwords can't contain , or =" : (pw ? "AES-256 encryption" : "Enter a password"));
      };
      pwInput.addEventListener("input", upd);
      ownInput.addEventListener("input", upd);
      ctx.body.append(
        filePill(rec, PDCore.fmtBytes(rec.size), ctx.restart),
        optSection("Passwords", h("div", { class: "opt-row" }, pwInput, ownInput),
          h("div", { class: "opt-note" }, "The first password is needed to open the file. The owner password (if set) additionally unlocks the permissions below.")),
        optSection("Permissions", h("div", { class: "opt-row", style: "flex-direction:column;align-items:flex-start;gap:9px" }, cPrint.el, cCopy.el, cModify.el, cAnnot.el)));
      upd();
      function run() {
        const upw = pwInput.value, opw = ownInput.value || upw;
        let perms = -4;
        if (!cPrint.get()) perms &= ~(4 | 2048);
        if (!cModify.get()) perms &= ~(8 | 1024);
        if (!cCopy.get()) perms &= ~16;
        if (!cAnnot.get()) perms &= ~(32 | 256);
        runJob(ctx, "Protecting", async prog => {
          prog.set(0.1, "Loading security engine (one-time)");
          const mupdf = await loadMuPDF();
          prog.set(0.5, "Encrypting with AES-256");
          const doc = mupdfOpen(mupdf, bytesOf(rec));
          if (doc.needsPassword && doc.needsPassword()) throw new Error("This PDF is already password-protected. Unlock it first.");
          const out = doc.saveToBuffer("encrypt=aes-256,user-password=" + upw + ",owner-password=" + opw + ",permissions=" + perms).asUint8Array();
          prog.set(0.9, "Verifying");
          const check = mupdfOpen(mupdf, out.slice(0));
          const locked = check.needsPassword();
          return { out, locked };
        }, res => ({
          files: [{ name: PDCore.baseName(rec.name) + "-protected.pdf", bytes: res.out, mime: "application/pdf" }],
          opts: { title: "Protected", meta: res.locked ? "Verified: a password is now required to open this file." : "Owner password set (opens without password, restricted permissions)." },
        }));
      }
    });
  },
});

/* ---------------- UNLOCK ---------------- */
registerTool({
  id: "unlock", name: "Unlock", icon: "unlock",
  desc: "Remove a password you know",
  build(ctx) {
    singlePdfTool(ctx, { needProbe: false }, async (rec) => {
      const bar = actionBar(PDCore.fmtBytes(rec.size), "Remove password", run);
      ctx.setCleanup(() => bar.el.remove());
      document.body.append(bar.el);
      bar.enable(true);
      ctx.body.append(
        filePill(rec, PDCore.fmtBytes(rec.size), ctx.restart),
        h("div", { class: "opt-note", style: "padding:16px 0" },
          "Removes encryption from a PDF you have the password for, so it opens freely. You'll be asked for the password if the file needs one."));
      function run() {
        runJob(ctx, "Unlocking", async prog => {
          prog.set(0.1, "Loading security engine (one-time)");
          const mupdf = await loadMuPDF();
          prog.set(0.4, "Opening document");
          const doc = mupdfOpen(mupdf, bytesOf(rec));
          let wasLocked = false;
          if (doc.needsPassword()) {
            wasLocked = true;
            let ok = false;
            for (let attempt = 0; attempt < 3 && !ok; attempt++) {
              const pw = await passwordPrompt(rec.name, attempt > 0);
              if (pw == null) throw new Error("Unlock cancelled.");
              ok = doc.authenticatePassword(pw) !== 0;
            }
            if (!ok) throw new Error("Wrong password (3 attempts).");
          }
          prog.set(0.8, "Writing unlocked copy");
          const out = doc.saveToBuffer("encrypt=none,garbage=compact").asUint8Array();
          return { out, wasLocked };
        }, res => ({
          files: [{ name: PDCore.baseName(rec.name) + "-unlocked.pdf", bytes: res.out, mime: "application/pdf" }],
          opts: { title: res.wasLocked ? "Password removed" : "No password found", meta: res.wasLocked ? "This copy opens without a password." : "The file wasn't encrypted. Saved a clean copy anyway." },
        }));
      }
    });
  },
});

/* ---------------- REPAIR ---------------- */
registerTool({
  id: "repair", name: "Repair", icon: "repair",
  desc: "Recover a damaged PDF",
  build(ctx) {
    singlePdfTool(ctx, { needProbe: false }, async (rec) => {
      const bar = actionBar(PDCore.fmtBytes(rec.size), "Repair PDF", run);
      ctx.setCleanup(() => bar.el.remove());
      document.body.append(bar.el);
      bar.enable(true);
      ctx.body.append(
        filePill(rec, PDCore.fmtBytes(rec.size), ctx.restart),
        h("div", { class: "opt-note", style: "padding:16px 0" },
          "Rebuilds the file structure of a PDF that won't open or behaves strangely. Recovers as many pages as possible."));
      function run() {
        runJob(ctx, "Repairing", async prog => {
          prog.set(0.1, "Loading repair engine (one-time)");
          const mupdf = await loadMuPDF();
          prog.set(0.4, "Reading with tolerant parser");
          let doc;
          try { doc = mupdfOpen(mupdf, bytesOf(rec)); }
          catch (e) { throw new Error("This file is damaged beyond what the tolerant parser can read."); }
          if (doc.needsPassword()) {
            const pw = await passwordPrompt(rec.name, false);
            if (pw == null || doc.authenticatePassword(pw) === 0) throw new Error("Can't repair without the correct password.");
          }
          const pages = doc.countPages();
          prog.set(0.6, "Rewriting " + pages + " pages");
          let out, method = "clean rewrite";
          try {
            out = doc.saveToBuffer("garbage=deduplicate,clean=yes,sanitize=yes").asUint8Array();
          } catch (e) {
            method = "page-by-page rebuild";
            const fresh = new mupdf.PDFDocument();
            let ok = 0;
            for (let i = 0; i < pages; i++) {
              try { fresh.graftPage(ok, doc, i); ok++; }
              catch (err) { /* skip unrecoverable page */ }
              prog.set(0.6 + 0.3 * (i + 1) / pages, "Recovering page " + (i + 1), (i + 1) + " / " + pages);
            }
            if (!ok) throw new Error("No pages could be recovered.");
            out = fresh.saveToBuffer("garbage=deduplicate,clean=yes").asUint8Array();
          }
          return { out, pages, method };
        }, res => ({
          files: [{ name: PDCore.baseName(rec.name) + "-repaired.pdf", bytes: res.out, mime: "application/pdf" }],
          opts: { title: "Repaired", meta: res.pages + " page(s) recovered via " + res.method + "." },
        }));
      }
    });
  },
});

/* ---------------- OCR ---------------- */
registerTool({
  id: "ocr", name: "OCR", icon: "ocr",
  desc: "Make scans searchable",
  hint: "Runs locally — scans never leave this device",
  build(ctx) {
    singlePdfTool(ctx, {}, (rec, pages) => {
      const bar = actionBar(pages + " pages", "Run OCR", run);
      ctx.setCleanup(() => bar.el.remove());
      document.body.append(bar.el);
      const langsAvail = Object.keys((ASSETS().langs) || {});
      if (!langsAvail.length) {
        ctx.body.append(h("div", { class: "opt-note", style: "padding:16px 0" }, "No OCR language data is embedded in this build."));
        return;
      }
      const langChecks = langsAvail.map((l, i) => checkbox(LANG_NAMES[l] || l, i === 0, () => updateNote()));
      let output = "pdf", dpi = 300;
      const outSeg = segmented([{ v: "pdf", label: "Searchable PDF" }, { v: "txt", label: "Text file (.txt)" }, { v: "both", label: "Both" }], output, v => { output = v; updateNote(); });
      const dpiSeg = segmented([{ v: 200, label: "Faster (200 DPI)" }, { v: 300, label: "Better (300 DPI)" }], dpi, v => { dpi = v; });
      const rangeInput = h("input", { class: "range", placeholder: "all pages · e.g. 1-5", style: "width:170px" });
      const note = h("div", { class: "opt-note" }, "");
      function selLangs() { return langsAvail.filter((l, i) => langChecks[i].get()); }
      function updateNote() {
        const nonLatin = selLangs().filter(l => !LATIN_LANGS.has(l));
        note.textContent = (output !== "txt" && nonLatin.length)
          ? "Note: the searchable-PDF text layer supports Latin text only for now. For " + nonLatin.map(l => LANG_NAMES[l] || l).join(", ") + ", the text-file output captures everything."
          : "Expect roughly 2–5 seconds per page. Everything runs on this device.";
        bar.enable(selLangs().length > 0);
      }
      rangeInput.addEventListener("input", debounce(() => {
        try { if (rangeInput.value.trim()) PDCore.parsePageSet(rangeInput.value, pages); rangeInput.classList.remove("bad"); bar.enable(selLangs().length > 0); }
        catch (e) { rangeInput.classList.add("bad"); bar.enable(false); }
      }, 250));
      ctx.body.append(
        filePill(rec, pages + " pages", ctx.restart),
        optSection("Language", h("div", { class: "opt-row" }, langChecks.map(c => c.el))),
        optSection("Output", h("div", { class: "opt-row" }, outSeg.el)),
        optSection("Quality & pages", h("div", { class: "opt-row" }, dpiSeg.el, rangeInput), note));
      updateNote();

      function parseTsv(tsv) {
        const words = [];
        for (const line of tsv.split("\n")) {
          const c = line.split("\t");
          if (c.length < 12 || c[0] !== "5") continue;
          const conf = parseFloat(c[10]);
          const text = c.slice(11).join("\t");
          if (!text.trim() || conf < 25) continue;
          const x = +c[6], y = +c[7], w = +c[8], hh = +c[9];
          words.push({ text: text.trim(), x0: x, y0: y, x1: x + w, y1: y + hh });
        }
        return words;
      }

      function run() {
        let idx;
        try { idx = rangeInput.value.trim() ? PDCore.parsePageSet(rangeInput.value, pages) : Array.from({ length: pages }, (_, i) => i); }
        catch (e) { toast(e.message, "err"); return; }
        const langs = selLangs().join("+");
        const wantPdf = output !== "txt", wantTxt = output !== "pdf";
        runJob(ctx, "Recognizing", async prog => {
          prog.set(0.02, "Starting OCR engine (one-time)");
          let pageProg = 0;
          const worker = await createTessWorker(langs, m => {
            if (m && m.status === "recognizing text" && typeof m.progress === "number")
              prog.set((pageProg + m.progress) / (idx.length + 0.3), null, null);
          });
          try {
            const doc = await openPdf(rec);
            const pageWords = [], pageTexts = [];
            try {
              for (let k = 0; k < idx.length; k++) {
                pageProg = k;
                const pno = idx[k] + 1;
                prog.set(k / (idx.length + 0.3), "Reading page " + pno, (k + 1) + " / " + idx.length);
                const r = await renderPageToCanvas(doc, pno, 0, { dpi });
                const res = await worker.recognize(r.canvas, {}, { text: true, tsv: true });
                pageWords.push({ pageIdx: idx[k], dpi, words: parseTsv(res.data.tsv || "") });
                pageTexts.push((res.data.text || "").trim());
                r.canvas.width = 1; r.canvas.height = 1;
              }
            } finally { closePdf(doc); }
            prog.set(0.94, "Assembling output");
            const files = [];
            let placed = 0, skipped = 0;
            if (wantPdf) {
              const o = await PDCore.ocrOverlay(bytesOf(rec), pageWords);
              placed = o.placed; skipped = o.skipped;
              files.push({ name: PDCore.baseName(rec.name) + "-ocr.pdf", bytes: o.bytes, mime: "application/pdf" });
            }
            if (wantTxt) {
              const txt = pageTexts.map((t, i) => "--- Page " + (idx[i] + 1) + " ---\n\n" + t).join("\n\n");
              files.push({ name: PDCore.baseName(rec.name) + ".txt", bytes: new TextEncoder().encode(txt), mime: "text/plain" });
            }
            return { files, placed, skipped, total: pageWords.reduce((a, p) => a + p.words.length, 0) };
          } finally {
            try { await worker.terminate(); } catch (e) {}
          }
        }, res => ({
          files: res.files,
          opts: {
            title: "OCR complete",
            zipName: PDCore.baseName(rec.name) + "-ocr.zip",
            meta: res.total + " words recognized" + (res.skipped ? " · " + res.skipped + " words couldn't join the PDF text layer (non-Latin) — they're in the .txt output" : ""),
          },
        }));
      }
    });
  },
});
