/* PDFDesk shared runtime: shell, components, pdf.js plumbing */
"use strict";

/* ---------------- icons ---------------- */
const ICONS = {
  logo:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M7 3h7l5 5v13H7z" fill="currentColor" stroke="none" opacity="0"/><path d="M6 3h8l5 5v13H6z"/><path d="M14 3v5h5"/></svg>',
  organize:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="8" height="8" rx="1.5"/><rect x="13" y="13" width="8" height="8" rx="1.5"/><path d="M17 3v4h4M3 17h4v4"/></svg>',
  merge:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 5h5l3 4h8"/><path d="M4 19h5l3-4h8"/><path d="M17 6l3 3-3 3M17 12l3 3-3 3"/></svg>',
  split:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="6" cy="6" r="2.6"/><circle cx="6" cy="18" r="2.6"/><path d="M8.2 7.6 20 18M8.2 16.4 20 6"/></svg>',
  extract:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M8 3h8l4 4v6"/><path d="M16 3v4h4"/><rect x="4" y="11" width="10" height="10" rx="1.5"/></svg>',
  rotate:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M20 8a8 8 0 1 0 2 6"/><path d="M20 3v5h-5"/></svg>',
  compress:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v6m0 0 3-3m-3 3L9 6M12 21v-6m0 0 3 3m-3-3-3 3"/><path d="M4 12h16"/></svg>',
  watermark:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3s6 6.6 6 11a6 6 0 1 1-12 0c0-4.4 6-11 6-11z"/><path d="M9.5 14a2.5 2.5 0 0 0 2.5 2.5"/></svg>',
  numbers:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M9 4 7 20M17 4l-2 16M5 9h15M4 15h15"/></svg>',
  img2pdf:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="13" height="11" rx="1.5"/><circle cx="7.5" cy="9" r="1.3"/><path d="m3 14 3.5-3 4 3.5L14 11l2 2"/><path d="M20 8v11h-9"/></svg>',
  pdf2img:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19V4h9l4 4v3"/><path d="M13 4v4h4"/><rect x="11" y="13" width="10" height="8" rx="1.5"/><circle cx="14" cy="16" r="1"/><path d="m11 19.5 2.5-2 2.5 2 2-1.5 3 2.3"/></svg>',
  view:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12z"/><circle cx="12" cy="12" r="3"/></svg>',
  back:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m14 6-6 6 6 6"/></svg>',
  close:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 6l12 12M18 6 6 18"/></svg>',
  check:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="m4.5 12.5 5 5 10-11"/></svg>',
  download:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 4v11m0 0 4.5-4.5M12 15l-4.5-4.5"/><path d="M4 19h16"/></svg>',
  drop:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v10m0 0 4-4m-4 4L8 9"/><path d="M3 14v4a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-4"/></svg>',
  sun:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><circle cx="12" cy="12" r="4.2"/><path d="M12 2.5v2.2M12 19.3v2.2M2.5 12h2.2M19.3 12h2.2M5 5l1.6 1.6M17.4 17.4 19 19M19 5l-1.6 1.6M6.6 17.4 5 19"/></svg>',
  moon:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M20 14.5A8.5 8.5 0 0 1 9.5 4a8.5 8.5 0 1 0 10.5 10.5z"/></svg>',
  themeauto:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="8.5"/><path d="M12 3.5v17A8.5 8.5 0 0 0 12 3.5z" fill="currentColor" stroke="none"/></svg>',
  trash:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 7h16M9 7V5h6v2M6.5 7l1 13h9l1-13"/><path d="M10 11v5M14 11v5"/></svg>',
  rotcw:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 8a8 8 0 1 1-2 6"/><path d="M4 3v5h5"/></svg>',
  grip:'<svg viewBox="0 0 24 24" fill="currentColor"><circle cx="9" cy="6" r="1.4"/><circle cx="15" cy="6" r="1.4"/><circle cx="9" cy="12" r="1.4"/><circle cx="15" cy="12" r="1.4"/><circle cx="9" cy="18" r="1.4"/><circle cx="15" cy="18" r="1.4"/></svg>',
  plus:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>',
  up:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="m6 14 6-6 6 6"/></svg>',
  down:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="m6 10 6 6 6-6"/></svg>',
  file:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M6 3h8l5 5v13H6z"/><path d="M14 3v5h5"/></svg>',
  zip:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="4" width="16" height="16" rx="2"/><path d="M12 4v3m0 2v2m0 2v2"/></svg>',
  image:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="8.5" cy="9.5" r="1.6"/><path d="m3 17 5-4.5 4.5 4L17 13l4 3.5"/></svg>',
  minus:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M5 12h14"/></svg>',
};
function icon(name, cls) {
  const s = document.createElement("span");
  if (cls) s.className = cls;
  s.style.display = "inline-flex";
  s.innerHTML = ICONS[name] || "";
  return s;
}

/* ---------------- dom helper ---------------- */
function h(tag, attrs, ...children) {
  const el = document.createElement(tag);
  if (attrs) for (const k in attrs) {
    const v = attrs[k];
    if (v == null) continue;
    if (k === "class") el.className = v;
    else if (k === "style") el.style.cssText = v;
    else if (k.startsWith("on")) el.addEventListener(k.slice(2), v);
    else if (k === "html") el.innerHTML = v;
    else el.setAttribute(k, v);
  }
  for (const c of children.flat(9)) {
    if (c == null || c === false) continue;
    el.append(c.nodeType ? c : document.createTextNode(c));
  }
  return el;
}

/* ---------------- toasts ---------------- */
const toastHost = h("div", { class: "toasts" });
let lastToast = { msg: "", t: 0 };
function toast(msg, kind, ms) {
  const now = Date.now();
  if (msg === lastToast.msg && now - lastToast.t < 1500) return;
  lastToast = { msg, t: now };
  const el = h("div", { class: "toast" + (kind === "err" ? " err" : "") }, msg);
  toastHost.append(el);
  setTimeout(() => { el.style.opacity = "0"; el.style.transition = "opacity 250ms"; setTimeout(() => el.remove(), 300); }, ms || (kind === "err" ? 5200 : 3200));
}

/* ---------------- modal ---------------- */
function showModal({ title, body, actions, dismissable = true }) {
  const wrap = h("div", { class: "modal-wrap" });
  const close = () => wrap.remove();
  const m = h("div", { class: "modal" },
    h("h3", null, title),
    body,
    actions ? h("div", { class: "mrow" }, actions.map(a =>
      h("button", { class: "btn " + (a.primary ? "primary" : "secondary"), onclick: () => a.onClick(close) }, a.label))) : null,
  );
  if (dismissable) wrap.addEventListener("click", e => { if (e.target === wrap) close(); });
  wrap.append(m);
  document.body.append(wrap);
  return close;
}
function passwordPrompt(filename, wrong) {
  return new Promise(resolve => {
    const input = h("input", { type: "password", placeholder: "Password", autofocus: "" });
    const done = (val, close) => { close(); resolve(val); };
    const close = showModal({
      title: "Password required",
      dismissable: false,
      body: h("div", null,
        h("p", null, wrong ? "That password didn't work. Try again for " : "Enter the password to open ", h("b", null, filename), "."),
        input),
      actions: [
        { label: "Cancel", onClick: c => done(null, c) },
        { label: "Open", primary: true, onClick: c => done(input.value, c) },
      ],
    });
    input.addEventListener("keydown", e => { if (e.key === "Enter") done(input.value, close); });
    setTimeout(() => input.focus(), 30);
  });
}

/* ---------------- pdf.js plumbing ---------------- */
const openDocs = new Set();
async function openPdf(rec) {
  const task = pdfjsLib.getDocument({
    data: new Uint8Array(rec.buf.slice(0)),
    isEvalSupported: false,
    disableFontFace: false,
  });
  let attempts = 0;
  task.onPassword = async (updatePassword, reason) => {
    const pw = await passwordPrompt(rec.name, reason === 2 || attempts > 0);
    attempts++;
    if (pw == null) { task.destroy(); return; }
    updatePassword(pw);
  };
  const doc = await task.promise;
  openDocs.add(doc);
  return doc;
}
function closePdf(doc) {
  if (!doc) return;
  try { doc.destroy(); } catch (e) {}
  openDocs.delete(doc);
}
async function renderPageToCanvas(doc, pageNo, targetDim, opts) {
  const page = await doc.getPage(pageNo);
  const base = page.getViewport({ scale: 1 });
  let scale;
  if (opts && opts.dpi) scale = opts.dpi / 72;
  else scale = targetDim / Math.max(base.width, base.height);
  const capped = Math.min(scale, 8000 / Math.max(base.width, base.height));
  const vp = page.getViewport({ scale: capped });
  const canvas = document.createElement("canvas");
  canvas.width = Math.max(1, Math.round(vp.width));
  canvas.height = Math.max(1, Math.round(vp.height));
  const ctx = canvas.getContext("2d", { alpha: false });
  ctx.fillStyle = "#ffffff";
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  await page.render({ canvasContext: ctx, viewport: vp }).promise;
  return { canvas, cssW: vp.width, cssH: vp.height, capped: capped < scale - 1e-9 };
}

/* sequential thumbnail queue */
class ThumbQueue {
  constructor(doc) { this.doc = doc; this.q = []; this.busy = false; this.dead = false; this.cache = new Map(); }
  render(pageNo, dim = 300) {
    if (this.cache.has(pageNo)) return Promise.resolve(this.cache.get(pageNo));
    return new Promise((resolve, reject) => {
      this.q.push({ pageNo, dim, resolve, reject });
      this.pump();
    });
  }
  async pump() {
    if (this.busy || this.dead) return;
    const job = this.q.shift();
    if (!job) return;
    this.busy = true;
    try {
      const { canvas } = await renderPageToCanvas(this.doc, job.pageNo, job.dim);
      this.cache.set(job.pageNo, canvas);
      job.resolve(canvas);
    } catch (e) { job.reject(e); }
    this.busy = false;
    if (!this.dead) this.pump();
  }
  kill() { this.dead = true; this.q.length = 0; }
}

/* ---------------- files ---------------- */
async function readFileRec(file) {
  const buf = await file.arrayBuffer();
  return { name: file.name, size: file.size, buf };
}
function bytesOf(rec) { return new Uint8Array(rec.buf.slice(0)); }
const heldUrls = [];
function downloadBytes(name, bytes, mime) {
  const blob = bytes instanceof Blob ? bytes : new Blob([bytes], { type: mime || "application/octet-stream" });
  const url = URL.createObjectURL(blob);
  heldUrls.push(url);
  const a = h("a", { href: url, download: name, style: "display:none" });
  document.body.append(a);
  a.click();
  setTimeout(() => { a.remove(); }, 1000);
  setTimeout(() => { try { URL.revokeObjectURL(url); } catch (e) {} }, 60000);
  return blob.size;
}
function isPdfFile(f) { return /\.pdf$/i.test(f.name) || f.type === "application/pdf"; }
function isImgFile(f) { return /\.(png|jpe?g|webp|gif|bmp|avif)$/i.test(f.name) || /^image\//.test(f.type); }
const BIG_WARN = 120 * 1024 * 1024;

/* dropzone component */
const DROP_ACCEPTS = {
  pdf: { test: isPdfFile, attr: "application/pdf,.pdf", msg: "not a PDF" },
  image: { test: isImgFile, attr: "image/*,.png,.jpg,.jpeg,.webp,.gif,.bmp,.avif", msg: "not an image" },
  docx: { test: f => /\.docx$/i.test(f.name), attr: ".docx,application/vnd.openxmlformats-officedocument.wordprocessingml.document", msg: "not a .docx file" },
  text: { test: f => /\.(txt|md|markdown|text)$/i.test(f.name) || f.type === "text/plain", attr: ".txt,.md,.markdown,text/plain", msg: "not a text file" },
};
function makeDrop({ accept = "pdf", multiple = false, big, sub, compact, onFiles }) {
  const spec = DROP_ACCEPTS[accept] || DROP_ACCEPTS.pdf;
  const test = spec.test;
  const acceptAttr = spec.attr;
  const input = h("input", { type: "file", accept: acceptAttr, style: "display:none" });
  if (multiple) input.setAttribute("multiple", "");
  const el = h("div", { class: "drop" + (compact ? " compact" : "") },
    icon("drop"),
    h("div", null,
      h("div", { class: "big" }, big || (multiple ? "Drop files here" : "Drop a file here")),
      h("div", { class: "sub" }, sub || "or click to browse. Files never leave this device.")),
    input);
  const handle = async fl => {
    const files = Array.from(fl).filter(test);
    const rejected = fl.length - files.length;
    if (rejected > 0) toast(rejected + " file(s) skipped: " + spec.msg, "err");
    if (!files.length) return;
    for (const f of files) if (f.size > BIG_WARN) toast(f.name + " is large. Processing may take a while.");
    const recs = [];
    for (const f of files) recs.push(await readFileRec(f));
    onFiles(multiple ? recs : recs.slice(0, 1));
  };
  el.addEventListener("click", e => { if (e.target !== input) input.click(); });
  input.addEventListener("change", () => { if (input.files.length) { handle(input.files); input.value = ""; } });
  ["dragover", "dragenter"].forEach(t => el.addEventListener(t, e => { e.preventDefault(); e.stopPropagation(); el.classList.add("over"); }));
  ["dragleave", "drop"].forEach(t => el.addEventListener(t, e => { e.preventDefault(); e.stopPropagation(); el.classList.remove("over"); }));
  el.addEventListener("drop", e => { if (e.dataTransfer.files.length) handle(e.dataTransfer.files); });
  return el;
}

/* ---------------- small controls ---------------- */
function segmented(options, value, onChange) {
  const el = h("div", { class: "seg" });
  const btns = new Map();
  const set = v => { value = v; btns.forEach((b, bv) => b.classList.toggle("on", bv === v)); };
  for (const o of options) {
    const b = h("button", { type: "button", onclick: () => { set(o.v); onChange && onChange(o.v); } }, o.label);
    btns.set(o.v, b);
    el.append(b);
  }
  set(value);
  return { el, get: () => value, set };
}
function posGrid(value, onChange) {
  const cells = ["tl","tc","tr","ml","mc","mr","bl","bc","br"];
  const el = h("div", { class: "posgrid" });
  const btns = new Map();
  const set = v => { value = v; btns.forEach((b, bv) => b.classList.toggle("on", bv === v)); };
  for (const c of cells) {
    const b = h("button", { type: "button", title: c, "aria-label": "position " + c, onclick: () => { set(c); onChange && onChange(c); } });
    btns.set(c, b);
    el.append(b);
  }
  set(value);
  return { el, get: () => value, set };
}
function slider(min, max, step, value, fmt, onChange) {
  const val = h("span", { class: "rangeval" }, fmt(value));
  const input = h("input", { type: "range", min, max, step, value });
  input.addEventListener("input", () => { val.textContent = fmt(+input.value); onChange && onChange(+input.value); });
  return { el: h("div", { class: "field" }, input, val), get: () => +input.value, set: v => { input.value = v; val.textContent = fmt(v); } };
}
function checkbox(label, checked, onChange) {
  const input = h("input", { type: "checkbox" });
  input.checked = !!checked;
  input.addEventListener("change", () => onChange && onChange(input.checked));
  const el = h("label", { class: "check" }, input, h("span", { class: "box" }, icon("check")), h("span", null, label));
  return { el, get: () => input.checked, set: v => { input.checked = v; } };
}
function swatches(colors, value, onChange) {
  const el = h("div", { class: "swatches" });
  const btns = [];
  const custom = h("input", { type: "color", value: colors.includes(value) ? "#888888" : value, title: "Custom color" });
  const set = v => { value = v; btns.forEach(b => b.classList.toggle("on", b.dataset.c === v)); };
  for (const c of colors) {
    const b = h("button", { type: "button", "data-c": c, style: "background:" + c, title: c, onclick: () => { set(c); onChange && onChange(c); } });
    btns.push(b); el.append(b);
  }
  custom.addEventListener("input", () => { set("__custom"); onChange && onChange(custom.value); });
  el.append(custom);
  set(value);
  return { el, get: () => (value === "__custom" ? custom.value : value) };
}
function optSection(label, ...rows) {
  return h("div", { class: "opt-section" }, h("div", { class: "opt-label" }, label), ...rows);
}

/* ---------------- progress / results ---------------- */
function progressPanel(label) {
  const fill = h("div", { class: "fill" });
  const left = h("span", null, label || "Working");
  const right = h("span", null, "");
  const el = h("div", { class: "progress" }, h("div", { class: "bar" }, fill), h("div", { class: "stat" }, left, right));
  return {
    el,
    set(frac, text, rightText) {
      fill.style.width = Math.round(Math.min(1, Math.max(0, frac)) * 100) + "%";
      if (text != null) left.textContent = text;
      if (rightText != null) right.textContent = rightText;
    },
  };
}

/* files: [{name, bytes, mime}] ; opts: {title, meta, deltaText, deltaGood, zipName} */
function resultScreen(container, files, opts, onAgain) {
  container.innerHTML = "";
  opts = opts || {};
  const multi = files.length > 1;
  let primaryAction, fileList = null;
  if (multi) {
    const zipName = opts.zipName || "pdfdesk-output.zip";
    primaryAction = () => {
      const bytes = PDCore.zipStore(files.map(f => ({ name: f.name, data: f.bytes })));
      downloadBytes(zipName, bytes, "application/zip");
    };
    fileList = h("div", { class: "files" }, files.map(f =>
      h("button", { onclick: () => downloadBytes(f.name, f.bytes, f.mime) },
        icon("file"), h("span", { style: "min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" }, f.name),
        h("span", { class: "sz" }, PDCore.fmtBytes(f.bytes.length)))));
  } else {
    primaryAction = () => downloadBytes(files[0].name, files[0].bytes, files[0].mime);
  }
  const el = h("div", { class: "result" },
    h("div", { class: "ok-ring" }, icon("check")),
    h("h2", null, opts.title || "Done"),
    h("div", { class: "rmeta" },
      multi
        ? h("span", null, files.length + " files · " + PDCore.fmtBytes(files.reduce((a, f) => a + f.bytes.length, 0)))
        : h("span", null, h("span", { class: "strong" }, files[0].name), " · " + PDCore.fmtBytes(files[0].bytes.length))),
    opts.meta ? h("div", { class: "rmeta" }, opts.meta) : null,
    opts.deltaText ? h("div", { class: "delta " + (opts.deltaGood ? "good" : "bad") }, opts.deltaText) : null,
    h("div", { class: "btns" },
      h("button", { class: "btn primary", onclick: primaryAction }, icon("download"), multi ? "Download all (ZIP)" : "Download"),
      h("button", { class: "btn secondary", onclick: onAgain }, "Run again"),
      h("button", { class: "btn secondary", onclick: () => showView("home") }, "Done"),
      (files.length === 1 && files[0].mime === "application/pdf")
        ? h("button", { class: "btn secondary", onclick: () => {
            const b = files[0].bytes;
            setWorkspaceFile({ name: files[0].name, size: b.length, buf: b.slice().buffer });
            toast("Now working on " + files[0].name);
          } }, "Continue with this result")
        : null),
    fileList);
  container.append(el);
  primaryAction(); // auto-download once
  toast(multi ? "ZIP download started" : "Download started");
}

function errorBack(container, err, onRetry) {
  container.innerHTML = "";
  container.append(h("div", { class: "result" },
    h("div", { class: "ok-ring", style: "background:var(--err-soft);color:var(--err)" }, icon("close")),
    h("h2", null, "That didn't work"),
    h("div", { class: "rmeta", style: "max-width:52ch;margin:0 auto" }, String(err && err.message || err)),
    h("div", { class: "btns" },
      h("button", { class: "btn primary", onclick: onRetry }, "Try again"),
      h("button", { class: "btn secondary", onclick: () => showView("home") }, "Done"))));
}

/* action bar */
function actionBar(summaryText, buttonLabel, onClick) {
  const summary = h("div", { class: "summary" }, summaryText || "");
  const btn = h("button", { class: "btn primary", disabled: "", onclick: () => onClick() }, buttonLabel);
  const el = h("div", { class: "actionbar" }, h("div", { class: "inner" }, summary, h("div", { class: "spacer" }), btn));
  return {
    el, btn,
    setSummary: t => { summary.textContent = t; },
    enable: on => { if (on) btn.removeAttribute("disabled"); else btn.setAttribute("disabled", ""); },
    setLabel: t => { btn.textContent = t; },
  };
}

/* ---------------- lazy engines (restored: lost in the v3 shell rewrite) ---------------- */
function b64ToBytes(b64) {
  const bin = atob(b64);
  const u = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
  return u;
}
function b64ToText(b64) { return new TextDecoder().decode(b64ToBytes(b64)); }
const ASSETS = () => (window.PD_ASSETS || {});

let _mupdfPromise = null;
function loadMuPDF() {
  if (_mupdfPromise) return _mupdfPromise;
  _mupdfPromise = (async () => {
    const A = ASSETS();
    if (!A.mupdfWasm || typeof window.__mupdfFactory !== "function")
      throw new Error("The MuPDF engine isn't embedded in this build.");
    globalThis["$libmupdf_wasm_Module"] = { wasmBinary: b64ToBytes(A.mupdfWasm), locateFile: f => f };
    const timeout = new Promise((_, rej) => setTimeout(() => rej(new Error("MuPDF engine took too long to start (60s). This browser may block WebAssembly here.")), 60000));
    return await Promise.race([window.__mupdfFactory(), timeout]);
  })();
  _mupdfPromise.catch(() => { _mupdfPromise = null; });
  return _mupdfPromise;
}
function mupdfOpen(mupdf, bytes) {
  return mupdf.Document.openDocument(bytes, "application/pdf");
}

const TESS_SHIM = '(function(){\n' +
  'var dec=function(b){var s=atob(b),u=new Uint8Array(s.length);for(var i=0;i<s.length;i++)u[i]=s.charCodeAt(i);return u;};\n' +
  'var of_=self.fetch?self.fetch.bind(self):null;\n' +
  'self.fetch=function(u){var m=String(u).match(/([A-Za-z_\\-]+)\\.traineddata(\\.gz)?$/);if(m&&self.PD_LANGS&&self.PD_LANGS[m[1]])return Promise.resolve(new Response(dec(self.PD_LANGS[m[1]]).buffer));return of_?of_.apply(self,arguments):Promise.reject(new Error("offline"));};\n' +
  'var oi_=self.importScripts?self.importScripts.bind(self):null;\n' +
  'self.importScripts=function(){var a=Array.prototype.filter.call(arguments,function(u){return !/tesseract-core/.test(String(u));});if(a.length&&oi_)oi_.apply(self,a);};\n' +
  '})();\n';

let _tessWorkerURL = null;
function tessWorkerURL() {
  if (_tessWorkerURL) return _tessWorkerURL;
  const A = ASSETS();
  if (!A.tessWorker || !A.tessCore) throw new Error("The OCR engine isn't embedded in this build.");
  const parts = [
    "self.PD_LANGS=" + JSON.stringify(A.langs || {}) + ";\n",
    TESS_SHIM,
    b64ToText(A.tessCore), "\n;\n",
    b64ToText(A.tessWorker),
  ];
  _tessWorkerURL = URL.createObjectURL(new Blob(parts, { type: "text/javascript" }));
  return _tessWorkerURL;
}
async function createTessWorker(langs, logger) {
  if (typeof Tesseract === "undefined") throw new Error("The OCR engine isn't embedded in this build.");
  return await Tesseract.createWorker(langs, 1, {
    workerPath: tessWorkerURL(),
    workerBlobURL: false,
    corePath: "tesseract-core-inline.js",
    langPath: "pdfdesk-inline",
    gzip: false,
    cacheMethod: "none",
    logger,
  });
}
const LANG_NAMES = { eng: "English", ara: "Arabic", hin: "Hindi", urd: "Urdu", fra: "French", deu: "German", spa: "Spanish", ita: "Italian", por: "Portuguese", rus: "Russian", tur: "Turkish", nld: "Dutch", pol: "Polish", chi_sim: "Chinese (simplified)", chi_tra: "Chinese (traditional)", jpn: "Japanese", kor: "Korean", mal: "Malayalam", tam: "Tamil", tel: "Telugu", ben: "Bengali", fas: "Persian" };
const LATIN_LANGS = new Set(["eng", "fra", "deu", "spa", "ita", "por", "nld", "pol", "tur"]);

/* ---------------- shell / router (Acrobat-style workspace) ---------------- */
const VIEWS = {};           // id -> {name, desc, group, hint, icon, build}
let currentView = null;
let workspace = null;       // the open FileRec
const viewRoot = h("div");
let sideFileBox = null, sideNav = null;

function registerTool(def) { VIEWS[def.id] = def; }

function showView(id, preloadOverride) {
  if (id === "home") id = workspace ? "view" : "welcome";
  if (currentView && currentView.cleanup) { try { currentView.cleanup(); } catch (e) {} }
  document.querySelectorAll(".actionbar").forEach(e => e.remove());
  document.querySelectorAll(".modal-wrap").forEach(e => e.remove());
  viewRoot.innerHTML = "";
  window.scrollTo(0, 0);
  markActive(id);
  if (id === "welcome") { currentView = { id }; buildWelcome(viewRoot); return; }
  const def = VIEWS[id];
  if (!def) return;
  const preload = preloadOverride !== undefined ? preloadOverride
    : (def.acceptsPdf === false ? null : workspace);
  const wrap = h("div", { class: "view" });
  const head = h("div", { class: "tool-head" },
    h("h1", null, def.name),
    def.hint ? h("div", { class: "hint" }, def.hint) : null);
  const body = h("div", { class: "tool-body" });
  wrap.append(head, body);
  viewRoot.append(wrap);
  currentView = { id, cleanup: null };
  const ctx = {
    body,
    setCleanup: fn => { if (currentView && currentView.id === id) currentView.cleanup = fn; },
    preload,
    restart: () => showView(id),
  };
  def.build(ctx);
}

const TOOL_GROUPS = [
  { name: "View & edit", ids: ["view", "edit", "sign", "forms", "watermark", "numbers"] },
  { name: "Pages", ids: ["organize", "merge", "split", "extract", "delete", "rotate", "crop"] },
  { name: "Convert", ids: ["toword", "totext", "fromword", "fromtxt", "img2pdf", "pdf2img", "ocr"] },
  { name: "Secure & optimize", ids: ["protect", "unlock", "compress", "flatten", "repair"] },
];

/* ---- workspace file ---- */
function setWorkspaceFile(rec, goto) {
  workspace = rec;
  renderSideFile();
  refreshNavDisabled();
  showView(goto || "view");
}
const pickerInput = h("input", { type: "file", accept: "application/pdf,.pdf", style: "display:none" });
pickerInput.addEventListener("change", async () => {
  const f = pickerInput.files[0];
  pickerInput.value = "";
  if (!f) return;
  if (!isPdfFile(f)) { toast("That doesn't look like a PDF", "err"); return; }
  if (f.size > BIG_WARN) toast(f.name + " is large. Processing may take a while.");
  setWorkspaceFile(await readFileRec(f));
});
function openPicker() { pickerInput.click(); }

/* ---- sidebar ---- */
function buildSidebar() {
  sideFileBox = h("div");
  sideNav = h("nav", { class: "side-nav" });
  for (const g of TOOL_GROUPS) {
    sideNav.append(h("div", { class: "side-group" }, g.name));
    for (const tid of g.ids) {
      const t = VIEWS[tid];
      if (!t) continue;
      const b = h("button", { class: "side-item", "data-tool": tid, title: t.name + " — " + t.desc },
        h("span", { class: "si-ico" }, icon(t.icon)), h("span", { class: "label" }, t.name));
      b.addEventListener("click", () => { if (!b.disabled) showView(tid); });
      sideNav.append(b);
    }
  }
  const aside = h("aside", { class: "side" },
    h("div", { class: "side-brand" },
      h("span", { class: "brand-mark" }, icon("logo")),
      h("span", { class: "brand-name" }, "PDFDesk")),
    sideFileBox, sideNav,
    h("div", { class: "side-foot" },
      h("div", { class: "offline-badge" }, h("span", { class: "dot" }), h("span", null, "Offline · files stay here")),
      h("div", { class: "links" },
        h("button", { onclick: runSelfTestUI }, "Self-test"),
        h("button", { onclick: showAbout }, "About"),
        h("span", null, "v3.2"))));
  renderSideFile();
  refreshNavDisabled();
  return aside;
}
function renderSideFile() {
  if (!sideFileBox) return;
  sideFileBox.innerHTML = "";
  if (workspace) {
    sideFileBox.append(h("div", { class: "side-file" },
      h("div", { class: "fname", title: workspace.name }, workspace.name),
      h("div", { class: "fmeta" }, PDCore.fmtBytes(workspace.size)),
      h("button", { class: "btn secondary", onclick: openPicker }, "Open another PDF")));
  } else {
    sideFileBox.append(h("div", { class: "side-file empty", onclick: openPicker }, "Open a PDF to begin"));
  }
}
function refreshNavDisabled() {
  if (!sideNav) return;
  sideNav.querySelectorAll(".side-item").forEach(b => {
    const t = VIEWS[b.dataset.tool];
    const needsPdf = !t || t.acceptsPdf !== false;
    b.disabled = needsPdf && !workspace && !t.standalone;
  });
}
function markActive(id) {
  if (sideNav) sideNav.querySelectorAll(".side-item").forEach(b => b.classList.toggle("on", b.dataset.tool === id));
}

/* ---- welcome ---- */
function buildWelcome(root) {
  const drop = makeDrop({ big: "Drop a PDF here", sub: "or click to browse. Files never leave this device.", onFiles: ([r]) => setWorkspaceFile(r) });
  root.append(h("div", { class: "welcome" },
    h("h1", null, "Open a PDF to get started"),
    h("p", null, "View, edit, organize, compress, protect and OCR — entirely offline in this window. Once a file is open, every tool in the sidebar works on it."),
    drop,
    h("div", { class: "alt" }, "No PDF yet? ",
      h("button", { onclick: () => showView("img2pdf") }, "Build one from images"),
      workspace ? h("span", null, " · ", h("button", { onclick: () => showView("view") }, "Back to current file")) : null)));
}

function showAbout() {
  showModal({
    title: "PDFDesk",
    body: h("div", { class: "licenses" },
      h("p", null, "A fully offline PDF workbench. This one file contains the whole app. Your documents are processed in this browser window and never leave your device."),
      h("p", null, h("b", null, "Share it:"), " send this HTML file to anyone. It works on Windows, macOS and Linux in Chrome, Edge, Firefox or Safari."),
      h("p", null, h("b", null, "Open-source engines inside:")),
      h("p", null, h("b", null, "PDF.js"), " (Mozilla, Apache-2.0) renders pages. ", h("b", null, "pdf-lib"), " (MIT) writes and restructures PDFs. ", h("b", null, "MuPDF"), " (Artifex, AGPL-3.0) powers editing, protect, unlock and repair. ", h("b", null, "Tesseract"), " (Apache-2.0) powers OCR. UI and everything else written for PDFDesk.")),
    actions: [{ label: "Close", primary: true, onClick: c => c() }],
  });
}

/* ---- global drop: opens/replaces the workspace file ---- */
function setupGlobalDrop() {
  const overlay = h("div", { class: "drag-overlay" }, h("div", { class: "frame" }), h("div", { class: "msg" }, "Drop to open in PDFDesk"));
  document.body.append(overlay);
  let depth = 0;
  window.addEventListener("dragenter", e => {
    if (!e.dataTransfer || !Array.from(e.dataTransfer.types).includes("Files")) return;
    if (e.target && e.target.closest && e.target.closest(".drop")) return;
    depth++;
    overlay.classList.add("on");
  });
  window.addEventListener("dragleave", () => { depth = Math.max(0, depth - 1); if (!depth) overlay.classList.remove("on"); });
  window.addEventListener("dragover", e => { if (overlay.classList.contains("on")) e.preventDefault(); });
  window.addEventListener("drop", async e => {
    if (!overlay.classList.contains("on")) return;
    e.preventDefault();
    depth = 0;
    overlay.classList.remove("on");
    const pdfs = Array.from(e.dataTransfer.files).filter(isPdfFile);
    if (!pdfs.length) { toast("That doesn't look like a PDF", "err"); return; }
    const recs = [];
    for (const f of pdfs) recs.push(await readFileRec(f));
    if (recs.length === 1) {
      setWorkspaceFile(recs[0]);
      toast("Opened " + recs[0].name);
      return;
    }
    showModal({
      title: recs.length + " PDFs dropped",
      body: h("p", null, "Merge them into one document, or open just the first one (" + recs[0].name + ")?"),
      actions: [
        { label: "Open first", onClick: c => { c(); setWorkspaceFile(recs[0]); } },
        { label: "Merge all " + recs.length, primary: true, onClick: c => { c(); showView("merge", recs); } },
      ],
    });
  });
}

/* ---------------- error surface ---------------- */
window.addEventListener("unhandledrejection", e => {
  const m = String(e.reason && e.reason.message || e.reason || "Unexpected error");
  if (/password/i.test(m)) return; // cancelled password prompt
  toast(m, "err");
});

/* ---------------- self test ---------------- */
async function runSelfTest() {
  const results = [];
  const t = async (name, fn) => {
    try { await fn(); results.push({ name, ok: true }); }
    catch (e) { results.push({ name, ok: false, err: String(e && e.message || e) }); }
  };
  const { PDFDocument, StandardFonts, rgb } = PDFLib;

  async function samplePdf(pages, big) {
    const d = await PDFDocument.create();
    const font = await d.embedFont(StandardFonts.Helvetica);
    for (let i = 0; i < pages; i++) {
      const p = d.addPage([595.28, 841.89]);
      p.drawText("Sample page " + (i + 1), { x: 60, y: 760, size: 28, font, color: rgb(0.15, 0.15, 0.2) });
      if (big) for (let k = 0; k < 40; k++)
        p.drawText("Lorem ipsum dolor sit amet " + k, { x: 60, y: 700 - k * 16, size: 11, font });
    }
    return await d.save();
  }

  let s5, s3;
  await t("pdf-lib creates documents", async () => {
    s5 = await samplePdf(5); s3 = await samplePdf(3);
    if (s5.length < 500) throw new Error("too small");
  });
  await t("merge 5+3 pages", async () => {
    const out = await PDCore.mergePdfs([s5, s3], [null, null]);
    const d = await PDFDocument.load(out);
    if (d.getPageCount() !== 8) throw new Error("got " + d.getPageCount());
  });
  await t("merge with ranges", async () => {
    const out = await PDCore.mergePdfs([s5, s3], ["1-2", "3"]);
    const d = await PDFDocument.load(out);
    if (d.getPageCount() !== 3) throw new Error("got " + d.getPageCount());
  });
  await t("split into groups", async () => {
    const groups = PDCore.parseRangeGroups("1-2,3-5", 5);
    const outs = await PDCore.splitPdf(s5, groups);
    if (outs.length !== 2) throw new Error("files " + outs.length);
    const d = await PDFDocument.load(outs[1]);
    if (d.getPageCount() !== 3) throw new Error("pages " + d.getPageCount());
  });
  await t("extract pages", async () => {
    const out = await PDCore.extractPages(s5, [0, 2, 4]);
    const d = await PDFDocument.load(out);
    if (d.getPageCount() !== 3) throw new Error("got " + d.getPageCount());
  });
  await t("rotate pages", async () => {
    const out = await PDCore.rotatePdf(s5, [0, 1], 90);
    const d = await PDFDocument.load(out);
    if (d.getPage(0).getRotation().angle % 360 !== 90) throw new Error("rot " + d.getPage(0).getRotation().angle);
    if (d.getPage(2).getRotation().angle % 360 !== 0) throw new Error("page3 rotated");
  });
  await t("organize reorder+delete", async () => {
    const out = await PDCore.organizePdf(s5, [{ srcIdx: 4 }, { srcIdx: 0, rotDelta: 180 }]);
    const d = await PDFDocument.load(out);
    if (d.getPageCount() !== 2) throw new Error("count");
    if (d.getPage(1).getRotation().angle % 360 !== 180) throw new Error("rot");
  });
  await t("page numbers", async () => {
    const out = await PDCore.addPageNumbers(s3, { pos: "bc", format: "pnt", size: 11, margin: "md" });
    if (out.length <= s3.length * 0.5) throw new Error("suspicious size");
    await PDFDocument.load(out);
  });
  await t("text watermark (tiled)", async () => {
    const out = await PDCore.addTextWatermark(s3, { text: "CONFIDENTIAL", tile: true, size: 48, opacity: 0.2, angle: -45 });
    await PDFDocument.load(out);
  });
  await t("range parser edge cases", async () => {
    const g = PDCore.parseRangeGroups("3-1, 5, 4-", 5);
    if (JSON.stringify(g) !== JSON.stringify([[2, 1, 0], [4], [3, 4]])) throw new Error(JSON.stringify(g));
    let threw = false;
    try { PDCore.parsePageSet("9", 5); } catch (e) { threw = e.code === "RANGE"; }
    if (!threw) throw new Error("no range error");
  });
  await t("zip writer", async () => {
    const z = PDCore.zipStore([{ name: "a.txt", data: new TextEncoder().encode("hello") }, { name: "b/c.pdf", data: s3 }]);
    const dv = new DataView(z.buffer, z.byteLength - 22, 22);
    if (dv.getUint32(0, true) !== 0x06054b50) throw new Error("no EOCD");
  });
  await t("pdf.js renders a page", async () => {
    const doc = await pdfjsLib.getDocument({ data: new Uint8Array(s3.slice(0)) }).promise;
    const page = await doc.getPage(1);
    const vp = page.getViewport({ scale: 0.5 });
    const c = document.createElement("canvas");
    c.width = vp.width; c.height = vp.height;
    await page.render({ canvasContext: c.getContext("2d"), viewport: vp }).promise;
    const px = c.getContext("2d").getImageData(0, 0, c.width, c.height).data;
    let nonWhite = 0;
    for (let i = 0; i < px.length; i += 4) if (px[i] < 240) nonWhite++;
    if (nonWhite < 20) throw new Error("blank render");
    doc.destroy();
  });
  await t("compress rebuild pipeline", async () => {
    const doc = await pdfjsLib.getDocument({ data: new Uint8Array(s3.slice(0)) }).promise;
    const pages = [];
    for (let i = 1; i <= doc.numPages; i++) {
      const { canvas } = await renderPageToCanvas(doc, i, 0, { dpi: 72 });
      const blob = await new Promise(r => canvas.toBlob(r, "image/jpeg", 0.6));
      const jpeg = new Uint8Array(await blob.arrayBuffer());
      const page = await doc.getPage(i);
      const vp = page.getViewport({ scale: 1 });
      pages.push({ jpeg, wPt: vp.width, hPt: vp.height });
    }
    doc.destroy();
    const out = await PDCore.rebuildFromJpegs(pages);
    const d = await PDFDocument.load(out);
    if (d.getPageCount() !== 3) throw new Error("count");
  });
  await t("images to pdf", async () => {
    const c = document.createElement("canvas");
    c.width = 320; c.height = 200;
    const ctx = c.getContext("2d");
    ctx.fillStyle = "#dd4422"; ctx.fillRect(0, 0, 320, 200);
    ctx.fillStyle = "#ffffff"; ctx.fillRect(40, 40, 100, 60);
    const blob = await new Promise(r => c.toBlob(r, "image/png"));
    const bytes = new Uint8Array(await blob.arrayBuffer());
    const out = await PDCore.imagesToPdf([{ bytes, isPng: true, w: 320, h: 200 }], { pageSize: "a4", orient: "auto", marginPct: 3 });
    const d = await PDFDocument.load(out);
    if (d.getPageCount() !== 1) throw new Error("count");
  });
  /* ---- Phase 2 checks ---- */
  await t("form fill + flatten", async () => {
    const d = await PDFDocument.create();
    const page = d.addPage([400, 300]);
    const form = d.getForm();
    const tf = form.createTextField("who");
    tf.addToPage(page, { x: 40, y: 200, width: 200, height: 24 });
    const cb = form.createCheckBox("agree");
    cb.addToPage(page, { x: 40, y: 150, width: 18, height: 18 });
    const src = await d.save();
    const fields = await PDCore.listFormFields(src);
    if (fields.length !== 2) throw new Error("fields " + fields.length);
    const res = await PDCore.fillForm(src, [
      { name: "who", kind: "text", value: "Ameen" },
      { name: "agree", kind: "check", value: true },
    ], { flatten: false });
    if (res.problems.length) throw new Error(res.problems[0]);
    const back = await PDCore.listFormFields(res.bytes);
    if (back.find(f => f.name === "who").value !== "Ameen") throw new Error("value lost");
    const flat = await PDCore.fillForm(src, [{ name: "who", kind: "text", value: "X" }], { flatten: true });
    if ((await PDCore.listFormFields(flat.bytes)).length !== 0) throw new Error("not flattened");
  });
  await t("signature placement", async () => {
    const c = document.createElement("canvas");
    c.width = 200; c.height = 80;
    const m = c.getContext("2d");
    m.strokeStyle = "#1b2a52"; m.lineWidth = 3;
    m.beginPath(); m.moveTo(10, 60); m.bezierCurveTo(50, 10, 120, 70, 190, 20); m.stroke();
    const blob = await new Promise(r => c.toBlob(r, "image/png"));
    const png = new Uint8Array(await blob.arrayBuffer());
    const out = await PDCore.placeSignature(s3, png, true, { pageIdx: 0, cx: 400, cy: 150, wPt: 140, dateStr: "22 Aug 2026" });
    await PDFDocument.load(out);
  });
  await t("ocr overlay writer", async () => {
    const out = await PDCore.ocrOverlay(s3, [{ pageIdx: 0, dpi: 300, words: [
      { text: "Hello", x0: 100, y0: 100, x1: 400, y1: 160 },
      { text: "world", x0: 420, y0: 100, x1: 700, y1: 160 },
    ]}]);
    if (out.placed !== 2) throw new Error("placed " + out.placed);
    await PDFDocument.load(out.bytes);
  });
  if ((window.PD_ASSETS || {}).mupdfWasm) {
    await t("MuPDF: protect + unlock roundtrip", async () => {
      const mupdf = await loadMuPDF();
      const doc = mupdf.Document.openDocument(s3.slice(0), "application/pdf");
      const enc = doc.saveToBuffer("encrypt=aes-256,user-password=pw1,owner-password=pw2,permissions=-4").asUint8Array();
      const doc2 = mupdf.Document.openDocument(enc.slice(0), "application/pdf");
      if (!doc2.needsPassword()) throw new Error("not locked");
      if (doc2.authenticatePassword("pw1") === 0) throw new Error("auth failed");
      const dec = doc2.saveToBuffer("encrypt=none").asUint8Array();
      if ((await PDFDocument.load(dec)).getPageCount() !== 3) throw new Error("pages lost");
    });
    await t("MuPDF: repair truncated file", async () => {
      const mupdf = await loadMuPDF();
      const broken = s5.slice(0, s5.length - 300);
      const doc = mupdf.Document.openDocument(broken, "application/pdf");
      let out;
      try { out = doc.saveToBuffer("garbage=deduplicate,clean=yes,sanitize=yes").asUint8Array(); }
      catch (e) {
        const fresh = new mupdf.PDFDocument();
        let ok = 0;
        for (let i = 0; i < doc.countPages(); i++) { try { fresh.graftPage(ok, doc, i); ok++; } catch (err) {} }
        out = fresh.saveToBuffer("garbage=deduplicate,clean=yes").asUint8Array();
      }
      if ((await PDFDocument.load(out)).getPageCount() < 1) throw new Error("no pages");
    });
  } else {
    results.push({ name: "MuPDF checks skipped (engine not embedded)", ok: true });
  }
  await t("editor: overlay ops (shapes, text, note)", async () => {
    const res = await PDCore.applyOverlay(s3, [{ pageIdx: 0, ops: [
      { type: "whiteout", x: 50, y: 50, w: 200, h: 40 },
      { type: "highlight", x: 60, y: 120, w: 180, h: 20 },
      { type: "text", x: 60, y: 200, size: 16, text: "Editor test", family: "serif" },
      { type: "rect", x: 100, y: 300, w: 120, h: 60, stroke: "#c0392b", strokeW: 2 },
      { type: "line", x1: 60, y1: 400, x2: 300, y2: 440, stroke: "#333", strokeW: 2, arrow: true },
      { type: "note", x: 500, y: 60, text: "selftest note" },
    ]}]);
    if (res.problems.length) throw new Error(res.problems[0]);
    const d = await PDFDocument.load(res.bytes);
    const annots = d.getPage(0).node.lookup(PDFLib.PDFName.of("Annots"));
    if (!annots || annots.size() !== 1) throw new Error("note annotation missing");
  });
  if ((window.PD_ASSETS || {}).mupdfWasm) {
    await t("editor: in-place text replace (redact + retype)", async () => {
      const mupdf = await loadMuPDF();
      const dd = await PDFDocument.create();
      const f = await dd.embedFont(StandardFonts.Helvetica);
      const pp = dd.addPage([500, 400]);
      pp.drawText("Keep this", { x: 50, y: 300, size: 20, font: f });
      pp.drawText("Replace this", { x: 50, y: 250, size: 20, font: f });
      const src = await dd.save();
      const st = JSON.parse(mupdf.Document.openDocument(src.slice(0), "application/pdf").loadPage(0).toStructuredText().asJSON());
      const target = PDCore.parseStext(st).lines.find(l => /Replace/.test(l.text));
      if (!target) throw new Error("stext line not found");
      const redacted = PDCore.redactRegions(mupdf, src.slice(0), [{ pageIdx: 0, rects: [target], mode: "text" }]);
      const res = await PDCore.applyOverlay(redacted, [{ pageIdx: 0, ops: [
        { type: "editline", x: target.x, baseline: target.baseline, size: target.size, text: "New words", family: target.family },
      ]}]);
      const st2 = JSON.parse(mupdf.Document.openDocument(res.bytes.slice(0), "application/pdf").loadPage(0).toStructuredText().asJSON());
      const txt = PDCore.parseStext(st2).lines.map(l => l.text).join(" ");
      if (!/Keep this/.test(txt) || /Replace this/.test(txt) || !/New words/.test(txt))
        throw new Error("replace flow got: " + txt);
    });
  }
  await t("docx roundtrip + text layout (converters)", async () => {
    const docx = PDCore.buildDocx([[{ text: "Round trip", size: 14, bold: true }]]);
    const files = await PDCore.unzipBytes(docx);
    const paras = PDCore.docxParas(new TextDecoder().decode(files["word/document.xml"]));
    if (!/Round trip/.test(paras[0].text)) throw new Error("docx roundtrip lost text");
    const pdf = await PDCore.parasToPdf(paras);
    if ((await PDFDocument.load(pdf.bytes)).getPageCount() < 1) throw new Error("layout failed");
  });
  if ((window.PD_ASSETS || {}).tessCore && (window.PD_ASSETS.langs || {}).eng) {
    await t("OCR: recognizes rendered text", async () => {
      const c = document.createElement("canvas");
      c.width = 640; c.height = 200;
      const m = c.getContext("2d");
      m.fillStyle = "#fff"; m.fillRect(0, 0, 640, 200);
      m.fillStyle = "#111"; m.font = "bold 56px Arial";
      m.fillText("OPEN 42 NOW", 40, 120);
      const worker = await createTessWorker("eng", null);
      try {
        const res = await worker.recognize(c, {}, { text: true, tsv: true });
        if (!/OPEN/i.test(res.data.text)) throw new Error("read: " + (res.data.text || "").slice(0, 40));
      } finally { try { await worker.terminate(); } catch (e) {} }
    });
  } else {
    results.push({ name: "OCR check skipped (engine not embedded)", ok: true });
  }
  const pass = results.every(r => r.ok);
  return { pass, results };
}
window.PDSelfTest = runSelfTest;

async function runSelfTestUI() {
  const body = h("div", { class: "licenses" }, h("p", null, "Running checks…"));
  const close = showModal({ title: "Self-test", body, actions: [{ label: "Close", primary: true, onClick: c => c() }] });
  try {
    const { pass, results } = await runSelfTest();
    body.innerHTML = "";
    body.append(h("p", null, pass ? "All " + results.length + " checks passed. This copy is working correctly." : "Some checks failed:"));
    for (const r of results)
      body.append(h("p", { style: r.ok ? "" : "color:var(--err)" }, (r.ok ? "✓ " : "✗ ") + r.name + (r.err ? ": " + r.err : "")));
  } catch (e) {
    body.innerHTML = "";
    body.append(h("p", { style: "color:var(--err)" }, "Self-test crashed: " + (e && e.message || e)));
  }
}

/* ---------------- UI self-test (drives the real editor with synthetic events) ---------------- */
const UILOG = [];
window.addEventListener("error", e => UILOG.push("winerr:" + String(e.message).slice(0, 90)));
async function runUITest() {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const report = t => {
    document.title = t.slice(0, 480);
    let d = document.getElementById("pduitest");
    if (!d) {
      d = h("pre", { id: "pduitest", style: "position:fixed;bottom:0;left:0;right:0;z-index:999998;background:#10241a;color:#b8f2cf;margin:0;padding:10px 14px;font:12px/1.5 monospace;white-space:pre-wrap;max-height:40vh;overflow:auto" });
      document.body.append(d);
    }
    d.textContent = t;
    if (/FAIL|ERR/.test(t)) { d.style.background = "#2a1210"; d.style.color = "#f6c8c0"; }
  };
  const steps = [];
  const fail = (step, msg) => { report("UITEST:FAIL:" + step + ":" + String(msg).slice(0, 220) + "|LOG:" + UILOG.join(";").slice(0, 150) + "|STATE:" + (window.__edState ? window.__edState() : "?")); };
  const pe = (el, type, x, y, opts) => el.dispatchEvent(new PointerEvent(type, Object.assign({
    bubbles: true, cancelable: true, clientX: x, clientY: y, pointerId: 1, isPrimary: true, button: 0, pointerType: "mouse",
  }, opts)));
  try {
    // 1. build a sample pdf and open it
    const d = await PDFLib.PDFDocument.create();
    const f = await d.embedFont(PDFLib.StandardFonts.Helvetica);
    const p = d.addPage([595, 842]);
    p.drawText("Heading text here", { x: 60, y: 760, size: 24, font: f });
    p.drawText("Body line for retyping.", { x: 60, y: 700, size: 12, font: f });
    const bytes = await d.save();
    setWorkspaceFile({ name: "uitest.pdf", size: bytes.length, buf: bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength) }, "edit");
    steps.push("open");
    // 2. wait for editor stage render
    let stage = null;
    for (let i = 0; i < 60 && !stage; i++) { await sleep(200); stage = document.querySelector(".ed-stage canvas.pagecanvas"); if (stage && stage.width < 10) stage = null; }
    if (!stage) return fail("stage", "editor canvas never rendered");
    const stEl = document.querySelector(".ed-stage");
    steps.push("stage");
    // 3. add text: click the mode button, then click the page
    const btn = Array.from(document.querySelectorAll(".ed-tool")).find(b => b.title === "Add text");
    if (!btn) return fail("addtext-btn", "mode button missing");
    btn.click();
    await sleep(100);
    const r = stEl.getBoundingClientRect();
    const cx = r.left + r.width * 0.4, cy = r.top + r.height * 0.4;
    pe(stEl, "pointerdown", cx, cy);
    pe(window, "pointerup", cx, cy);
    await sleep(250);
    const tobj = document.querySelector(".ed-obj.textobj");
    if (!tobj) return fail("addtext-create", "no text object appeared after click");
    if (!tobj.isContentEditable) return fail("addtext-edit", "text object not editable (focus flow broke)");
    if (document.activeElement !== tobj) return fail("addtext-focus", "editable box did not receive focus; active=" + (document.activeElement && document.activeElement.tagName));
    steps.push("addtext-open");
    // 4. type into it (execCommand fires real input events, like typing) and commit
    document.execCommand("insertText", false, "Hello from UI test");
    tobj.blur();
    await sleep(250);
    const persisted = Array.from(document.querySelectorAll(".ed-obj.textobj")).find(e => /Hello from UI test/.test(e.textContent));
    if (!persisted) return fail("addtext-commit", "typed text did not persist after blur");
    steps.push("addtext-commit");
    // 5. select + drag it (re-query AFTER mode switch: renders replace nodes)
    const selBtn = Array.from(document.querySelectorAll(".ed-tool")).find(b => b.title === "Select & move");
    selBtn.click(); await sleep(120);
    const target = Array.from(document.querySelectorAll(".ed-obj.textobj")).find(e => /Hello from UI test/.test(e.textContent));
    if (!target) return fail("drag-pre", "text object missing before drag");
    const r0 = target.getBoundingClientRect();
    pe(target, "pointerdown", r0.left + 5, r0.top + 5);
    pe(window, "pointermove", r0.left + 45, r0.top + 35);
    pe(window, "pointermove", r0.left + 85, r0.top + 65);
    pe(window, "pointerup", r0.left + 85, r0.top + 65);
    await sleep(250);
    const moved = Array.from(document.querySelectorAll(".ed-obj.textobj")).find(e => /Hello from UI test/.test(e.textContent));
    if (!moved) return fail("drag", "text object vanished during drag");
    const r1 = moved.getBoundingClientRect();
    if (Math.abs(r1.left - r0.left) < 30) return fail("drag-move", "object did not move (dx=" + Math.round(r1.left - r0.left) + ")");
    steps.push("drag");
    // 6. whiteout drag-draw
    const wBtn = Array.from(document.querySelectorAll(".ed-tool")).find(b => b.title === "Whiteout");
    wBtn.click(); await sleep(80);
    pe(stEl, "pointerdown", r.left + 60, r.top + 80);
    pe(window, "pointermove", r.left + 180, r.top + 130);
    pe(window, "pointerup", r.left + 180, r.top + 130);
    await sleep(250);
    if (!document.querySelector(".ed-obj.whiteout")) return fail("whiteout", "no whiteout object after drag");
    steps.push("whiteout");
    // 7. edit-text mode (requires MuPDF; skip cleanly on lean builds)
    if ((window.PD_ASSETS || {}).mupdfWasm) {
      const eBtn = Array.from(document.querySelectorAll(".ed-tool")).find(b => b.title === "Edit existing text");
      eBtn.click();
      let hits = null;
      for (let i = 0; i < 100 && !hits; i++) { await sleep(300); const hh = document.querySelectorAll(".ed-hit"); if (hh.length) hits = hh; }
      if (!hits) return fail("edittext-lines", "no clickable text lines appeared (stext/mupdf failed?)");
      hits[0].click();
      await sleep(400);
      const eobj = Array.from(document.querySelectorAll(".ed-obj.textobj")).find(e => e.isContentEditable);
      if (!eobj) return fail("edittext-open", "clicking a line did not open the inline editor");
      document.execCommand("selectAll");
      document.execCommand("insertText", false, "Retyped by UI test");
      eobj.blur();
      await sleep(250);
      if (!Array.from(document.querySelectorAll(".ed-obj.textobj")).some(e => /Retyped by UI test/.test(e.textContent)))
        return fail("edittext-commit", "retyped text did not persist");
      steps.push("edittext");
    } else steps.push("edittext-skipped");
    // 8. sign tool placement accuracy: click at 30%,70% of the preview and
    //    verify the recorded placement matches that fraction of the page.
    showView("sign");
    let ov = null;
    for (let i = 0; i < 50 && !ov; i++) { await sleep(200); const c = document.querySelector(".preview-wrap canvas"); if (c && c.getBoundingClientRect().width > 50) ov = c; }
    if (!ov) return fail("sign-preview", "sign preview never rendered");
    // draw a quick signature on the pad so placement is armed
    const padEl = document.querySelector('canvas[style*="crosshair"]');
    if (!padEl) return fail("sign-pad", "draw pad missing");
    const pr = padEl.getBoundingClientRect();
    pe(padEl, "pointerdown", pr.left + 30, pr.top + 60);
    pe(padEl, "pointermove", pr.left + 150, pr.top + 90);
    pe(padEl, "pointerup", pr.left + 150, pr.top + 90);
    // wait until the signature is actually registered (marker becomes visible at its default spot)
    let sigEl = null;
    for (let i = 0; i < 40 && !sigEl; i++) {
      await sleep(250);
      const im = document.querySelector(".preview-wrap img");
      if (im && im.style.display === "block") sigEl = im;
    }
    if (!sigEl) return fail("sign-place", "signature was never registered after drawing");
    const ovWrap = ov.parentElement.querySelector("div"); // overlay div above canvas
    const or = ov.getBoundingClientRect();
    const clickX = or.left + or.width * 0.3, clickY = or.top + or.height * 0.7;
    pe(ovWrap || ov, "pointerdown", clickX, clickY);
    pe(window, "pointerup", clickX, clickY);
    await sleep(300);
    const sr = sigEl.getBoundingClientRect();
    const cxFrac = ((sr.left + sr.width / 2) - or.left) / or.width;
    const cyFrac = ((sr.top + sr.height / 2) - or.top) / or.height;
    if (Math.abs(cxFrac - 0.3) > 0.03 || Math.abs(cyFrac - 0.7) > 0.03)
      return fail("sign-accuracy", "marker at " + cxFrac.toFixed(2) + "," + cyFrac.toFixed(2) + " expected 0.30,0.70");
    steps.push("sign-place");
    // 9. viewer: text layer + search
    showView("view");
    let ti = null;
    for (let i = 0; i < 50 && !ti; i++) { await sleep(200); ti = document.getElementById("pdfind"); }
    if (!ti) return fail("viewer-ui", "search input missing");
    let spans = 0;
    for (let i = 0; i < 50 && !spans; i++) { await sleep(200); spans = document.querySelectorAll(".textLayer span").length; }
    if (!spans) return fail("viewer-textlayer", "no selectable text layer rendered");
    ti.value = "heading";
    ti.dispatchEvent(new Event("input", { bubbles: true }));
    let found = false;
    for (let i = 0; i < 40 && !found; i++) {
      await sleep(200);
      const info = document.getElementById("pdfindinfo");
      if (info && /\d+ \/ \d+/.test(info.textContent)) found = true;
    }
    if (!found) return fail("viewer-search", "search found no matches for 'heading'");
    steps.push("viewer-search");
    report("UITEST:PASS:" + steps.join(","));
  } catch (e) {
    fail("crash", (e && e.message || e) + " @ " + steps.join(","));
  }
}
window.PDUITest = runUITest;

/* ---------------- boot ---------------- */
function boot() {
  pdfjsLib.GlobalWorkerOptions.workerSrc = "pdfdesk.worker.inline";
  const app = document.getElementById("app");
  const main = h("main", { class: "main" }, viewRoot);
  app.append(h("div", { class: "shell" }, buildSidebar(), main), toastHost, pickerInput);
  setupGlobalDrop();
  showView("welcome");
  // Native desktop shell bridge (Electron): receive files opened via
  // double-click / "Open with" and load them straight into the workspace.
  if (window.pdeskAPI) {
    const handleBatch = list => {
      try {
        const recs = list.map(f => ({ name: f.name, size: f.data.byteLength, buf: f.data }));
        if (recs.length > 1) { showView("merge", recs); toast(recs.length + " PDFs ready to merge"); }
        else if (recs.length === 1) { setWorkspaceFile(recs[0]); toast("Opened " + recs[0].name); }
      } catch (e) { toast("Could not open the dropped files", "err"); }
    };
    if (typeof window.pdeskAPI.onOpenFiles === "function") window.pdeskAPI.onOpenFiles(handleBatch);
    else if (typeof window.pdeskAPI.onOpenFile === "function") window.pdeskAPI.onOpenFile(f => handleBatch([f]));
    window.pdeskAPI.ready && window.pdeskAPI.ready();
  }
  if (window.PD_DEBUG) setTimeout(runUITest, 600);
  if (location.hash === "#selftest") {
    const pre = document.createElement("pre");
    pre.id = "selftest-out";
    pre.style.cssText = "position:fixed;top:12px;right:12px;width:min(520px,90vw);max-height:88vh;overflow:auto;z-index:999;background:#141311;color:#d9f2df;padding:14px 16px;border-radius:10px;font:12px/1.55 ui-monospace,Menlo,Consolas,monospace;box-shadow:0 12px 40px rgba(0,0,0,.4);white-space:pre-wrap";
    pre.textContent = "Self-test running…";
    document.body.append(pre);
    runSelfTest().then(r => {
      document.title = (r.pass ? "SELFTEST:PASS" : "SELFTEST:FAIL");
      pre.textContent = (r.pass ? "SELFTEST: ALL PASS\n\n" : "SELFTEST: FAILURES\n\n") +
        r.results.map(x => (x.ok ? "ok   " : "FAIL ") + x.name + (x.err ? "\n     " + x.err : "")).join("\n");
      if (!r.pass) pre.style.color = "#f2c8c2";
    }).catch(e => {
      document.title = "SELFTEST:CRASH";
      pre.textContent = "CRASH " + (e && e.stack || e);
      pre.style.color = "#f2c8c2";
    });
  }
}
document.addEventListener("DOMContentLoaded", boot);
