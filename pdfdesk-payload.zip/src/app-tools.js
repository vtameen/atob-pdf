/* PDFDesk tools */
"use strict";

function debounce(fn, ms) {
  let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); };
}

/* compact indicator for a loaded file */
function filePill(rec, meta, onClear) {
  return h("div", { class: "fchip", style: "margin-bottom:14px" },
    icon("file"),
    h("span", { class: "fname" }, rec.name),
    h("span", { class: "fmeta" }, meta),
    h("span", { style: "flex:1" }),
    h("button", { class: "iconbtn x", title: "Choose a different file", onclick: onClear }, icon("close")));
}

/* single-PDF tool scaffold. needProbe: validate with pdf-lib (rejects encrypted early) */
function singlePdfTool(ctx, { needProbe = true, big }, onReady) {
  const start = async rec => {
    let pages = null;
    if (needProbe) {
      try {
        const d = await PDCore.loadDoc(bytesOf(rec));
        pages = d.getPageCount();
      } catch (e) {
        if (ctx.preload) { ctx.body.innerHTML = ""; errorBack(ctx.body, e, ctx.restart); return; }
        toast(e.message, "err");
        ctx.restart();
        return;
      }
    }
    ctx.body.innerHTML = "";
    try { await onReady(rec, pages); }
    catch (e) { errorBack(ctx.body, e, ctx.restart); }
  };
  if (ctx.preload) { start(ctx.preload); return; }
  ctx.body.append(makeDrop({ big: big || "Drop a PDF here", onFiles: ([r]) => start(r) }));
}

/* generic run wrapper: swaps body to progress, runs job, shows result */
async function runJob(ctx, label, job, makeFiles) {
  ctx.body.innerHTML = "";
  document.querySelectorAll(".actionbar").forEach(e => e.remove());
  const prog = progressPanel(label);
  ctx.body.append(prog.el);
  try {
    const out = await job(prog);
    const { files, opts } = makeFiles(out);
    resultScreen(ctx.body, files, opts, ctx.restart);
  } catch (e) {
    if (e && e.code === "RANGE") { toast(e.message, "err"); ctx.restart(); return; }
    errorBack(ctx.body, e, ctx.restart);
  }
}

/* live preview: renders page 1 once, then overlays drawFn(ctx2d, w, h, scale) */
function livePreview(rec, caption) {
  const base = document.createElement("canvas");
  const over = document.createElement("canvas");
  over.style.position = "absolute"; over.style.inset = "0"; over.style.width = "100%"; over.style.height = "100%";
  const frame = h("div", { class: "frame", style: "position:relative" }, base, over);
  const el = h("div", { class: "preview-wrap" }, frame, h("div", { class: "cap" }, caption || "Preview · page 1"));
  let pageW = 595, pageH = 842, drawFn = null, ready = false;
  (async () => {
    try {
      const doc = await openPdf(rec);
      const page = await doc.getPage(1);
      const vp1 = page.getViewport({ scale: 1 });
      pageW = vp1.width; pageH = vp1.height;
      const scale = 360 / vp1.width;
      const vp = page.getViewport({ scale });
      base.width = over.width = Math.round(vp.width);
      base.height = over.height = Math.round(vp.height);
      const c2 = base.getContext("2d", { alpha: false });
      c2.fillStyle = "#fff"; c2.fillRect(0, 0, base.width, base.height);
      await page.render({ canvasContext: c2, viewport: vp }).promise;
      closePdf(doc);
      ready = true;
      redraw();
    } catch (e) { /* preview is best-effort */ }
  })();
  function redraw() {
    if (!ready) return;
    const c = over.getContext("2d");
    c.clearRect(0, 0, over.width, over.height);
    if (drawFn) drawFn(c, pageW, pageH, over.width / pageW);
  }
  return { el, setDraw: fn => { drawFn = fn; redraw(); }, redraw: () => redraw(), getPageSize: () => ({ w: pageW, h: pageH }) };
}

/* =============== MERGE =============== */
registerTool({
  id: "merge", name: "Merge", icon: "merge", standalone: true,
  desc: "Combine PDFs into one file",
  hint: "Tip: select several files at once (Ctrl-click)",
  build(ctx) {
    const files = []; // {rec, pages, rangeStr}
    const list = h("div", { class: "filelist" });
    const bar = actionBar("", "Merge PDFs", run);
    ctx.setCleanup(() => bar.el.remove());

    const dropBig = makeDrop({ multiple: true, big: "Drop PDFs here", sub: "Add two or more files - you can select many at once in the picker (Ctrl-click or Ctrl+A).", onFiles: addFiles });
    const dropMore = makeDrop({ multiple: true, compact: true, big: "Add more PDFs", sub: "", onFiles: addFiles });
    dropMore.classList.add("hidden");
    ctx.body.append(dropBig, dropMore, list);
    document.body.append(bar.el);
    if (ctx.preload) addFiles(Array.isArray(ctx.preload) ? ctx.preload : [ctx.preload]);

    async function addFiles(recs) {
      for (const rec of recs) {
        try {
          const d = await PDCore.loadDoc(bytesOf(rec));
          files.push({ rec, pages: d.getPageCount(), rangeStr: "" });
        } catch (e) { toast(rec.name + ": " + e.message, "err"); }
      }
      render();
    }
    function selectedCount(f) {
      if (!f.rangeStr.trim()) return f.pages;
      try { return PDCore.parseRangeGroups(f.rangeStr, f.pages).reduce((a, g) => a + g.length, 0); }
      catch (e) { return null; }
    }
    function render() {
      list.innerHTML = "";
      files.forEach((f, i) => {
        const range = h("input", { class: "range", placeholder: "all pages · e.g. 1-3, 7", value: f.rangeStr });
        range.addEventListener("input", debounce(() => {
          f.rangeStr = range.value;
          const ok = selectedCount(f) != null;
          range.classList.toggle("bad", !ok && !!range.value.trim());
          updateBar();
        }, 200));
        list.append(h("div", { class: "fchip" },
          h("span", { class: "updown" },
            h("button", { title: "Move up", onclick: () => { if (i > 0) { files.splice(i - 1, 0, files.splice(i, 1)[0]); render(); } } }, "▲"),
            h("button", { title: "Move down", onclick: () => { if (i < files.length - 1) { files.splice(i + 1, 0, files.splice(i, 1)[0]); render(); } } }, "▼")),
          h("span", { class: "fname" }, f.rec.name),
          h("span", { class: "fmeta" }, f.pages + " pages"),
          range,
          h("button", { class: "iconbtn x", title: "Remove", onclick: () => { files.splice(i, 1); render(); } }, icon("close"))));
      });
      dropBig.classList.toggle("hidden", files.length > 0);
      dropMore.classList.toggle("hidden", files.length === 0);
      updateBar();
    }
    function updateBar() {
      const counts = files.map(selectedCount);
      const bad = counts.some(c => c == null);
      const total = counts.reduce((a, c) => a + (c || 0), 0);
      bar.setSummary(files.length ? files.length + " files · " + total + " pages" + (bad ? " · check the highlighted range" : "") : "");
      bar.enable(files.length >= 2 && !bad);
    }
    function run() {
      const snapshot = files.slice();
      runJob(ctx, "Merging", async prog => {
        return await PDCore.mergePdfs(
          snapshot.map(f => bytesOf(f.rec)),
          snapshot.map(f => f.rangeStr),
          (done, total) => prog.set(done / total, "Merging " + snapshot[done - 1].rec.name, done + " / " + total));
      }, bytes => ({
        files: [{ name: PDCore.baseName(snapshot[0].rec.name) + "-merged.pdf", bytes, mime: "application/pdf" }],
        opts: { title: "Merged" },
      }));
    }
  },
});

/* =============== SPLIT =============== */
registerTool({
  id: "split", name: "Split", icon: "split",
  desc: "Cut one PDF into several",
  build(ctx) {
    singlePdfTool(ctx, {}, (rec, pages) => {
      const bar = actionBar(pages + " pages", "Split PDF", run);
      ctx.setCleanup(() => bar.el.remove());
      document.body.append(bar.el);

      let mode = "ranges";
      const rangeInput = h("input", { type: "text", class: "wide", placeholder: "e.g. 1-3, 4-6, 7-" + pages, style: "width:min(340px,72vw);padding:7px 10px;border:1px solid var(--line);border-radius:8px;background:var(--surface)" });
      const everyInput = h("input", { type: "number", min: 1, max: pages, value: Math.min(2, pages) , style:"width:70px;padding:7px 10px;border:1px solid var(--line);border-radius:8px;background:var(--surface)"});
      const previewNote = h("div", { class: "opt-note" }, "");

      const rangesRow = h("div", { class: "opt-row" }, rangeInput);
      const everyRow = h("div", { class: "opt-row hidden" }, h("span", { class: "field" }, "Every", everyInput, "pages"));
      const eachRow = h("div", { class: "opt-note hidden" }, "Each of the " + pages + " pages becomes its own PDF.");

      const seg = segmented([
        { v: "ranges", label: "Custom ranges" },
        { v: "every", label: "Every N pages" },
        { v: "each", label: "One file per page" },
      ], mode, v => { mode = v;
        rangesRow.classList.toggle("hidden", v !== "ranges");
        everyRow.classList.toggle("hidden", v !== "every");
        eachRow.classList.toggle("hidden", v !== "each");
        update();
      });

      ctx.body.append(
        filePill(rec, pages + " pages · " + PDCore.fmtBytes(rec.size), ctx.restart),
        optSection("How to split", h("div", { class: "opt-row" }, seg.el), rangesRow, everyRow, eachRow, previewNote));

      function groups() {
        if (mode === "each") return Array.from({ length: pages }, (_, i) => [i]);
        if (mode === "every") {
          const n = Math.max(1, Math.min(pages, Math.floor(+everyInput.value || 1)));
          const g = [];
          for (let i = 0; i < pages; i += n) g.push(Array.from({ length: Math.min(n, pages - i) }, (_, k) => i + k));
          return g;
        }
        return PDCore.parseRangeGroups(rangeInput.value, pages);
      }
      function update() {
        try {
          const g = groups();
          previewNote.textContent = "→ " + g.length + " file" + (g.length === 1 ? "" : "s");
          rangeInput.classList.remove("bad");
          bar.enable(true);
          bar.setSummary(pages + " pages → " + g.length + " files");
        } catch (e) {
          previewNote.textContent = rangeInput.value.trim() ? e.message : "Enter ranges separated by commas. Each range becomes one file.";
          if (rangeInput.value.trim()) rangeInput.classList.add("bad");
          bar.enable(false);
          bar.setSummary(pages + " pages");
        }
      }
      rangeInput.addEventListener("input", debounce(update, 200));
      everyInput.addEventListener("input", debounce(update, 200));
      update();

      function run() {
        let g;
        try { g = groups(); } catch (e) { toast(e.message, "err"); return; }
        const base = PDCore.baseName(rec.name);
        runJob(ctx, "Splitting", async prog => {
          return await PDCore.splitPdf(bytesOf(rec), g, (d, t) => prog.set(d / t, "Writing part " + d, d + " / " + t));
        }, outs => ({
          files: outs.map((bytes, i) => {
            const gr = g[i];
            const label = gr.length === 1 ? "p" + (gr[0] + 1) : "p" + (Math.min(...gr) + 1) + "-" + (Math.max(...gr) + 1);
            return { name: base + "-" + label + ".pdf", bytes, mime: "application/pdf" };
          }),
          opts: { title: "Split into " + outs.length + " files", zipName: base + "-split.zip" },
        }));
      }
    });
  },
});

/* =============== thumbnail grid helper =============== */
async function buildThumbGrid(ctx, rec, { selectable, organize }) {
  const doc = await openPdf(rec);
  const tq = new ThumbQueue(doc);
  ctx.setCleanup(() => { tq.kill(); closePdf(doc); document.querySelectorAll(".actionbar").forEach(e => e.remove()); });
  const grid = h("div", { class: "thumbs" + (organize ? " roomy" : " roomy") });
  const items = []; // organize: {srcIdx, rot, el}; select: {idx, sel, el}
  const n = doc.numPages;
  for (let i = 0; i < n; i++) {
    const holder = h("div", { class: "rotwrap" });
    const frame = h("div", { class: "frame" }, holder);
    const card = h("div", { class: "pcard" }, frame, h("div", { class: "pno" }, String(i + 1)));
    if (selectable) card.append(h("span", { class: "selmark" }, icon("check")));
    grid.append(card);
    items.push(organize ? { srcIdx: i, rot: 0, el: card, holder } : { idx: i, sel: false, el: card });
    tq.render(i + 1, 240).then(c => { holder.innerHTML = ""; holder.append(c); c.style.maxWidth = "100%"; c.style.maxHeight = "100%"; c.style.width = "auto"; c.style.height = "auto"; }).catch(() => {});
  }
  return { doc, grid, items, n, tq };
}

/* =============== EXTRACT =============== */
registerTool({
  id: "extract", name: "Extract pages", icon: "extract",
  desc: "Pull selected pages into a new PDF",
  build(ctx) {
    singlePdfTool(ctx, {}, async (rec, pages) => {
      const { grid, items } = await buildThumbGrid(ctx, rec, { selectable: true });
      const bar = actionBar("", "Extract pages", run);
      document.body.append(bar.el);
      const count = h("span", { class: "count" }, "");
      let lastClicked = -1;

      function setSel(it, v) { it.sel = v; it.el.classList.toggle("sel", v); }
      function refresh() {
        const c = items.filter(i => i.sel).length;
        count.textContent = c + " of " + items.length + " selected";
        bar.setSummary(c + " page" + (c === 1 ? "" : "s") + " selected");
        bar.enable(c > 0);
        bar.setLabel(c > 0 ? "Extract " + c + " page" + (c === 1 ? "" : "s") : "Extract pages");
      }
      items.forEach((it, i) => it.el.addEventListener("click", e => {
        if (e.shiftKey && lastClicked >= 0) {
          const [a, b] = [Math.min(lastClicked, i), Math.max(lastClicked, i)];
          for (let k = a; k <= b; k++) setSel(items[k], true);
        } else setSel(it, !it.sel);
        lastClicked = i;
        refresh();
      }));

      const rangeInput = h("input", { class: "range", placeholder: "or type a range: 1-3, 7", style: "width:200px" });
      rangeInput.addEventListener("input", debounce(() => {
        if (!rangeInput.value.trim()) { rangeInput.classList.remove("bad"); return; }
        try {
          const set = new Set(PDCore.parsePageSet(rangeInput.value, items.length));
          items.forEach((it, i) => setSel(it, set.has(i)));
          rangeInput.classList.remove("bad");
          refresh();
        } catch (e) { rangeInput.classList.add("bad"); }
      }, 250));

      ctx.body.append(
        filePill(rec, pages + " pages", ctx.restart),
        h("div", { class: "thumb-toolbar" },
          h("button", { class: "btn secondary", style: "height:32px;padding:0 12px;font-size:12.5px", onclick: () => { items.forEach(i => setSel(i, true)); refresh(); } }, "All"),
          h("button", { class: "btn secondary", style: "height:32px;padding:0 12px;font-size:12.5px", onclick: () => { items.forEach(i => setSel(i, false)); refresh(); } }, "None"),
          h("button", { class: "btn secondary", style: "height:32px;padding:0 12px;font-size:12.5px", onclick: () => { items.forEach(i => setSel(i, !i.sel)); refresh(); } }, "Invert"),
          rangeInput,
          h("span", { class: "spacer" }), count),
        grid);
      refresh();

      function run() {
        const sel = items.filter(i => i.sel).map(i => i.idx);
        runJob(ctx, "Extracting", async prog => {
          prog.set(0.4, "Copying " + sel.length + " pages");
          return await PDCore.extractPages(bytesOf(rec), sel);
        }, bytes => ({
          files: [{ name: PDCore.baseName(rec.name) + "-extracted.pdf", bytes, mime: "application/pdf" }],
          opts: { title: "Extracted " + sel.length + " page" + (sel.length === 1 ? "" : "s") },
        }));
      }
    });
  },
});

/* =============== ORGANIZE =============== */
registerTool({
  id: "organize", name: "Organize", icon: "organize",
  desc: "Reorder, rotate, delete pages",
  hint: "Drag pages to reorder. Hover a page for actions.",
  build(ctx) {
    singlePdfTool(ctx, {}, async (rec, pages) => {
      const built = await buildThumbGrid(ctx, rec, { organize: true });
      const { grid } = built;
      let items = built.items;
      const bar = actionBar("", "Apply changes", run);
      document.body.append(bar.el);
      const count = h("span", { class: "count" }, "");

      function attach(it) {
        const acts = h("div", { class: "acts" },
          h("button", { title: "Rotate 90°", onclick: e => { e.stopPropagation(); it.rot = (it.rot + 90) % 360; it.holder.style.transform = "rotate(" + it.rot + "deg)"; markDirty(); } }, icon("rotcw")),
          h("button", { title: "Duplicate", onclick: e => { e.stopPropagation(); dup(it); } }, icon("plus")),
          h("button", { title: "Delete", onclick: e => { e.stopPropagation(); items = items.filter(x => x !== it); it.el.remove(); renumber(); markDirty(); } }, icon("trash")));
        it.el.append(acts);
        enableDrag(it);
      }
      function dup(it) {
        const holder = h("div", { class: "rotwrap" });
        const c = it.holder.firstChild;
        if (c && c.tagName === "CANVAS") {
          const copy = document.createElement("canvas");
          copy.width = c.width; copy.height = c.height;
          copy.getContext("2d").drawImage(c, 0, 0);
          copy.style.cssText = c.style.cssText;
          holder.append(copy);
        }
        holder.style.transform = it.holder.style.transform;
        const card = h("div", { class: "pcard" }, h("div", { class: "frame" }, holder), h("div", { class: "pno" }, ""));
        const ni = { srcIdx: it.srcIdx, rot: it.rot, el: card, holder };
        items.splice(items.indexOf(it) + 1, 0, ni);
        it.el.after(card);
        attach(ni);
        renumber(); markDirty();
      }
      function renumber() {
        items.forEach((it, i) => { const pno = it.el.querySelector(".pno"); if (pno) pno.textContent = String(i + 1); });
        count.textContent = items.length + " page" + (items.length === 1 ? "" : "s");
      }
      let dirty = false;
      function markDirty() { dirty = true; bar.enable(items.length > 0); bar.setSummary(items.length + " pages · modified"); }

      /* pointer-based drag reorder */
      function enableDrag(it) {
        it.el.addEventListener("pointerdown", e => {
          if (e.button !== 0 || e.target.closest(".acts")) return;
          const startX = e.clientX, startY = e.clientY;
          let dragging = false, target = null, side = "r";
          const move = ev => {
            if (!dragging && Math.hypot(ev.clientX - startX, ev.clientY - startY) > 7) {
              dragging = true;
              it.el.classList.add("dragging");
              it.el.setPointerCapture && it.el.setPointerCapture(e.pointerId);
            }
            if (!dragging) return;
            ev.preventDefault();
            const elu = document.elementFromPoint(ev.clientX, ev.clientY);
            const card = elu && elu.closest ? elu.closest(".pcard") : null;
            grid.querySelectorAll(".pcard").forEach(c => c.classList.remove("dropside-l", "dropside-r"));
            target = null;
            if (card && card !== it.el && card.parentElement === grid) {
              const r = card.getBoundingClientRect();
              side = ev.clientX < r.left + r.width / 2 ? "l" : "r";
              card.classList.add(side === "l" ? "dropside-l" : "dropside-r");
              target = card;
            }
          };
          const up = () => {
            window.removeEventListener("pointermove", move);
            window.removeEventListener("pointerup", up);
            it.el.classList.remove("dragging");
            grid.querySelectorAll(".pcard").forEach(c => c.classList.remove("dropside-l", "dropside-r"));
            if (dragging && target) {
              const ti = items.find(x => x.el === target);
              const from = items.indexOf(it);
              items.splice(from, 1);
              let to = items.indexOf(ti);
              if (side === "r") to++;
              items.splice(to, 0, it);
              if (side === "l") grid.insertBefore(it.el, target);
              else grid.insertBefore(it.el, target.nextSibling);
              renumber(); markDirty();
            }
          };
          window.addEventListener("pointermove", move, { passive: false });
          window.addEventListener("pointerup", up);
        });
      }
      items.forEach(attach);
      renumber();
      bar.setSummary(items.length + " pages");
      bar.enable(false);

      ctx.body.append(
        filePill(rec, pages + " pages", ctx.restart),
        h("div", { class: "thumb-toolbar" },
          h("button", { class: "btn secondary", style: "height:32px;padding:0 12px;font-size:12.5px", onclick: ctx.restart }, "Reset"),
          h("span", { class: "spacer" }), count),
        grid);

      function run() {
        const order = items.map(it => ({ srcIdx: it.srcIdx, rotDelta: it.rot }));
        runJob(ctx, "Rebuilding", async prog => {
          prog.set(0.4, "Writing " + order.length + " pages");
          return await PDCore.organizePdf(bytesOf(rec), order);
        }, bytes => ({
          files: [{ name: PDCore.baseName(rec.name) + "-organized.pdf", bytes, mime: "application/pdf" }],
          opts: { title: "Pages reorganized" },
        }));
      }
    });
  },
});

/* =============== ROTATE =============== */
registerTool({
  id: "rotate", name: "Rotate", icon: "rotate",
  desc: "Turn all or some pages",
  build(ctx) {
    singlePdfTool(ctx, {}, (rec, pages) => {
      const bar = actionBar(pages + " pages", "Rotate", run);
      ctx.setCleanup(() => bar.el.remove());
      document.body.append(bar.el);
      let scope = "all", angle = 90;
      const rangeInput = h("input", { class: "range hidden", placeholder: "e.g. 2, 5-7", style: "width:170px" });
      const scopeSeg = segmented([
        { v: "all", label: "All pages" }, { v: "odd", label: "Odd" }, { v: "even", label: "Even" }, { v: "custom", label: "Custom" },
      ], scope, v => { scope = v; rangeInput.classList.toggle("hidden", v !== "custom"); update(); });
      const angleSeg = segmented([
        { v: 90, label: "90° right" }, { v: 180, label: "180°" }, { v: 270, label: "90° left" },
      ], angle, v => { angle = v; });
      rangeInput.addEventListener("input", debounce(update, 200));

      ctx.body.append(
        filePill(rec, pages + " pages", ctx.restart),
        optSection("Which pages", h("div", { class: "opt-row" }, scopeSeg.el, rangeInput)),
        optSection("Direction", h("div", { class: "opt-row" }, angleSeg.el)));

      function indices() {
        if (scope === "all") return Array.from({ length: pages }, (_, i) => i);
        if (scope === "odd") return Array.from({ length: pages }, (_, i) => i).filter(i => i % 2 === 0);
        if (scope === "even") return Array.from({ length: pages }, (_, i) => i).filter(i => i % 2 === 1);
        return PDCore.parsePageSet(rangeInput.value, pages);
      }
      function update() {
        try {
          const k = indices().length;
          bar.setSummary("Will rotate " + k + " of " + pages + " pages");
          bar.enable(k > 0);
          rangeInput.classList.remove("bad");
        } catch (e) {
          bar.setSummary(rangeInput.value.trim() ? e.message : "Enter a page range");
          bar.enable(false);
          if (rangeInput.value.trim()) rangeInput.classList.add("bad");
        }
      }
      update();
      function run() {
        let idx;
        try { idx = indices(); } catch (e) { toast(e.message, "err"); return; }
        runJob(ctx, "Rotating", async prog => {
          prog.set(0.5, "Rotating " + idx.length + " pages");
          return await PDCore.rotatePdf(bytesOf(rec), idx, angle);
        }, bytes => ({
          files: [{ name: PDCore.baseName(rec.name) + "-rotated.pdf", bytes, mime: "application/pdf" }],
          opts: { title: "Rotated" },
        }));
      }
    });
  },
});

/* =============== COMPRESS =============== */
registerTool({
  id: "compress", name: "Compress", icon: "compress",
  desc: "Shrink the file size",
  build(ctx) {
    singlePdfTool(ctx, {}, (rec, pages) => {
      const bar = actionBar(PDCore.fmtBytes(rec.size), "Compress", run);
      ctx.setCleanup(() => bar.el.remove());
      document.body.append(bar.el);
      let level = "balanced";
      const NOTES = {
        light: "Rewrites the file structure without touching quality. Typical gain 0–20%.",
        deep: "MuPDF deep clean: deduplicates objects and recompresses streams, fonts and images losslessly. Keeps text selectable. Often the best choice.",
        balanced: "Re-renders pages at 150 DPI. Good quality for reading and printing. Text becomes non-selectable.",
        strong: "Re-renders at 110 DPI. Noticeably smaller, fine on screen. Text becomes non-selectable.",
        extreme: "Re-renders at 72 DPI. Smallest file, visibly softer. Text becomes non-selectable.",
      };
      const note = h("div", { class: "opt-note" }, NOTES[level]);
      const seg = segmented([
        { v: "light", label: "Light (lossless)" },
        { v: "deep", label: "Deep (lossless)" },
        { v: "balanced", label: "Balanced" },
        { v: "strong", label: "Strong" },
        { v: "extreme", label: "Extreme" },
      ], level, v => { level = v; note.textContent = NOTES[v]; note.classList.toggle("warn", v !== "light" && v !== "deep"); });
      ctx.body.append(
        filePill(rec, pages + " pages · " + PDCore.fmtBytes(rec.size), ctx.restart),
        optSection("Compression level", h("div", { class: "opt-row" }, seg.el), note));
      bar.enable(true);

      const DPI = { balanced: 150, strong: 110, extreme: 72 };
      const Q = { balanced: 0.72, strong: 0.62, extreme: 0.5 };
      function run() {
        const before = rec.size;
        runJob(ctx, "Compressing", async prog => {
          if (level === "light") {
            prog.set(0.5, "Rebuilding file structure");
            const out = await PDCore.resavePdf(bytesOf(rec));
            return { out, rasterized: false };
          }
          if (level === "deep") {
            prog.set(0.15, "Loading MuPDF engine (one-time)");
            const mupdf = await loadMuPDF();
            prog.set(0.6, "Deduplicating and recompressing");
            const doc = mupdfOpen(mupdf, bytesOf(rec));
            const out = doc.saveToBuffer("garbage=deduplicate,compress=yes,compress-fonts=yes,compress-images=yes,clean=yes").asUint8Array();
            return { out, rasterized: false };
          }
          const doc = await openPdf(rec);
          try {
            const pageJpegs = [];
            for (let i = 1; i <= doc.numPages; i++) {
              prog.set((i - 1) / doc.numPages, "Rendering page " + i, i + " / " + doc.numPages);
              const { canvas } = await renderPageToCanvas(doc, i, 0, { dpi: DPI[level] });
              const blob = await new Promise(r => canvas.toBlob(r, "image/jpeg", Q[level]));
              const page = await doc.getPage(i);
              const vp = page.getViewport({ scale: 1 });
              pageJpegs.push({ jpeg: new Uint8Array(await blob.arrayBuffer()), wPt: vp.width, hPt: vp.height });
              canvas.width = 1; canvas.height = 1;
            }
            prog.set(0.96, "Assembling PDF");
            const out = await PDCore.rebuildFromJpegs(pageJpegs);
            return { out, rasterized: true };
          } finally { closePdf(doc); }
        }, res => {
          let bytes = res.out, kept = false;
          if (bytes.length >= before) {
            if (!res.rasterized) { bytes = new Uint8Array(rec.buf.slice(0)); kept = true; }
          }
          const after = bytes.length;
          const pct = Math.round((1 - after / before) * 100);
          return {
            files: [{ name: PDCore.baseName(rec.name) + "-compressed.pdf", bytes, mime: "application/pdf" }],
            opts: {
              title: kept ? "Already optimized" : "Compressed",
              meta: PDCore.fmtBytes(before) + " → " + PDCore.fmtBytes(after),
              deltaText: kept ? "This PDF was already efficient. Kept the original quality untouched."
                : (pct >= 0 ? pct + "% smaller" : "Result came out larger. Try a stronger level, or the original may already be optimized."),
              deltaGood: pct > 0 && !kept,
            },
          };
        });
      }
    });
  },
});

/* =============== WATERMARK =============== */
registerTool({
  id: "watermark", name: "Watermark", icon: "watermark",
  desc: "Stamp text or an image",
  build(ctx) {
    singlePdfTool(ctx, {}, (rec, pages) => {
      const bar = actionBar(pages + " pages", "Add watermark", run);
      ctx.setCleanup(() => bar.el.remove());
      document.body.append(bar.el);
      let mode = "text", imgRec = null, imgIsPng = true, imgEl = null;

      const preview = livePreview(rec);
      const textInput = h("input", { type: "text", class: "wide", value: "CONFIDENTIAL", style: "padding:8px 11px;border:1px solid var(--line);border-radius:8px;background:var(--surface);width:min(300px,70vw)" });
      const sizeS = slider(24, 140, 2, 64, v => v + " pt", redraw);
      const opacS = slider(5, 100, 5, 25, v => v + "%", redraw);
      const scaleS = slider(10, 100, 5, 40, v => v + "%", redraw);
      let angle = 45;
      const angleSeg = segmented([{ v: 45, label: "45°" }, { v: 0, label: "0°" }, { v: -45, label: "-45°" }, { v: 90, label: "90°" }], angle, v => { angle = v; redraw(); });
      const colorSw = swatches(["#9a9186", "#b3362a", "#2c4a6e", "#3d7a4f"], "#9a9186", redraw);
      let tiled = true, pos = "mc";
      const posG = posGrid(pos, v => { pos = v; tileC.set(false); tiled = false; redraw(); });
      const tileC = checkbox("Tile across the page", true, v => { tiled = v; redraw(); });
      const rangeInput = h("input", { class: "range", placeholder: "all pages · e.g. 2-", style: "width:170px" });
      rangeInput.addEventListener("input", debounce(update, 250));
      textInput.addEventListener("input", debounce(redraw, 150));

      const imgDrop = makeDrop({ accept: "image", compact: true, big: "Choose a watermark image", sub: "PNG with transparency works best", onFiles: async ([r]) => {
        imgRec = r;
        imgIsPng = !/\.jpe?g$/i.test(r.name);
        const blob = new Blob([r.buf]);
        imgEl = new Image();
        imgEl.onload = redraw;
        imgEl.src = URL.createObjectURL(blob);
        imgDrop.querySelector(".big").textContent = r.name;
        update();
      }});

      const textOpts = h("div", null,
        optSection("Text", h("div", { class: "opt-row" }, textInput, colorSw.el)),
        optSection("Size & angle", h("div", { class: "opt-row" }, sizeS.el, angleSeg.el)));
      const imgOpts = h("div", { class: "hidden" },
        optSection("Image", h("div", { class: "opt-row" }, imgDrop)),
        optSection("Size", h("div", { class: "opt-row" }, scaleS.el, h("span", { class: "muted", style: "font-size:12.5px" }, "of page width"))));

      const modeSeg = segmented([{ v: "text", label: "Text" }, { v: "image", label: "Image" }], mode, v => {
        mode = v;
        textOpts.classList.toggle("hidden", v !== "text");
        imgOpts.classList.toggle("hidden", v !== "image");
        update(); redraw();
      });

      ctx.body.append(
        filePill(rec, pages + " pages", ctx.restart),
        h("div", { class: "preview-cols" },
          h("div", { class: "opts" },
            optSection("Watermark type", h("div", { class: "opt-row" }, modeSeg.el)),
            textOpts, imgOpts,
            optSection("Placement", h("div", { class: "opt-row" }, posG.el, tileC.el)),
            optSection("Opacity & pages", h("div", { class: "opt-row" }, opacS.el, rangeInput))),
          preview.el));

      preview.setDraw(draw);
      function redraw() { if (tiled) posGridDim(true); else posGridDim(false); preview.redraw(); }
      function posGridDim(dim) { posG.el.style.opacity = dim ? "0.45" : "1"; }
      tileC.el.addEventListener("click", () => {}); // handled in onChange

      function draw(c, pw, ph, s) {
        c.globalAlpha = opacS.get() / 100;
        if (mode === "text") {
          const text = textInput.value || " ";
          const sizePx = sizeS.get() * s;
          c.fillStyle = colorSw.get();
          c.font = "600 " + sizePx + "px Helvetica, Arial, sans-serif";
          const tw = c.measureText(text).width;
          const th = sizePx * 0.72;
          const rad = -angle * Math.PI / 180; // canvas y-down
          const drawAt = (cx, cy) => {
            c.save();
            c.translate(cx * s, (ph - cy) * s);
            c.rotate(rad);
            c.fillText(text, -tw / 2, th / 2);
            c.restore();
          };
          if (tiled) {
            const twPt = tw / s, thPt = th / s;
            const stepX = twPt + 110, stepY = Math.max(130, thPt + 110);
            const diag = Math.sqrt(pw * pw + ph * ph);
            for (let y = -diag * 0.1; y <= ph + diag * 0.1; y += stepY)
              for (let x = -diag * 0.1; x <= pw + diag * 0.1; x += stepX)
                drawAt(x + twPt / 2, y + thPt / 2);
          } else {
            const m = 46, twPt = tw / s, thPt = th / s;
            const box = PDCore.posXY(pos, pw, ph, Math.min(twPt, pw - 2 * m), thPt, m);
            drawAt(box.x + Math.min(twPt, pw - 2 * m) / 2, box.y + thPt / 2);
          }
        } else if (imgEl && imgEl.complete && imgEl.naturalWidth) {
          const iw = pw * scaleS.get() / 100;
          const ih = iw * imgEl.naturalHeight / imgEl.naturalWidth;
          const drawAt = (x, y) => c.drawImage(imgEl, x * s, (ph - y - ih) * s, iw * s, ih * s);
          if (tiled) {
            for (let y = -ih / 2; y <= ph; y += ih + 70)
              for (let x = -iw / 2; x <= pw; x += iw + 70) drawAt(x, y);
          } else {
            const box = PDCore.posXY(pos, pw, ph, iw, ih, 40);
            drawAt(box.x, box.y);
          }
        }
        c.globalAlpha = 1;
      }

      function indices() {
        if (!rangeInput.value.trim()) return null;
        return PDCore.parsePageSet(rangeInput.value, pages);
      }
      function update() {
        try {
          const idx = indices();
          rangeInput.classList.remove("bad");
          const k = idx ? idx.length : pages;
          bar.setSummary("Watermark on " + k + " page" + (k === 1 ? "" : "s"));
          bar.enable(mode === "text" ? true : !!imgRec);
        } catch (e) {
          rangeInput.classList.add("bad");
          bar.enable(false);
          bar.setSummary(e.message);
        }
      }
      update();

      function run() {
        let idx;
        try { idx = indices(); } catch (e) { toast(e.message, "err"); return; }
        const opts = { opacity: opacS.get() / 100, tile: tiled, pos, indices: idx };
        runJob(ctx, "Stamping", async prog => {
          prog.set(0.4, "Stamping pages");
          if (mode === "text")
            return await PDCore.addTextWatermark(bytesOf(rec), Object.assign(opts, {
              text: textInput.value || "WATERMARK", size: sizeS.get(), color: colorSw.get(), angle }));
          return await PDCore.addImageWatermark(bytesOf(rec), new Uint8Array(imgRec.buf.slice(0)), imgIsPng, Object.assign(opts, { scalePct: scaleS.get() }));
        }, bytes => ({
          files: [{ name: PDCore.baseName(rec.name) + "-watermarked.pdf", bytes, mime: "application/pdf" }],
          opts: { title: "Watermark added" },
        }));
      }
    });
  },
});

/* =============== PAGE NUMBERS =============== */
registerTool({
  id: "numbers", name: "Page numbers", icon: "numbers",
  desc: "Stamp numbers on every page",
  build(ctx) {
    singlePdfTool(ctx, {}, (rec, pages) => {
      const bar = actionBar(pages + " pages", "Add page numbers", run);
      ctx.setCleanup(() => bar.el.remove());
      document.body.append(bar.el);
      let pos = "bc", format = "n", margin = "md", size = 11;
      const preview = livePreview(rec);
      const posG = posGrid(pos, v => { pos = v; preview.redraw(); });
      const fmtSel = h("select", null,
        h("option", { value: "n" }, "1"),
        h("option", { value: "nt" }, "1 / " + pages),
        h("option", { value: "pn" }, "Page 1"),
        h("option", { value: "pnt" }, "Page 1 of " + pages));
      fmtSel.addEventListener("change", () => { format = fmtSel.value; preview.redraw(); });
      const sizeSeg = segmented([{ v: 9, label: "Small" }, { v: 11, label: "Normal" }, { v: 14, label: "Large" }], size, v => { size = v; preview.redraw(); });
      const marginSeg = segmented([{ v: "sm", label: "Tight" }, { v: "md", label: "Normal" }, { v: "lg", label: "Wide" }], margin, v => { margin = v; preview.redraw(); });
      const colorSw = swatches(["#4b4640", "#8a8377", "#1a1a1a"], "#4b4640", () => preview.redraw());
      const startField = h("input", { type: "number", value: 1, min: 0, style: "width:70px;padding:6px 9px;border:1px solid var(--line);border-radius:8px;background:var(--surface)" });
      const skipC = checkbox("Skip the first page (cover)", false, () => {});
      startField.addEventListener("input", () => preview.redraw());

      ctx.body.append(
        filePill(rec, pages + " pages", ctx.restart),
        h("div", { class: "preview-cols" },
          h("div", { class: "opts" },
            optSection("Position", h("div", { class: "opt-row" }, posG.el)),
            optSection("Format", h("div", { class: "opt-row" }, fmtSel, h("span", { class: "field" }, "Start at", startField))),
            optSection("Style", h("div", { class: "opt-row" }, sizeSeg.el, marginSeg.el, colorSw.el)),
            optSection("Options", h("div", { class: "opt-row" }, skipC.el))),
          preview.el));
      bar.enable(true);

      preview.setDraw((c, pw, ph, s) => {
        const start = parseInt(startField.value, 10) || 1;
        const text = PDCore.NUM_FORMATS[format](start, pages);
        const sizePx = size * s;
        c.font = sizePx + "px Helvetica, Arial, sans-serif";
        c.fillStyle = colorSw.get();
        const tw = c.measureText(text).width;
        const box = PDCore.posXY(pos, pw, ph, tw / s, size * 0.72, PDCore.MARGINS[margin]);
        c.fillText(text, box.x * s, (ph - box.y) * s);
      });

      function run() {
        runJob(ctx, "Numbering", async prog => {
          prog.set(0.5, "Stamping " + pages + " pages");
          return await PDCore.addPageNumbers(bytesOf(rec), {
            pos, format, margin, size,
            color: colorSw.get(),
            start: parseInt(startField.value, 10) || 1,
            skipFirst: skipC.get(),
          });
        }, bytes => ({
          files: [{ name: PDCore.baseName(rec.name) + "-numbered.pdf", bytes, mime: "application/pdf" }],
          opts: { title: "Page numbers added" },
        }));
      }
    });
  },
});

/* =============== IMAGES -> PDF =============== */
registerTool({
  id: "img2pdf", name: "Images to PDF", icon: "img2pdf", acceptsPdf: false,
  desc: "JPG or PNG pages into one PDF",
  build(ctx) {
    const imgs = []; // {rec, url}
    const list = h("div", { class: "filelist" });
    const bar = actionBar("", "Create PDF", run);
    ctx.setCleanup(() => { bar.el.remove(); imgs.forEach(i => URL.revokeObjectURL(i.url)); });
    document.body.append(bar.el);
    let pageSize = "a4", orient = "auto", marginPct = 3;
    const sizeSeg = segmented([{ v: "a4", label: "A4" }, { v: "letter", label: "Letter" }, { v: "fit", label: "Fit image" }], pageSize, v => { pageSize = v; orientSeg.el.style.opacity = v === "fit" ? "0.45" : "1"; });
    const orientSeg = segmented([{ v: "auto", label: "Auto" }, { v: "p", label: "Portrait" }, { v: "l", label: "Landscape" }], orient, v => { orient = v; });
    const marginSeg = segmented([{ v: 0, label: "None" }, { v: 3, label: "Small" }, { v: 8, label: "Wide" }], marginPct, v => { marginPct = v; });

    const drop = makeDrop({ accept: "image", multiple: true, big: "Drop images here", sub: "JPG, PNG, WebP, GIF or BMP. They'll become PDF pages in order.", onFiles: addImgs });
    const dropMore = makeDrop({ accept: "image", multiple: true, compact: true, big: "Add more images", sub: "", onFiles: addImgs });
    dropMore.classList.add("hidden");

    ctx.body.append(drop, dropMore, list,
      optSection("Page setup", h("div", { class: "opt-row" }, sizeSeg.el, orientSeg.el, marginSeg.el)));

    function addImgs(recs) {
      for (const rec of recs) imgs.push({ rec, url: URL.createObjectURL(new Blob([rec.buf])) });
      render();
    }
    function render() {
      list.innerHTML = "";
      imgs.forEach((im, i) => {
        list.append(h("div", { class: "fchip" },
          h("span", { class: "updown" },
            h("button", { title: "Move up", onclick: () => { if (i > 0) { imgs.splice(i - 1, 0, imgs.splice(i, 1)[0]); render(); } } }, "▲"),
            h("button", { title: "Move down", onclick: () => { if (i < imgs.length - 1) { imgs.splice(i + 1, 0, imgs.splice(i, 1)[0]); render(); } } }, "▼")),
          h("img", { src: im.url, style: "width:34px;height:34px;object-fit:cover;border-radius:6px;border:1px solid var(--line)" }),
          h("span", { class: "fname" }, im.rec.name),
          h("span", { class: "fmeta" }, PDCore.fmtBytes(im.rec.size)),
          h("button", { class: "iconbtn x", title: "Remove", onclick: () => { imgs.splice(i, 1); render(); } }, icon("close"))));
      });
      drop.classList.toggle("hidden", imgs.length > 0);
      dropMore.classList.toggle("hidden", imgs.length === 0);
      bar.setSummary(imgs.length ? imgs.length + " image" + (imgs.length === 1 ? "" : "s") + " → " + imgs.length + " pages" : "");
      bar.enable(imgs.length > 0);
    }

    async function toEmbeddable(rec) {
      const head = new Uint8Array(rec.buf.slice(0, 4));
      const isJpg = head[0] === 0xff && head[1] === 0xd8;
      const isPng = head[0] === 0x89 && head[1] === 0x50;
      if (isJpg || isPng) return { bytes: new Uint8Array(rec.buf.slice(0)), isPng };
      // decode via browser, re-encode as PNG
      const img = new Image();
      const url = URL.createObjectURL(new Blob([rec.buf]));
      try {
        await new Promise((res, rej) => { img.onload = res; img.onerror = () => rej(new Error(rec.name + ": this image format can't be decoded here")); img.src = url; });
        const c = document.createElement("canvas");
        c.width = img.naturalWidth; c.height = img.naturalHeight;
        c.getContext("2d").drawImage(img, 0, 0);
        const blob = await new Promise(r => c.toBlob(r, "image/png"));
        return { bytes: new Uint8Array(await blob.arrayBuffer()), isPng: true };
      } finally { URL.revokeObjectURL(url); }
    }

    function run() {
      const snapshot = imgs.slice();
      runJob(ctx, "Building PDF", async prog => {
        const prepared = [];
        for (let i = 0; i < snapshot.length; i++) {
          prog.set(i / (snapshot.length + 1), "Preparing " + snapshot[i].rec.name, (i + 1) + " / " + snapshot.length);
          prepared.push(await toEmbeddable(snapshot[i].rec));
        }
        prog.set(0.94, "Assembling PDF");
        return await PDCore.imagesToPdf(prepared, { pageSize, orient, marginPct });
      }, bytes => ({
        files: [{ name: (snapshot.length === 1 ? snapshot[0].rec.name.replace(/\.[^.]+$/, "") : "images") + ".pdf", bytes, mime: "application/pdf" }],
        opts: { title: "PDF created" },
      }));
    }
  },
});

/* =============== PDF -> IMAGES =============== */
registerTool({
  id: "pdf2img", name: "PDF to images", icon: "pdf2img",
  desc: "Export pages as PNG or JPG",
  build(ctx) {
    singlePdfTool(ctx, { needProbe: false }, async (rec) => {
      // probe with pdf.js for page count (handles encrypted-with-password too)
      let doc;
      try { doc = await openPdf(rec); } catch (e) { errorBack(ctx.body, new Error("Could not open this PDF."), ctx.restart); return; }
      const pages = doc.numPages;
      closePdf(doc);

      const bar = actionBar(pages + " pages", "Export images", run);
      ctx.setCleanup(() => bar.el.remove());
      document.body.append(bar.el);
      let format = "png", dpi = 150, outMode = "files";
      const qualS = slider(30, 95, 5, 80, v => v + "%", null);
      const qualRow = h("div", { class: "opt-row hidden" }, h("span", { class: "muted", style: "font-size:13px" }, "JPG quality"), qualS.el);
      const fmtSeg = segmented([{ v: "png", label: "PNG" }, { v: "jpeg", label: "JPG" }], format, v => { format = v; qualRow.classList.toggle("hidden", v !== "jpeg"); });
      const outSeg = segmented([{ v: "files", label: "One file per page" }, { v: "long", label: "Single long image" }], outMode, v => { outMode = v; });
      const dpiSeg = segmented([{ v: 72, label: "72 DPI · screen" }, { v: 150, label: "150 DPI · sharp" }, { v: 300, label: "300 DPI · print" }], dpi, v => { dpi = v; });
      const rangeInput = h("input", { class: "range", placeholder: "all pages · e.g. 1-3", style: "width:170px" });
      rangeInput.addEventListener("input", debounce(update, 250));

      ctx.body.append(
        filePill(rec, pages + " pages", ctx.restart),
        optSection("Format", h("div", { class: "opt-row" }, fmtSeg.el), h("div", { class: "opt-row", style: "margin-top:8px" }, outSeg.el), qualRow),
        optSection("Resolution", h("div", { class: "opt-row" }, dpiSeg.el)),
        optSection("Pages", h("div", { class: "opt-row" }, rangeInput)));
      update();

      function indices() {
        if (!rangeInput.value.trim()) return Array.from({ length: pages }, (_, i) => i);
        return PDCore.parsePageSet(rangeInput.value, pages);
      }
      function update() {
        try {
          const k = indices().length;
          rangeInput.classList.remove("bad");
          bar.setSummary(k + " page" + (k === 1 ? "" : "s") + " → " + k + " image" + (k === 1 ? "" : "s"));
          bar.enable(k > 0);
        } catch (e) {
          rangeInput.classList.add("bad");
          bar.setSummary(e.message);
          bar.enable(false);
        }
      }

      function run() {
        let idx;
        try { idx = indices(); } catch (e) { toast(e.message, "err"); return; }
        const base = PDCore.baseName(rec.name);
        const ext = format === "png" ? "png" : "jpg";
        runJob(ctx, "Exporting", async prog => {
          const d = await openPdf(rec);
          try {
            if (outMode === "long") {
              const canvases = [];
              let maxW = 0, totalH = 0;
              for (let k = 0; k < idx.length; k++) {
                prog.set(k / (idx.length + 1), "Rendering page " + (idx[k] + 1), (k + 1) + " / " + idx.length);
                const r = await renderPageToCanvas(d, idx[k] + 1, 0, { dpi });
                canvases.push(r.canvas);
                maxW = Math.max(maxW, r.canvas.width);
                totalH += r.canvas.height;
              }
              let scale = 1;
              if (totalH > 32000) scale = 32000 / totalH;
              const big = document.createElement("canvas");
              big.width = Math.round(maxW * scale);
              big.height = Math.round(totalH * scale);
              const bc = big.getContext("2d", { alpha: false });
              bc.fillStyle = "#fff"; bc.fillRect(0, 0, big.width, big.height);
              let yy = 0;
              for (const c of canvases) {
                bc.drawImage(c, Math.round((maxW - c.width) / 2 * scale), Math.round(yy), Math.round(c.width * scale), Math.round(c.height * scale));
                yy += c.height * scale;
                c.width = 1; c.height = 1;
              }
              prog.set(0.96, "Encoding image");
              const blob = await new Promise(res => big.toBlob(res, "image/" + format, format === "jpeg" ? qualS.get() / 100 : undefined));
              return { outs: [{ name: base + "-long." + ext, bytes: new Uint8Array(await blob.arrayBuffer()), mime: "image/" + format }], capped: scale < 1 };
            }
            const outs = [];
            let capped = false;
            for (let k = 0; k < idx.length; k++) {
              const pno = idx[k] + 1;
              prog.set(k / idx.length, "Rendering page " + pno, (k + 1) + " / " + idx.length);
              const r = await renderPageToCanvas(d, pno, 0, { dpi });
              capped = capped || r.capped;
              const blob = await new Promise(res => r.canvas.toBlob(res, "image/" + format, format === "jpeg" ? qualS.get() / 100 : undefined));
              outs.push({ name: base + "-p" + pno + "." + ext, bytes: new Uint8Array(await blob.arrayBuffer()), mime: "image/" + format });
              r.canvas.width = 1; r.canvas.height = 1;
            }
            return { outs, capped };
          } finally { closePdf(d); }
        }, res => ({
          files: res.outs,
          opts: {
            title: res.outs.length + " image" + (res.outs.length === 1 ? "" : "s") + " exported",
            zipName: base + "-images.zip",
            meta: res.capped ? "Some very large pages were capped at 8000px on the long side." : null,
          },
        }));
      }
    });
  },
});

/* =============== VIEWER (reader-grade: search, text selection, print) =============== */
registerTool({
  id: "view", name: "View a PDF", icon: "view",
  desc: "Read, search, select, print",
  build(ctx) {
    singlePdfTool(ctx, { needProbe: false, big: "Drop a PDF to read" }, async (rec) => {
      let doc;
      try { doc = await openPdf(rec); } catch (e) { errorBack(ctx.body, new Error("Could not open this PDF."), ctx.restart); return; }
      const n = doc.numPages;
      let zoom = 0, fitWidth = true;
      const holders = [];
      let io = null, dead = false;
      const textCache = new Map();       // pageIdx -> textContent
      let matches = [], curMatch = -1, query = "";

      const pageNum = h("input", { type: "number", min: 1, max: n, value: 1 });
      const zoomLabel = h("span", { class: "zoomval" }, "fit");
      const pagesEl = h("div", { class: "viewer-pages" });

      /* search UI */
      const searchInput = h("input", { id: "pdfind", type: "text", placeholder: "Find in document  (Ctrl+F)", style: "width:min(210px,40vw);padding:6px 10px;border:1px solid var(--line);border-radius:8px;background:var(--surface);font-size:12.5px" });
      const matchInfo = h("span", { id: "pdfindinfo", class: "muted", style: "font-size:12px;min-width:56px;text-align:center;font-variant-numeric:tabular-nums" }, "");
      const prevBtn = h("button", { class: "iconbtn", title: "Previous match (Shift+Enter)", onclick: () => matches.length && gotoMatch(curMatch - 1) }, icon("up"));
      const nextBtn = h("button", { class: "iconbtn", title: "Next match (Enter)", onclick: () => matches.length && gotoMatch(curMatch + 1) }, icon("down"));
      const printBtn = h("button", { class: "btn secondary", style: "height:32px;padding:0 12px;font-size:12.5px", onclick: doPrint }, "Print");

      const barEl = h("div", { class: "viewer-bar" },
        h("span", { class: "pageinfo" }, "Page", pageNum, "of " + n),
        h("span", { class: "sep", style: "width:1px;height:20px;background:var(--line);margin:0 4px" }),
        searchInput, prevBtn, nextBtn, matchInfo,
        h("span", { style: "flex:1" }),
        h("button", { class: "iconbtn", title: "Zoom out", onclick: () => setZoom((zoom || currentFit()) / 1.2, false) }, icon("minus")),
        zoomLabel,
        h("button", { class: "iconbtn", title: "Zoom in", onclick: () => setZoom((zoom || currentFit()) * 1.2, false) }, icon("plus")),
        h("button", { class: "btn secondary", style: "height:32px;padding:0 12px;font-size:12.5px", onclick: () => setZoom(0, true) }, "Fit"),
        printBtn);
      ctx.body.append(filePill(rec, n + " pages · " + PDCore.fmtBytes(rec.size), ctx.restart), barEl, pagesEl);

      const meta = [];
      for (let i = 1; i <= n; i++) {
        const holder = h("div", { class: "vpage" });
        holders.push(holder);
        pagesEl.append(holder);
      }
      const first = await doc.getPage(1);
      const vp1 = first.getViewport({ scale: 1 });
      function currentFit() {
        const w = pagesEl.clientWidth - 2 * parseFloat(getComputedStyle(pagesEl).paddingLeft || "24");
        return Math.max(0.2, Math.min(4, w / vp1.width));
      }
      function effZoom() { return fitWidth || !zoom ? currentFit() : zoom; }

      async function pageText(i) {
        if (!textCache.has(i)) {
          const p = await doc.getPage(i + 1);
          textCache.set(i, await p.getTextContent());
        }
        return textCache.get(i);
      }

      async function layout() {
        const z = effZoom();
        zoomLabel.textContent = fitWidth ? "fit" : Math.round(z * 100) + "%";
        for (let i = 0; i < n; i++) {
          const holder = holders[i];
          holder.dataset.rendered = "";
          holder.innerHTML = "";
          const m = meta[i];
          holder.style.width = (m ? m.w : vp1.width) * z + "px";
          holder.style.height = (m ? m.h : vp1.height) * z + "px";
        }
        observe();
      }
      function observe() {
        if (io) io.disconnect();
        io = new IntersectionObserver(entries => {
          for (const en of entries) if (en.isIntersecting) renderHolder(holders.indexOf(en.target));
        }, { rootMargin: "700px 0px" });
        holders.forEach(hd => io.observe(hd));
      }
      const rendering = new Set();
      async function renderHolder(i) {
        if (i < 0 || dead) return;
        const holder = holders[i];
        const z = effZoom();
        const key = i + "@" + z.toFixed(3);
        if (holder.dataset.rendered === key || rendering.has(i)) return;
        rendering.add(i);
        try {
          const page = await doc.getPage(i + 1);
          const bvp = page.getViewport({ scale: 1 });
          meta[i] = { w: bvp.width, h: bvp.height };
          const dpr = Math.min(window.devicePixelRatio || 1, 2);
          const vp = page.getViewport({ scale: z * dpr });
          const cssVp = page.getViewport({ scale: z });
          const canvas = document.createElement("canvas");
          canvas.width = Math.round(vp.width); canvas.height = Math.round(vp.height);
          const cctx = canvas.getContext("2d", { alpha: false });
          cctx.fillStyle = "#fff"; cctx.fillRect(0, 0, canvas.width, canvas.height);
          await page.render({ canvasContext: cctx, viewport: vp }).promise;
          if (dead) { rendering.delete(i); return; }
          holder.style.width = bvp.width * z + "px";
          holder.style.height = bvp.height * z + "px";
          holder.innerHTML = "";
          holder.append(canvas);
          holder._vp = cssVp;
          const hlL = h("div", { class: "hl-layer" });
          const tl = h("div", { class: "textLayer" });
          holder.append(hlL, tl);
          try {
            const tc = await pageText(i);
            const task = pdfjsLib.renderTextLayer({ textContent: tc, textContentSource: tc, container: tl, viewport: cssVp, textDivs: [] });
            if (task && task.promise) await task.promise;
          } catch (e) { /* text layer is best-effort */ }
          holder.dataset.rendered = key;
          drawHighlights(i);
        } catch (e) { /* page render failed */ }
        rendering.delete(i);
      }
      function setZoom(v, fit) {
        fitWidth = fit;
        zoom = fit ? 0 : Math.max(0.2, Math.min(4, v));
        layout();
      }

      /* ---- search ---- */
      function drawHighlights(i) {
        const holder = holders[i];
        const hl = holder.querySelector(".hl-layer");
        if (!hl || !holder._vp) return;
        hl.innerHTML = "";
        if (!query || query.length < 2) return;
        const tc = textCache.get(i);
        if (!tc) return;
        const z = effZoom();
        for (let mi = 0; mi < matches.length; mi++) {
          const m = matches[mi];
          if (m.page !== i) continue;
          const it = tc.items[m.item];
          if (!it) continue;
          const tx = pdfjsLib.Util.transform(holder._vp.transform, it.transform);
          const hgt = Math.hypot(tx[2], tx[3]) || 10;
          hl.append(h("div", {
            class: "hl" + (mi === curMatch ? " cur" : ""),
            style: "left:" + tx[4] + "px;top:" + (tx[5] - hgt) + "px;width:" + Math.max(4, it.width * z) + "px;height:" + hgt + "px",
          }));
        }
      }
      function refreshAllHighlights() { for (let i = 0; i < n; i++) if (holders[i].dataset.rendered) drawHighlights(i); }
      let searchSeq = 0;
      const runSearch = debounce(async () => {
        const seq = ++searchSeq;
        query = searchInput.value.trim().toLowerCase();
        matches = []; curMatch = -1;
        if (query.length < 2) { matchInfo.textContent = ""; refreshAllHighlights(); return; }
        matchInfo.textContent = "…";
        for (let i = 0; i < n; i++) {
          if (dead || seq !== searchSeq) return;
          const tc = await pageText(i);
          tc.items.forEach((it, k) => { if (it.str && it.str.toLowerCase().includes(query)) matches.push({ page: i, item: k }); });
        }
        if (seq !== searchSeq) return;
        matchInfo.textContent = matches.length ? "0 / " + matches.length : "0 found";
        refreshAllHighlights();
        if (matches.length) gotoMatch(0);
      }, 300);
      function gotoMatch(m) {
        if (!matches.length) return;
        curMatch = ((m % matches.length) + matches.length) % matches.length;
        matchInfo.textContent = (curMatch + 1) + " / " + matches.length;
        const mt = matches[curMatch];
        holders[mt.page].scrollIntoView({ block: "center", behavior: "smooth" });
        renderHolder(mt.page);
        refreshAllHighlights();
      }
      searchInput.addEventListener("input", runSearch);
      searchInput.addEventListener("keydown", e => {
        e.stopPropagation();
        if (e.key === "Enter") { e.preventDefault(); matches.length && gotoMatch(curMatch + (e.shiftKey ? -1 : 1)); }
        if (e.key === "Escape") { searchInput.value = ""; runSearch(); searchInput.blur(); }
      });
      const keyHandler = e => {
        if (!currentView || currentView.id !== "view") return;
        if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "f") { e.preventDefault(); searchInput.focus(); searchInput.select(); }
        if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "p") { e.preventDefault(); doPrint(); }
      };
      document.addEventListener("keydown", keyHandler);

      /* ---- print ---- */
      let printing = false;
      async function doPrint() {
        if (printing) return;
        printing = true;
        printBtn.setAttribute("disabled", "");
        try {
          const cap = 200;
          const count = Math.min(n, cap);
          if (n > cap) toast("Printing the first " + cap + " pages");
          let box = document.getElementById("printbox");
          if (!box) { box = h("div", { id: "printbox" }); document.body.append(box); }
          box.innerHTML = "";
          toast("Preparing " + count + " page" + (count === 1 ? "" : "s") + " for printing…");
          for (let i = 1; i <= count && !dead; i++) {
            const r = await renderPageToCanvas(doc, i, 0, { dpi: 150 });
            const img = document.createElement("img");
            img.src = r.canvas.toDataURL("image/jpeg", 0.92);
            box.append(img);
            r.canvas.width = 1; r.canvas.height = 1;
          }
          window.print();
          setTimeout(() => { box.innerHTML = ""; }, 3000);
        } finally {
          printing = false;
          printBtn.removeAttribute("disabled");
        }
      }

      /* current page tracking */
      const pageIO = new IntersectionObserver(entries => {
        for (const en of entries) if (en.isIntersecting) {
          const idx = holders.indexOf(en.target);
          if (idx >= 0) pageNum.value = idx + 1;
        }
      }, { threshold: 0.4 });
      holders.forEach(hd => pageIO.observe(hd));
      ctx.setCleanup(() => {
        dead = true;
        document.removeEventListener("keydown", keyHandler);
        pageIO.disconnect();
        if (io) io.disconnect();
        closePdf(doc);
        const box = document.getElementById("printbox");
        if (box) box.innerHTML = "";
      });
      pageNum.addEventListener("change", () => {
        const v = Math.max(1, Math.min(n, parseInt(pageNum.value, 10) || 1));
        holders[v - 1].scrollIntoView({ behavior: "smooth", block: "start" });
      });
      let rT;
      window.addEventListener("resize", () => { if (fitWidth) { clearTimeout(rT); rT = setTimeout(layout, 200); } });
      layout();
    });
  },
});
