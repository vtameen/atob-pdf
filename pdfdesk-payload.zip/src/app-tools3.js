/* PDFDesk v3.1 — LightPDF-parity tools: delete pages, crop, converters, flatten */
"use strict";

Object.assign(ICONS, {
  delpages: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M6 3h8l5 5v13H6z"/><path d="M14 3v5h5"/><path d="m9.5 12 5 5m0-5-5 5"/></svg>',
  crop: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M6 2v16a2 2 0 0 0 2 2h14"/><path d="M2 6h16a2 2 0 0 1 2 2v14"/></svg>',
  totext: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19V4h9l4 4v3"/><path d="M13 4v4h4"/><path d="M12 14h9M12 17.5h9M12 21h6"/></svg>',
  toword: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19V4h9l4 4v3"/><path d="M13 4v4h4"/><path d="m11 14 2 7 2.5-5.5L18 21l2-7"/></svg>',
  fromword: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="m3 10 2 7 2.5-5.5L10 17l2-7"/><path d="M14 21h6V9l-4-4h-2z" opacity="0.9"/><path d="M16 5v4h4"/></svg>',
  fromtxt: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6V4h9v2M7.5 4v10M5.5 14h4"/><path d="M14 21h6V9l-4-4h-2z"/><path d="M16 5v4h4"/></svg>',
  flatten: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="m12 3 9 5-9 5-9-5z"/><path d="m5.5 12.5 -2.5 1.5 9 5 9-5-2.5-1.5"/></svg>',
});

/* =============== DELETE PAGES =============== */
registerTool({
  id: "delete", name: "Delete pages", icon: "delpages",
  desc: "Remove selected pages",
  build(ctx) {
    singlePdfTool(ctx, {}, async (rec, pages) => {
      const { grid, items } = await buildThumbGrid(ctx, rec, { selectable: true });
      const bar = actionBar("", "Delete pages", run);
      document.body.append(bar.el);
      const count = h("span", { class: "count" }, "");
      let lastClicked = -1;
      function setSel(it, v) { it.sel = v; it.el.classList.toggle("sel", v); }
      function refresh() {
        const c = items.filter(i => i.sel).length;
        count.textContent = c + " marked for deletion";
        bar.setSummary(c ? c + " of " + items.length + " pages will be removed" : "Select the pages to remove");
        bar.enable(c > 0 && c < items.length);
        if (c === items.length) bar.setSummary("You can't delete every page");
        bar.setLabel(c ? "Delete " + c + " page" + (c === 1 ? "" : "s") : "Delete pages");
      }
      items.forEach((it, i) => it.el.addEventListener("click", e => {
        if (e.shiftKey && lastClicked >= 0) {
          const [a, b] = [Math.min(lastClicked, i), Math.max(lastClicked, i)];
          for (let k = a; k <= b; k++) setSel(items[k], true);
        } else setSel(it, !it.sel);
        lastClicked = i;
        refresh();
      }));
      ctx.body.append(
        filePill(rec, pages + " pages", ctx.restart),
        h("div", { class: "thumb-toolbar" },
          h("button", { class: "btn secondary", style: "height:32px;padding:0 12px;font-size:12.5px", onclick: () => { items.forEach(i => setSel(i, false)); refresh(); } }, "Clear"),
          h("button", { class: "btn secondary", style: "height:32px;padding:0 12px;font-size:12.5px", onclick: () => { items.forEach(i => setSel(i, !i.sel)); refresh(); } }, "Invert"),
          h("span", { class: "spacer" }), count),
        grid);
      refresh();
      function run() {
        const keep = items.filter(i => !i.sel).map(i => i.idx);
        runJob(ctx, "Deleting", async prog => {
          prog.set(0.5, "Rebuilding with " + keep.length + " pages");
          return await PDCore.extractPages(bytesOf(rec), keep);
        }, bytes => ({
          files: [{ name: PDCore.baseName(rec.name) + "-pages-removed.pdf", bytes, mime: "application/pdf" }],
          opts: { title: (pages - keep.length) + " page" + (pages - keep.length === 1 ? "" : "s") + " removed" },
        }));
      }
    });
  },
});

/* =============== CROP =============== */
registerTool({
  id: "crop", name: "Crop", icon: "crop",
  desc: "Trim page margins",
  hint: "Drag a box on the preview, apply to any pages",
  build(ctx) {
    singlePdfTool(ctx, {}, async (rec, pages) => {
      const bar = actionBar(pages + " pages", "Crop PDF", run);
      ctx.setCleanup(() => bar.el.remove());
      document.body.append(bar.el);
      let pageW = 595, pageH = 842, pvScale = 1, box = null; // box in display pts (top-origin)
      const canvas = document.createElement("canvas");
      const shade = h("div", { style: "position:absolute;inset:0" });
      const rectEl = h("div", { class: "ed-rubber", style: "display:none;box-shadow:0 0 0 9999px oklch(0.2 0.01 75 / 0.45)" });
      const overlay = h("div", { style: "position:absolute;inset:0;cursor:crosshair;overflow:hidden" }, rectEl);
      const frame = h("div", { class: "frame", style: "position:relative;width:max-content;max-width:100%" }, canvas, overlay);
      const pvWrap = h("div", { class: "preview-wrap" }, frame, h("div", { class: "cap" }, "Drag to choose the crop area · page 1 preview"));
      let scope = "all";
      const rangeInput = h("input", { class: "range hidden", placeholder: "e.g. 2, 5-7", style: "width:170px" });
      const scopeSeg = segmented([{ v: "all", label: "All pages" }, { v: "custom", label: "Custom range" }], scope,
        v => { scope = v; rangeInput.classList.toggle("hidden", v !== "custom"); update(); });
      rangeInput.addEventListener("input", debounce(update, 250));

      overlay.addEventListener("pointerdown", e => {
        e.preventDefault();
        const r = overlay.getBoundingClientRect();
        const live = r.width > 0 ? r.width / pageW : pvScale; // CSS may shrink the canvas
        const sx = e.clientX - r.left, sy = e.clientY - r.top;
        const move = ev => {
          const x = Math.max(0, Math.min(r.width, ev.clientX - r.left));
          const y = Math.max(0, Math.min(r.height, ev.clientY - r.top));
          const bx = Math.min(sx, x), by = Math.min(sy, y);
          const bw = Math.abs(x - sx), bh = Math.abs(y - sy);
          rectEl.style.display = "block";
          rectEl.style.left = bx + "px"; rectEl.style.top = by + "px";
          rectEl.style.width = bw + "px"; rectEl.style.height = bh + "px";
          box = { x: bx / live, y: by / live, w: bw / live, h: bh / live };
        };
        const up = () => { window.removeEventListener("pointermove", move); window.removeEventListener("pointerup", up); update(); };
        window.addEventListener("pointermove", move);
        window.addEventListener("pointerup", up);
      });

      function indices() {
        if (scope === "all") return null;
        return PDCore.parsePageSet(rangeInput.value, pages);
      }
      function update() {
        try {
          const k = scope === "all" ? pages : indices().length;
          rangeInput.classList.remove("bad");
          const ok = box && box.w > 20 && box.h > 20;
          bar.enable(ok);
          bar.setSummary(ok ? "Crop " + Math.round(box.w) + "×" + Math.round(box.h) + " pt on " + k + " page" + (k === 1 ? "" : "s") : "Drag a crop area on the preview");
        } catch (e) { rangeInput.classList.add("bad"); bar.enable(false); bar.setSummary(e.message); }
      }
      ctx.body.append(
        filePill(rec, pages + " pages", ctx.restart),
        h("div", { class: "preview-cols" },
          h("div", { class: "opts" },
            optSection("Apply to", h("div", { class: "opt-row" }, scopeSeg.el, rangeInput),
              h("div", { class: "opt-note" }, "The crop area is taken from page 1 and applied at the same position on the chosen pages. Content outside it is hidden, not deleted."))),
          pvWrap));
      update();
      // render page 1
      try {
        const doc = await openPdf(rec);
        const page = await doc.getPage(1);
        const vp1 = page.getViewport({ scale: 1 });
        pageW = vp1.width; pageH = vp1.height;
        const cssW = Math.min(480, Math.max(300, window.innerWidth * 0.42));
        pvScale = cssW / pageW;
        const dpr = Math.min(window.devicePixelRatio || 1, 2);
        const vp = page.getViewport({ scale: pvScale * dpr });
        canvas.width = Math.round(vp.width); canvas.height = Math.round(vp.height);
        canvas.style.width = cssW + "px";
        const c2 = canvas.getContext("2d", { alpha: false });
        c2.fillStyle = "#fff"; c2.fillRect(0, 0, canvas.width, canvas.height);
        await page.render({ canvasContext: c2, viewport: vp }).promise;
        closePdf(doc);
      } catch (e) { toast("Preview failed", "err"); }

      function run() {
        let idx;
        try { idx = indices(); } catch (e) { toast(e.message, "err"); return; }
        const b = box;
        runJob(ctx, "Cropping", async prog => {
          prog.set(0.5, "Setting crop boxes");
          return await PDCore.cropPdf(bytesOf(rec), b, idx);
        }, bytes => ({
          files: [{ name: PDCore.baseName(rec.name) + "-cropped.pdf", bytes, mime: "application/pdf" }],
          opts: { title: "Cropped" },
        }));
      }
    });
  },
});

/* =============== shared: extract paragraphs per page via MuPDF =============== */
async function extractPageParas(rec, prog, from, to) {
  const mupdf = await loadMuPDF();
  const doc = mupdfOpen(mupdf, bytesOf(rec));
  const n = doc.countPages();
  if (doc.needsPassword && doc.needsPassword()) throw new Error("This PDF is password-protected. Unlock it first.");
  const pageParas = [];
  let totalLines = 0;
  for (let i = 0; i < n; i++) {
    if (prog) prog.set(from + (to - from) * (i / n), "Reading page " + (i + 1), (i + 1) + " / " + n);
    const json = JSON.parse(doc.loadPage(i).toStructuredText().asJSON());
    const { lines } = PDCore.parseStext(json);
    totalLines += lines.length;
    pageParas.push(PDCore.linesToParas(lines));
  }
  return { pageParas, totalLines, pageCount: n };
}

/* =============== EXTRACT TEXT (PDF -> TXT / Markdown) =============== */
registerTool({
  id: "totext", name: "PDF to text", icon: "totext",
  desc: "Extract all text (.txt or .md)",
  build(ctx) {
    singlePdfTool(ctx, { needProbe: false }, (rec) => {
      const bar = actionBar(PDCore.fmtBytes(rec.size), "Extract text", run);
      ctx.setCleanup(() => bar.el.remove());
      document.body.append(bar.el);
      bar.enable(true);
      let fmt = "txt";
      const seg = segmented([{ v: "txt", label: "Plain text (.txt)" }, { v: "md", label: "Markdown (.md)" }], fmt, v => { fmt = v; });
      ctx.body.append(
        filePill(rec, PDCore.fmtBytes(rec.size), ctx.restart),
        optSection("Format", h("div", { class: "opt-row" }, seg.el),
          h("div", { class: "opt-note" }, "Reads the real text in the PDF — instant and exact for digital documents. For scanned pages, use OCR instead.")));
      function run() {
        runJob(ctx, "Extracting", async prog => {
          prog.set(0.05, "Loading text engine (one-time)");
          const { pageParas, totalLines } = await extractPageParas(rec, prog, 0.1, 0.9);
          if (!totalLines) throw new Error("No selectable text found. This looks like a scanned PDF — run OCR on it instead.");
          let out, ext;
          if (fmt === "md") { out = PDCore.parasToMarkdown(pageParas); ext = "md"; }
          else { out = pageParas.map((ps, i) => "--- Page " + (i + 1) + " ---\n\n" + ps.map(p => p.text).join("\n\n")).join("\n\n"); ext = "txt"; }
          return { bytes: new TextEncoder().encode(out), ext, words: out.split(/\s+/).length };
        }, res => ({
          files: [{ name: PDCore.baseName(rec.name) + "." + res.ext, bytes: res.bytes, mime: "text/plain" }],
          opts: { title: "Text extracted", meta: "about " + res.words + " words" },
        }));
      }
    });
  },
});

/* =============== PDF -> WORD =============== */
registerTool({
  id: "toword", name: "PDF to Word", icon: "toword",
  desc: "Export as .docx",
  build(ctx) {
    singlePdfTool(ctx, { needProbe: false }, (rec) => {
      const bar = actionBar(PDCore.fmtBytes(rec.size), "Convert to Word", run);
      ctx.setCleanup(() => bar.el.remove());
      document.body.append(bar.el);
      bar.enable(true);
      ctx.body.append(
        filePill(rec, PDCore.fmtBytes(rec.size), ctx.restart),
        h("div", { class: "opt-note", style: "padding:16px 0" },
          "Converts the document's text — including any language — into an editable Word file with sizes, bold and italics preserved. Complex layouts (columns, tables, floating images) come out as flowing text; no offline converter keeps those perfectly."));
      function run() {
        runJob(ctx, "Converting", async prog => {
          prog.set(0.05, "Loading text engine (one-time)");
          const { pageParas, totalLines } = await extractPageParas(rec, prog, 0.1, 0.9);
          if (!totalLines) throw new Error("No selectable text found. This looks like a scanned PDF — run OCR first, then convert.");
          prog.set(0.95, "Building .docx");
          return PDCore.buildDocx(pageParas);
        }, bytes => ({
          files: [{ name: PDCore.baseName(rec.name) + ".docx", bytes, mime: "application/vnd.openxmlformats-officedocument.wordprocessingml.document" }],
          opts: { title: "Word file ready" },
        }));
      }
    });
  },
});

/* =============== WORD -> PDF =============== */
registerTool({
  id: "fromword", name: "Word to PDF", icon: "fromword", acceptsPdf: false,
  desc: ".docx into a clean PDF",
  build(ctx) {
    ctx.body.append(makeDrop({ accept: "docx", big: "Drop a Word file (.docx)", sub: "Text, sizes, bold and italics carry over. Latin scripts only for now.", onFiles: ([r]) => run(r) }));
    function run(rec) {
      runJob(ctx, "Converting", async prog => {
        prog.set(0.2, "Unpacking document");
        const files = await PDCore.unzipBytes(new Uint8Array(rec.buf.slice(0)));
        const docXml = files["word/document.xml"];
        if (!docXml) throw new Error("That doesn't look like a Word .docx file.");
        prog.set(0.5, "Reading paragraphs");
        const paras = PDCore.docxParas(new TextDecoder().decode(docXml));
        if (!paras.some(p => p.text.trim())) throw new Error("No text found in this document.");
        prog.set(0.75, "Laying out PDF");
        return await PDCore.parasToPdf(paras);
      }, res => ({
        files: [{ name: rec.name.replace(/\.docx$/i, "") + ".pdf", bytes: res.bytes, mime: "application/pdf" }],
        opts: { title: "PDF created", meta: res.replaced ? res.replaced + " non-Latin characters became '?' (full Unicode fonts are on the roadmap)" : null },
      }));
    }
  },
});

/* =============== TXT/MD -> PDF =============== */
registerTool({
  id: "fromtxt", name: "Text to PDF", icon: "fromtxt", acceptsPdf: false,
  desc: ".txt or .md into a PDF",
  build(ctx) {
    ctx.body.append(makeDrop({ accept: "text", big: "Drop a text file (.txt, .md)", sub: "Paragraphs are wrapped and paginated automatically.", onFiles: ([r]) => run(r) }));
    function run(rec) {
      runJob(ctx, "Converting", async prog => {
        prog.set(0.3, "Reading text");
        const text = new TextDecoder().decode(new Uint8Array(rec.buf));
        const paras = PDCore.textToParas(text);
        if (!paras.length) throw new Error("The file is empty.");
        prog.set(0.6, "Laying out PDF");
        return await PDCore.parasToPdf(paras);
      }, res => ({
        files: [{ name: rec.name.replace(/\.(txt|md|markdown)$/i, "") + ".pdf", bytes: res.bytes, mime: "application/pdf" }],
        opts: { title: "PDF created", meta: res.replaced ? res.replaced + " non-Latin characters became '?'" : null },
      }));
    }
  },
});

/* =============== FLATTEN =============== */
registerTool({
  id: "flatten", name: "Flatten", icon: "flatten",
  desc: "Bake forms & annotations flat",
  build(ctx) {
    singlePdfTool(ctx, { needProbe: false }, (rec) => {
      const bar = actionBar(PDCore.fmtBytes(rec.size), "Flatten PDF", run);
      ctx.setCleanup(() => bar.el.remove());
      document.body.append(bar.el);
      bar.enable(true);
      const cAnnot = checkbox("Flatten annotations (highlights, notes, stamps)", true, null);
      const cForms = checkbox("Flatten form fields (answers become permanent)", true, null);
      ctx.body.append(
        filePill(rec, PDCore.fmtBytes(rec.size), ctx.restart),
        optSection("What to flatten", h("div", { class: "opt-row", style: "flex-direction:column;align-items:flex-start;gap:9px" }, cAnnot.el, cForms.el),
          h("div", { class: "opt-note" }, "Flattening merges interactive elements into the page itself, so they can't be edited or hidden — useful before archiving or sharing.")));
      function run() {
        const annots = cAnnot.get(), widgets = cForms.get();
        if (!annots && !widgets) { toast("Pick at least one thing to flatten"); return; }
        runJob(ctx, "Flattening", async prog => {
          prog.set(0.15, "Loading engine (one-time)");
          const mupdf = await loadMuPDF();
          prog.set(0.6, "Baking content");
          const doc = mupdfOpen(mupdf, bytesOf(rec));
          if (doc.needsPassword()) throw new Error("This PDF is password-protected. Unlock it first.");
          doc.bake(annots, widgets);
          return doc.saveToBuffer("garbage=compact").asUint8Array();
        }, bytes => ({
          files: [{ name: PDCore.baseName(rec.name) + "-flattened.pdf", bytes, mime: "application/pdf" }],
          opts: { title: "Flattened" },
        }));
      }
    });
  },
});
