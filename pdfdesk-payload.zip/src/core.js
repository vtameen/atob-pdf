/* PDFDesk core — pure PDF operations on top of pdf-lib (global PDFLib).
   Runs in browser and Node (for tests). No DOM usage in this file. */
(function (root, factory) {
  if (typeof module === "object" && module.exports) module.exports = factory();
  else root.PDCore = factory();
})(typeof self !== "undefined" ? self : globalThis, function () {
  "use strict";

  function lib() {
    const L = (typeof self !== "undefined" ? self : globalThis).PDFLib;
    if (!L) throw new Error("pdf-lib not loaded");
    return L;
  }

  /* ---------------- page range parsing ---------------- */
  // "1-3, 5, 8-" -> groups of 0-based index arrays. Throws {code:'RANGE', message}
  function parseRangeGroups(str, numPages) {
    const s = String(str || "").trim();
    if (!s) throw rangeErr("Enter a page range, e.g. 1-3, 5");
    const groups = [];
    for (let part of s.split(",")) {
      part = part.trim();
      if (!part) continue;
      const m = part.match(/^(\d+)?\s*-\s*(\d+)?$|^(\d+)$/);
      if (!m) throw rangeErr('"' + part + '" is not a page or range');
      let a, b;
      if (m[3] !== undefined) { a = b = parseInt(m[3], 10); }
      else {
        if (m[1] === undefined && m[2] === undefined) throw rangeErr('"-" needs at least one page number');
        a = m[1] !== undefined ? parseInt(m[1], 10) : 1;
        b = m[2] !== undefined ? parseInt(m[2], 10) : numPages;
      }
      if (a < 1 || b < 1 || a > numPages || b > numPages)
        throw rangeErr("Pages must be between 1 and " + numPages);
      const g = [];
      if (a <= b) { for (let i = a; i <= b; i++) g.push(i - 1); }
      else { for (let i = a; i >= b; i--) g.push(i - 1); }
      groups.push(g);
    }
    if (!groups.length) throw rangeErr("Enter a page range, e.g. 1-3, 5");
    return groups;
  }
  // flat ordered unique set
  function parsePageSet(str, numPages) {
    const seen = new Set(), out = [];
    for (const g of parseRangeGroups(str, numPages))
      for (const i of g) if (!seen.has(i)) { seen.add(i); out.push(i); }
    return out;
  }
  function rangeErr(message) { const e = new Error(message); e.code = "RANGE"; return e; }

  /* ---------------- loading ---------------- */
  async function loadDoc(bytes, opts) {
    const { PDFDocument } = lib();
    try {
      return await PDFDocument.load(bytes, Object.assign({ updateMetadata: false }, opts));
    } catch (err) {
      const msg = String(err && err.message || err);
      if (/encrypted/i.test(msg)) {
        const e = new Error("This PDF is password-protected. Unlock support arrives in Phase 2.");
        e.code = "ENCRYPTED";
        throw e;
      }
      const e = new Error("Could not read this PDF. It may be corrupted.");
      e.code = "PARSE"; e.cause = err;
      throw e;
    }
  }

  /* ---------------- operations ---------------- */
  async function mergePdfs(buffers, rangeStrs, onProgress) {
    const { PDFDocument } = lib();
    const out = await PDFDocument.create();
    for (let f = 0; f < buffers.length; f++) {
      const src = await loadDoc(buffers[f]);
      const n = src.getPageCount();
      let idx;
      if (rangeStrs && rangeStrs[f] && String(rangeStrs[f]).trim()) {
        idx = [];
        for (const g of parseRangeGroups(rangeStrs[f], n)) idx.push.apply(idx, g);
      } else {
        idx = Array.from({ length: n }, (_, i) => i);
      }
      const pages = await out.copyPages(src, idx);
      for (const p of pages) out.addPage(p);
      if (onProgress) onProgress(f + 1, buffers.length);
    }
    return out.save({ useObjectStreams: true });
  }

  async function extractPages(buffer, indices) {
    const { PDFDocument } = lib();
    const src = await loadDoc(buffer);
    const out = await PDFDocument.create();
    const pages = await out.copyPages(src, indices);
    for (const p of pages) out.addPage(p);
    return out.save({ useObjectStreams: true });
  }

  async function splitPdf(buffer, groups, onProgress) {
    const { PDFDocument } = lib();
    const src = await loadDoc(buffer);
    const outs = [];
    for (let i = 0; i < groups.length; i++) {
      const out = await PDFDocument.create();
      const pages = await out.copyPages(src, groups[i]);
      for (const p of pages) out.addPage(p);
      outs.push(await out.save({ useObjectStreams: true }));
      if (onProgress) onProgress(i + 1, groups.length);
    }
    return outs;
  }

  function norm360(d) { return ((d % 360) + 360) % 360; }

  async function rotatePdf(buffer, indices, delta) {
    const { degrees } = lib();
    const doc = await loadDoc(buffer);
    const pages = doc.getPages();
    for (const i of indices) {
      const p = pages[i];
      p.setRotation(degrees(norm360(p.getRotation().angle + delta)));
    }
    return doc.save({ useObjectStreams: true });
  }

  // items: [{srcIdx, rotDelta}] in final order (deleted pages simply absent)
  async function organizePdf(buffer, items) {
    const { PDFDocument, degrees } = lib();
    const src = await loadDoc(buffer);
    const out = await PDFDocument.create();
    const pages = await out.copyPages(src, items.map(it => it.srcIdx));
    for (let i = 0; i < pages.length; i++) {
      const p = pages[i];
      const d = items[i].rotDelta || 0;
      if (d) p.setRotation(degrees(norm360(p.getRotation().angle + d)));
      out.addPage(p);
    }
    return out.save({ useObjectStreams: true });
  }

  async function resavePdf(buffer) {
    const doc = await loadDoc(buffer);
    return doc.save({ useObjectStreams: true });
  }

  /* ---- geometry helpers ---- */
  const MARGINS = { sm: 24, md: 36, lg: 54 };
  // Returns {x,y} bottom-left coords for an element of elW×elH on a W×H page.
  function posXY(pos, W, H, elW, elH, margin) {
    const m = margin == null ? MARGINS.md : margin;
    let x, y;
    switch (pos[1]) {
      case "l": x = m; break;
      case "r": x = W - m - elW; break;
      default: x = (W - elW) / 2;
    }
    switch (pos[0]) {
      case "t": y = H - m - elH; break;
      case "b": y = m; break;
      default: y = (H - elH) / 2;
    }
    return { x, y };
  }
  function hexToRgb01(hex) {
    const h = hex.replace("#", "");
    const v = h.length === 3 ? h.split("").map(c => c + c).join("") : h;
    return {
      r: parseInt(v.slice(0, 2), 16) / 255,
      g: parseInt(v.slice(2, 4), 16) / 255,
      b: parseInt(v.slice(4, 6), 16) / 255,
    };
  }

  /* effective (rotation-aware) page box: width/height as displayed */
  function effSize(page) {
    const rot = norm360(page.getRotation().angle);
    const { width, height } = page.getSize();
    return rot === 90 || rot === 270 ? { w: height, h: width, rot } : { w: width, h: height, rot };
  }

  /* Convert display-space coords (origin bottom-left of the page AS VIEWED)
     into raw pdf coords + rotation for drawing on a rotated page. */
  function displayToRaw(page, dx, dy, angleDeg) {
    const rot = norm360(page.getRotation().angle);
    const { width: W, height: H } = page.getSize(); // raw box
    let x, y, a;
    switch (rot) {
      case 90:  x = W - dy; y = dx; a = angleDeg + 90; break;
      case 180: x = W - dx; y = H - dy; a = angleDeg + 180; break;
      case 270: x = dy; y = H - dx; a = angleDeg - 90; break;
      default:  x = dx; y = dy; a = angleDeg;
    }
    return { x, y, a };
  }

  /* ---------------- page numbers ---------------- */
  const NUM_FORMATS = {
    n:   (n, t) => String(n),
    nt:  (n, t) => n + " / " + t,
    pn:  (n, t) => "Page " + n,
    pnt: (n, t) => "Page " + n + " of " + t,
  };

  async function addPageNumbers(buffer, o) {
    const { StandardFonts, rgb, degrees } = lib();
    const doc = await loadDoc(buffer);
    const font = await doc.embedFont(StandardFonts.Helvetica);
    const pages = doc.getPages();
    const total = pages.length;
    const fmt = NUM_FORMATS[o.format] || NUM_FORMATS.n;
    const col = hexToRgb01(o.color || "#4b4640");
    const size = o.size || 11;
    const margin = MARGINS[o.margin || "md"];
    const targets = o.indices || pages.map((_, i) => i);
    let shown = o.start != null ? o.start : 1;
    for (const i of targets) {
      if (o.skipFirst && i === 0) { shown++; continue; }
      const p = pages[i];
      const text = fmt(shown, total);
      const w = font.widthOfTextAtSize(text, size);
      const h = size * 0.72;
      const e = effSize(p);
      const { x, y } = posXY(o.pos || "bc", e.w, e.h, w, h, margin);
      const r = displayToRaw(p, x, y, 0);
      p.drawText(text, { x: r.x, y: r.y, size, font, color: rgb(col.r, col.g, col.b), rotate: degrees(r.a) });
      shown++;
    }
    return doc.save({ useObjectStreams: true });
  }

  /* ---------------- watermark ---------------- */
  async function addTextWatermark(buffer, o) {
    const { StandardFonts, rgb, degrees } = lib();
    const doc = await loadDoc(buffer);
    let font;
    try {
      font = await doc.embedFont(StandardFonts.Helvetica);
      // trigger encoding errors early
      font.widthOfTextAtSize(o.text, 10);
    } catch (err) {
      const e = new Error("Watermark text has characters Helvetica can't encode. Use basic Latin text for now.");
      e.code = "ENCODING";
      throw e;
    }
    const col = hexToRgb01(o.color || "#9a9186");
    const size = o.size || 64;
    const angle = o.angle != null ? o.angle : -45;
    const opacity = o.opacity != null ? o.opacity : 0.25;
    const pages = doc.getPages();
    const targets = o.indices || pages.map((_, i) => i);
    const tw = font.widthOfTextAtSize(o.text, size);
    const th = size * 0.72;
    const rad = angle * Math.PI / 180;
    for (const i of targets) {
      const p = pages[i];
      const e = effSize(p);
      const draw = (cx, cy) => {
        // place so the text box center sits at (cx, cy), display space
        const bx = cx - (tw / 2) * Math.cos(rad) + (th / 2) * Math.sin(rad);
        const by = cy - (tw / 2) * Math.sin(rad) - (th / 2) * Math.cos(rad);
        const r = displayToRaw(p, bx, by, angle);
        p.drawText(o.text, {
          x: r.x, y: r.y, size, font,
          color: rgb(col.r, col.g, col.b), opacity,
          rotate: degrees(r.a),
        });
      };
      if (o.tile) {
        const stepX = tw + 110, stepY = Math.max(130, th + 110);
        const diag = Math.sqrt(e.w * e.w + e.h * e.h);
        for (let y = -diag * 0.1; y <= e.h + diag * 0.1; y += stepY)
          for (let x = -diag * 0.1; x <= e.w + diag * 0.1; x += stepX)
            draw(x + tw / 2, y + th / 2);
      } else {
        const m = 46;
        const box = posXY(o.pos || "mc", e.w, e.h, Math.min(tw, e.w - 2 * m), th, m);
        draw(box.x + Math.min(tw, e.w - 2 * m) / 2, box.y + th / 2);
      }
    }
    return doc.save({ useObjectStreams: true });
  }

  async function addImageWatermark(buffer, imgBytes, isPng, o) {
    const doc = await loadDoc(buffer);
    const img = isPng ? await doc.embedPng(imgBytes) : await doc.embedJpg(imgBytes);
    const opacity = o.opacity != null ? o.opacity : 0.4;
    const pages = doc.getPages();
    const targets = o.indices || pages.map((_, i) => i);
    for (const i of targets) {
      const p = pages[i];
      const e = effSize(p);
      const iw = e.w * (o.scalePct || 40) / 100;
      const ih = iw * img.height / img.width;
      const drawAt = (dx, dy) => {
        const r = displayToRaw(p, dx, dy, 0);
        p.drawImage(img, { x: r.x, y: r.y, width: iw, height: ih, opacity, rotate: lib().degrees(r.a) });
      };
      if (o.tile) {
        const stepX = iw + 70, stepY = ih + 70;
        for (let y = -ih / 2; y <= e.h; y += stepY)
          for (let x = -iw / 2; x <= e.w; x += stepX) drawAt(x, y);
      } else {
        const box = posXY(o.pos || "mc", e.w, e.h, iw, ih, 40);
        drawAt(box.x, box.y);
      }
    }
    return doc.save({ useObjectStreams: true });
  }

  /* ---------------- images -> pdf ---------------- */
  const PAGE_SIZES = { a4: [595.28, 841.89], letter: [612, 792] };

  async function imagesToPdf(images, o) {
    const { PDFDocument } = lib();
    const doc = await PDFDocument.create();
    const marginPct = o.marginPct || 0;
    for (const im of images) {
      const img = im.isPng ? await doc.embedPng(im.bytes) : await doc.embedJpg(im.bytes);
      let pw, ph;
      if (o.pageSize === "fit") {
        pw = img.width * 0.75; ph = img.height * 0.75; // px @96dpi -> pt
      } else {
        const base = PAGE_SIZES[o.pageSize] || PAGE_SIZES.a4;
        let landscape;
        if (o.orient === "p") landscape = false;
        else if (o.orient === "l") landscape = true;
        else landscape = img.width > img.height;
        pw = landscape ? base[1] : base[0];
        ph = landscape ? base[0] : base[1];
      }
      const page = doc.addPage([pw, ph]);
      const m = Math.min(pw, ph) * marginPct / 100;
      const availW = pw - 2 * m, availH = ph - 2 * m;
      const s = Math.min(availW / img.width, availH / img.height);
      const w = img.width * s, h = img.height * s;
      page.drawImage(img, { x: (pw - w) / 2, y: (ph - h) / 2, width: w, height: h });
    }
    return doc.save({ useObjectStreams: true });
  }

  /* ---------------- compressed rebuild ---------------- */
  // pages: [{jpeg:Uint8Array, wPt, hPt}]
  async function rebuildFromJpegs(pages, onProgress) {
    const { PDFDocument } = lib();
    const doc = await PDFDocument.create();
    for (let i = 0; i < pages.length; i++) {
      const pg = pages[i];
      const img = await doc.embedJpg(pg.jpeg);
      const page = doc.addPage([pg.wPt, pg.hPt]);
      page.drawImage(img, { x: 0, y: 0, width: pg.wPt, height: pg.hPt });
      if (onProgress) onProgress(i + 1, pages.length);
    }
    return doc.save({ useObjectStreams: true });
  }

  /* ---------------- zip (store) ---------------- */
  const CRC_TABLE = (() => {
    const t = new Int32Array(256);
    for (let n = 0; n < 256; n++) {
      let c = n;
      for (let k = 0; k < 8; k++) c = c & 1 ? (c >>> 1) ^ 0xedb88320 : c >>> 1;
      t[n] = c;
    }
    return t;
  })();
  function crc32(data) {
    let c = -1;
    for (let i = 0; i < data.length; i++) c = (c >>> 8) ^ CRC_TABLE[(c ^ data[i]) & 0xff];
    return (c ^ -1) >>> 0;
  }
  function dosDateTime(d) {
    d = d || new Date();
    const time = (d.getHours() << 11) | (d.getMinutes() << 5) | (d.getSeconds() >> 1);
    const date = (((d.getFullYear() - 1980) & 0x7f) << 9) | ((d.getMonth() + 1) << 5) | d.getDate();
    return { time, date };
  }
  // entries: [{name, data:Uint8Array}] -> Uint8Array (STORE zip)
  function zipStore(entries) {
    const enc = new TextEncoder();
    const { time, date } = dosDateTime();
    const parts = [], central = [];
    let offset = 0;
    for (const e of entries) {
      const name = enc.encode(e.name);
      const crc = crc32(e.data);
      const lh = new DataView(new ArrayBuffer(30));
      lh.setUint32(0, 0x04034b50, true);
      lh.setUint16(4, 20, true);        // version needed
      lh.setUint16(6, 0x0800, true);    // UTF-8 flag
      lh.setUint16(8, 0, true);         // store
      lh.setUint16(10, time, true);
      lh.setUint16(12, date, true);
      lh.setUint32(14, crc, true);
      lh.setUint32(18, e.data.length, true);
      lh.setUint32(22, e.data.length, true);
      lh.setUint16(26, name.length, true);
      lh.setUint16(28, 0, true);
      parts.push(new Uint8Array(lh.buffer), name, e.data);
      const ch = new DataView(new ArrayBuffer(46));
      ch.setUint32(0, 0x02014b50, true);
      ch.setUint16(4, 20, true);
      ch.setUint16(6, 20, true);
      ch.setUint16(8, 0x0800, true);
      ch.setUint16(10, 0, true);
      ch.setUint16(12, time, true);
      ch.setUint16(14, date, true);
      ch.setUint32(16, crc, true);
      ch.setUint32(20, e.data.length, true);
      ch.setUint32(24, e.data.length, true);
      ch.setUint16(28, name.length, true);
      ch.setUint32(42, offset, true);
      central.push(new Uint8Array(ch.buffer), name);
      offset += 30 + name.length + e.data.length;
    }
    let cdSize = 0;
    for (const c of central) cdSize += c.length;
    const eocd = new DataView(new ArrayBuffer(22));
    eocd.setUint32(0, 0x06054b50, true);
    eocd.setUint16(8, entries.length, true);
    eocd.setUint16(10, entries.length, true);
    eocd.setUint32(12, cdSize, true);
    eocd.setUint32(16, offset, true);
    const total = offset + cdSize + 22;
    const out = new Uint8Array(total);
    let p = 0;
    for (const part of parts) { out.set(part, p); p += part.length; }
    for (const part of central) { out.set(part, p); p += part.length; }
    out.set(new Uint8Array(eocd.buffer), p);
    return out;
  }

  /* ---------------- signature ---------------- */
  // Place an image (signature) centered at display-space point (cx,cy) on one page.
  async function placeSignature(buffer, imgBytes, isPng, o) {
    const { StandardFonts, rgb, degrees } = lib();
    const doc = await loadDoc(buffer);
    const img = isPng ? await doc.embedPng(imgBytes) : await doc.embedJpg(imgBytes);
    const pages = doc.getPages();
    const p = pages[o.pageIdx];
    if (!p) throw new Error("Page " + (o.pageIdx + 1) + " does not exist");
    const w = o.wPt;
    const hgt = w * img.height / img.width;
    const r = displayToRaw(p, o.cx - w / 2, o.cy - hgt / 2, 0);
    p.drawImage(img, { x: r.x, y: r.y, width: w, height: hgt, rotate: degrees(r.a) });
    if (o.dateStr) {
      const font = await doc.embedFont(StandardFonts.Helvetica);
      const size = Math.max(8, Math.min(12, w * 0.055));
      const tw = font.widthOfTextAtSize(o.dateStr, size);
      const rd = displayToRaw(p, o.cx - tw / 2, o.cy - hgt / 2 - size * 1.5, 0);
      p.drawText(o.dateStr, { x: rd.x, y: rd.y, size, font, color: rgb(0.25, 0.24, 0.22), rotate: degrees(rd.a) });
    }
    return doc.save({ useObjectStreams: true });
  }

  /* ---------------- forms ---------------- */
  // Duck-typed: constructor names are mangled in the minified pdf-lib build.
  function fieldKind(f) {
    if (typeof f.isChecked === "function" && typeof f.check === "function") return "check";
    if (typeof f.setText === "function" && typeof f.getText === "function") return "text";
    if (typeof f.getOptions === "function") {
      if (typeof f.isEditable === "function") return "dropdown";
      if (typeof f.isMultiselect === "function") return "optionlist";
      return "radio";
    }
    return "other";
  }
  async function listFormFields(buffer) {
    const doc = await loadDoc(buffer);
    let form;
    try { form = doc.getForm(); } catch (e) { return []; }
    const out = [];
    for (const f of form.getFields()) {
      const kind = fieldKind(f);
      const item = { name: f.getName(), kind };
      try {
        if (kind === "text") { item.value = f.getText() || ""; item.multiline = !!(f.isMultiline && f.isMultiline()); }
        else if (kind === "check") item.value = f.isChecked();
        else if (kind === "radio") { item.options = f.getOptions(); item.value = f.getSelected(); }
        else if (kind === "dropdown") { item.options = f.getOptions(); item.value = (f.getSelected() || [])[0] || ""; }
        else if (kind === "optionlist") { item.options = f.getOptions(); item.value = f.getSelected() || []; }
      } catch (e) { item.error = true; }
      out.push(item);
    }
    return out;
  }
  // entries: [{name, kind, value}]
  async function fillForm(buffer, entries, opts) {
    const { StandardFonts } = lib();
    const doc = await loadDoc(buffer);
    const form = doc.getForm();
    const problems = [];
    for (const e of entries) {
      try {
        if (e.kind === "text") {
          const f = form.getTextField(e.name);
          f.setText(String(e.value == null ? "" : e.value));
        } else if (e.kind === "check") {
          const f = form.getCheckBox(e.name);
          if (e.value) f.check(); else f.uncheck();
        } else if (e.kind === "radio") {
          const f = form.getRadioGroup(e.name);
          if (e.value) f.select(e.value);
        } else if (e.kind === "dropdown") {
          const f = form.getDropdown(e.name);
          if (e.value) f.select(e.value);
        } else if (e.kind === "optionlist") {
          const f = form.getOptionList(e.name);
          f.select(Array.isArray(e.value) ? e.value : [e.value]);
        }
      } catch (err) {
        problems.push(e.name + ": " + (err && err.message || err));
      }
    }
    try {
      const helv = await doc.embedFont(StandardFonts.Helvetica);
      form.updateFieldAppearances(helv);
    } catch (e) { /* appearance regen is best-effort */ }
    if (opts && opts.flatten) {
      try { form.flatten(); }
      catch (e) { problems.push("Flatten failed: " + (e && e.message || e)); }
    }
    const bytes = await doc.save({ useObjectStreams: true });
    return { bytes, problems };
  }

  /* ---------------- OCR overlay ----------------
     pageWords: [{pageIdx, dpi, words:[{text, x0, y0, x1, y1}]}] with coords in
     rendered-image pixels (origin top-left, display orientation). Adds an
     invisible-but-selectable text layer over the original pages. */
  async function ocrOverlay(buffer, pageWords) {
    const { StandardFonts, rgb, degrees } = lib();
    const doc = await loadDoc(buffer);
    const font = await doc.embedFont(StandardFonts.Helvetica);
    const pages = doc.getPages();
    let placed = 0, skipped = 0;
    for (const pw of pageWords) {
      const p = pages[pw.pageIdx];
      if (!p) continue;
      const e = effSize(p);
      const s = 72 / pw.dpi; // image px -> pt
      for (const w of pw.words) {
        const text = (w.text || "").trim();
        if (!text) continue;
        const hPt = Math.max(2, (w.y1 - w.y0) * s);
        const wPt = Math.max(1, (w.x1 - w.x0) * s);
        let size = hPt * 0.92;
        let tw;
        try { tw = font.widthOfTextAtSize(text, size); }
        catch (err) { skipped++; continue; }
        if (tw > 0) size = Math.min(size, size * wPt / tw); // squeeze to box width
        // display-space baseline: bottom of box (y measured from top of image)
        const dx = w.x0 * s;
        const dy = e.h - w.y1 * s + hPt * 0.12;
        const r = displayToRaw(p, dx, dy, 0);
        try {
          p.drawText(text, { x: r.x, y: r.y, size: Math.max(1, size), font, color: rgb(1, 1, 1), opacity: 0, rotate: degrees(r.a) });
          placed++;
        } catch (err) { skipped++; }
      }
    }
    const bytes = await doc.save({ useObjectStreams: true });
    return { bytes, placed, skipped };
  }

  /* ================= Phase 3: editor pipeline =================
     Editor coordinates are TOP-ORIGIN points (matching MuPDF structured text
     and CSS math). Conversions to PDF bottom-origin space happen here. */

  const EDITOR_FONTS = {
    sans: ["Helvetica", "HelveticaBold", "HelveticaOblique", "HelveticaBoldOblique"],
    serif: ["TimesRoman", "TimesRomanBold", "TimesRomanItalic", "TimesRomanBoldItalic"],
    mono: ["Courier", "CourierBold", "CourierOblique", "CourierBoldOblique"],
  };
  async function pickFont(doc, cache, family, bold, italic) {
    const { StandardFonts } = lib();
    const fam = EDITOR_FONTS[family] ? family : "sans";
    const idx = (bold ? 1 : 0) + (italic ? 2 : 0);
    const key = fam + idx;
    if (!cache[key]) cache[key] = await doc.embedFont(StandardFonts[EDITOR_FONTS[fam][idx]]);
    return cache[key];
  }
  function famFromStext(family, style) {
    if (/mono/i.test(family || "")) return "mono";
    if (/serif/i.test(family || "") && !/sans/i.test(family || "")) return "serif";
    return "sans";
  }

  /* pageOps: [{pageIdx, ops:[op...]}] — op.type:
     whiteout {x,y,w,h,color}
     text     {x,y,size,text,color,family,bold,italic}      (y = top of first line)
     editline {baseline,x,size,text,color,family,bold,italic}  (baseline top-origin)
     image    {x,y,w,h,bytes,isPng}
     imgdelete{x,y,w,h}          (visual only here; actual removal via redactRegions)
     rect     {x,y,w,h,stroke,strokeW,fill,opacity}
     ellipse  {x,y,w,h,stroke,strokeW,fill,opacity}
     line     {x1,y1,x2,y2,stroke,strokeW,opacity,arrow}
     highlight{x,y,w,h,color,opacity}
     note     {x,y,text,author}
  */
  async function applyOverlay(buffer, pageOps) {
    const L = lib();
    const { rgb, degrees, PDFName, PDFHexString, PDFString } = L;
    const doc = await loadDoc(buffer);
    const pages = doc.getPages();
    const fontCache = {};
    const problems = [];
    const col = c => { const v = hexToRgb01(c || "#000000"); return rgb(v.r, v.g, v.b); };

    for (const pg of pageOps) {
      const p = pages[pg.pageIdx];
      if (!p) continue;
      const e = effSize(p);
      const toRaw = (dx, dyBottom, ang) => displayToRaw(p, dx, dyBottom, ang || 0);
      const rawRect = (x, y, w, hgt) => { // top-origin box -> raw axis-aligned rect
        const a = toRaw(x, e.h - y - hgt, 0), b = toRaw(x + w, e.h - y, 0);
        return [Math.min(a.x, b.x), Math.min(a.y, b.y), Math.max(a.x, b.x), Math.max(a.y, b.y)];
      };
      const order = { whiteout: 0, imgdelete: 0, highlight: 1, image: 2, rect: 3, ellipse: 3, line: 3, text: 4, editline: 4, note: 5 };
      const ops = pg.ops.slice().sort((A, B) => (order[A.type] ?? 9) - (order[B.type] ?? 9));
      for (const op of ops) {
        try {
          if (op.type === "whiteout") {
            const r = toRaw(op.x, e.h - op.y - op.h);
            p.drawRectangle({ x: r.x, y: r.y, width: op.w, height: op.h, rotate: degrees(r.a), color: col(op.color || "#ffffff"), borderWidth: 0 });
          } else if (op.type === "imgdelete") {
            // actual pixels removed in redact pass; nothing to draw
          } else if (op.type === "highlight") {
            const r = toRaw(op.x, e.h - op.y - op.h);
            p.drawRectangle({ x: r.x, y: r.y, width: op.w, height: op.h, rotate: degrees(r.a), color: col(op.color || "#ffe066"), opacity: op.opacity != null ? op.opacity : 0.4, blendMode: "Multiply", borderWidth: 0 });
          } else if (op.type === "image") {
            const img = op.isPng ? await doc.embedPng(op.bytes) : await doc.embedJpg(op.bytes);
            const r = toRaw(op.x, e.h - op.y - op.h);
            p.drawImage(img, { x: r.x, y: r.y, width: op.w, height: op.h, rotate: degrees(r.a) });
          } else if (op.type === "rect") {
            const r = toRaw(op.x, e.h - op.y - op.h);
            p.drawRectangle({ x: r.x, y: r.y, width: op.w, height: op.h, rotate: degrees(r.a),
              borderColor: col(op.stroke || "#c0392b"), borderWidth: op.strokeW || 2,
              color: op.fill ? col(op.fill) : undefined, opacity: op.opacity != null ? op.opacity : 1,
              borderOpacity: op.opacity != null ? op.opacity : 1 });
          } else if (op.type === "ellipse") {
            const cx = op.x + op.w / 2, cy = op.y + op.h / 2;
            const r = toRaw(cx, e.h - cy);
            const rot = norm360(p.getRotation().angle);
            const swap = rot === 90 || rot === 270;
            p.drawEllipse({ x: r.x, y: r.y, xScale: (swap ? op.h : op.w) / 2, yScale: (swap ? op.w : op.h) / 2,
              borderColor: col(op.stroke || "#c0392b"), borderWidth: op.strokeW || 2,
              color: op.fill ? col(op.fill) : undefined, opacity: op.opacity != null ? op.opacity : 1,
              borderOpacity: op.opacity != null ? op.opacity : 1 });
          } else if (op.type === "line") {
            const a = toRaw(op.x1, e.h - op.y1), b = toRaw(op.x2, e.h - op.y2);
            const w = op.strokeW || 2, c = col(op.stroke || "#c0392b");
            const opa = op.opacity != null ? op.opacity : 1;
            p.drawLine({ start: { x: a.x, y: a.y }, end: { x: b.x, y: b.y }, thickness: w, color: c, opacity: opa });
            if (op.arrow) {
              const ang = Math.atan2(b.y - a.y, b.x - a.x);
              const len = Math.max(8, w * 4);
              for (const da of [Math.PI * 5 / 6, -Math.PI * 5 / 6]) {
                p.drawLine({ start: { x: b.x, y: b.y },
                  end: { x: b.x + len * Math.cos(ang + da), y: b.y + len * Math.sin(ang + da) },
                  thickness: w, color: c, opacity: opa });
              }
            }
          } else if (op.type === "text" || op.type === "editline") {
            const font = await pickFont(doc, fontCache, op.family, op.bold, op.italic);
            const size = op.size || 14;
            const lines = String(op.text || "").split("\n");
            let baseTop = op.type === "editline" ? op.baseline : op.y + size * 0.82;
            for (const lineText of lines) {
              if (lineText.trim()) {
                font.widthOfTextAtSize(lineText, size); // trigger encoding errors early
                const r = toRaw(op.x, e.h - baseTop);
                p.drawText(lineText, { x: r.x, y: r.y, size, font, color: col(op.color || "#1a1a1a"), rotate: degrees(r.a) });
              }
              baseTop += size * 1.25;
            }
          } else if (op.type === "note") {
            const rect = rawRect(op.x, op.y, 22, 22);
            const now = new Date();
            const mdate = "D:" + now.getFullYear() + String(now.getMonth() + 1).padStart(2, "0") + String(now.getDate()).padStart(2, "0");
            const annot = doc.context.obj({
              Type: "Annot", Subtype: "Text", Rect: rect,
              Contents: PDFHexString.fromText(String(op.text || "")),
              T: PDFHexString.fromText(op.author || "PDFDesk"),
              Name: "Comment", C: [0.98, 0.75, 0.2], CA: 1, F: 4,
              M: PDFString.of(mdate),
            });
            const ref = doc.context.register(annot);
            let annots = p.node.lookup(PDFName.of("Annots"));
            if (!annots) {
              annots = doc.context.obj([]);
              p.node.set(PDFName.of("Annots"), annots);
            }
            annots.push(ref);
          }
        } catch (err) {
          problems.push(op.type + ": " + (err && err.message || err));
        }
      }
    }
    const bytes = await doc.save({ useObjectStreams: true });
    return { bytes, problems };
  }

  /* regions: [{pageIdx, rects:[{x,y,w,h}], mode:'text'|'image'|'black'}] — rects TOP-ORIGIN (MuPDF space).
     'black' = true redaction with a drawn black box (content removed underneath). */
  function redactRegions(mupdf, buffer, regions) {
    const doc = mupdf.Document.openDocument(buffer, "application/pdf");
    const byPage = new Map();
    for (const r of regions) {
      if (!byPage.has(r.pageIdx)) byPage.set(r.pageIdx, { text: [], image: [], black: [] });
      const bucket = r.mode === "image" ? "image" : r.mode === "black" ? "black" : "text";
      byPage.get(r.pageIdx)[bucket].push(...r.rects);
    }
    const P = mupdf.PDFPage;
    for (const [pageIdx, sets] of byPage) {
      const page = doc.loadPage(pageIdx);
      if (sets.text.length) {
        for (const rc of sets.text) {
          const a = page.createAnnotation("Redact");
          a.setRect([rc.x - 0.5, rc.y - 0.5, rc.x + rc.w + 0.5, rc.y + rc.h + 0.5]);
        }
        page.applyRedactions(false, P.REDACT_IMAGE_NONE, undefined, P.REDACT_TEXT_REMOVE);
      }
      if (sets.image.length) {
        for (const rc of sets.image) {
          const a = page.createAnnotation("Redact");
          a.setRect([rc.x, rc.y, rc.x + rc.w, rc.y + rc.h]);
        }
        page.applyRedactions(false, P.REDACT_IMAGE_REMOVE, undefined, P.REDACT_TEXT_NONE);
      }
      if (sets.black.length) {
        for (const rc of sets.black) {
          const a = page.createAnnotation("Redact");
          a.setRect([rc.x, rc.y, rc.x + rc.w, rc.y + rc.h]);
        }
        page.applyRedactions(true, P.REDACT_IMAGE_PIXELS, undefined, P.REDACT_TEXT_REMOVE);
      }
    }
    return doc.saveToBuffer("garbage=compact").asUint8Array();
  }

  /* normalize MuPDF stext JSON into editor line/image lists (all TOP-ORIGIN pts) */
  function parseStext(json) {
    const lines = [], images = [];
    for (const b of json.blocks || []) {
      if (b.type === "text") {
        for (const l of b.lines || []) {
          if (!l.text || !l.text.trim()) continue;
          lines.push({
            text: l.text,
            x: l.bbox.x, y: l.bbox.y, w: l.bbox.w, h: l.bbox.h,
            baseline: l.y,
            size: l.font && l.font.size || Math.max(8, l.bbox.h * 0.75),
            family: famFromStext(l.font && l.font.family),
            bold: /bold/i.test(l.font && l.font.weight || ""),
            italic: /italic|oblique/i.test(l.font && l.font.style || ""),
          });
        }
      } else if (b.type === "image") {
        images.push({ x: b.bbox.x, y: b.bbox.y, w: b.bbox.w, h: b.bbox.h });
      }
    }
    return { lines, images };
  }

  /* ================= LightPDF-parity additions ================= */

  /* ---- crop: box in TOP-ORIGIN display points measured on page 1 ---- */
  async function cropPdf(buffer, box, indices) {
    const doc = await loadDoc(buffer);
    const pages = doc.getPages();
    const targets = indices || pages.map((_, i) => i);
    for (const i of targets) {
      const p = pages[i];
      if (!p) continue;
      const e = effSize(p);
      const x = Math.max(0, Math.min(box.x, e.w - 8));
      const y = Math.max(0, Math.min(box.y, e.h - 8));
      const w = Math.min(box.w, e.w - x), hh = Math.min(box.h, e.h - y);
      const a = displayToRaw(p, x, e.h - y - hh, 0);
      const b = displayToRaw(p, x + w, e.h - y, 0);
      const rx = Math.min(a.x, b.x), ry = Math.min(a.y, b.y);
      const rw = Math.abs(b.x - a.x), rh = Math.abs(b.y - a.y);
      p.setCropBox(rx, ry, rw, rh);
      try { p.setMediaBox(rx, ry, rw, rh); } catch (err) {}
    }
    return doc.save({ useObjectStreams: true });
  }

  /* ---- stext lines -> paragraphs (for text/markdown/docx export) ---- */
  function linesToParas(lines) {
    const paras = [];
    let curP = null, lastBottom = null, lastSize = 12;
    for (const ln of lines) {
      const gap = lastBottom == null ? 0 : ln.y - lastBottom;
      const newPara = !curP || gap > Math.max(6, lastSize * 0.7) || Math.abs(ln.size - curP.size) > 2;
      if (newPara) {
        curP = { text: ln.text.trim(), size: ln.size, bold: ln.bold, italic: ln.italic, family: ln.family };
        paras.push(curP);
      } else {
        curP.text += " " + ln.text.trim();
      }
      lastBottom = ln.y + ln.h;
      lastSize = ln.size;
    }
    return paras;
  }
  function parasToMarkdown(pageParas) {
    const all = pageParas.flat();
    const sizes = all.map(p => p.size).sort((a, b) => a - b);
    const median = sizes.length ? sizes[Math.floor(sizes.length / 2)] : 12;
    return pageParas.map(paras => paras.map(p => {
      let t = p.text;
      if (p.size >= median * 1.7) t = "# " + t;
      else if (p.size >= median * 1.3) t = "## " + t;
      else if (p.bold) t = "**" + t + "**";
      return t;
    }).join("\n\n")).join("\n\n---\n\n");
  }

  /* ---- minimal .docx builder (zipStore-based; Unicode-safe) ---- */
  function xmlEsc(s) {
    return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;").replace(/[\x00-\x08\x0b\x0c\x0e-\x1f]/g, "");
  }
  function buildDocx(pageParas) {
    const enc = new TextEncoder();
    const body = [];
    pageParas.forEach((paras, pi) => {
      if (pi > 0) body.push('<w:p><w:r><w:br w:type="page"/></w:r></w:p>');
      for (const p of paras) {
        const sz = Math.max(2, Math.round((p.size || 11) * 2));
        const rpr = "<w:rPr>" + (p.bold ? "<w:b/>" : "") + (p.italic ? "<w:i/>" : "") +
          '<w:sz w:val="' + sz + '"/><w:szCs w:val="' + sz + '"/></w:rPr>';
        body.push("<w:p><w:r>" + rpr + '<w:t xml:space="preserve">' + xmlEsc(p.text) + "</w:t></w:r></w:p>");
      }
    });
    const documentXml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n' +
      '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">' +
      "<w:body>" + body.join("") + '<w:sectPr><w:pgSz w:w="11906" w:h="16838"/>' +
      '<w:pgMar w:top="1134" w:right="1134" w:bottom="1134" w:left="1134"/></w:sectPr></w:body></w:document>';
    const contentTypes = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n' +
      '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">' +
      '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>' +
      '<Default Extension="xml" ContentType="application/xml"/>' +
      '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>';
    const rels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n' +
      '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' +
      '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>';
    return zipStore([
      { name: "[Content_Types].xml", data: enc.encode(contentTypes) },
      { name: "_rels/.rels", data: enc.encode(rels) },
      { name: "word/document.xml", data: enc.encode(documentXml) },
    ]);
  }

  /* ---- minimal unzip (STORE + DEFLATE via DecompressionStream) ---- */
  async function unzipBytes(bytes) {
    const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    let eocd = -1;
    for (let i = bytes.length - 22; i >= Math.max(0, bytes.length - 65558); i--) {
      if (dv.getUint32(i, true) === 0x06054b50) { eocd = i; break; }
    }
    if (eocd < 0) throw new Error("Not a valid zip/docx file");
    const count = dv.getUint16(eocd + 10, true);
    let off = dv.getUint32(eocd + 16, true);
    const files = {};
    for (let n = 0; n < count; n++) {
      if (dv.getUint32(off, true) !== 0x02014b50) break;
      const method = dv.getUint16(off + 10, true);
      const csize = dv.getUint32(off + 20, true);
      const nameLen = dv.getUint16(off + 28, true);
      const extraLen = dv.getUint16(off + 30, true);
      const commentLen = dv.getUint16(off + 32, true);
      const lho = dv.getUint32(off + 42, true);
      const name = new TextDecoder().decode(bytes.subarray(off + 46, off + 46 + nameLen));
      const lNameLen = dv.getUint16(lho + 26, true);
      const lExtraLen = dv.getUint16(lho + 28, true);
      const dataStart = lho + 30 + lNameLen + lExtraLen;
      const raw = bytes.subarray(dataStart, dataStart + csize);
      if (method === 0) files[name] = raw.slice();
      else if (method === 8) {
        const ds = new DecompressionStream("deflate-raw");
        const stream = new Blob([raw]).stream().pipeThrough(ds);
        files[name] = new Uint8Array(await new Response(stream).arrayBuffer());
      } else throw new Error("Unsupported compression in zip: " + method);
      off += 46 + nameLen + extraLen + commentLen;
    }
    return files;
  }

  /* ---- extract paragraphs from a docx document.xml (regex subset parser) ---- */
  function xmlUnesc(s) {
    return s.replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"')
      .replace(/&apos;/g, "'").replace(/&#x([0-9a-f]+);/gi, (m, h) => String.fromCodePoint(parseInt(h, 16)))
      .replace(/&#(\d+);/g, (m, d) => String.fromCodePoint(+d)).replace(/&amp;/g, "&");
  }
  function docxParas(xml) {
    const paras = [];
    const pRe = /<w:p[\s>][\s\S]*?<\/w:p>|<w:p\/>/g;
    let m;
    while ((m = pRe.exec(xml))) {
      const pxml = m[0];
      let text = "", bold = false, italic = false, size = 0, runs = 0;
      const rRe = /<w:r[\s>][\s\S]*?<\/w:r>/g;
      let r;
      while ((r = rRe.exec(pxml))) {
        const rx = r[0];
        const rpr = (rx.match(/<w:rPr>[\s\S]*?<\/w:rPr>/) || [""])[0];
        if (/<w:b(?:\s[^>]*)?\/>/.test(rpr) && !/w:val="(?:false|0)"/.test((rpr.match(/<w:b\s[^>]*\/>/) || [""])[0])) bold = true;
        if (/<w:i(?:\s[^>]*)?\/>/.test(rpr)) italic = true;
        const sm = rpr.match(/<w:sz w:val="(\d+)"/);
        if (sm) size = Math.max(size, parseInt(sm[1], 10) / 2);
        let t = "";
        const tRe = /<w:t(?:\s[^>]*)?>([\s\S]*?)<\/w:t>|<w:tab\/>|<w:br\/>/g;
        let tm;
        while ((tm = tRe.exec(rx))) {
          if (tm[0] === "<w:tab/>") t += "\t";
          else if (tm[0] === "<w:br/>") t += "\n";
          else t += xmlUnesc(tm[1]);
        }
        text += t;
        runs++;
      }
      const heading = (pxml.match(/<w:pStyle w:val="Heading(\d)"/) || [])[1];
      if (heading && !size) size = [0, 22, 17, 14][+heading] || 13;
      paras.push({ text, bold: bold && runs > 0, italic, size: size || 11 });
    }
    return paras;
  }

  /* ---- paragraphs -> PDF (wrapped text layout) ---- */
  const WINANSI_SAFE = new RegExp("[^\\u0000-\\u00ff\\u0152\\u0153\\u0160\\u0161\\u0178\\u017d\\u017e\\u0192\\u2013\\u2014\\u2018\\u2019\\u201a\\u201c\\u201d\\u201e\\u2020\\u2021\\u2022\\u2026\\u2030\\u2039\\u203a\\u20ac\\u2122]", "g");
  async function parasToPdf(paras, opts) {
    const { PDFDocument, StandardFonts } = lib();
    const doc = await PDFDocument.create();
    const fonts = {};
    const getFont = async (bold, italic) => {
      const k = (bold ? "b" : "") + (italic ? "i" : "");
      if (!fonts[k]) {
        const name = bold && italic ? "HelveticaBoldOblique" : bold ? "HelveticaBold" : italic ? "HelveticaOblique" : "Helvetica";
        fonts[k] = await doc.embedFont(StandardFonts[name]);
      }
      return fonts[k];
    };
    const PW = 595.28, PH = 841.89, M = 64;
    let page = doc.addPage([PW, PH]);
    let y = PH - M;
    let replaced = 0;
    for (const p of paras) {
      const size = Math.max(7, Math.min(36, p.size || 11));
      const font = await getFont(p.bold, p.italic);
      const clean = String(p.text || "").replace(WINANSI_SAFE, () => { replaced++; return "?"; });
      const lineH = size * 1.4;
      const words = clean.split(/\s+/).filter(Boolean);
      if (!words.length) { y -= lineH * 0.6; continue; }
      let line = "";
      const flush = () => {
        if (!line) return;
        if (y < M + size) { page = doc.addPage([PW, PH]); y = PH - M; }
        page.drawText(line, { x: M, y: y - size, size, font });
        y -= lineH;
        line = "";
      };
      for (const w of words) {
        const cand = line ? line + " " + w : w;
        let cw;
        try { cw = font.widthOfTextAtSize(cand, size); } catch (e) { continue; }
        if (cw > PW - 2 * M && line) { flush(); line = w; }
        else line = cand;
      }
      flush();
      y -= lineH * 0.35;
    }
    const bytes = await doc.save({ useObjectStreams: true });
    return { bytes, replaced };
  }

  function textToParas(text) {
    return String(text).replace(/\r\n?/g, "\n").split(/\n{2,}/).map(chunk => ({
      text: chunk.replace(/\n/g, " ").trim(), size: 11,
    })).filter(p => p.text);
  }

  /* ---------------- misc ---------------- */
  function fmtBytes(n) {
    if (n < 1024) return n + " B";
    if (n < 1024 * 1024) return (n / 1024).toFixed(n < 10240 ? 1 : 0) + " KB";
    return (n / 1048576).toFixed(n < 10485760 ? 2 : 1) + " MB";
  }
  function baseName(name) { return String(name || "file").replace(/\.pdf$/i, ""); }

  return {
    parseRangeGroups, parsePageSet, loadDoc,
    mergePdfs, extractPages, splitPdf, rotatePdf, organizePdf, resavePdf,
    addPageNumbers, addTextWatermark, addImageWatermark,
    placeSignature, listFormFields, fillForm, ocrOverlay,
    applyOverlay, redactRegions, parseStext,
    cropPdf, linesToParas, parasToMarkdown, buildDocx, unzipBytes, docxParas, parasToPdf, textToParas,
    imagesToPdf, rebuildFromJpegs,
    zipStore, crc32, fmtBytes, baseName, norm360, effSize, posXY, hexToRgb01,
    MARGINS, NUM_FORMATS, PAGE_SIZES,
  };
});
