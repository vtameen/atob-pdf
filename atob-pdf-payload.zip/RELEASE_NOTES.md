Offline PDF toolkit for Windows, macOS and Android. Download the file for your system below:
- Windows: "AtoB PDF Setup {{VERSION}}.exe"
- macOS: "AtoB PDF-{{VERSION}}-universal.dmg" (Intel + Apple Silicon)
- Android: "AtoB-PDF-{{VERSION}}.apk" (Android 10 or newer)

**Android:** if you already have 3.4.3, this installs over it and keeps your data. If you have 3.4.0 or 3.4.2, uninstall that first (those were signed with a temporary key).

New in {{VERSION}}: real comments, smarter merging, document properties.
- **Comments that other apps can see and edit.** Select text and pick Highlight, Underline, Strike out or Note from the little menu that appears. The comment button adds sticky notes, boxes, ovals, arrows, freehand drawing and stamps (Approved, Paid, Received, Draft) in five colours. They're saved as real PDF comments, so Acrobat, Preview and Edge show them and can edit or delete them. Every comment can be undone.
- **Comments panel** on the right: every comment in the document, including ones made in other apps, listed by page. Click one to jump to it, add or edit its text, delete it, or filter by type. Set the name saved with your comments at the top of the panel.
- In the Edit tool, highlights, boxes, ovals and lines are now saved as comments too. Tick "Flatten" next to Apply to burn them into the page as before.
- **Merge keeps bookmarks.** The merged file gets one bookmark per file, with each file's own bookmarks inside it, and links that jump within a file keep working. Merged files no longer carry hidden extra copies of linked pages.
- **Document properties** (Ctrl+D / ⌘D): edit the title, author, subject and keywords, and see the PDF version, page size, dates, encryption and permissions, and every font (embedded or not).
- Text on pages that were rotated can now be selected correctly.

Earlier in this update: a faster workbench.
- **Search tools and commands (Ctrl+K / ⌘K).** Type a few letters to run any tool or action: rotate, crop, print, go to page 12, open a recent file, switch tabs, change the theme. Actions that can't run yet say why. On phones, the search box is at the top of Home. Ctrl+/ (⌘/) lists every keyboard shortcut.
- **Side panels in the viewer**, from the icon strip on the right: Pages, **Bookmarks** (a searchable, collapsible tree), **Attachments** (save or open files attached to the PDF) and **Form fields** (click one to jump to it, or Fill form). A dot on an icon means the document has that content. Drag the panel's edge to resize it. On phones the panels slide in from the right.
- **Helpful notices when a PDF opens**, one at a time: protected PDFs offer Unlock, forms offer Fill this form, scans offer Make it searchable (OCR), and attachments offer Show attachments.
- **Dark mode.** Light, Dark or Match system, from the button at the top right (or the phone's Home screen). PDF pages stay white.

Also in this version: your edits are much harder to lose.
- **Asks before closing.** Closing the window, quitting, or pressing Back on the phone's Home screen with unsaved documents now asks first: Save / Don't save / Cancel. When several documents have changes, one prompt lists them all.
- **Save writes back to the original file** in the Windows and macOS apps. The file is saved safely: AtoB writes a temporary copy, then swaps it in, so a crash or full disk can't leave a half-written PDF. Hover over a tab to see where its file lives.
- **Save As…** (Ctrl+Shift+S / ⇧⌘S) saves a copy under a new name or in a new place, and the tab switches to the new file. On Android and in the plain HTML file, Save still downloads a copy as before.
- **Crash recovery.** Every minute, and whenever the app is hidden, AtoB keeps a private copy of each document with unsaved changes on this device. If the app crashes, the computer loses power or Android closes the app in the background, the next launch offers to bring those documents back.
- **Redo** with Ctrl+Shift+Z, ⇧⌘Z or Ctrl+Y, and a Redo button next to Undo. The Undo and Redo buttons now name the step, for example "Undo rotate page 2 clockwise".
- **New: PDF to Excel** (in Convert). Turns invoices, statements and reports into a spreadsheet: columns are worked out from where the text sits, amounts like 1,250.00 or (300) become real numbers, and you can have one sheet per page or everything on one sheet. Scanned pages are read with OCR.
- Desktop menus: File now has Open, Save and Save As; Edit's Undo and Redo work on the document.
- **Windows: AtoB PDF now shows up in "Open with" for PDFs and in Settings > Default apps.** Earlier installers registered it in a way Windows 10/11 ignored. To make double-clicking a PDF open AtoB, click "Make AtoB PDF your PDF app" on the Home tab and choose AtoB PDF for .pdf (Windows only lets you make that choice yourself).
- Windows: when a PDF is opened while AtoB is already running, the AtoB window now comes to the front instead of staying behind Explorer. Help > Show log file shows what happened on each launch, for troubleshooting.

See the README for install steps and first-run notes.
