Offline PDF toolkit for Windows, macOS and Android. Download the file for your system below:
- Windows: "AtoB PDF Setup {{VERSION}}.exe"
- macOS: "AtoB PDF-{{VERSION}}-universal.dmg" (Intel + Apple Silicon)
- Android: "AtoB-PDF-{{VERSION}}.apk" (Android 10 or newer)

**Android:** if installing over an older AtoB PDF fails with "App not installed" or a package conflict, uninstall the old version first, then install this APK.

Fixed in 3.4.2:
- Editor: deleting or covering something (whiteout, retyped or removed text, highlights, shapes, images, notes) now lands exactly where you placed it when you save. Before, on many PDFs (scanned files, Word / Print-to-PDF exports, and any page cut with the Crop tool) the white box and new text were saved in a different spot on the page. The same fix applies to page numbers, watermarks, signatures and the OCR text layer.

Also included (3.4.1 reliability fixes):
- Saved files from Protect, Unlock, Repair, Compress, Flatten and text editing can no longer come out empty or corrupted
- The Back button and switching tools no longer leave password or voice prompts stuck
- Editor: fast page changes, zoom and undo/redo across pages behave correctly
- Read-aloud: no more repeated sentences, "Skip language" works, and speech no longer stops mid-page in Chrome
- Android: speech recovers when the voice engine fails to start
- macOS: no more double Save dialogs after reopening the window; files opened right after closing the window aren't lost
- Urdu sentences are read one at a time

See the README for install steps and first-run notes.
