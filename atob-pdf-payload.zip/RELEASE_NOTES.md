Offline PDF toolkit for Windows, macOS and Android. Download the file for your system below:
- Windows: "AtoB PDF Setup {{VERSION}}.exe"
- macOS: "AtoB PDF-{{VERSION}}-universal.dmg" (Intel + Apple Silicon)
- Android: "AtoB-PDF-{{VERSION}}.apk" (Android 10 or newer)

**Android:** if you already have 3.4.3, this installs over it and keeps your data. If you have 3.4.0 or 3.4.2, uninstall that first (those were signed with a temporary key).

New in {{VERSION}} — Acrobat-style document tabs and page tools:
- **Tabs:** a Home tab plus one tab per open PDF, so several documents stay open side by side. Pick or drop several PDFs at once to open each in its own tab. A dot on a tab means unsaved changes; closing it asks before throwing them away.
- **Page thumbnails** on the right of the viewer: click to jump, Ctrl/⌘-click or Shift-click to select several pages. Toggle the panel from the toolbar (on phones it slides in from the right).
- **Rotate pages** clockwise, counter-clockwise or 180° — right-click a thumbnail or a page, use the buttons that appear when you hover over a page, or the toolbar. Works on one page or every selected page.
- **Crop pages** in place: drag a box, move or resize it with the handles, and apply it to this page, the selected pages or all pages.
- **Undo** (Ctrl/⌘+Z) and **Save** (Ctrl/⌘+S) for these changes. Every tool in the sidebar works on the edited document.
- Home tab lists the documents you have open and your recent files.

See the README for install steps and first-run notes.
