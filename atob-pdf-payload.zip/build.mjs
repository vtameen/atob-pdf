/* AtoB PDF single-file assembler. Run from the pdfdesk dir: node build.mjs
   Expects vendor files in VENDOR (env) or ./vendor */
import { readFileSync, writeFileSync, mkdirSync, existsSync, readdirSync } from "fs";
import { execFileSync } from "child_process";
import { join } from "path";
import { tmpdir } from "os";
import { fileURLToPath } from "url";

const SRC = fileURLToPath(new URL("./src/", import.meta.url));
const VENDOR = process.env.VENDOR || fileURLToPath(new URL("./vendor/", import.meta.url));
const DIST = fileURLToPath(new URL("./dist/", import.meta.url));
mkdirSync(DIST, { recursive: true });

const read = p => readFileSync(p, "utf8");

function sanitizeScript(code, name) {
  let out = code.replace(/\/\/# sourceMappingURL=\S+/g, "");
  out = out.replace(/<\/script/gi, "<\\/script");
  out = out.replace(/<!--/g, "<\\u0021--");
  out = out.replace(/�/g, "\\uFFFD"); // literal replacement chars (pdf-lib uses one) -> escape
  // syntax check the transformed blob
  const tmp = join(tmpdir(), "pdfdesk-check-" + name.replace(/[^\w.]/g, "_"));
  writeFileSync(tmp, out);
  execFileSync(process.execPath, ["--check", tmp], { stdio: "pipe" });
  return out;
}

const files = {
  worker: sanitizeScript(read(join(VENDOR, "pdf.worker.min.js")), "worker.js"),
  pdf: sanitizeScript(read(join(VENDOR, "pdf.min.js")), "pdf.js"),
  pdflib: sanitizeScript(read(join(VENDOR, "pdf-lib.min.js")), "pdflib.js"),
  core: sanitizeScript(read(join(SRC, "core.js")), "core.js"),
  shared: sanitizeScript(read(join(SRC, "app-shared.js")), "shared.js"),
  tools: sanitizeScript(read(join(SRC, "app-tools.js")), "tools.js"),
  tools2: sanitizeScript(read(join(SRC, "app-tools2.js")), "tools2.js"),
  editor: sanitizeScript(read(join(SRC, "app-editor.js")), "editor.js"),
  tools3: sanitizeScript(read(join(SRC, "app-tools3.js")), "tools3.js"),
  audio: sanitizeScript(read(join(SRC, "app-audio.js")), "audio.js"),
  reader: sanitizeScript(read(join(SRC, "app-reader.js")), "reader.js"),
  css: read(join(SRC, "style.css")),
};

/* Phase 2 engines, embedded as base64 (decoded lazily at runtime) */
const b64 = p => readFileSync(p).toString("base64");
const assets = {};
let tessMain = "";
const LEAN = !!process.env.LEAN;
const mupdfDist = join(VENDOR, "mupdf-pkg/dist");
if (!LEAN && existsSync(mupdfDist)) {
  assets.mupdfWasm = b64(join(mupdfDist, "mupdf-wasm.wasm"));
  assets.mupdfGlue = b64(join(mupdfDist, "mupdf-wasm.js"));
  assets.mupdfJs = b64(join(mupdfDist, "mupdf.js"));
}
const tessDist = join(VENDOR, "tessjs-pkg/dist");
const tessCore = join(VENDOR, "tesscore-pkg/tesseract-core-simd-lstm.wasm.js");
if (!LEAN && !process.env.SKIP_TESS && existsSync(tessDist) && existsSync(tessCore)) {
  tessMain = sanitizeScript(read(join(tessDist, "tesseract.min.js")), "tessmain.js");
  assets.tessWorker = b64(join(tessDist, "worker.min.js"));
  assets.tessCore = b64(tessCore);
  assets.langs = {};
  for (const f of readdirSync(VENDOR)) {
    const m = f.match(/^([a-z_]+)\.traineddata$/i);
    if (m) assets.langs[m[1].toLowerCase()] = b64(join(VENDOR, f));
  }
}
let assetsScript = "window.PD_ASSETS=" + JSON.stringify(assets) + ";";
/* ARTIFACT (debug) builds: published artifacts cap each file at ~16 MB, so the
   engine blobs go into side files (pd-asset-*.js) loaded by <script src>. */
const sideFiles = [];
if (process.env.ARTIFACT) {
  const js = v => JSON.stringify(v);
  const heads = ["window.PD_ASSETS=window.PD_ASSETS||{};window.PD_ASSETS.langs=window.PD_ASSETS.langs||{};"];
  for (const k of Object.keys(assets)) {
    if (k === "langs") continue;
    sideFiles.push({ name: "pd-asset-" + k + ".js", code: heads[0] + "window.PD_ASSETS[" + js(k) + "]=" + js(assets[k]) + ";" });
  }
  for (const l of Object.keys(assets.langs || {}))
    sideFiles.push({ name: "pd-asset-lang-" + l + ".js", code: heads[0] + "window.PD_ASSETS.langs[" + js(l) + "]=" + js(assets.langs[l]) + ";" });
  assetsScript = heads[0] + (assets.langs ? "" : "");
}

/* MuPDF as a classic-script factory: no dynamic import, no blob URLs, CSP-friendly.
   The ESM sources are transformed: glue's `export default` becomes a return, and
   mupdf.js's exports are collected into the factory's return object. */
let mupdfFactory = "";
if (assets.mupdfGlue) {
  let glue = read(join(mupdfDist, "mupdf-wasm.js"));
  glue = glue.replace(/import\.meta\.url/g, '"https://pdfdesk.inline/"');
  if (!/export default _;\s*$/.test(glue)) throw new Error("glue tail changed");
  glue = glue.replace(/export default _;\s*$/, "return _;");
  const glueWrapped = "const libmupdf_wasm = (function(){\n" + glue + "\n})();";
  let mj = read(join(mupdfDist, "mupdf.js"));
  mj = mj.replace(/^import\s+libmupdf_wasm\s+from\s+"\.\/mupdf-wasm\.js";\s*$/m, "");
  const names = [];
  mj = mj.replace(/^export\s+(const|let|var|function|class)\s+([A-Za-z_$][\w$]*)/gm,
    (m0, kind, name) => { names.push(name); return kind + " " + name; });
  mj = mj.replace(/^export\s+default\s+\{/m, "const __mupdf_default = {");
  if (/^export\s/m.test(mj)) throw new Error("unhandled export form remains in mupdf.js");
  mupdfFactory = "window.__mupdfFactory = async function () {\n" +
    glueWrapped + "\n" + mj + "\nreturn { " + names.join(", ") + " };\n};";
  mupdfFactory = sanitizeScript(mupdfFactory, "mupdf-factory.js");
}

const favicon = encodeURIComponent(
  `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><rect width="32" height="32" rx="7" fill="#3b5ba5"/><path d="M10 7h8l5 5v13H10z" fill="none" stroke="#f7f5f1" stroke-width="2.4" stroke-linejoin="round"/><path d="M18 7v5h5" fill="none" stroke="#f7f5f1" stroke-width="2.4" stroke-linejoin="round"/></svg>`);

const glue = `
${process.env.ARTIFACT ? "window.PD_DEBUG = true;" : ""}
window.pdfjsLib = window.pdfjsLib || window["pdfjs-dist/build/pdf"];
window.pdfjsWorker = window.pdfjsWorker || window["pdfjs-dist/build/pdf.worker"];
if (window.pdfjsLib) { window.pdfjsLib.GlobalWorkerOptions.workerSrc = "pdfdesk.worker.inline"; }
`;

const errCatcher = process.env.ARTIFACT ? `<script>
(function(){
  function show(m){
    var d=document.getElementById("pderr");
    if(!d){d=document.createElement("pre");d.id="pderr";d.style.cssText="position:fixed;top:0;left:0;right:0;background:#fff0f0;color:#900;padding:10px;z-index:999999;font:12px/1.5 monospace;white-space:pre-wrap;max-height:60vh;overflow:auto;margin:0;border-bottom:2px solid #900";(document.body||document.documentElement).appendChild(d);}
    d.textContent += m + "\\n";
    document.title = "BOOTERR";
  }
  window.addEventListener("error", function(e){ show((e.message||"err") + " @ line " + e.lineno + ":" + e.colno); });
  window.addEventListener("unhandledrejection", function(e){ show("REJECT: " + (e.reason && (e.reason.message + " | " + String(e.reason.stack).slice(0,300)) || e.reason)); });
})();
</script>` : "";

const html = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="color-scheme" content="light dark">
<title>AtoB PDF — offline toolkit</title>
<link rel="icon" href="data:image/svg+xml,${favicon}">
<style>
${files.css}
</style>
</head>
<body>
${errCatcher}
<div id="app"></div>
<script>/* PDF.js worker (Mozilla, Apache-2.0) running inline on the main thread */
${files.worker}
</script>
<script>/* PDF.js (Mozilla, Apache-2.0) */
${files.pdf}
</script>
<script>${glue}</script>
<script>/* pdf-lib (MIT) */
${files.pdflib}
</script>
<script>/* embedded engine assets (MuPDF AGPL-3.0, Tesseract Apache-2.0, language data Apache-2.0) */
${assetsScript}
</script>
${sideFiles.map(f => '<script src="' + f.name + '"></script>').join("\n")}
${mupdfFactory ? "<script>/* MuPDF (AGPL-3.0), transformed to a classic-script factory */\n" + mupdfFactory + "\n</script>" : ""}
${tessMain ? "<script>/* Tesseract.js (Apache-2.0) */\n" + tessMain + "\n</script>" : ""}
<script>
${files.core}
</script>
<script>
${files.shared}
</script>
<script>
${files.tools}
</script>
<script>
${files.tools2}
</script>
<script>
${files.editor}
</script>
<script>
${files.tools3}
</script>
<script>
${files.audio}
</script>
<script>
${files.reader}
</script>
</body>
</html>
`;

let outHtml = html, outName = "AtoB-PDF.html";
if (process.env.ARTIFACT) {
  // Artifact publishing wraps content in its own skeleton: strip ours.
  outHtml = html
    .replace(/^<!DOCTYPE html>\s*<html lang="en">\s*<head>\s*/i, "")
    .replace(/<meta charset="utf-8">\s*<meta name="viewport"[^>]*>\s*<meta name="color-scheme"[^>]*>\s*/i, "")
    .replace(/<\/head>\s*<body>\s*/i, "")
    .replace(/<\/body>\s*<\/html>\s*$/i, "")
    .replace(/<title>[^<]*<\/title>/, "<title>AtoB PDF Debug</title>");
  outName = "pdfdesk-debug.html";
}
let outDir = DIST;
if (process.env.ARTIFACT) {
  outDir = join(DIST, "artifact");
  mkdirSync(outDir, { recursive: true });
  for (const f of sideFiles) writeFileSync(join(outDir, f.name), f.code);
  if (sideFiles.length) console.log("side files:", sideFiles.map(f => f.name + " " + (f.code.length / 1048576).toFixed(1) + "MB").join(", "));
}
const out = join(outDir, outName);
writeFileSync(out, outHtml);
console.log("built", out, (outHtml.length / 1048576).toFixed(2) + " MB");
