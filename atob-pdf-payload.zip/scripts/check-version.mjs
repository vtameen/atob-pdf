/* Fails if the version isn't the same in all five places (see CLAUDE.md → Conventions).
   Usage: node scripts/check-version.mjs   → prints the version on success. */
import { readFileSync } from "fs";
import { fileURLToPath } from "url";
const root = fileURLToPath(new URL("../", import.meta.url));
const read = p => readFileSync(root + p, "utf8");
const want = JSON.parse(read("electron/package.json")).version;
const [maj, min, pat] = want.split(".").map(Number);
const gradle = read("android/app/build.gradle");
const found = {
  "electron/package.json": want,
  "src/app-shared.js APP_VERSION": (read("src/app-shared.js").match(/const APP_VERSION = "([^"]+)"/) || [])[1],
  "android/app/build.gradle versionName": (gradle.match(/versionName "([^"]+)"/) || [])[1],
  "android/app/build.gradle versionCode": (gradle.match(/versionCode (\d+)/) || [])[1],
  "MainActivity.platformInfo": (read("android/app/src/main/java/app/atobpdf/android/MainActivity.java").match(/put\("app", "([^"]+)"\)/) || [])[1],
};
const code = String(maj * 100 + min * 10 + pat);
const bad = Object.entries(found).filter(([k, v]) => k.endsWith("versionCode") ? v !== code : v !== want);
if (bad.length) {
  console.error("Version mismatch (want " + want + ", versionCode " + code + "):\n" + bad.map(([k, v]) => "  " + k + " = " + v).join("\n"));
  process.exit(1);
}
console.log(want);
