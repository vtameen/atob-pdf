#!/usr/bin/env bash
# Rebuild the two payload zips that CI unpacks. Run from the project root.
# Everything CI needs, nothing private: _signing/ and other local files are never included.
set -euo pipefail
cd "$(dirname "$0")/.."
node scripts/check-version.mjs >/dev/null
T=$(mktemp -d)   # build fresh zips outside the project, then copy over the old ones
zip -X -q "$T/atob-pdf-payload.zip" \
  src/*.js src/style.css build.mjs RELEASE_NOTES.md \
  test/core.test.mjs scripts/check-version.mjs scripts/make-payload.sh \
  vendor/pdf.min.js vendor/pdf.worker.min.js vendor/pdf-lib.min.js vendor/eng.traineddata \
  vendor/mupdf-pkg/dist/mupdf-wasm.js vendor/mupdf-pkg/dist/mupdf-wasm.wasm vendor/mupdf-pkg/dist/mupdf.js \
  vendor/tessjs-pkg/dist/tesseract.min.js vendor/tessjs-pkg/dist/worker.min.js vendor/tesscore-pkg/tesseract-core-simd-lstm.wasm.js \
  electron/main.js electron/preload.js electron/package.json electron/build/installer.nsh electron/build/icon.icns electron/build/icon.ico electron/build/icon.png \
  android/build.gradle android/gradle.properties android/settings.gradle android/app/build.gradle \
  android/app/src/main/AndroidManifest.xml android/app/src/main/res/mipmap-xxxhdpi/ic_launcher.png android/app/src/main/res/mipmap-xxhdpi/ic_launcher.png \
  android/app/src/main/res/xml/file_paths.xml android/app/src/main/java/app/atobpdf/android/MainActivity.java android/app/src/main/java/app/atobpdf/android/ReaderAudioService.java
zip -X -q "$T/atob-pdf-payload-langs.zip" vendor/ara.traineddata vendor/hin.traineddata vendor/mal.traineddata vendor/tam.traineddata vendor/urd.traineddata
cp -f "$T/atob-pdf-payload.zip" "$T/atob-pdf-payload-langs.zip" .
rm -rf "$T"
if unzip -l atob-pdf-payload.zip | grep -qiE '_signing|\.jks|\.keystore'; then echo "refusing: signing material in payload" >&2; exit 1; fi
for z in atob-pdf-payload.zip atob-pdf-payload-langs.zip; do
  n=$(wc -c < "$z"); echo "$z  $((n/1024)) KB"
  [ "$n" -lt 10485760 ] || { echo "  over the 10 MB browser-upload cap" >&2; exit 1; }
done
