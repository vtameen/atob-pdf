/* Node-side tests for AtoB PDF core (no DOM needed). Run: node test/core.test.mjs */
import { createRequire } from "module";
import { writeFileSync } from "fs";
import { tmpdir } from "os";
import { join as pjoin } from "path";
import { fileURLToPath } from "url";
const require = createRequire(import.meta.url);

const VENDOR = process.env.VENDOR || fileURLToPath(new URL("../vendor/", import.meta.url));
globalThis.PDFLib = require(VENDOR + "pdf-lib.min.js");
const PDCore = require(fileURLToPath(new URL("../src/core.js", import.meta.url)));
const { PDFDocument, StandardFonts, rgb } = globalThis.PDFLib;

let pass = 0, fail = 0;
async function t(name, fn) {
  try { await fn(); pass++; console.log("  ok  " + name); }
  catch (e) { fail++; console.log("  FAIL " + name + " :: " + (e && e.message || e)); }
}
function assert(cond, msg) { if (!cond) throw new Error(msg || "assertion failed"); }

async function samplePdf(pages, rotateFirst) {
  const d = await PDFDocument.create();
  const font = await d.embedFont(StandardFonts.Helvetica);
  for (let i = 0; i < pages; i++) {
    const p = d.addPage([595.28, 841.89]);
    p.drawText("Sample page " + (i + 1), { x: 60, y: 760, size: 28, font, color: rgb(0.1, 0.1, 0.2) });
    if (rotateFirst && i === 0) p.setRotation(globalThis.PDFLib.degrees(90));
  }
  return await d.save();
}

const main = async () => {
  console.log("AtoB PDF core tests");
  const s5 = await samplePdf(5), s3 = await samplePdf(3);

  await t("range parser basics", async () => {
    assert(JSON.stringify(PDCore.parseRangeGroups("1-3,5", 5)) === "[[0,1,2],[4]]");
    assert(JSON.stringify(PDCore.parseRangeGroups("4-", 5)) === "[[3,4]]");
    assert(JSON.stringify(PDCore.parseRangeGroups("-2", 5)) === "[[0,1]]");
    assert(JSON.stringify(PDCore.parseRangeGroups("3-1", 5)) === "[[2,1,0]]");
    assert(JSON.stringify(PDCore.parsePageSet("1,1,2-3,2", 5)) === "[0,1,2]");
  });
  await t("range parser rejects garbage", async () => {
    for (const bad of ["0", "6", "abc", "1-9", "", "-", "2--3"]) {
      let threw = false;
      try { PDCore.parseRangeGroups(bad, 5); } catch (e) { threw = e.code === "RANGE"; }
      assert(threw, "should reject: " + JSON.stringify(bad));
    }
  });
  await t("merge full + ranged", async () => {
    const out = await PDCore.mergePdfs([s5, s3], [null, null]);
    assert((await PDFDocument.load(out)).getPageCount() === 8, "full merge");
    const out2 = await PDCore.mergePdfs([s5, s3], ["1-2,5", "2"]);
    assert((await PDFDocument.load(out2)).getPageCount() === 4, "ranged merge");
  });
  await t("split", async () => {
    const outs = await PDCore.splitPdf(s5, PDCore.parseRangeGroups("1-2,3-5", 5));
    assert(outs.length === 2);
    assert((await PDFDocument.load(outs[0])).getPageCount() === 2);
    assert((await PDFDocument.load(outs[1])).getPageCount() === 3);
  });
  await t("extract", async () => {
    const out = await PDCore.extractPages(s5, [4, 0]);
    assert((await PDFDocument.load(out)).getPageCount() === 2);
  });
  await t("rotate accumulates existing rotation", async () => {
    const rot = await samplePdf(3, true); // page1 already at 90
    const out = await PDCore.rotatePdf(rot, [0, 1], 90);
    const d = await PDFDocument.load(out);
    assert(d.getPage(0).getRotation().angle % 360 === 180, "was 90 + 90");
    assert(d.getPage(1).getRotation().angle % 360 === 90);
    assert(d.getPage(2).getRotation().angle % 360 === 0);
  });
  await t("organize reorder+rotate+delete+duplicate", async () => {
    const out = await PDCore.organizePdf(s5, [
      { srcIdx: 2 }, { srcIdx: 2, rotDelta: 90 }, { srcIdx: 0, rotDelta: 270 },
    ]);
    const d = await PDFDocument.load(out);
    assert(d.getPageCount() === 3);
    assert(d.getPage(1).getRotation().angle % 360 === 90);
    assert(d.getPage(2).getRotation().angle % 360 === 270);
  });
  await t("page numbers on plain and rotated pages", async () => {
    for (const src of [s3, await samplePdf(3, true)]) {
      const out = await PDCore.addPageNumbers(src, { pos: "bc", format: "pnt", size: 11, margin: "md", start: 1 });
      await PDFDocument.load(out);
    }
  });
  await t("page numbers skipFirst + start", async () => {
    const out = await PDCore.addPageNumbers(s3, { pos: "br", format: "n", start: 10, skipFirst: true });
    await PDFDocument.load(out);
  });
  await t("text watermark: single, tiled, rotated pages", async () => {
    await PDFDocument.load(await PDCore.addTextWatermark(s3, { text: "DRAFT", pos: "mc", size: 60, angle: 45 }));
    await PDFDocument.load(await PDCore.addTextWatermark(s3, { text: "CONFIDENTIAL", tile: true, size: 44, angle: 45 }));
    await PDFDocument.load(await PDCore.addTextWatermark(await samplePdf(2, true), { text: "X", tile: true, size: 44, angle: 45 }));
  });
  await t("watermark rejects non-latin cleanly", async () => {
    let code = null;
    try { await PDCore.addTextWatermark(s3, { text: "机密文件", size: 40 }); } catch (e) { code = e.code; }
    assert(code === "ENCODING", "got " + code);
  });
  await t("image watermark (png)", async () => {
    // tiny valid png: 1x1 red pixel
    const png = Buffer.from("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==", "base64");
    const out = await PDCore.addImageWatermark(s3, new Uint8Array(png), true, { scalePct: 30, pos: "br" });
    await PDFDocument.load(out);
    const out2 = await PDCore.addImageWatermark(s3, new Uint8Array(png), true, { scalePct: 20, tile: true });
    await PDFDocument.load(out2);
  });
  await t("images to pdf (fit + a4 auto)", async () => {
    const png = Buffer.from("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==", "base64");
    const imgs = [{ bytes: new Uint8Array(png), isPng: true }, { bytes: new Uint8Array(png), isPng: true }];
    for (const ps of ["fit", "a4", "letter"]) {
      const out = await PDCore.imagesToPdf(imgs, { pageSize: ps, orient: "auto", marginPct: 3 });
      assert((await PDFDocument.load(out)).getPageCount() === 2, ps);
    }
  });
  await t("resave keeps pages", async () => {
    const out = await PDCore.resavePdf(s5);
    assert((await PDFDocument.load(out)).getPageCount() === 5);
  });
  await t("encrypted pdf raises friendly error", async () => {
    // minimal encrypted-flag detection test: pdf-lib throws on real encrypted docs;
    // here we just confirm loadDoc wraps parse failures
    let code = null;
    try { await PDCore.loadDoc(new Uint8Array([1, 2, 3, 4])); } catch (e) { code = e.code; }
    assert(code === "PARSE", "got " + code);
  });
  await t("zip store writes valid structure", async () => {
    const z = PDCore.zipStore([
      { name: "a.txt", data: new TextEncoder().encode("hello pdfdesk") },
      { name: "sub/b.pdf", data: s3 },
    ]);
    writeFileSync(pjoin(tmpdir(), "atob-test.zip"), z);
    const dv = new DataView(z.buffer, z.byteLength - 22, 22);
    assert(dv.getUint32(0, true) === 0x06054b50, "EOCD");
  });

  // pdf.js parse in Node (best-effort; canvas rendering is covered by in-app self-test)
  await t("pdf.js parses and extracts text (node)", async () => {
    globalThis.pdfjsWorker = require(VENDOR + "pdf.worker.min.js");
    const pdfjs = require(VENDOR + "pdf.min.js");
    const doc = await pdfjs.getDocument({ data: new Uint8Array(s3.slice(0)), useSystemFonts: true }).promise;
    assert(doc.numPages === 3);
    const tc = await (await doc.getPage(1)).getTextContent();
    const text = tc.items.map(i => i.str).join(" ");
    assert(/Sample page 1/.test(text), "text was: " + text);
    await doc.destroy();
  });

  /* ---- Phase 2 ---- */
  const PNG1 = Buffer.from("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==", "base64");
  await t("placeSignature (plain + rotated page)", async () => {
    for (const src of [s3, await samplePdf(2, true)]) {
      const out = await PDCore.placeSignature(src, new Uint8Array(PNG1), true, { pageIdx: 0, cx: 300, cy: 120, wPt: 120, dateStr: "22 Aug 2026" });
      await PDFDocument.load(out);
    }
  });
  await t("placeSignature rejects bad page", async () => {
    let threw = false;
    try { await PDCore.placeSignature(s3, new Uint8Array(PNG1), true, { pageIdx: 9, cx: 1, cy: 1, wPt: 10 }); } catch (e) { threw = true; }
    assert(threw);
  });
  await t("forms: list, fill, flatten", async () => {
    const d = await PDFDocument.create();
    const page = d.addPage([400, 300]);
    const form = d.getForm();
    const tf = form.createTextField("who"); tf.addToPage(page, { x: 40, y: 200, width: 200, height: 24 });
    const cb = form.createCheckBox("agree"); cb.addToPage(page, { x: 40, y: 150, width: 18, height: 18 });
    const dd = form.createDropdown("color"); dd.addOptions(["red", "blue"]); dd.addToPage(page, { x: 40, y: 100, width: 120, height: 22 });
    const src = await d.save();
    const fields = await PDCore.listFormFields(src);
    assert(fields.length === 3, "fields " + fields.length);
    const res = await PDCore.fillForm(src, [
      { name: "who", kind: "text", value: "Ameen" },
      { name: "agree", kind: "check", value: true },
      { name: "color", kind: "dropdown", value: "blue" },
    ], {});
    assert(res.problems.length === 0, res.problems[0]);
    const back = await PDCore.listFormFields(res.bytes);
    assert(back.find(f => f.name === "who").value === "Ameen");
    assert(back.find(f => f.name === "agree").value === true);
    assert(back.find(f => f.name === "color").value === "blue");
    const flat = await PDCore.fillForm(src, [{ name: "who", kind: "text", value: "X" }], { flatten: true });
    assert((await PDCore.listFormFields(flat.bytes)).length === 0, "not flattened");
  });
  await t("ocrOverlay places invisible words", async () => {
    const out = await PDCore.ocrOverlay(s3, [{ pageIdx: 0, dpi: 300, words: [
      { text: "Hello", x0: 100, y0: 100, x1: 400, y1: 160 },
      { text: "机密", x0: 100, y0: 200, x1: 300, y1: 260 }, // non-latin -> skipped
    ]}]);
    assert(out.placed === 1 && out.skipped === 1, "placed " + out.placed + " skipped " + out.skipped);
    await PDFDocument.load(out.bytes);
  });
  await t("mupdf: encrypt/unlock/repair/deep-clean", async () => {
    const mupdf = await import(VENDOR + "mupdf-pkg/dist/mupdf.js");
    const doc = mupdf.Document.openDocument(s3.slice(0), "application/pdf");
    const enc = doc.saveToBuffer("encrypt=aes-256,user-password=pw1,owner-password=pw2,permissions=-3140").asUint8Array();
    const doc2 = mupdf.Document.openDocument(enc.slice(0), "application/pdf");
    assert(doc2.needsPassword(), "not locked");
    assert(doc2.authenticatePassword("bad") === 0, "bad pw accepted");
    assert(doc2.authenticatePassword("pw1") !== 0, "good pw rejected");
    const dec = doc2.saveToBuffer("encrypt=none,garbage=compact").asUint8Array();
    assert((await PDFDocument.load(dec)).getPageCount() === 3);
    // repair truncated
    const broken = s5.slice(0, s5.length - 300);
    const doc3 = mupdf.Document.openDocument(broken, "application/pdf");
    let out;
    try { out = doc3.saveToBuffer("garbage=deduplicate,clean=yes,sanitize=yes").asUint8Array(); }
    catch (e) {
      const fresh = new mupdf.PDFDocument();
      let ok = 0;
      for (let i = 0; i < doc3.countPages(); i++) { try { fresh.graftPage(ok, doc3, i); ok++; } catch (err) {} }
      out = fresh.saveToBuffer("garbage=deduplicate,clean=yes").asUint8Array();
    }
    assert((await PDFDocument.load(out)).getPageCount() >= 1, "repair produced no pages");
    // deep clean runs
    const clean = doc.saveToBuffer("garbage=deduplicate,compress=yes,compress-fonts=yes,compress-images=yes,clean=yes").asUint8Array();
    assert(clean.length > 100);
  });

  /* ---- Phase 3: editor pipeline ---- */
  await t("applyOverlay: all op types + note annotation", async () => {
    const res = await PDCore.applyOverlay(s3, [{ pageIdx: 0, ops: [
      { type: "whiteout", x: 50, y: 50, w: 200, h: 40 },
      { type: "highlight", x: 60, y: 120, w: 180, h: 20, color: "#ffe066", opacity: 0.4 },
      { type: "text", x: 60, y: 200, size: 16, text: "Added line one\nand line two", color: "#123456", family: "serif", bold: true },
      { type: "editline", x: 60, baseline: 300, size: 14, text: "Replacement text", family: "sans" },
      { type: "image", x: 300, y: 400, w: 80, h: 60, bytes: new Uint8Array(PNG1), isPng: true },
      { type: "rect", x: 100, y: 450, w: 120, h: 60, stroke: "#c0392b", strokeW: 2 },
      { type: "ellipse", x: 260, y: 450, w: 100, h: 60, stroke: "#2c4a6e", strokeW: 2, fill: "#eeeeee", opacity: 0.8 },
      { type: "line", x1: 60, y1: 560, x2: 300, y2: 600, stroke: "#333333", strokeW: 2, arrow: true },
      { type: "note", x: 500, y: 60, text: "مراجعة this note supports unicode", author: "Ameen" },
    ]}]);
    assert(res.problems.length === 0, "problems: " + res.problems[0]);
    const d = await PDFDocument.load(res.bytes);
    assert(d.getPageCount() === 3);
    const annots = d.getPage(0).node.lookup(globalThis.PDFLib.PDFName.of("Annots"));
    assert(annots && annots.size() === 1, "note annotation missing");
  });
  await t("applyOverlay: rotated page ops", async () => {
    const rot = await samplePdf(2, true);
    const res = await PDCore.applyOverlay(rot, [{ pageIdx: 0, ops: [
      { type: "whiteout", x: 30, y: 30, w: 100, h: 30 },
      { type: "text", x: 40, y: 100, size: 14, text: "On a rotated page" },
      { type: "line", x1: 10, y1: 10, x2: 200, y2: 200, arrow: true },
    ]}]);
    assert(res.problems.length === 0, res.problems[0]);
    await PDFDocument.load(res.bytes);
  });
  await t("applyOverlay: reports encoding problems without dying", async () => {
    const res = await PDCore.applyOverlay(s3, [{ pageIdx: 0, ops: [
      { type: "text", x: 10, y: 10, size: 12, text: "机密" },
      { type: "text", x: 10, y: 40, size: 12, text: "fine" },
    ]}]);
    assert(res.problems.length === 1, "problems " + res.problems.length);
    await PDFDocument.load(res.bytes);
  });
  await t("applyOverlay: whiteout/text land on target when CropBox/MediaBox don't start at 0,0", async () => {
    const mupdf = await import(VENDOR + "mupdf-pkg/dist/mupdf.js");
    const darkIn = (bytes, r) => {
      const doc = mupdf.Document.openDocument(bytes.slice(0), "application/pdf");
      const pix = doc.loadPage(0).toPixmap(mupdf.Matrix.identity, mupdf.ColorSpace.DeviceGray, false);
      const W = pix.getWidth(), px = pix.getPixels(); let n = 0;
      for (let y = Math.floor(r.y); y < r.y + r.h; y++) for (let x = Math.floor(r.x); x < r.x + r.w; x++) if (px[y * W + x] < 128) n++;
      return n;
    };
    for (const kind of ["mediaOrigin", "crop", "cropRot90", "cropRot270", "atobCropped"]) {
      const d = await PDFDocument.create();
      const f = await d.embedFont(StandardFonts.Helvetica);
      const p = d.addPage([612, 792]);
      if (kind === "mediaOrigin") p.setMediaBox(0, -100, 612, 792);
      if (kind.startsWith("crop")) p.setCropBox(40, 60, 520, 700);
      if (kind === "cropRot90") p.setRotation(globalThis.PDFLib.degrees(90));
      if (kind === "cropRot270") p.setRotation(globalThis.PDFLib.degrees(270));
      p.drawText("TARGET LINE", { x: 120, y: 400, size: 30, font: f, color: rgb(0, 0, 0) });
      let src = await d.save();
      if (kind === "atobCropped") src = await PDCore.cropPdf(src, { x: 60, y: 200, w: 450, h: 400 });
      const doc = mupdf.Document.openDocument(src.slice(0), "application/pdf");
      const ln = PDCore.parseStext(JSON.parse(doc.loadPage(0).toStructuredText().asJSON())).lines[0];
      assert(ln && darkIn(src, ln) > 100, kind + ": fixture text not found");
      const res = await PDCore.applyOverlay(src, [{ pageIdx: 0, ops: [{ type: "whiteout", x: ln.x - 2, y: ln.y - 2, w: ln.w + 4, h: ln.h + 4 }] }]);
      assert(darkIn(res.bytes, ln) === 0, kind + ": whiteout missed the text (" + darkIn(res.bytes, ln) + " dark px left)");
      const res2 = await PDCore.applyOverlay(src, [{ pageIdx: 0, ops: [{ type: "text", x: 30, y: 30, size: 20, text: "HERE" }] }]);
      const d2 = mupdf.Document.openDocument(res2.bytes.slice(0), "application/pdf");
      const here = PDCore.parseStext(JSON.parse(d2.loadPage(0).toStructuredText().asJSON())).lines.find(l => l.text.includes("HERE"));
      assert(here && Math.abs(here.x - 30) < 3 && Math.abs(here.y - 30) < 8, kind + ": added text drifted to " + (here && [Math.round(here.x), Math.round(here.y)]));
    }
  });
  await t("redactRegions + parseStext: line-level replace flow", async () => {
    const mupdf = await import(VENDOR + "mupdf-pkg/dist/mupdf.js");
    // page with two lines
    const d = await PDFDocument.create();
    const f = await d.embedFont(StandardFonts.Helvetica);
    const p = d.addPage([500, 400]);
    p.drawText("Keep this line", { x: 50, y: 300, size: 20, font: f });
    p.drawText("Replace this line", { x: 50, y: 250, size: 20, font: f });
    const src = await d.save();
    // find target via stext
    const doc = mupdf.Document.openDocument(src.slice(0), "application/pdf");
    const st = JSON.parse(doc.loadPage(0).toStructuredText("preserve-images").asJSON());
    const { lines } = PDCore.parseStext(st);
    assert(lines.length === 2, "lines " + lines.length);
    const target = lines.find(l => /Replace/.test(l.text));
    assert(target && target.size === 20 && target.family === "sans", JSON.stringify(target));
    // redact it
    const redacted = PDCore.redactRegions(mupdf, src.slice(0), [{ pageIdx: 0, rects: [target], mode: "text" }]);
    // overlay replacement at same baseline
    const res = await PDCore.applyOverlay(redacted, [{ pageIdx: 0, ops: [
      { type: "editline", x: target.x, baseline: target.baseline, size: target.size, text: "Brand new words", family: target.family },
    ]}]);
    // verify via stext of final
    const doc2 = mupdf.Document.openDocument(res.bytes.slice(0), "application/pdf");
    const st2 = JSON.parse(doc2.loadPage(0).toStructuredText().asJSON());
    const text2 = PDCore.parseStext(st2).lines.map(l => l.text).join(" | ");
    assert(/Keep this line/.test(text2), "kept line lost: " + text2);
    assert(!/Replace this line/.test(text2), "old text still present: " + text2);
    assert(/Brand new words/.test(text2), "replacement missing: " + text2);
  });

  await t("mupdfSave returns an owned copy; redactRegions output survives heap growth", async () => {
    const mupdf = await import(VENDOR + "mupdf-pkg/dist/mupdf.js");
    const doc = mupdf.Document.openDocument(s3.slice(0), "application/pdf");
    const out = PDCore.mupdfSave(doc, "garbage=compact");
    doc.destroy();
    assert(out.byteOffset === 0 && out.buffer.byteLength === out.length, "not an owned copy");
    const red = PDCore.redactRegions(mupdf, s3.slice(0), [{ pageIdx: 0, rects: [{ x: 10, y: 10, w: 50, h: 20 }], mode: "black" }]);
    const head = String.fromCharCode(...red.slice(0, 5));
    // allocate and free a lot of WASM memory; a heap view would detach or be overwritten
    for (let i = 0; i < 6; i++) { const d = mupdf.Document.openDocument(s5.slice(0), "application/pdf"); PDCore.mupdfSave(d, "garbage=deduplicate"); d.destroy(); }
    const big = new mupdf.Buffer(); big.write("x".repeat(8 << 20)); big.destroy();
    assert(red.length > 0 && head === String.fromCharCode(...red.slice(0, 5)) && head === "%PDF-", "redacted bytes changed: " + head);
    assert((await PDFDocument.load(red)).getPageCount() === 3, "redacted pdf unreadable");
    assert((await PDFDocument.load(out)).getPageCount() === 3, "saved pdf unreadable");
  });
  await t("unzipBytes rejects tiny input cleanly", async () => {
    let msg = "";
    try { await PDCore.unzipBytes(new Uint8Array(5)); } catch (e) { msg = e.message; }
    assert(msg === "Not a valid zip/docx file", msg);
  });

  /* ---- LightPDF-parity core ---- */
  await t("cropPdf sets crop box", async () => {
    const out = await PDCore.cropPdf(s3, { x: 50, y: 60, w: 300, h: 400 });
    const d = await PDFDocument.load(out);
    const cb = d.getPage(0).getCropBox();
    assert(Math.round(cb.width) === 300 && Math.round(cb.height) === 400, JSON.stringify(cb));
  });
  await t("linesToParas + markdown", async () => {
    const lines = [
      { text: "Big Title", y: 40, h: 24, size: 24, bold: true, family: "sans" },
      { text: "First line of body", y: 90, h: 12, size: 11, family: "sans" },
      { text: "second line continues", y: 104, h: 12, size: 11, family: "sans" },
      { text: "New paragraph after gap", y: 160, h: 12, size: 11, family: "sans" },
    ];
    const paras = PDCore.linesToParas(lines);
    assert(paras.length === 3, "paras " + paras.length);
    assert(/First line of body second line continues/.test(paras[1].text));
    const md = PDCore.parasToMarkdown([paras]);
    assert(/# Big Title/.test(md), md.slice(0, 60));
  });
  await t("docx build -> unzip -> parse roundtrip (incl. Arabic)", async () => {
    const src = [[{ text: "Hello World", size: 16, bold: true }, { text: "مرحبا بالعالم", size: 11 }],
                 [{ text: "Page two text", size: 11, italic: true }]];
    const docx = PDCore.buildDocx(src);
    const files = await PDCore.unzipBytes(docx);
    assert(files["word/document.xml"], "document.xml missing");
    const xml = new TextDecoder().decode(files["word/document.xml"]);
    const paras = PDCore.docxParas(xml);
    const texts = paras.map(p => p.text).join("|");
    assert(/Hello World/.test(texts) && /مرحبا بالعالم/.test(texts) && /Page two text/.test(texts), texts);
    const hw = paras.find(p => /Hello World/.test(p.text));
    assert(hw.bold === true && Math.round(hw.size) === 16, JSON.stringify(hw));
  });
  await t("unzip handles deflate (real-world docx)", async () => {
    const { execSync } = await import("child_process");
    const zpath = pjoin(tmpdir(), "atob-t-deflate.zip");
    execSync(`python3 -c "
import os, zipfile
z = zipfile.ZipFile(os.environ['ZPATH'],'w',zipfile.ZIP_DEFLATED)
z.writestr('word/document.xml','<w:document><w:body><w:p><w:r><w:t>Deflated content here</w:t></w:r></w:p></w:body></w:document>' * 30)
z.close()"`, { env: { ...process.env, ZPATH: zpath } });
    const bytes = new Uint8Array((await import("fs")).readFileSync(zpath));
    const files = await PDCore.unzipBytes(bytes);
    const xml = new TextDecoder().decode(files["word/document.xml"]);
    assert(/Deflated content here/.test(xml) && xml.length > 2000, "len " + xml.length);
    assert(PDCore.docxParas(xml).length === 30);
  });
  await t("parasToPdf lays out wrapped text", async () => {
    const long = "word ".repeat(400).trim();
    const res = await PDCore.parasToPdf([
      { text: "A Heading", size: 20, bold: true },
      { text: long, size: 11 },
      { text: "机密 mixed latin", size: 11 },
    ]);
    const d = await PDFDocument.load(res.bytes);
    assert(d.getPageCount() >= 1);
    assert(res.replaced === 2, "replaced " + res.replaced);
    const mupdf = await import(VENDOR + "mupdf-pkg/dist/mupdf.js");
    const st = JSON.parse(mupdf.Document.openDocument(res.bytes.slice(0), "application/pdf").loadPage(0).toStructuredText().asJSON());
    const txt = PDCore.parseStext(st).lines.map(l => l.text).join(" ");
    assert(/A Heading/.test(txt), txt.slice(0, 80));
  });
  await t("textToParas splits blank lines", async () => {
    const p = PDCore.textToParas("one\ntwo\n\nthree\r\n\r\nfour");
    assert(p.length === 3 && p[0].text === "one two", JSON.stringify(p));
  });
  await t("black-box redaction removes content", async () => {
    const mupdf = await import(VENDOR + "mupdf-pkg/dist/mupdf.js");
    const d = await PDFDocument.create();
    const f = await d.embedFont(StandardFonts.Helvetica);
    const p = d.addPage([500, 400]);
    p.drawText("PUBLIC info", { x: 50, y: 300, size: 20, font: f });
    p.drawText("SECRET info", { x: 50, y: 250, size: 20, font: f });
    const src = await d.save();
    const st = JSON.parse(mupdf.Document.openDocument(src.slice(0), "application/pdf").loadPage(0).toStructuredText().asJSON());
    const target = PDCore.parseStext(st).lines.find(l => /SECRET/.test(l.text));
    const out = PDCore.redactRegions(mupdf, src.slice(0), [{ pageIdx: 0, rects: [target], mode: "black" }]);
    const st2 = JSON.parse(mupdf.Document.openDocument(out.slice(0), "application/pdf").loadPage(0).toStructuredText().asJSON());
    const txt = PDCore.parseStext(st2).lines.map(l => l.text).join(" ");
    assert(/PUBLIC/.test(txt) && !/SECRET/.test(txt), txt);
  });

  /* ---------- v3.4 language layer ---------- */
  await t("detectLang: en/ar/ur/hi/ml/ta", async () => {
    const cases = {
      en: "The quick brown fox jumps over the lazy dog.",
      ar: "ذهب الطالب إلى المدرسة في الصباح الباكر.",
      ur: "یہ ایک اچھی کتاب ہے اور میں اسے پڑھ رہا ہوں۔",
      hi: "यह एक अच्छी किताब है और मैं इसे पढ़ रहा हूँ।",
      ml: "ഇതൊരു നല്ല പുസ്തകമാണ്, ഞാൻ അത് വായിക്കുന്നു.",
      ta: "இது ஒரு நல்ல புத்தகம், நான் அதைப் படிக்கிறேன்.",
    };
    for (const [lang, s] of Object.entries(cases)) assert(PDCore.detectLang(s) === lang, lang + " -> " + PDCore.detectLang(s));
    assert(PDCore.langDir("ar") === "rtl" && PDCore.langDir("ur") === "rtl" && PDCore.langDir("ml") === "ltr");
    assert(PDCore.detectLang("12345 !!") === null);
  });
  await t("normalizeText folds Arabic presentation forms + ligatures", async () => {
    const pres = "ﺍﻟﺴﻼﻡ"; // ﺍﻟﺴﻼﻡ
    assert(PDCore.normalizeText(pres) === "السلام", JSON.stringify(PDCore.normalizeText(pres)));
    assert(PDCore.normalizeText("ﬁle of­fice") === "file office");
    assert(PDCore.normalizeText("كتـــاب") === "كتاب", "tatweel");
    const ml = "ഞാൻ"; // chillu must survive
    assert(PDCore.normalizeText(ml) === ml.normalize("NFKC"));
  });
  await t("visual-order Arabic is detected and repaired", async () => {
    const logical = "ذهب الطالب إلى المدرسة في الصباح وقرأ الكتاب في المكتبة العامة";
    const visual = Array.from(logical).reverse().join("");
    assert(!PDCore.looksVisualOrder(logical), "logical flagged");
    assert(PDCore.looksVisualOrder(visual), "visual missed " + JSON.stringify(PDCore.rtlOrderScore(visual)));
    assert(PDCore.reverseVisual(visual) === logical, PDCore.reverseVisual(visual));
    // numbers and Latin stay forwards
    const mixed = "صفحة 2026 PDF الكتاب";
    const vis = PDCore.reverseVisual(mixed);
    assert(/PDF/.test(vis) && /2026/.test(vis), "LTR runs must stay forwards in visual order: " + vis);
    assert(PDCore.reverseVisual(vis) === mixed, PDCore.reverseVisual(vis));
  });
  await t("textQuality flags ML-TT / Kruti Dev / PUA text, passes clean text", async () => {
    const clean = ["The quick brown fox jumps over the lazy dog and keeps running across the field.",
      "ഇതൊരു നല്ല പുസ്തകമാണ്, ഞാൻ അത് വായിക്കുന്നു. മലയാളം വളരെ മനോഹരമായ ഭാഷയാണ്.",
      "ذهب الطالب إلى المدرسة في الصباح الباكر وقرأ الكتاب."];
    for (const c of clean) assert(!PDCore.textQuality(c).garbled, "false positive: " + c.slice(0, 20) + " " + PDCore.textQuality(c).reason);
    const mltt = "tIcf kÀ¡mÀ hmÀ¯I Ah³ ]Ã¯n¡m³ tIcf kÀ¡m­À hn`mKw sNbvXp ¨Xv";
    assert(PDCore.textQuality(mltt).garbled, "ML-TT missed " + JSON.stringify(PDCore.textQuality(mltt)));
    const kruti = "vkSj ;g fdlh Hkh jkT; ds fy, t:jh gS fd og vius ukxfjdksa dh lqj{kk djs";
    assert(PDCore.textQuality(kruti).garbled, "Kruti missed " + JSON.stringify(PDCore.textQuality(kruti)));
    const pua = "   ";
    assert(PDCore.textQuality(pua).garbled, "PUA missed");
    assert(PDCore.legacyFontLang(["ABCDEF+ML-TTKarthika"]) === "ml");
    assert(PDCore.legacyFontLang(["KrutiDev010"]) === "hi");
    assert(PDCore.legacyFontLang(["Helvetica"]) === null);
    assert(PDCore.legacyFontLang(["Agrandir-Regular"]) === null, "Agrandir is Latin");
    assert(PDCore.legacyFontLang(["ABCDEF+Amanda"]) === null, "Amanda is Latin");
    assert(PDCore.legacyFontLang(["Agra-Bold"]) === "hi");
  });
  await t("splitSentences: Latin, ؟ ، ۔ । and abbreviations", async () => {
    const pick = s => PDCore.splitSentences(s).map(r => s.slice(r.start, r.end));
    let r = pick("Dr. Smith arrived at 3.5 p.m. today. He left! Did he? Yes.");
    assert(r.length === 4 && r[0] === "Dr. Smith arrived at 3.5 p.m. today.", JSON.stringify(r));
    r = pick("هل ذهبت؟ نعم، ذهبت إلى السوق.");
    assert(r.length === 3 && r[0] === "هل ذهبت؟" && r[1] === "نعم،", JSON.stringify(r));
    r = pick("यह पहला वाक्य है। यह दूसरा है।");
    assert(r.length === 2, JSON.stringify(r));
    r = pick("یہ پہلا جملہ ہے۔ یہ دوسرا ہے۔");
    assert(r.length === 2 && r[0] === "یہ پہلا جملہ ہے۔", "urdu full stop " + JSON.stringify(r));
    r = pick("line one\nline two");
    assert(r.length === 2, "newline");
    const long = ("word ".repeat(120)).trim() + ".";
    assert(PDCore.splitSentences(long, 200).every(x => x.end - x.start <= 200), "maxLen");
    const wl = PDCore.sentencesWithLang("Hello there. مرحبا بك. नमस्ते दोस्त।");
    assert(wl.map(x => x.lang).join() === "en,ar,hi", JSON.stringify(wl));
  });
  await t("buildPageText: lines, paragraphs, dehyphenation, offsets→boxes", async () => {
    const runs = [
      { str: "Chapter One", x: 50, y: 40, w: 200, h: 24, eol: true },
      { str: "This is a para-", x: 50, y: 100, w: 300, h: 12, eol: true },
      { str: "graph that wraps.", x: 50, y: 114, w: 300, h: 12, eol: true },
      { str: "Second", x: 50, y: 160, w: 60, h: 12 },
      { str: "paragraph", x: 114, y: 160, w: 90, h: 12, eol: true },
    ];
    const pg = PDCore.buildPageText(runs);
    assert(pg.text === "Chapter One\nThis is a paragraph that wraps.\nSecond paragraph", JSON.stringify(pg.text));
    assert(pg.paras.length === 3 && pg.paras[0].heading, JSON.stringify(pg.paras));
    const at = pg.text.lastIndexOf("paragraph");
    const hy = pg.text.indexOf("paragraph");
    assert(PDCore.boxesForRange(pg, hy, hy + 9).length === 2, "hyphen-joined word spans two lines");
    const boxes = PDCore.boxesForRange(pg, at, at + 9);
    assert(boxes.length === 1 && Math.abs(boxes[0].x - 114) < 1, JSON.stringify(boxes));
    const off = PDCore.offsetAtPoint(pg, 120, 165);
    assert(off >= at && off <= at + 3, "offsetAtPoint " + off + " vs " + at);
    const w = PDCore.wordRangeAt(pg.text, at + 3);
    assert(pg.text.slice(w.start, w.end) === "paragraph");
    assert(pg.lang === "en" && !pg.quality.garbled);
  });
  await t("buildPageText repairs a visually-ordered Arabic page", async () => {
    const lines = ["ذهب الطالب إلى المدرسة في الصباح", "وقرأ الكتاب في المكتبة العامة"];
    const runs = lines.map((l, i) => ({ str: Array.from(l).reverse().join(""), x: 50, y: 50 + i * 16, w: 300, h: 12, eol: true }));
    const pg = PDCore.buildPageText(runs);
    assert(pg.visualOrderFixed && pg.text === lines.join(" "), JSON.stringify(pg.text));
    assert(pg.lang === "ar" && pg.dir === "rtl" && pg.runs[0].rtl);
  });
  await t("repairArabic / repairIndic fix impossible ligature & vowel-sign orders", async () => {
    assert(PDCore.repairArabic("الفصل األول") === "الفصل الأول", PDCore.repairArabic("الفصل األول"));
    assert(PDCore.repairArabic("قال ال شيء") === "قال لا شيء");
    assert(PDCore.repairArabic("الكتاب") === "الكتاب", "article untouched");
    assert(PDCore.repairIndic("िहन्दी") === "हिन्दी", PDCore.repairIndic("िहन्दी"));
    assert(PDCore.repairIndic("ഇെതാരു").normalize("NFC") === "ഇതൊരു", PDCore.repairIndic("ഇെതാരു"));
    assert(PDCore.repairIndic("அைதப்") === "அதைப்", PDCore.repairIndic("அைதப்"));
    for (const ok of ["हिन्दी", "ഇതൊരു നല്ല", "அதைப் படிக்கிறேன்"]) assert(PDCore.repairIndic(ok) === ok, "changed clean text: " + ok);
  });
  await t("hashBytes is stable and size-sensitive", async () => {
    const a = new Uint8Array(600000).map((_, i) => i * 7);
    const b = a.slice(); b[300000] ^= 1; // middle byte: not sampled, same hash expected
    const c = a.slice(0, a.length - 1);
    assert(PDCore.hashBytes(a) === PDCore.hashBytes(a.slice()));
    assert(PDCore.hashBytes(a) === PDCore.hashBytes(b), "middle sampling");
    assert(PDCore.hashBytes(a) !== PDCore.hashBytes(c));
    assert(PDCore.countWords("One two, three — ഇതൊരു നല്ല") === 5);
    assert(PDCore.fmtDuration(95) === "1 h 35 min");
  });
  await t("inkBBox trims to inked pixels (alpha + white knockout)", async () => {
    const w = 20, hgt = 10, px = new Uint8ClampedArray(w * hgt * 4);
    for (let i = 0; i < px.length; i += 4) { px[i] = px[i + 1] = px[i + 2] = 255; px[i + 3] = 255; } // opaque white
    const put = (x, y) => { const i = (y * w + x) * 4; px[i] = px[i + 1] = px[i + 2] = 20; };
    put(5, 3); put(12, 7);
    assert(PDCore.inkBBox(px, w, hgt) && PDCore.inkBBox(px, w, hgt).w === 20, "alpha-only sees whole image");
    const b = PDCore.inkBBox(px, w, hgt, { whiteCut: 235 });
    assert(b.x === 5 && b.y === 3 && b.w === 8 && b.h === 5, JSON.stringify(b));
  });
  console.log(pass + " passed, " + fail + " failed");
  process.exit(fail ? 1 : 0);
};
main().catch(e => { console.error("CRASH", e); process.exit(2); });
