/* Node-side tests for AtoB PDF core (no DOM needed). Run: node test/core.test.mjs */
import { createRequire } from "module";
import { writeFileSync } from "fs";
import { tmpdir } from "os";
import { join as pjoin } from "path";
import { fileURLToPath } from "url";
const require = createRequire(import.meta.url);

const VENDOR = process.env.VENDOR || fileURLToPath(new URL("../vendor/", import.meta.url));
globalThis.PDFLib = require(VENDOR + "pdf-lib.min.js");
const PDCore = require(fileURLToPath(new URL("../src/core.js", import.meta.url)));
const { PDFDocument, StandardFonts, rgb } = globalThis.PDFLib;

let pass = 0, fail = 0;
async function t(name, fn) {
  try { await fn(); pass++; console.log("  ok  " + name); }
  catch (e) { fail++; console.log("  FAIL " + name + " :: " + (e && e.message || e)); }
}
function assert(cond, msg) { if (!cond) throw new Error(msg || "assertion failed"); }

async function samplePdf(pages, rotateFirst) {
  const d = await PDFDocument.create();
  const font = await d.embedFont(StandardFonts.Helvetica);
  for (let i = 0; i < pages; i++) {
    const p = d.addPage([595.28, 841.89]);
    p.drawText("Sample page " + (i + 1), { x: 60, y: 760, size: 28, font, color: rgb(0.1, 0.1, 0.2) });
    if (rotateFirst && i === 0) p.setRotation(globalThis.PDFLib.degrees(90));
  }
  return await d.save();
}

const main = async () => {
  console.log("AtoB PDF core tests");
  const s5 = await samplePdf(5), s3 = await samplePdf(3);

  await t("range parser basics", async () => {
    assert(JSON.stringify(PDCore.parseRangeGroups("1-3,5", 5)) === "[[0,1,2],[4]]");
    assert(JSON.stringify(PDCore.parseRangeGroups("4-", 5)) === "[[3,4]]");
    assert(JSON.stringify(PDCore.parseRangeGroups("-2", 5)) === "[[0,1]]");
    assert(JSON.stringify(PDCore.parseRangeGroups("3-1", 5)) === "[[2,1,0]]");
    assert(JSON.stringify(PDCore.parsePageSet("1,1,2-3,2", 5)) === "[0,1,2]");
  });
  await t("range parser rejects garbage", async () => {
    for (const bad of ["0", "6", "abc", "1-9", "", "-", "2--3"]) {
      let threw = false;
      try { PDCore.parseRangeGroups(bad, 5); } catch (e) { threw = e.code === "RANGE"; }
      assert(threw, "should reject: " + JSON.stringify(bad));
    }
  });
  await t("merge full + ranged", async () => {
    const out = await PDCore.mergePdfs([s5, s3], [null, null]);
    assert((await PDFDocument.load(out)).getPageCount() === 8, "full merge");
    const out2 = await PDCore.mergePdfs([s5, s3], ["1-2,5", "2"]);
    assert((await PDFDocument.load(out2)).getPageCount() === 4, "ranged merge");
  });
  await t("split", async () => {
    const outs = await PDCore.splitPdf(s5, PDCore.parseRangeGroups("1-2,3-5", 5));
    assert(outs.length === 2);
    assert((await PDFDocument.load(outs[0])).getPageCount() === 2);
    assert((await PDFDocument.load(outs[1])).getPageCount() === 3);
  });
  await t("extract", async () => {
    const out = await PDCore.extractPages(s5, [4, 0]);
    assert((await PDFDocument.load(out)).getPageCount() === 2);
  });
  await t("rotate accumulates existing rotation", async () => {
    const rot = await samplePdf(3, true); // page1 already at 90
    const out = await PDCore.rotatePdf(rot, [0, 1], 90);
    const d = await PDFDocument.load(out);
    assert(d.getPage(0).getRotation().angle % 360 === 180, "was 90 + 90");
    assert(d.getPage(1).getRotation().angle % 360 === 90);
    assert(d.getPage(2).getRotation().angle % 360 === 0);
  });
  await t("organize reorder+rotate+delete+duplicate", async () => {
    const out = await PDCore.organizePdf(s5, [
      { srcIdx: 2 }, { srcIdx: 2, rotDelta: 90 }, { srcIdx: 0, rotDelta: 270 },
    ]);
    const d = await PDFDocument.load(out);
    assert(d.getPageCount() === 3);
    assert(d.getPage(1).getRotation().angle % 360 === 90);
    assert(d.getPage(2).getRotation().angle % 360 === 270);
  });
  await t("page numbers on plain and rotated pages", async () => {
    for (const src of [s3, await samplePdf(3, true)]) {
      const out = await PDCore.addPageNumbers(src, { pos: "bc", format: "pnt", size: 11, margin: "md", start: 1 });
      await PDFDocument.load(out);
    }
  });
  await t("page numbers skipFirst + start", async () => {
    const out = await PDCore.addPageNumbers(s3, { pos: "br", format: "n", start: 10, skipFirst: true });
    await PDFDocument.load(out);
  });
  await t("text watermark: single, tiled, rotated pages", async () => {
    await PDFDocument.load(await PDCore.addTextWatermark(s3, { text: "DRAFT", pos: "mc", size: 60, angle: 45 }));
    await PDFDocument.load(await PDCore.addTextWatermark(s3, { text: "CONFIDENTIAL", tile: true, size: 44, angle: 45 }));
    await PDFDocument.load(await PDCore.addTextWatermark(await samplePdf(2, true), { text: "X", tile: true, size: 44, angle: 45 }));
  });
  await t("watermark rejects non-latin cleanly", async () => {
    let code = null;
    try { await PDCore.addTextWatermark(s3, { text: "机密文件", size: 40 }); } catch (e) { code = e.code; }
    assert(code === "ENCODING", "got " + code);
  });
  await t("image watermark (png)", async () => {
    // tiny valid png: 1x1 red pixel
    const png = Buffer.from("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==", "base64");
    const out = await PDCore.addImageWatermark(s3, new Uint8Array(png), true, { scalePct: 30, pos: "br" });
    await PDFDocument.load(out);
    const out2 = await PDCore.addImageWatermark(s3, new Uint8Array(png), true, { scalePct: 20, tile: true });
    await PDFDocument.load(out2);
  });
  await t("images to pdf (fit + a4 auto)", async () => {
    const png = Buffer.from("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==", "base64");
    const imgs = [{ bytes: new Uint8Array(png), isPng: true }, { bytes: new Uint8Array(png), isPng: true }];
    for (const ps of ["fit", "a4", "letter"]) {
      const out = await PDCore.imagesToPdf(imgs, { pageSize: ps, orient: "auto", marginPct: 3 });
      assert((await PDFDocument.load(out)).getPageCount() === 2, ps);
    }
  });
  await t("resave keeps pages", async () => {
    const out = await PDCore.resavePdf(s5);
    assert((await PDFDocument.load(out)).getPageCount() === 5);
  });
  await t("encrypted pdf raises friendly error", async () => {
    // minimal encrypted-flag detection test: pdf-lib throws on real encrypted docs;
    // here we just confirm loadDoc wraps parse failures
    let code = null;
    try { await PDCore.loadDoc(new Uint8Array([1, 2, 3, 4])); } catch (e) { code = e.code; }
    assert(code === "PARSE", "got " + code);
  });
  await t("zip store writes valid structure", async () => {
    const z = PDCore.zipStore([
      { name: "a.txt", data: new TextEncoder().encode("hello pdfdesk") },
      { name: "sub/b.pdf", data: s3 },
    ]);
    writeFileSync(pjoin(tmpdir(), "atob-test.zip"), z);
    const dv = new DataView(z.buffer, z.byteLength - 22, 22);
    assert(dv.getUint32(0, true) === 0x06054b50, "EOCD");
  });

  // pdf.js parse in Node (best-effort; canvas rendering is covered by in-app self-test)
  await t("pdf.js parses and extracts text (node)", async () => {
    globalThis.pdfjsWorker = require(VENDOR + "pdf.worker.min.js");
    const pdfjs = require(VENDOR + "pdf.min.js");
    const doc = await pdfjs.getDocument({ data: new Uint8Array(s3.slice(0)), useSystemFonts: true }).promise;
    assert(doc.numPages === 3);
    const tc = await (await doc.getPage(1)).getTextContent();
    const text = tc.items.map(i => i.str).join(" ");
    assert(/Sample page 1/.test(text), "text was: " + text);
    await doc.destroy();
  });

  /* ---- Phase 2 ---- */
  const PNG1 = Buffer.from("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==", "base64");
  await t("placeSignature (plain + rotated page)", async () => {
    for (const src of [s3, await samplePdf(2, true)]) {
      const out = await PDCore.placeSignature(src, new Uint8Array(PNG1), true, { pageIdx: 0, cx: 300, cy: 120, wPt: 120, dateStr: "22 Aug 2026" });
      await PDFDocument.load(out);
    }
  });
  await t("placeSignature on every page (v3.8): one image per page, mixed sizes", async () => {
    const d = await PDFDocument.create();
    d.addPage([595, 842]); d.addPage([842, 595]); d.addPage([300, 400]);
    const src = await d.save();
    const out = await PDCore.placeSignature(src, new Uint8Array(PNG1), true, { pageIdx: 0, cx: 400, cy: 120, wPt: 120, dateStr: "20 Oct 2026", pageIdxs: [0, 1, 2] });
    const od = await PDFDocument.load(out);
    for (const pg of od.getPages()) {
      const xo = pg.node.Resources().lookup(globalThis.PDFLib.PDFName.of("XObject"));
      assert(xo && xo.keys().length === 1, "each page has the signature image");
    }
  });
  await t("placeSignature rejects bad page", async () => {
    let threw = false;
    try { await PDCore.placeSignature(s3, new Uint8Array(PNG1), true, { pageIdx: 9, cx: 1, cy: 1, wPt: 10 }); } catch (e) { threw = true; }
    assert(threw);
  });
  await t("forms: list, fill, flatten", async () => {
    const d = await PDFDocument.create();
    const page = d.addPage([400, 300]);
    const form = d.getForm();
    const tf = form.createTextField("who"); tf.addToPage(page, { x: 40, y: 200, width: 200, height: 24 });
    const cb = form.createCheckBox("agree"); cb.addToPage(page, { x: 40, y: 150, width: 18, height: 18 });
    const dd = form.createDropdown("color"); dd.addOptions(["red", "blue"]); dd.addToPage(page, { x: 40, y: 100, width: 120, height: 22 });
    const src = await d.save();
    const fields = await PDCore.listFormFields(src);
    assert(fields.length === 3, "fields " + fields.length);
    const res = await PDCore.fillForm(src, [
      { name: "who", kind: "text", value: "Ameen" },
      { name: "agree", kind: "check", value: true },
      { name: "color", kind: "dropdown", value: "blue" },
    ], {});
    assert(res.problems.length === 0, res.problems[0]);
    const back = await PDCore.listFormFields(res.bytes);
    assert(back.find(f => f.name === "who").value === "Ameen");
    assert(back.find(f => f.name === "agree").value === true);
    assert(back.find(f => f.name === "color").value === "blue");
    const flat = await PDCore.fillForm(src, [{ name: "who", kind: "text", value: "X" }], { flatten: true });
    assert((await PDCore.listFormFields(flat.bytes)).length === 0, "not flattened");
  });
  await t("ocrOverlay places invisible words", async () => {
    const out = await PDCore.ocrOverlay(s3, [{ pageIdx: 0, dpi: 300, words: [
      { text: "Hello", x0: 100, y0: 100, x1: 400, y1: 160 },
      { text: "机密", x0: 100, y0: 200, x1: 300, y1: 260 }, // non-latin -> skipped
    ]}]);
    assert(out.placed === 1 && out.skipped === 1, "placed " + out.placed + " skipped " + out.skipped);
    await PDFDocument.load(out.bytes);
  });
  await t("mupdf: encrypt/unlock/repair/deep-clean", async () => {
    const mupdf = await import(VENDOR + "mupdf-pkg/dist/mupdf.js");
    const doc = mupdf.Document.openDocument(s3.slice(0), "application/pdf");
    const enc = doc.saveToBuffer("encrypt=aes-256,user-password=pw1,owner-password=pw2,permissions=-3140").asUint8Array();
    const doc2 = mupdf.Document.openDocument(enc.slice(0), "application/pdf");
    assert(doc2.needsPassword(), "not locked");
    assert(doc2.authenticatePassword("bad") === 0, "bad pw accepted");
    assert(doc2.authenticatePassword("pw1") !== 0, "good pw rejected");
    const dec = doc2.saveToBuffer("encrypt=none,garbage=compact").asUint8Array();
    assert((await PDFDocument.load(dec)).getPageCount() === 3);
    // repair truncated
    const broken = s5.slice(0, s5.length - 300);
    const doc3 = mupdf.Document.openDocument(broken, "application/pdf");
    let out;
    try { out = doc3.saveToBuffer("garbage=deduplicate,clean=yes,sanitize=yes").asUint8Array(); }
    catch (e) {
      const fresh = new mupdf.PDFDocument();
      let ok = 0;
      for (let i = 0; i < doc3.countPages(); i++) { try { fresh.graftPage(ok, doc3, i); ok++; } catch (err) {} }
      out = fresh.saveToBuffer("garbage=deduplicate,clean=yes").asUint8Array();
    }
    assert((await PDFDocument.load(out)).getPageCount() >= 1, "repair produced no pages");
    // deep clean runs
    const clean = doc.saveToBuffer("garbage=deduplicate,compress=yes,compress-fonts=yes,compress-images=yes,clean=yes").asUint8Array();
    assert(clean.length > 100);
  });

  /* ---- Phase 3: editor pipeline ---- */
  await t("applyOverlay: all op types + note annotation", async () => {
    const res = await PDCore.applyOverlay(s3, [{ pageIdx: 0, ops: [
      { type: "whiteout", x: 50, y: 50, w: 200, h: 40 },
      { type: "highlight", x: 60, y: 120, w: 180, h: 20, color: "#ffe066", opacity: 0.4 },
      { type: "text", x: 60, y: 200, size: 16, text: "Added line one\nand line two", color: "#123456", family: "serif", bold: true },
      { type: "editline", x: 60, baseline: 300, size: 14, text: "Replacement text", family: "sans" },
      { type: "image", x: 300, y: 400, w: 80, h: 60, bytes: new Uint8Array(PNG1), isPng: true },
      { type: "rect", x: 100, y: 450, w: 120, h: 60, stroke: "#c0392b", strokeW: 2 },
      { type: "ellipse", x: 260, y: 450, w: 100, h: 60, stroke: "#2c4a6e", strokeW: 2, fill: "#eeeeee", opacity: 0.8 },
      { type: "line", x1: 60, y1: 560, x2: 300, y2: 600, stroke: "#333333", strokeW: 2, arrow: true },
      { type: "note", x: 500, y: 60, text: "مراجعة this note supports unicode", author: "Ameen" },
    ]}]);
    assert(res.problems.length === 0, "problems: " + res.problems[0]);
    const d = await PDFDocument.load(res.bytes);
    assert(d.getPageCount() === 3);
    const annots = d.getPage(0).node.lookup(globalThis.PDFLib.PDFName.of("Annots"));
    assert(annots && annots.size() === 1, "note annotation missing");
  });
  await t("applyOverlay: rotated page ops", async () => {
    const rot = await samplePdf(2, true);
    const res = await PDCore.applyOverlay(rot, [{ pageIdx: 0, ops: [
      { type: "whiteout", x: 30, y: 30, w: 100, h: 30 },
      { type: "text", x: 40, y: 100, size: 14, text: "On a rotated page" },
      { type: "line", x1: 10, y1: 10, x2: 200, y2: 200, arrow: true },
    ]}]);
    assert(res.problems.length === 0, res.problems[0]);
    await PDFDocument.load(res.bytes);
  });
  await t("applyOverlay: reports encoding problems without dying", async () => {
    const res = await PDCore.applyOverlay(s3, [{ pageIdx: 0, ops: [
      { type: "text", x: 10, y: 10, size: 12, text: "机密" },
      { type: "text", x: 10, y: 40, size: 12, text: "fine" },
    ]}]);
    assert(res.problems.length === 1, "problems " + res.problems.length);
    await PDFDocument.load(res.bytes);
  });
  await t("applyOverlay: whiteout/text land on target when CropBox/MediaBox don't start at 0,0", async () => {
    const mupdf = await import(VENDOR + "mupdf-pkg/dist/mupdf.js");
    const darkIn = (bytes, r) => {
      const doc = mupdf.Document.openDocument(bytes.slice(0), "application/pdf");
      const pix = doc.loadPage(0).toPixmap(mupdf.Matrix.identity, mupdf.ColorSpace.DeviceGray, false);
      const W = pix.getWidth(), px = pix.getPixels(); let n = 0;
      for (let y = Math.floor(r.y); y < r.y + r.h; y++) for (let x = Math.floor(r.x); x < r.x + r.w; x++) if (px[y * W + x] < 128) n++;
      return n;
    };
    for (const kind of ["mediaOrigin", "crop", "cropRot90", "cropRot270", "atobCropped"]) {
      const d = await PDFDocument.create();
      const f = await d.embedFont(StandardFonts.Helvetica);
      const p = d.addPage([612, 792]);
      if (kind === "mediaOrigin") p.setMediaBox(0, -100, 612, 792);
      if (kind.startsWith("crop")) p.setCropBox(40, 60, 520, 700);
      if (kind === "cropRot90") p.setRotation(globalThis.PDFLib.degrees(90));
      if (kind === "cropRot270") p.setRotation(globalThis.PDFLib.degrees(270));
      p.drawText("TARGET LINE", { x: 120, y: 400, size: 30, font: f, color: rgb(0, 0, 0) });
      let src = await d.save();
      if (kind === "atobCropped") src = await PDCore.cropPdf(src, { x: 60, y: 200, w: 450, h: 400 });
      const doc = mupdf.Document.openDocument(src.slice(0), "application/pdf");
      const ln = PDCore.parseStext(JSON.parse(doc.loadPage(0).toStructuredText().asJSON())).lines[0];
      assert(ln && darkIn(src, ln) > 100, kind + ": fixture text not found");
      const res = await PDCore.applyOverlay(src, [{ pageIdx: 0, ops: [{ type: "whiteout", x: ln.x - 2, y: ln.y - 2, w: ln.w + 4, h: ln.h + 4 }] }]);
      assert(darkIn(res.bytes, ln) === 0, kind + ": whiteout missed the text (" + darkIn(res.bytes, ln) + " dark px left)");
      const res2 = await PDCore.applyOverlay(src, [{ pageIdx: 0, ops: [{ type: "text", x: 30, y: 30, size: 20, text: "HERE" }] }]);
      const d2 = mupdf.Document.openDocument(res2.bytes.slice(0), "application/pdf");
      const here = PDCore.parseStext(JSON.parse(d2.loadPage(0).toStructuredText().asJSON())).lines.find(l => l.text.includes("HERE"));
      assert(here && Math.abs(here.x - 30) < 3 && Math.abs(here.y - 30) < 8, kind + ": added text drifted to " + (here && [Math.round(here.x), Math.round(here.y)]));
    }
  });
  await t("redactRegions + parseStext: line-level replace flow", async () => {
    const mupdf = await import(VENDOR + "mupdf-pkg/dist/mupdf.js");
    // page with two lines
    const d = await PDFDocument.create();
    const f = await d.embedFont(StandardFonts.Helvetica);
    const p = d.addPage([500, 400]);
    p.drawText("Keep this line", { x: 50, y: 300, size: 20, font: f });
    p.drawText("Replace this line", { x: 50, y: 250, size: 20, font: f });
    const src = await d.save();
    // find target via stext
    const doc = mupdf.Document.openDocument(src.slice(0), "application/pdf");
    const st = JSON.parse(doc.loadPage(0).toStructuredText("preserve-images").asJSON());
    const { lines } = PDCore.parseStext(st);
    assert(lines.length === 2, "lines " + lines.length);
    const target = lines.find(l => /Replace/.test(l.text));
    assert(target && target.size === 20 && target.family === "sans", JSON.stringify(target));
    // redact it
    const redacted = PDCore.redactRegions(mupdf, src.slice(0), [{ pageIdx: 0, rects: [target], mode: "text" }]);
    // overlay replacement at same baseline
    const res = await PDCore.applyOverlay(redacted, [{ pageIdx: 0, ops: [
      { type: "editline", x: target.x, baseline: target.baseline, size: target.size, text: "Brand new words", family: target.family },
    ]}]);
    // verify via stext of final
    const doc2 = mupdf.Document.openDocument(res.bytes.slice(0), "application/pdf");
    const st2 = JSON.parse(doc2.loadPage(0).toStructuredText().asJSON());
    const text2 = PDCore.parseStext(st2).lines.map(l => l.text).join(" | ");
    assert(/Keep this line/.test(text2), "kept line lost: " + text2);
    assert(!/Replace this line/.test(text2), "old text still present: " + text2);
    assert(/Brand new words/.test(text2), "replacement missing: " + text2);
  });

  await t("mupdfSave returns an owned copy; redactRegions output survives heap growth", async () => {
    const mupdf = await import(VENDOR + "mupdf-pkg/dist/mupdf.js");
    const doc = mupdf.Document.openDocument(s3.slice(0), "application/pdf");
    const out = PDCore.mupdfSave(doc, "garbage=compact");
    doc.destroy();
    assert(out.byteOffset === 0 && out.buffer.byteLength === out.length, "not an owned copy");
    const red = PDCore.redactRegions(mupdf, s3.slice(0), [{ pageIdx: 0, rects: [{ x: 10, y: 10, w: 50, h: 20 }], mode: "black" }]);
    const head = String.fromCharCode(...red.slice(0, 5));
    // allocate and free a lot of WASM memory; a heap view would detach or be overwritten
    for (let i = 0; i < 6; i++) { const d = mupdf.Document.openDocument(s5.slice(0), "application/pdf"); PDCore.mupdfSave(d, "garbage=deduplicate"); d.destroy(); }
    const big = new mupdf.Buffer(); big.write("x".repeat(8 << 20)); big.destroy();
    assert(red.length > 0 && head === String.fromCharCode(...red.slice(0, 5)) && head === "%PDF-", "redacted bytes changed: " + head);
    assert((await PDFDocument.load(red)).getPageCount() === 3, "redacted pdf unreadable");
    assert((await PDFDocument.load(out)).getPageCount() === 3, "saved pdf unreadable");
  });
  await t("unzipBytes rejects tiny input cleanly", async () => {
    let msg = "";
    try { await PDCore.unzipBytes(new Uint8Array(5)); } catch (e) { msg = e.message; }
    assert(msg === "Not a valid zip/docx file", msg);
  });

  /* ---- LightPDF-parity core ---- */
  await t("cropPdf sets crop box", async () => {
    const out = await PDCore.cropPdf(s3, { x: 50, y: 60, w: 300, h: 400 });
    const d = await PDFDocument.load(out);
    const cb = d.getPage(0).getCropBox();
    assert(Math.round(cb.width) === 300 && Math.round(cb.height) === 400, JSON.stringify(cb));
  });
  await t("linesToParas + markdown", async () => {
    const lines = [
      { text: "Big Title", y: 40, h: 24, size: 24, bold: true, family: "sans" },
      { text: "First line of body", y: 90, h: 12, size: 11, family: "sans" },
      { text: "second line continues", y: 104, h: 12, size: 11, family: "sans" },
      { text: "New paragraph after gap", y: 160, h: 12, size: 11, family: "sans" },
    ];
    const paras = PDCore.linesToParas(lines);
    assert(paras.length === 3, "paras " + paras.length);
    assert(/First line of body second line continues/.test(paras[1].text));
    const md = PDCore.parasToMarkdown([paras]);
    assert(/# Big Title/.test(md), md.slice(0, 60));
  });
  await t("docx build -> unzip -> parse roundtrip (incl. Arabic)", async () => {
    const src = [[{ text: "Hello World", size: 16, bold: true }, { text: "مرحبا بالعالم", size: 11 }],
                 [{ text: "Page two text", size: 11, italic: true }]];
    const docx = PDCore.buildDocx(src);
    const files = await PDCore.unzipBytes(docx);
    assert(files["word/document.xml"], "document.xml missing");
    const xml = new TextDecoder().decode(files["word/document.xml"]);
    const paras = PDCore.docxParas(xml);
    const texts = paras.map(p => p.text).join("|");
    assert(/Hello World/.test(texts) && /مرحبا بالعالم/.test(texts) && /Page two text/.test(texts), texts);
    const hw = paras.find(p => /Hello World/.test(p.text));
    assert(hw.bold === true && Math.round(hw.size) === 16, JSON.stringify(hw));
  });
  await t("unzip handles deflate (real-world docx)", async () => {
    const { execSync } = await import("child_process");
    const zpath = pjoin(tmpdir(), "atob-t-deflate.zip");
    execSync(`python3 -c "
import os, zipfile
z = zipfile.ZipFile(os.environ['ZPATH'],'w',zipfile.ZIP_DEFLATED)
z.writestr('word/document.xml','<w:document><w:body><w:p><w:r><w:t>Deflated content here</w:t></w:r></w:p></w:body></w:document>' * 30)
z.close()"`, { env: { ...process.env, ZPATH: zpath } });
    const bytes = new Uint8Array((await import("fs")).readFileSync(zpath));
    const files = await PDCore.unzipBytes(bytes);
    const xml = new TextDecoder().decode(files["word/document.xml"]);
    assert(/Deflated content here/.test(xml) && xml.length > 2000, "len " + xml.length);
    assert(PDCore.docxParas(xml).length === 30);
  });
  await t("parasToPdf lays out wrapped text", async () => {
    const long = "word ".repeat(400).trim();
    const res = await PDCore.parasToPdf([
      { text: "A Heading", size: 20, bold: true },
      { text: long, size: 11 },
      { text: "机密 mixed latin", size: 11 },
    ]);
    const d = await PDFDocument.load(res.bytes);
    assert(d.getPageCount() >= 1);
    assert(res.replaced === 2, "replaced " + res.replaced);
    const mupdf = await import(VENDOR + "mupdf-pkg/dist/mupdf.js");
    const st = JSON.parse(mupdf.Document.openDocument(res.bytes.slice(0), "application/pdf").loadPage(0).toStructuredText().asJSON());
    const txt = PDCore.parseStext(st).lines.map(l => l.text).join(" ");
    assert(/A Heading/.test(txt), txt.slice(0, 80));
  });
  await t("textToParas splits blank lines", async () => {
    const p = PDCore.textToParas("one\ntwo\n\nthree\r\n\r\nfour");
    assert(p.length === 3 && p[0].text === "one two", JSON.stringify(p));
  });
  await t("black-box redaction removes content", async () => {
    const mupdf = await import(VENDOR + "mupdf-pkg/dist/mupdf.js");
    const d = await PDFDocument.create();
    const f = await d.embedFont(StandardFonts.Helvetica);
    const p = d.addPage([500, 400]);
    p.drawText("PUBLIC info", { x: 50, y: 300, size: 20, font: f });
    p.drawText("SECRET info", { x: 50, y: 250, size: 20, font: f });
    const src = await d.save();
    const st = JSON.parse(mupdf.Document.openDocument(src.slice(0), "application/pdf").loadPage(0).toStructuredText().asJSON());
    const target = PDCore.parseStext(st).lines.find(l => /SECRET/.test(l.text));
    const out = PDCore.redactRegions(mupdf, src.slice(0), [{ pageIdx: 0, rects: [target], mode: "black" }]);
    const st2 = JSON.parse(mupdf.Document.openDocument(out.slice(0), "application/pdf").loadPage(0).toStructuredText().asJSON());
    const txt = PDCore.parseStext(st2).lines.map(l => l.text).join(" ");
    assert(/PUBLIC/.test(txt) && !/SECRET/.test(txt), txt);
  });

  /* ---------- v3.4 language layer ---------- */
  await t("detectLang: en/ar/ur/hi/ml/ta", async () => {
    const cases = {
      en: "The quick brown fox jumps over the lazy dog.",
      ar: "ذهب الطالب إلى المدرسة في الصباح الباكر.",
      ur: "یہ ایک اچھی کتاب ہے اور میں اسے پڑھ رہا ہوں۔",
      hi: "यह एक अच्छी किताब है और मैं इसे पढ़ रहा हूँ।",
      ml: "ഇതൊരു നല്ല പുസ്തകമാണ്, ഞാൻ അത് വായിക്കുന്നു.",
      ta: "இது ஒரு நல்ல புத்தகம், நான் அதைப் படிக்கிறேன்.",
    };
    for (const [lang, s] of Object.entries(cases)) assert(PDCore.detectLang(s) === lang, lang + " -> " + PDCore.detectLang(s));
    assert(PDCore.langDir("ar") === "rtl" && PDCore.langDir("ur") === "rtl" && PDCore.langDir("ml") === "ltr");
    assert(PDCore.detectLang("12345 !!") === null);
  });
  await t("normalizeText folds Arabic presentation forms + ligatures", async () => {
    const pres = "ﺍﻟﺴﻼﻡ"; // ﺍﻟﺴﻼﻡ
    assert(PDCore.normalizeText(pres) === "السلام", JSON.stringify(PDCore.normalizeText(pres)));
    assert(PDCore.normalizeText("ﬁle of­fice") === "file office");
    assert(PDCore.normalizeText("كتـــاب") === "كتاب", "tatweel");
    const ml = "ഞാൻ"; // chillu must survive
    assert(PDCore.normalizeText(ml) === ml.normalize("NFKC"));
  });
  await t("visual-order Arabic is detected and repaired", async () => {
    const logical = "ذهب الطالب إلى المدرسة في الصباح وقرأ الكتاب في المكتبة العامة";
    const visual = Array.from(logical).reverse().join("");
    assert(!PDCore.looksVisualOrder(logical), "logical flagged");
    assert(PDCore.looksVisualOrder(visual), "visual missed " + JSON.stringify(PDCore.rtlOrderScore(visual)));
    assert(PDCore.reverseVisual(visual) === logical, PDCore.reverseVisual(visual));
    // numbers and Latin stay forwards
    const mixed = "صفحة 2026 PDF الكتاب";
    const vis = PDCore.reverseVisual(mixed);
    assert(/PDF/.test(vis) && /2026/.test(vis), "LTR runs must stay forwards in visual order: " + vis);
    assert(PDCore.reverseVisual(vis) === mixed, PDCore.reverseVisual(vis));
  });
  await t("textQuality flags ML-TT / Kruti Dev / PUA text, passes clean text", async () => {
    const clean = ["The quick brown fox jumps over the lazy dog and keeps running across the field.",
      "ഇതൊരു നല്ല പുസ്തകമാണ്, ഞാൻ അത് വായിക്കുന്നു. മലയാളം വളരെ മനോഹരമായ ഭാഷയാണ്.",
      "ذهب الطالب إلى المدرسة في الصباح الباكر وقرأ الكتاب."];
    for (const c of clean) assert(!PDCore.textQuality(c).garbled, "false positive: " + c.slice(0, 20) + " " + PDCore.textQuality(c).reason);
    const mltt = "tIcf kÀ¡mÀ hmÀ¯I Ah³ ]Ã¯n¡m³ tIcf kÀ¡m­À hn`mKw sNbvXp ¨Xv";
    assert(PDCore.textQuality(mltt).garbled, "ML-TT missed " + JSON.stringify(PDCore.textQuality(mltt)));
    const kruti = "vkSj ;g fdlh Hkh jkT; ds fy, t:jh gS fd og vius ukxfjdksa dh lqj{kk djs";
    assert(PDCore.textQuality(kruti).garbled, "Kruti missed " + JSON.stringify(PDCore.textQuality(kruti)));
    const pua = "   ";
    assert(PDCore.textQuality(pua).garbled, "PUA missed");
    assert(PDCore.legacyFontLang(["ABCDEF+ML-TTKarthika"]) === "ml");
    assert(PDCore.legacyFontLang(["KrutiDev010"]) === "hi");
    assert(PDCore.legacyFontLang(["Helvetica"]) === null);
    assert(PDCore.legacyFontLang(["Agrandir-Regular"]) === null, "Agrandir is Latin");
    assert(PDCore.legacyFontLang(["ABCDEF+Amanda"]) === null, "Amanda is Latin");
    assert(PDCore.legacyFontLang(["Agra-Bold"]) === "hi");
  });
  await t("splitSentences: Latin, ؟ ، ۔ । and abbreviations", async () => {
    const pick = s => PDCore.splitSentences(s).map(r => s.slice(r.start, r.end));
    let r = pick("Dr. Smith arrived at 3.5 p.m. today. He left! Did he? Yes.");
    assert(r.length === 4 && r[0] === "Dr. Smith arrived at 3.5 p.m. today.", JSON.stringify(r));
    r = pick("هل ذهبت؟ نعم، ذهبت إلى السوق.");
    assert(r.length === 3 && r[0] === "هل ذهبت؟" && r[1] === "نعم،", JSON.stringify(r));
    r = pick("यह पहला वाक्य है। यह दूसरा है।");
    assert(r.length === 2, JSON.stringify(r));
    r = pick("یہ پہلا جملہ ہے۔ یہ دوسرا ہے۔");
    assert(r.length === 2 && r[0] === "یہ پہلا جملہ ہے۔", "urdu full stop " + JSON.stringify(r));
    r = pick("line one\nline two");
    assert(r.length === 2, "newline");
    const long = ("word ".repeat(120)).trim() + ".";
    assert(PDCore.splitSentences(long, 200).every(x => x.end - x.start <= 200), "maxLen");
    const wl = PDCore.sentencesWithLang("Hello there. مرحبا بك. नमस्ते दोस्त।");
    assert(wl.map(x => x.lang).join() === "en,ar,hi", JSON.stringify(wl));
  });
  await t("buildPageText: lines, paragraphs, dehyphenation, offsets→boxes", async () => {
    const runs = [
      { str: "Chapter One", x: 50, y: 40, w: 200, h: 24, eol: true },
      { str: "This is a para-", x: 50, y: 100, w: 300, h: 12, eol: true },
      { str: "graph that wraps.", x: 50, y: 114, w: 300, h: 12, eol: true },
      { str: "Second", x: 50, y: 160, w: 60, h: 12 },
      { str: "paragraph", x: 114, y: 160, w: 90, h: 12, eol: true },
    ];
    const pg = PDCore.buildPageText(runs);
    assert(pg.text === "Chapter One\nThis is a paragraph that wraps.\nSecond paragraph", JSON.stringify(pg.text));
    assert(pg.paras.length === 3 && pg.paras[0].heading, JSON.stringify(pg.paras));
    const at = pg.text.lastIndexOf("paragraph");
    const hy = pg.text.indexOf("paragraph");
    assert(PDCore.boxesForRange(pg, hy, hy + 9).length === 2, "hyphen-joined word spans two lines");
    const boxes = PDCore.boxesForRange(pg, at, at + 9);
    assert(boxes.length === 1 && Math.abs(boxes[0].x - 114) < 1, JSON.stringify(boxes));
    const off = PDCore.offsetAtPoint(pg, 120, 165);
    assert(off >= at && off <= at + 3, "offsetAtPoint " + off + " vs " + at);
    const w = PDCore.wordRangeAt(pg.text, at + 3);
    assert(pg.text.slice(w.start, w.end) === "paragraph");
    assert(pg.lang === "en" && !pg.quality.garbled);
  });
  await t("buildPageText repairs a visually-ordered Arabic page", async () => {
    const lines = ["ذهب الطالب إلى المدرسة في الصباح", "وقرأ الكتاب في المكتبة العامة"];
    const runs = lines.map((l, i) => ({ str: Array.from(l).reverse().join(""), x: 50, y: 50 + i * 16, w: 300, h: 12, eol: true }));
    const pg = PDCore.buildPageText(runs);
    assert(pg.visualOrderFixed && pg.text === lines.join(" "), JSON.stringify(pg.text));
    assert(pg.lang === "ar" && pg.dir === "rtl" && pg.runs[0].rtl);
  });
  await t("repairArabic / repairIndic fix impossible ligature & vowel-sign orders", async () => {
    assert(PDCore.repairArabic("الفصل األول") === "الفصل الأول", PDCore.repairArabic("الفصل األول"));
    assert(PDCore.repairArabic("قال ال شيء") === "قال لا شيء");
    assert(PDCore.repairArabic("الكتاب") === "الكتاب", "article untouched");
    assert(PDCore.repairIndic("िहन्दी") === "हिन्दी", PDCore.repairIndic("िहन्दी"));
    assert(PDCore.repairIndic("ഇെതാരു").normalize("NFC") === "ഇതൊരു", PDCore.repairIndic("ഇെതാരു"));
    assert(PDCore.repairIndic("அைதப்") === "அதைப்", PDCore.repairIndic("அைதப்"));
    for (const ok of ["हिन्दी", "ഇതൊരു നല്ല", "அதைப் படிக்கிறேன்"]) assert(PDCore.repairIndic(ok) === ok, "changed clean text: " + ok);
  });
  await t("hashBytes is stable and size-sensitive", async () => {
    const a = new Uint8Array(600000).map((_, i) => i * 7);
    const b = a.slice(); b[300000] ^= 1; // middle byte: not sampled, same hash expected
    const c = a.slice(0, a.length - 1);
    assert(PDCore.hashBytes(a) === PDCore.hashBytes(a.slice()));
    assert(PDCore.hashBytes(a) === PDCore.hashBytes(b), "middle sampling");
    assert(PDCore.hashBytes(a) !== PDCore.hashBytes(c));
    assert(PDCore.countWords("One two, three — ഇതൊരു നല്ല") === 5);
    assert(PDCore.fmtDuration(95) === "1 h 35 min");
  });
  await t("inkBBox trims to inked pixels (alpha + white knockout)", async () => {
    const w = 20, hgt = 10, px = new Uint8ClampedArray(w * hgt * 4);
    for (let i = 0; i < px.length; i += 4) { px[i] = px[i + 1] = px[i + 2] = 255; px[i + 3] = 255; } // opaque white
    const put = (x, y) => { const i = (y * w + x) * 4; px[i] = px[i + 1] = px[i + 2] = 20; };
    put(5, 3); put(12, 7);
    assert(PDCore.inkBBox(px, w, hgt) && PDCore.inkBBox(px, w, hgt).w === 20, "alpha-only sees whole image");
    const b = PDCore.inkBBox(px, w, hgt, { whiteCut: 235 });
    assert(b.x === 5 && b.y === 3 && b.w === 8 && b.h === 5, JSON.stringify(b));
  });
  /* ---- v3.5.1: edit history (undo / redo / named steps / dirty tracking) ---- */
  const snap = (tag, size) => ({ buf: tag, size: size || 10 });
  await t("EditHistory: undo/redo restore the right snapshots with their labels", async () => {
    const H = new PDCore.EditHistory();
    assert(!H.dirty && !H.canUndo && !H.canRedo, "fresh history is clean");
    H.push("Rotate page 1 clockwise", snap("A"), [0]);       // A -> B
    H.push("Crop 3 pages", snap("B"), [0, 1, 2]);              // B -> C
    assert(H.dirty && H.depth === 2 && H.undoLabel === "Crop 3 pages", "after two edits");
    let e = H.undo(snap("C"));
    assert(e.buf === "B" && e.label === "Crop 3 pages" && JSON.stringify(e.idx) === "[0,1,2]", "undo returns B");
    assert(H.canRedo && H.redoLabel === "Crop 3 pages" && H.undoLabel === "Rotate page 1 clockwise", "labels after undo");
    e = H.redo(snap("B"));
    assert(e.buf === "C" && !H.canRedo && H.depth === 2, "redo returns C");
    e = H.undo(snap("C")); e = H.undo(snap("B"));
    assert(e.buf === "A" && !H.dirty, "undo all the way = clean again");
    assert(H.undo(snap("A")) === null, "nothing left to undo");
  });
  await t("EditHistory: a new edit clears redo, and undo-then-edit stays dirty", async () => {
    const H = new PDCore.EditHistory();
    H.push("Rotate page 1 clockwise", snap("A"));
    H.markSaved();                                   // saved at B
    H.undo(snap("B"));                               // back to A: differs from disk
    assert(H.dirty && H.canRedo, "undo past the save point is dirty");
    H.push("Crop page 1", snap("A"));                // A -> D, same depth as the saved state
    assert(!H.canRedo, "new edit dropped the redo step");
    assert(H.dirty && H.depth === 1, "same depth as saved but different content must stay dirty");
    H.undo(snap("D"));
    assert(H.dirty, "A is still not what was saved");
  });
  await t("EditHistory: limits trim the oldest steps, dirty state survives trimming", async () => {
    const H = new PDCore.EditHistory({ max: 3, maxBytes: 1000 });
    for (let i = 0; i < 6; i++) H.push("Step " + i, snap("S" + i));
    assert(H.depth === 3 && H.undoLabel === "Step 5", "count limit keeps the newest 3");
    assert(H.dirty, "still dirty");
    const B = new PDCore.EditHistory({ max: 20, maxBytes: 250 });
    for (let i = 0; i < 5; i++) B.push("Big " + i, snap("X" + i, 100));
    assert(B.depth === 2 && B.bytes() <= 250, "byte limit: depth " + B.depth + ", bytes " + B.bytes());
    B.markSaved(); B.undo(snap("cur", 100)); B.redo(snap("prev", 100));
    assert(!B.dirty, "undo + redo returns to the saved state");
    const R = new PDCore.EditHistory();
    R.markUnsaved();
    assert(R.dirty && !R.canUndo, "recovered document is dirty with nothing to undo");
    R.reset();
    assert(!R.dirty && !R.canUndo && !R.canRedo, "reset = clean, empty");
  });
  await t("pastTense names finished steps for toasts", async () => {
    assert(PDCore.pastTense("Rotate 3 pages clockwise") === "Rotated 3 pages clockwise");
    assert(PDCore.pastTense("Crop page 2") === "Cropped page 2");
    assert(PDCore.pastTense("Insert blank page") === "Inserted blank page");
    assert(PDCore.pastTense("Delete page 4") === "Deleted page 4");
    assert(PDCore.pastTense("Duplicate page 1") === "Duplicated page 1");
  });
  await t("recoveryOrphans skips live sessions and our own, newest first", async () => {
    const entries = [
      { key: "a", session: "dead1", at: 100 },
      { key: "b", session: "me", at: 300 },
      { key: "c", session: "alive", at: 400 },
      { key: "d", session: "dead2", at: 200 },
    ];
    const got = PDCore.recoveryOrphans(entries, ["alive"], "me").map(e => e.key).join(",");
    assert(got === "d,a", got);
    assert(PDCore.recoveryOrphans([], [], "me").length === 0);
  });
  /* ---- v3.5.1: PDF -> Excel ---- */
  await t("parseCellNumber reads amounts, keeps ids/phones/dates as text", async () => {
    const P = s => PDCore.parseCellNumber(s);
    const eq = (s, v, f) => { const r = P(s); assert(r && Math.abs(r.v - v) < 1e-9 && (!f || r.fmt === f), s + " -> " + JSON.stringify(r)); };
    eq("1,234.50", 1234.5, "dec"); eq("(1,200)", -1200, "int"); eq("-45", -45, "gen"); eq("12.5%", 0.125, "pct2");
    eq("AED 3,000", 3000, "int"); eq("$19.99", 19.99, "dec"); eq("250.00 AED", 250, "dec"); eq("7", 7, "gen"); eq("0.5", 0.5, "dec");
    for (const txt of ["00123", "050 123 4567", "12/05/2026", "2026-10-19", "INV-0042", "Total", "1234567890123456", "", "1.2.3"])
      assert(P(txt) === null, "should stay text: " + txt);
  });
  await t("tableFromWords: columns from positions, phrases kept together, empty columns dropped", async () => {
    const W = (str, x, y, w) => ({ str, x, y, w: w || str.length * 5, h: 10 });
    const words = [
      W("Monthly", 40, 20), W("report", 79, 20),                    // title: one phrase, column A
      W("Item", 40, 50), W("Qty", 200, 50), W("Unit", 300, 50), W("price", 324, 50), W("Total", 420, 50),
      W("Water", 40, 70), W("tank", 68, 70), W("2", 210, 70), W("150.00", 300, 70), W("300.00", 420, 70),
      W("Pump", 40, 90), W("1", 210, 90), W("1,200.00", 290, 90), W("1,200.00", 410, 90),
      W("Grand", 40, 110), W("total", 68, 110), W("1,500.00", 410, 110),
    ];
    const { rows, cols } = PDCore.tableFromWords(words);
    assert(cols === 4, "cols " + cols + " " + JSON.stringify(rows));
    assert(JSON.stringify(rows[0]) === JSON.stringify(["Monthly report", null, null, null]), "title row " + JSON.stringify(rows[0]));
    assert(JSON.stringify(rows[1]) === JSON.stringify(["Item", "Qty", "Unit price", "Total"]), "header " + JSON.stringify(rows[1]));
    assert(JSON.stringify(rows[2]) === JSON.stringify(["Water tank", "2", "150.00", "300.00"]), "row " + JSON.stringify(rows[2]));
    assert(JSON.stringify(rows[4]) === JSON.stringify(["Grand total", null, null, "1,500.00"]), "total " + JSON.stringify(rows[4]));
    assert(PDCore.tableFromWords([]).rows.length === 0);
  });
  await t("PDF -> Excel end to end: a drawn table comes out as cells and numbers in a valid .xlsx", async () => {
    const mupdf = await import(VENDOR + "mupdf-pkg/dist/mupdf.js");
    const d = await PDFDocument.create();
    const f = await d.embedFont(StandardFonts.Helvetica);
    const p = d.addPage([595, 842]);
    const put = (txt, x, row) => p.drawText(txt, { x, y: 780 - row * 20, size: 10, font: f });
    put("Camp 07 WiFi sales - October", 50, 0);
    [["Date", "Cards sold", "Rate", "Amount"], ["01 Oct", "12", "10.00", "120.00"], ["02 Oct", "9", "10.00", "90.00"], ["Total", "", "", "1,210.50"]]
      .forEach((r, i) => r.forEach((c, j) => { if (c) put(c, [50, 200, 320, 440][j] + (j >= 2 ? 40 - f.widthOfTextAtSize(c, 10) : 0), i + 2); }));
    const bytes = await d.save();
    const doc = mupdf.Document.openDocument(bytes.slice(0), "application/pdf");
    const st = doc.loadPage(0).toStructuredText("preserve-whitespace");
    const { runs } = PDCore.stextWordRuns(st);
    const { rows } = PDCore.tableFromWords(runs);
    const flat = rows.map(r => r.map(c => c == null ? "" : c).join("|"));
    assert(flat[0] === "Camp 07 WiFi sales - October|||", "title " + flat[0]);
    assert(flat[1] === "Date|Cards sold|Rate|Amount", "header " + flat[1]);
    assert(flat[2] === "01 Oct|12|10.00|120.00", "row " + flat[2]);
    assert(flat[4] === "Total|||1,210.50", "total " + flat[4]);
    const x = PDCore.buildXlsx([{ name: "Page 1", rows }, { name: "Page 1", rows: [["dup name"]] }, { name: "a/b:c*?[x]", rows: [[1.5, "<&>"]] }]);
    const files = await PDCore.unzipBytes(x);
    const names = Object.keys(files);
    for (const want of ["[Content_Types].xml", "_rels/.rels", "xl/workbook.xml", "xl/_rels/workbook.xml.rels", "xl/styles.xml", "xl/worksheets/sheet1.xml", "xl/worksheets/sheet3.xml"])
      assert(names.includes(want), "missing " + want + " in " + names.join(","));
    const dec = n => new TextDecoder().decode(files[n]);
    const wb = dec("xl/workbook.xml");
    assert(/name="Page 1"/.test(wb) && /name="Page 1 2"/.test(wb) && /name="a b c   x"/.test(wb), "sheet names: " + wb);
    const s1 = dec("xl/worksheets/sheet1.xml");
    assert(/<c r="D5" s="2"><v>1210.5<\/v><\/c>/.test(s1), "Total as a number with 2 decimals: " + s1.slice(0, 400));
    assert(/<c r="B3"><v>12<\/v>/.test(s1) && /<c r="A3" t="inlineStr"><is><t xml:space="preserve">01 Oct</.test(s1), "cells typed");
    assert(/&lt;&amp;&gt;/.test(dec("xl/worksheets/sheet3.xml")), "xml escaped");
  });
  /* ---- v3.6: command palette search + shortcut parsing ---- */
  await t("fuzzyScore ranks prefix/word-start/contiguous matches and rejects non-matches", async () => {
    const F = PDCore.fuzzyScore;
    assert(F("", "anything") === 0, "empty query matches everything");
    assert(F("xyz", "Rotate clockwise") === null, "no match");
    assert(F("rot", "Rotate clockwise") > F("rot", "Merge, protect"), "prefix beats middle");
    assert(F("pdf exc", "PDF to Excel") != null && F("exc pdf", "PDF to Excel") != null, "words in any order");
    assert(F("pte", "PDF to Excel") != null, "word starts P-t-E");
    assert(F("cmp", "Compress") != null && F("comp", "Compress") > F("comp", "Crop or map"), "subsequence + contiguity");
    const names = ["Save", "Save as…", "Search tools and commands", "Sign"];
    const best = names.map(n => [n, F("save", n)]).filter(x => x[1] != null).sort((a, b) => b[1] - a[1])[0][0];
    assert(best === "Save", "exact word first, got " + best);
  });
  await t("keysMatch / keysLabel: Mod = Ctrl or Cmd, Ctrl+ is Ctrl only", async () => {
    const ev = (key, o) => Object.assign({ key, ctrlKey: false, metaKey: false, shiftKey: false, altKey: false }, o);
    const M = PDCore.keysMatch;
    assert(M("Mod+S", ev("s", { ctrlKey: true })) && M("Mod+S", ev("s", { metaKey: true })), "Mod+S");
    assert(!M("Mod+S", ev("s", { ctrlKey: true, shiftKey: true })), "shift must match");
    assert(M("Mod+Shift+S", ev("S", { metaKey: true, shiftKey: true })), "Mod+Shift+S with capital key");
    assert(M("Ctrl+Y", ev("y", { ctrlKey: true })) && !M("Ctrl+Y", ev("y", { metaKey: true })), "Ctrl+Y is Control only");
    assert(!M("Mod+K", ev("k")), "needs the modifier");
    assert(M("Mod+/", ev("?", { ctrlKey: true, shiftKey: true })), "Mod+/ also as Mod+? on layouts that need Shift");
    assert(PDCore.keysLabel("Mod+Shift+S", true) === "⇧⌘S" && PDCore.keysLabel("Mod+Shift+S", false) === "Ctrl+Shift+S", "labels");
    assert(PDCore.keysLabel("Ctrl+Y", true) === "⌃Y", "mac ctrl label");
  });
  await t("writeOutline / readOutline round trip (nesting, pages, named and GoTo destinations)", async () => {
    const { PDFName, PDFString, PDFArray, PDFNull } = globalThis.PDFLib;
    const d = await PDFDocument.create();
    for (let i = 0; i < 4; i++) d.addPage([300, 400]);
    PDCore.writeOutline(d, [{ title: "Intro", page: 0 }, { title: "Part B", page: 1, open: true, items: [{ title: "B.1 – Ünïcode", page: 2 }, { title: "B.2", page: 3 }] }]);
    const back = await PDFDocument.load(await d.save());
    const ol = PDCore.readOutline(back);
    const pageNo = dest => back.getPages().findIndex(p => p.ref === dest.get(0));
    assert(ol.length === 2 && ol[1].items.length === 2, JSON.stringify(ol.map(o => o.title)));
    assert(ol[1].items[0].title === "B.1 – Ünïcode", "unicode title " + ol[1].items[0].title);
    assert(pageNo(ol[0].dest) === 0 && pageNo(ol[1].items[1].dest) === 3, "page targets");
    // named destination via /Dests + GoTo action
    const ctx = back.context;
    const dests = ctx.obj({});
    const arr = PDFArray.withContext(ctx); arr.push(back.getPage(2).ref); arr.push(PDFName.of("Fit"));
    dests.set(PDFName.of("chap3"), arr);
    back.catalog.set(PDFName.of("Dests"), ctx.register(dests));
    const root = ctx.lookup(back.catalog.get(PDFName.of("Outlines")));
    const first = ctx.lookup(root.get(PDFName.of("First")));
    first.delete(PDFName.of("Dest"));
    first.set(PDFName.of("A"), ctx.obj({ S: "GoTo", D: PDFString.of("chap3") }));
    const ol2 = PDCore.readOutline(back);
    assert(back.getPages().findIndex(p => p.ref === ol2[0].dest.get(0)) === 2, "GoTo + named dest resolved");
    PDCore.writeOutline(back, []);
    assert(PDCore.readOutline(back).length === 0, "outline removed");
  });
  /* ---- v3.7: real annotations through MuPDF ---- */
  await t("addAnnots: every comment type is a real annotation that survives save -> reopen", async () => {
    const mupdf = await import(VENDOR + "mupdf-pkg/dist/mupdf.js");
    const d = await PDFDocument.create();
    const f = await d.embedFont(StandardFonts.Helvetica);
    const p0 = d.addPage([400, 600]); p0.drawText("Annotate this line", { x: 50, y: 500, size: 14, font: f });
    d.addPage([400, 600]).setRotation(globalThis.PDFLib.degrees(90));
    // an annotation another app made (plain pdf-lib Square)
    const other = d.context.obj({ Type: "Annot", Subtype: "Square", Rect: [10, 10, 60, 60], C: [0, 0, 1], T: globalThis.PDFLib.PDFHexString.fromText("Acrobat user"), Contents: globalThis.PDFLib.PDFHexString.fromText("from another app") });
    d.getPage(1).node.set(globalThis.PDFLib.PDFName.of("Annots"), d.context.obj([d.context.register(other)]));
    const src = await d.save();
    const Y = [1, 0.85, 0];
    const ops = [
      { page: 0, type: "highlight", quads: [[50, 86, 180, 86, 50, 102, 180, 102]], color: Y, author: "Ameen" },
      { page: 0, type: "underline", quads: [[50, 86, 180, 86, 50, 102, 180, 102]], color: [0, 0.5, 0] },
      { page: 0, type: "strikeout", quads: [[50, 86, 180, 86, 50, 102, 180, 102]], color: [1, 0, 0] },
      { page: 0, type: "note", rect: [300, 80, 320, 100], contents: "Check this figure", color: Y },
      { page: 0, type: "box", rect: [60, 200, 160, 260], color: [1, 0, 0], width: 2 },
      { page: 0, type: "oval", rect: [180, 200, 280, 260], color: [0, 0, 1], width: 2 },
      { page: 0, type: "line", line: [[60, 300], [200, 340]], arrow: true, color: [0, 0, 0], width: 2 },
      { page: 0, type: "ink", ink: [[[60, 400], [80, 420], [100, 410]]], color: [0, 0.5, 0], width: 2 },
      { page: 1, type: "stamp", rect: [100, 100, 250, 150], stamp: "Paid" },
      { page: 1, type: "highlight", boxes: [[696, 60, 716, 200]], color: Y },   // on the page turned 90°
    ];
    const out = PDCore.addAnnots(mupdf, src, ops);
    const re = await PDFDocument.load(out);
    const subs = i => { const A = re.getPage(i).node.Annots(); const r = []; for (let k = 0; k < (A ? A.size() : 0); k++) r.push(re.context.lookup(A.get(k)).get(globalThis.PDFLib.PDFName.of("Subtype")).decodeText()); return r; };
    const s0 = subs(0).filter(x => x !== "Popup");
    // (page 2 also gets a highlight; checked through listAnnots below)
    assert(JSON.stringify(s0) === JSON.stringify(["Highlight", "Underline", "StrikeOut", "Text", "Square", "Circle", "Line", "Ink"]), "page 1 subtypes " + s0);
    assert(subs(1).includes("Stamp") && subs(1).includes("Square"), "page 2 keeps the other app's annotation and gets the stamp: " + subs(1));
    const list = PDCore.listAnnots(mupdf, out);
    assert(list.length === 11, "listed " + list.length + " " + list.map(x => x.subtype));
    const rh = list.find(x => x.kind === "highlight" && x.page === 1).bounds;
    assert(Math.abs(rh[0] - 696) < 3 && Math.abs(rh[1] - 60) < 7 && Math.abs(rh[2] - 716) < 3 && Math.abs(rh[3] - 200) < 7, "rotated-page highlight stays on its box: " + rh.map(Math.round));
    assert(JSON.stringify(PDCore.boxQuad([1, 2, 3, 4], 90)) === "[3,2,3,4,1,2,1,4]", "quad order on a 90° page");
    const note = list.find(x => x.kind === "note");
    assert(note && note.contents === "Check this figure" && note.page === 0, "note listed with text");
    assert(list.find(x => x.kind === "highlight").author === "Ameen", "author kept");
    const stamp = list.find(x => x.kind === "stamp");
    assert(stamp.icon === "Paid" && stamp.page === 1, "stamp icon " + stamp.icon);
    const foreign = list.find(x => x.author === "Acrobat user");
    assert(foreign && foreign.kind === "box" && foreign.contents === "from another app", "other app's annotation listed");
    // edit a note, delete the other app's annotation
    const edited = PDCore.changeAnnot(mupdf, out, note, { contents: "Figure checked" });
    const l2 = PDCore.listAnnots(mupdf, edited);
    assert(l2.find(x => x.kind === "note").contents === "Figure checked", "note edited");
    const f2 = l2.find(x => x.author === "Acrobat user");
    const del = PDCore.changeAnnot(mupdf, edited, f2, { delete: true });
    const l3 = PDCore.listAnnots(mupdf, del);
    assert(l3.length === 10 && !l3.some(x => x.author === "Acrobat user"), "deleted: " + l3.length);
    let threw = false;
    try { PDCore.changeAnnot(mupdf, del, { page: 1, index: 7, subtype: "Square" }, { delete: true }); } catch (e) { threw = true; }
    assert(threw, "stale target refused");
  });
  await t("merge keeps bookmarks (one entry per file, remapped) and internal links", async () => {
    const { PDFName, PDFArray, PDFDict, PDFString } = globalThis.PDFLib;
    const mk = async (pages, tree, link) => {
      const d = await PDFDocument.create();
      for (let i = 0; i < pages; i++) d.addPage([300, 400]);
      PDCore.writeOutline(d, tree);
      if (link) {   // a link on page 0 to page `link`, via a named destination
        const ctx = d.context;
        const arr = PDFArray.withContext(ctx); arr.push(d.getPage(link).ref); arr.push(PDFName.of("Fit"));
        const dests = ctx.obj({}); dests.set(PDFName.of("target"), arr);
        d.catalog.set(PDFName.of("Dests"), ctx.register(dests));
        const ann = ctx.obj({ Type: "Annot", Subtype: "Link", Rect: [10, 10, 100, 30], Dest: PDFString.of("target"), P: d.getPage(0).ref });
        d.getPage(0).node.set(PDFName.of("Annots"), ctx.obj([ctx.register(ann)]));
      }
      return d.save();
    };
    const A = await mk(3, [{ title: "A1", page: 0 }, { title: "A2", page: 2, items: [{ title: "A2.1", page: 1 }] }], 2);
    const B = await mk(2, [{ title: "B1", page: 1 }]);
    const out = await PDFDocument.load(await PDCore.mergePdfs([A, B], [null, null], null, { names: ["Lease.pdf", "Invoice.pdf"] }));
    const pages = out.getPages();
    assert(pages.length === 5, "pages " + pages.length);
    let pageObjs = 0;
    for (const [, obj] of out.context.enumerateIndirectObjects()) if (obj instanceof PDFDict && obj.get(PDFName.of("Type")) && obj.get(PDFName.of("Type")).decodeText() === "Page") pageObjs++;
    assert(pageObjs === 5, "no hidden extra page copies (found " + pageObjs + " page objects)");
    const ol = PDCore.readOutline(out);
    const pg = n => pages.findIndex(p => p.ref === n.dest.get(0));
    assert(ol.map(o => o.title).join("|") === "Lease|Invoice", "top level " + ol.map(o => o.title));
    assert(pg(ol[0]) === 0 && pg(ol[1]) === 3, "file entries open their first page");
    const a = ol[0].items;
    assert(a.map(o => o.title).join("|") === "A1|A2" && a[1].items[0].title === "A2.1", "A's bookmarks nested");
    assert(pg(a[0]) === 0 && pg(a[1]) === 2 && pg(a[1].items[0]) === 1 && pg(ol[1].items[0]) === 4, "destinations remapped");
    assert(a[1].dest.get(1).decodeText() === "XYZ", "fit type kept");
    const link = out.context.lookup(pages[0].node.Annots().get(0));
    const ld = out.context.lookup(link.get(PDFName.of("Dest")));
    assert(ld instanceof PDFArray && pages.indexOf(pages.find(p => p.ref === ld.get(0))) === 2 && ld.get(1).decodeText() === "Fit", "internal link points at merged page 3");
    // ranged: A pages 1-2 only → A2's own page is gone but its child stays; the link target (page 3) is gone
    const out2 = await PDFDocument.load(await PDCore.mergePdfs([A, B], ["1-2", "2"], null, { names: ["Lease.pdf", "Invoice.pdf"] }));
    const ol2 = PDCore.readOutline(out2), p2 = out2.getPages();
    const pg2 = n => p2.findIndex(p => p.ref === n.dest.get(0));
    assert(p2.length === 3 && ol2[0].items.map(o => o.title).join("|") === "A1|A2" && pg2(ol2[0].items[1]) === 1 && pg2(ol2[1].items[0]) === 2, "ranged merge outline");
    const link2 = out2.context.lookup(p2[0].node.Annots().get(0));
    assert(!link2.get(PDFName.of("Dest")), "link to a page that wasn't merged is disabled");
    const plain = await PDFDocument.load(await PDCore.mergePdfs([A, B], [null, null], null, { names: ["a.pdf", "b.pdf"], bookmarks: false }));
    assert(PDCore.readOutline(plain).length === 0, "bookmarks can be turned off");
  });
  await t("docInfo / setDocInfo: description, version, page size, fonts (embedded or not)", async () => {
    const d = await PDFDocument.create();
    const helv = await d.embedFont(StandardFonts.Helvetica);
    const p = d.addPage([595.28, 841.89]); p.drawText("x", { font: helv, x: 10, y: 10 });
    d.setTitle("Old title"); d.setAuthor("Someone");
    const bytes = await d.save();
    const i1 = await PDCore.docInfo(bytes);
    assert(i1.title === "Old title" && i1.author === "Someone" && i1.pageCount === 1 && !i1.encrypted, JSON.stringify(i1));
    assert(/^1\.\d$/.test(i1.version), "version " + i1.version);
    assert(/^A4 · 210 × 297 mm$/.test(i1.size.label), "size " + i1.size.label);
    assert(i1.fonts.length === 1 && i1.fonts[0].name === "Helvetica" && !i1.fonts[0].embedded && i1.fonts[0].type === "Type 1", JSON.stringify(i1.fonts));
    const out = await PDCore.setDocInfo(bytes, { title: "Lease 2026 – Camp 7", author: "Ameen", subject: "Renewal", keywords: "lease, camp 7; 2026" });
    const i2 = await PDCore.docInfo(out);
    assert(i2.title === "Lease 2026 – Camp 7" && i2.author === "Ameen" && i2.subject === "Renewal", JSON.stringify(i2));
    assert(/lease/.test(i2.keywords) && /camp 7/.test(i2.keywords) && /2026/.test(i2.keywords), "keywords " + i2.keywords);
    assert(!i2.hasXmp && i2.modified > 0, "XMP dropped, modified stamped");
    assert(PDCore.paperName(842, 595) === "A4 · 297 × 210 mm, landscape", PDCore.paperName(842, 595));
    // a TrueType font that is embedded
    const mupdf = await import(VENDOR + "mupdf-pkg/dist/mupdf.js");
    const md = mupdf.Document.openDocument(bytes.slice(0), "application/pdf");
    const enc = PDCore.mupdfSave(md, "encrypt=aes-256,owner-password=o,user-password=,permissions=4");
    const i3 = await PDCore.docInfo(enc);
    assert(i3.encrypted && i3.pageCount === 1 && i3.title === "", "encrypted file still described: " + JSON.stringify({ e: i3.encrypted, n: i3.pageCount }));
  });
  /* ---- v3.5.1: desktop save in place (electron/safe-write.js) ---- */
  await t("writeAtomic replaces the file in place, keeps its mode, leaves no temp file", async () => {
    const fs = require("fs"), path = require("path"), os = require("os");
    const SW = require(fileURLToPath(new URL("../electron/safe-write.js", import.meta.url)));
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), "atob-save-"));
    const f = path.join(dir, "doc.pdf");
    fs.writeFileSync(f, "old contents");
    if (process.platform !== "win32") fs.chmodSync(f, 0o640);
    const n = SW.writeAtomic(f, new Uint8Array([37, 80, 68, 70]).buffer);
    assert(n === 4 && fs.readFileSync(f, "latin1") === "%PDF", "new bytes written");
    if (process.platform !== "win32") assert((fs.statSync(f).mode & 0o777) === 0o640, "mode kept: " + (fs.statSync(f).mode & 0o777).toString(8));
    assert(!fs.existsSync(f + ".atob-tmp"), "temp file removed");
    assert(SW.checkPdfPath(f, true) === null, "valid path accepted");
    assert(SW.checkPdfPath("doc.pdf", false), "relative path rejected");
    assert(SW.checkPdfPath(path.join(dir, "notes.txt"), false), "non-pdf rejected");
    assert(SW.checkPdfPath(path.join(dir, "gone.pdf"), true), "missing original rejected for Save");
    assert(SW.checkPdfPath(path.join(dir, "nope", "x.pdf"), false), "missing folder rejected for Save As");
    // a failed write leaves the original untouched and cleans up
    let threw = false;
    try { SW.writeAtomic(path.join(dir, "nope", "x.pdf"), Buffer.from("x")); } catch (e) { threw = true; }
    assert(threw && fs.readFileSync(f, "latin1") === "%PDF", "failure is clean");
    fs.rmSync(dir, { recursive: true, force: true });
  });
  console.log(pass + " passed, " + fail + " failed");
  process.exit(fail ? 1 : 0);
};
main().catch(e => { console.error("CRASH", e); process.exit(2); });
