/* AtoB PDF desktop: atomic file writes (v3.5.1). Plain Node, no Electron imports,
   so test/core.test.mjs can exercise it directly. */
const fs = require("fs");
const path = require("path");

/* Only absolute .pdf paths are writable through the save IPC. */
function checkPdfPath(p, mustExist) {
  if (typeof p !== "string" || !p || p.includes("\0")) return "No file path";
  if (!path.isAbsolute(p)) return "Not an absolute path";
  if (!/\.pdf$/i.test(p)) return "Only .pdf files can be saved";
  if (mustExist) {
    let st;
    try { st = fs.statSync(p); } catch (e) { return "The original file is gone (moved, renamed or deleted)"; }
    if (!st.isFile()) return "Not a regular file";
  } else if (!fs.existsSync(path.dirname(p))) return "The folder does not exist";
  return null;
}

/* Write data to <target>.atob-tmp, flush it to disk, then rename it over target.
   A crash or a full disk mid-write leaves the original untouched. The original
   file's permission bits are kept. Throws on failure (temp file removed). */
function writeAtomic(target, data) {
  const buf = Buffer.isBuffer(data) ? data : Buffer.from(data instanceof ArrayBuffer ? new Uint8Array(data) : data);
  const tmp = target + ".atob-tmp";
  let mode = null;
  try { mode = fs.statSync(target).mode & 0o777; } catch (e) { /* new file */ }
  let fd = null;
  try {
    fd = fs.openSync(tmp, "w", mode == null ? 0o666 : mode);
    let off = 0;
    while (off < buf.length) off += fs.writeSync(fd, buf, off, buf.length - off);
    fs.fsyncSync(fd);
    fs.closeSync(fd); fd = null;
    if (mode != null) { try { fs.chmodSync(tmp, mode); } catch (e) {} }
    fs.renameSync(tmp, target);
  } catch (err) {
    if (fd != null) { try { fs.closeSync(fd); } catch (e) {} }
    try { fs.unlinkSync(tmp); } catch (e) {}
    throw err;
  }
  return buf.length;
}

/* human message for common errno codes */
function saveError(err) {
  const c = err && err.code;
  if (c === "EACCES" || c === "EPERM") return "Permission denied. The file or its folder is read-only, or the file is open in another program";
  if (c === "EBUSY") return "The file is in use by another program";
  if (c === "ENOSPC") return "The disk is full";
  if (c === "EROFS") return "The disk is read-only";
  return String(err && err.message || err);
}

module.exports = { checkPdfPath, writeAtomic, saveError };
