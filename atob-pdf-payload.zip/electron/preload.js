const { contextBridge, ipcRenderer, webUtils } = require("electron");

contextBridge.exposeInMainWorld("pdeskAPI", {
  platform: process.platform,
  /* list: [{name, path, data: ArrayBuffer}] (path = absolute file path, v3.5.1) */
  onOpenFiles: cb => ipcRenderer.on("open-files", (e, list) => cb(list)),
  ready: () => ipcRenderer.send("renderer-ready"),
  /* v3.4: {name, data: ArrayBuffer, target: "email"|"whatsapp"|"any"} -> {ok, method, path?, error?} */
  shareFile: payload => ipcRenderer.invoke("share-file", payload),
  /* ---- v3.5.1: save in place, Save As, quit guard, menu commands ---- */
  /* absolute path of a File from a picker or a drop ("" if it has none) */
  pathForFile: file => {
    try { return (webUtils && webUtils.getPathForFile ? webUtils.getPathForFile(file) : file.path) || ""; }
    catch (e) { return ""; }
  },
  /* {path, data} -> {ok, path, error?}: atomic write over the original */
  saveFile: payload => ipcRenderer.invoke("save-in-place", payload),
  /* {name, path?, data} -> {ok, path, name, canceled?, error?}: native Save As dialog */
  saveAs: payload => ipcRenderer.invoke("save-as", payload),
  /* main asks before closing the window or quitting; answer with closeReply(true|false) */
  onCloseRequest: cb => ipcRenderer.on("query-close", (e, info) => { ipcRenderer.send("close-ack"); cb(info || {}); }),
  closeReply: ok => ipcRenderer.send("close-reply", !!ok),
  onMenuCommand: cb => ipcRenderer.on("menu-command", (e, id) => cb(String(id))),
  /* Windows: Settings > Default apps, opened at AtoB PDF */
  openDefaultApps: () => ipcRenderer.invoke("open-default-apps"),
});
