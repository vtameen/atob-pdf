const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("pdeskAPI", {
  platform: process.platform,
  onOpenFiles: cb => ipcRenderer.on("open-files", (e, list) => cb(list)),
  ready: () => ipcRenderer.send("renderer-ready"),
  /* v3.4: {name, data: ArrayBuffer, target: "email"|"whatsapp"|"any"} -> {ok, method, path?, error?} */
  shareFile: payload => ipcRenderer.invoke("share-file", payload),
});
