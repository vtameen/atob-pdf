const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("pdeskAPI", {
  onOpenFiles: cb => ipcRenderer.on("open-files", (e, list) => cb(list)),
  ready: () => ipcRenderer.send("renderer-ready"),
});
