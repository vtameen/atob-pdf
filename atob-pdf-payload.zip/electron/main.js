/* AtoB PDF desktop shell (Electron) */
const { app, BrowserWindow, dialog, ipcMain, session, Menu, shell, clipboard, ShareMenu } = require("electron");
const { execFile } = require("child_process");
const path = require("path");
const fs = require("fs");

let win = null;
let rendererReady = false;
const pendingBatches = [];
let fileBatch = [];
let batchTimer = null;

/* single instance: a second launch (or double-clicked PDF) routes here */
const gotLock = app.requestSingleInstanceLock();
if (!gotLock) app.quit();

/* Multi-selection in Explorer launches one process per file; the single-instance
   lock funnels them here in a quick burst. Collect for 500ms, then deliver as
   one batch: 1 file = open it, 2+ files = the app opens its Merge tool. */
function pushFile(p) {
  try {
    if (!p || !/\.pdf$/i.test(p) || !fs.existsSync(p)) return;
    const data = fs.readFileSync(p);
    fileBatch.push({ name: path.basename(p), data: data.buffer.slice(data.byteOffset, data.byteOffset + data.byteLength) });
    clearTimeout(batchTimer);
    batchTimer = setTimeout(flushBatch, 500);
    if (win) { if (win.isMinimized()) win.restore(); win.focus(); }
  } catch (e) { /* unreadable file: ignore */ }
}
function flushBatch() {
  if (!fileBatch.length) return;
  const batch = fileBatch;
  fileBatch = [];
  if (rendererReady && win) win.webContents.send("open-files", batch);
  else pendingBatches.push(batch);
}

app.on("second-instance", (e, argv) => {
  argv.filter(a => /\.pdf$/i.test(a)).forEach(pushFile);
  if (win) { if (win.isMinimized()) win.restore(); win.focus(); }
});
app.on("open-file", (e, p) => { e.preventDefault(); pushFile(p); }); // macOS

/* remember window size/position */
const stateFile = () => path.join(app.getPath("userData"), "window-state.json");
function loadState() {
  try { return JSON.parse(fs.readFileSync(stateFile(), "utf8")); } catch (e) { return {}; }
}
function saveState() {
  if (!win) return;
  try {
    const b = win.getNormalBounds();
    fs.writeFileSync(stateFile(), JSON.stringify({ ...b, max: win.isMaximized() }));
  } catch (e) {}
}

function createWindow() {
  const s = loadState();
  win = new BrowserWindow({
    width: s.width || 1280,
    height: s.height || 850,
    x: s.x, y: s.y,
    minWidth: 720, minHeight: 500,
    title: "AtoB PDF",
    backgroundColor: "#f7f5f1",
    icon: process.platform === "win32" ? path.join(__dirname, "build", "icon.ico") : undefined,
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
    },
  });
  if (s.max) win.maximize();
  win.on("close", saveState);
  win.on("closed", () => { win = null; });

  /* downloads -> native Save dialog, default to the user's Documents */
  session.defaultSession.on("will-download", (event, item) => {
    const target = dialog.showSaveDialogSync(win, {
      title: "Save file",
      defaultPath: path.join(app.getPath("documents"), item.getFilename()),
    });
    if (target) item.setSavePath(target);
    else item.cancel();
  });

  /* external links (about page etc.) open in the default browser */
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:/i.test(url)) shell.openExternal(url);
    return { action: "deny" };
  });

  win.loadFile(path.join(__dirname, "app", "AtoB-PDF.html"));
}

ipcMain.on("renderer-ready", () => {
  rendererReady = true;
  while (pendingBatches.length && win) win.webContents.send("open-files", pendingBatches.shift());
});

/* ---- v3.4 sharing: write the file to a temp folder, then hand it to the OS ----
   macOS: native share menu (Mail, Messages, AirDrop, WhatsApp…).
   Windows: copy the file itself to the clipboard + reveal it in Explorer, so
   the user can paste it straight into WhatsApp Desktop or an email. */
const shareRoot = () => path.join(app.getPath("temp"), "AtoB PDF share");
function cleanShareTemp() {
  try {
    const root = shareRoot();
    if (!fs.existsSync(root)) return;
    const cutoff = Date.now() - 24 * 3600 * 1000;
    for (const d of fs.readdirSync(root)) {
      const p = path.join(root, d);
      try { if (fs.statSync(p).mtimeMs < cutoff) fs.rmSync(p, { recursive: true, force: true }); } catch (e) {}
    }
  } catch (e) {}
}
function safeName(n) {
  const s = String(n || "atob-pdf-file").replace(/[\\/:*?"<>|\x00-\x1f]/g, "_").trim();
  return s || "atob-pdf-file";
}
function copyFileToClipboardWin(p) {
  return new Promise(resolve => {
    const lit = "'" + p.replace(/'/g, "''") + "'";
    execFile("powershell.exe", ["-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", "Set-Clipboard -LiteralPath " + lit],
      { windowsHide: true, timeout: 15000 }, err => {
        if (!err) return resolve(true);
        try { clipboard.writeBuffer("FileNameW", Buffer.from(p + "\0", "ucs2")); resolve(true); }
        catch (e) { resolve(false); }
      });
  });
}
ipcMain.handle("share-file", async (e, payload) => {
  try {
    const dir = path.join(shareRoot(), String(Date.now()));
    fs.mkdirSync(dir, { recursive: true });
    const p = path.join(dir, safeName(payload && payload.name));
    fs.writeFileSync(p, Buffer.from(payload.data));
    if (process.platform === "darwin" && ShareMenu) {
      const menu = new ShareMenu({ filePaths: [p] });
      menu.popup({ window: win || undefined });
      return { ok: true, method: "sharemenu", path: p };
    }
    if (process.platform === "win32") {
      const copied = await copyFileToClipboardWin(p);
      shell.showItemInFolder(p);
      return { ok: true, method: copied ? "clipboard" : "reveal", path: p };
    }
    shell.showItemInFolder(p);
    return { ok: true, method: "reveal", path: p };
  } catch (err) {
    return { ok: false, error: String(err && err.message || err) };
  }
});

/* minimal menu (keeps copy/paste shortcuts working on macOS) */
function buildMenu() {
  const template = [
    ...(process.platform === "darwin" ? [{ role: "appMenu" }] : []),
    { role: "fileMenu" },
    { role: "editMenu" },
    { label: "View", submenu: [{ role: "reload" }, { role: "togglefullscreen" }, { role: "toggleDevTools" }] },
    { role: "windowMenu" },
  ];
  Menu.setApplicationMenu(Menu.buildFromTemplate(template));
}

app.whenReady().then(() => {
  buildMenu();
  cleanShareTemp();
  createWindow();
  // Windows/Linux: files passed on first launch
  process.argv.slice(1).filter(a => /\.pdf$/i.test(a)).forEach(pushFile);
  app.on("activate", () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});
app.on("window-all-closed", () => { if (process.platform !== "darwin") app.quit(); });
