/* AtoB PDF desktop shell (Electron) */
const { app, BrowserWindow, dialog, ipcMain, session, Menu, shell, clipboard, ShareMenu, nativeTheme } = require("electron");
const { execFile } = require("child_process");
const path = require("path");
const fs = require("fs");
const { checkPdfPath, writeAtomic, saveError } = require("./safe-write");

let win = null;
let rendererReady = false;
const pendingBatches = [];
let fileBatch = [];
let batchTimer = null;
let allowClose = false;      // v3.5.1: the renderer said it's fine to close (nothing unsaved, or the user chose)
let quitting = false;        // the close is part of a quit (Cmd+Q / app menu Quit)
let closeAskedAt = 0;
let closeAckTimer = null;

/* v3.5.1 diagnostics: a small log of launches and file opens, so "double-clicking a PDF does
   nothing" can be traced on a user's PC (Help > Show log file). Capped at ~256 KB. */
let logPath = null;
function log(...parts) {
  try {
    if (!logPath) logPath = path.join(app.getPath("userData"), "atob-pdf.log");
    try { if (fs.statSync(logPath).size > 262144) fs.renameSync(logPath, logPath + ".old"); } catch (e) {}
    fs.appendFileSync(logPath, new Date().toISOString() + " [" + process.pid + "] " + parts.map(x => typeof x === "string" ? x : JSON.stringify(x)).join(" ") + "\n");
  } catch (e) { /* logging must never break the app */ }
}
log("launch v" + app.getVersion(), process.platform, process.arch, "argv:", process.argv.slice(1), "cwd:", process.cwd());

/* single instance: a second launch (or double-clicked PDF) routes here */
const gotLock = app.requestSingleInstanceLock();
if (!gotLock) { log("another AtoB PDF is running: handing the arguments to it and quitting"); app.quit(); }

/* bring the window forward. Windows blocks focus stealing from a background process (the
   file arrives through the already-running instance), so the window could stay hidden
   behind Explorer and the open looked like it did nothing; a brief always-on-top fixes that */
function showWindow() {
  if (!win) return;
  try {
    if (win.isMinimized()) win.restore();
    if (!win.isVisible()) win.show();
    if (process.platform === "win32") {
      win.setAlwaysOnTop(true);
      win.focus();
      setTimeout(() => { try { if (win) win.setAlwaysOnTop(false); } catch (e) {} }, 300);
      if (!win.isFocused()) win.flashFrame(true);
    } else {
      win.focus();
      if (process.platform === "darwin") app.focus({ steal: true });
    }
  } catch (e) { log("showWindow failed", String(e && e.message || e)); }
}

/* Multi-selection in Explorer launches one process per file; the single-instance
   lock funnels them here in a quick burst. Collect for 500ms, then deliver as
   one batch: 1 file = open it, 2+ files = the app opens its Merge tool. */
function pushFile(p) {
  try {
    if (!p || !/\.pdf$/i.test(p)) { log("ignored argument (not a .pdf):", p); return; }
    if (!fs.existsSync(p)) { log("file not found:", p); return; }
    const data = fs.readFileSync(p);
    fileBatch.push({ name: path.basename(p), path: p, data: data.buffer.slice(data.byteOffset, data.byteOffset + data.byteLength) });
    log("queued", p, data.length + " bytes");
    clearTimeout(batchTimer);
    batchTimer = setTimeout(flushBatch, 500);
    showWindow();
  } catch (e) { log("could not read", p, String(e && e.message || e)); }
}
function flushBatch() {
  if (!fileBatch.length) return;
  const batch = fileBatch;
  fileBatch = [];
  if (rendererReady && win) { win.webContents.send("open-files", batch); log("sent " + batch.length + " file(s) to the window"); }
  else { pendingBatches.push(batch); log("window not ready yet: holding " + batch.length + " file(s)"); }
}

app.on("second-instance", (e, argv, workingDirectory) => {
  log("second launch, argv:", argv.slice(1), "cwd:", workingDirectory);
  // relative paths (shell launches, some shortcuts) are relative to the second instance's cwd
  argv.filter(a => /\.pdf$/i.test(a)).forEach(a => pushFile(path.resolve(workingDirectory || process.cwd(), a)));
  showWindow();
});
app.on("open-file", (e, p) => { e.preventDefault(); log("open-file", p); pushFile(p); }); // macOS

/* remember window size/position */
const stateFile = () => path.join(app.getPath("userData"), "window-state.json");
function loadState() {
  try { return JSON.parse(fs.readFileSync(stateFile(), "utf8")); } catch (e) { return {}; }
}
function saveState() {
  if (!win) return;
  try {
    const b = win.getNormalBounds();
    fs.writeFileSync(stateFile(), JSON.stringify({ ...b, max: win.isMaximized() }));
  } catch (e) {}
}

function createWindow() {
  const s = loadState();
  win = new BrowserWindow({
    width: s.width || 1280,
    height: s.height || 850,
    x: s.x, y: s.y,
    minWidth: 720, minHeight: 500,
    title: "AtoB PDF",
    backgroundColor: nativeTheme && nativeTheme.shouldUseDarkColors ? "#1d1b19" : "#f7f5f1",   // v3.6: no white flash in dark mode
    icon: process.platform === "win32" ? path.join(__dirname, "build", "icon.ico") : undefined,
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
    },
  });
  if (s.max) win.maximize();
  allowClose = false;
  /* v3.5.1 quit/close guard: ask the page whether anything is unsaved. It shows its own
     Save / Don't save / Cancel prompt and answers on "close-reply". A page that doesn't
     acknowledge within 2.5 s (hung or crashed) can't hold the window open. */
  win.on("close", e => {
    saveState();
    if (allowClose || !win) return;
    const wc = win.webContents;
    if (!rendererReady || wc.isCrashed() || wc.isLoading()) return;
    e.preventDefault();
    if (Date.now() - closeAskedAt < 1500) return;   // prompt already up
    closeAskedAt = Date.now();
    wc.send("query-close", { quitting });
    clearTimeout(closeAckTimer);
    closeAckTimer = setTimeout(() => { if (closeAskedAt) finishClose(true); }, 2500);
  });
  win.on("closed", () => { win = null; rendererReady = false; clearTimeout(closeAckTimer); });
  win.webContents.on("render-process-gone", (e, d) => log("window process gone:", d && d.reason, d && d.exitCode));
  win.webContents.on("did-fail-load", (e, code, desc) => log("page failed to load:", code, desc));
  /* reload (View menu, Ctrl+R) while tabs are unsaved: the page's beforeunload blocks it; ask natively */
  win.webContents.on("will-prevent-unload", e => {
    if (allowClose) { e.preventDefault(); return; }
    const choice = dialog.showMessageBoxSync(win, {
      type: "warning", buttons: ["Reload anyway", "Cancel"], defaultId: 1, cancelId: 1,
      title: "Unsaved changes", message: "Some documents have unsaved changes.",
      detail: "Reloading closes them. AtoB PDF keeps a recovery copy, so it will offer to bring them back.",
    });
    if (choice === 0) e.preventDefault();   // preventDefault here = ignore beforeunload and unload
  });
  // reload / re-created window: hold file batches until the new page says it's ready
  win.webContents.on("did-navigate", () => { rendererReady = false; });

  /* external links (about page etc.) open in the default browser */
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:/i.test(url)) shell.openExternal(url);
    return { action: "deny" };
  });

  win.loadFile(path.join(__dirname, "app", "AtoB-PDF.html"));
}

/* only our own page (the top frame of the app window) may use the file IPC */
function fromApp(e) {
  try {
    if (!win || e.sender !== win.webContents) return false;
    const f = e.senderFrame;
    if (!f || f !== win.webContents.mainFrame) return false;
    return /^file:/i.test(f.url || "");
  } catch (err) { return false; }
}
function finishClose(ok) {
  clearTimeout(closeAckTimer);
  closeAskedAt = 0;
  if (!ok) { quitting = false; return; }
  allowClose = true;
  if (quitting) app.quit();
  else if (win) win.close();
}
ipcMain.on("close-ack", e => { if (fromApp(e)) clearTimeout(closeAckTimer); });
ipcMain.on("close-reply", (e, ok) => { if (fromApp(e)) finishClose(!!ok); });
app.on("before-quit", () => { quitting = true; });

/* v3.5.1 Save: write the edited bytes back over the file the tab was opened from */
ipcMain.handle("save-in-place", async (e, payload) => {
  if (!fromApp(e)) return { ok: false, error: "Not allowed" };
  const p = payload && payload.path;
  const bad = checkPdfPath(p, true);
  if (bad) return { ok: false, error: bad };
  try {
    const n = writeAtomic(p, payload.data);
    return { ok: true, path: p, bytes: n };
  } catch (err) { return { ok: false, error: saveError(err) }; }
});
/* v3.5.1 Save As: native dialog, then the same atomic write */
ipcMain.handle("save-as", async (e, payload) => {
  if (!fromApp(e)) return { ok: false, error: "Not allowed" };
  const name = safeName(payload && payload.name || "document.pdf");
  const startDir = payload && typeof payload.path === "string" && path.isAbsolute(payload.path)
    ? path.dirname(payload.path) : app.getPath("documents");
  const res = await dialog.showSaveDialog(win || undefined, {
    title: "Save As",
    defaultPath: path.join(startDir, /\.pdf$/i.test(name) ? name : name + ".pdf"),
    filters: [{ name: "PDF", extensions: ["pdf"] }],
  });
  if (res.canceled || !res.filePath) return { ok: false, canceled: true };
  let target = res.filePath;
  if (!/\.pdf$/i.test(target)) target += ".pdf";
  const bad = checkPdfPath(target, false);
  if (bad) return { ok: false, error: bad };
  try {
    const n = writeAtomic(target, payload.data);
    return { ok: true, path: target, name: path.basename(target), bytes: n };
  } catch (err) { return { ok: false, error: saveError(err) }; }
});

/* v3.5.1 Windows: open Settings > Default apps at AtoB's page, so PDFs can be set to open here.
   (Windows 8+ doesn't let an app make itself the default; the user confirms it there.) */
ipcMain.handle("open-default-apps", async e => {
  if (!fromApp(e)) return { ok: false };
  if (process.platform !== "win32") return { ok: false, error: "Windows only" };
  try { await shell.openExternal("ms-settings:defaultapps?registeredAppUser=" + encodeURIComponent("AtoB PDF")); return { ok: true }; }
  catch (err) {
    try { await shell.openExternal("ms-settings:defaultapps"); return { ok: true }; } catch (e2) { return { ok: false, error: String(err && err.message || err) }; }
  }
});

ipcMain.on("renderer-ready", () => {
  log("window ready" + (pendingBatches.length ? ", delivering " + pendingBatches.length + " held batch(es)" : ""));
  rendererReady = true;
  while (pendingBatches.length && win) win.webContents.send("open-files", pendingBatches.shift());
});

/* ---- v3.4 sharing: write the file to a temp folder, then hand it to the OS ----
   macOS: native share menu (Mail, Messages, AirDrop, WhatsApp…).
   Windows: copy the file itself to the clipboard + reveal it in Explorer, so
   the user can paste it straight into WhatsApp Desktop or an email. */
const shareRoot = () => path.join(app.getPath("temp"), "AtoB PDF share");
function cleanShareTemp() {
  try {
    const root = shareRoot();
    if (!fs.existsSync(root)) return;
    const cutoff = Date.now() - 24 * 3600 * 1000;
    for (const d of fs.readdirSync(root)) {
      const p = path.join(root, d);
      try { if (fs.statSync(p).mtimeMs < cutoff) fs.rmSync(p, { recursive: true, force: true }); } catch (e) {}
    }
  } catch (e) {}
}
function safeName(n) {
  const s = String(n || "atob-pdf-file").replace(/[\\/:*?"<>|\x00-\x1f]/g, "_").trim();
  return s || "atob-pdf-file";
}
function copyFileToClipboardWin(p) {
  return new Promise(resolve => {
    const lit = "'" + p.replace(/'/g, "''") + "'";
    execFile("powershell.exe", ["-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", "Set-Clipboard -LiteralPath " + lit],
      { windowsHide: true, timeout: 15000 }, err => {
        if (!err) return resolve(true);
        try { clipboard.writeBuffer("FileNameW", Buffer.from(p + "\0", "ucs2")); resolve(true); }
        catch (e) { resolve(false); }
      });
  });
}
ipcMain.handle("share-file", async (e, payload) => {
  try {
    const dir = path.join(shareRoot(), String(Date.now()));
    fs.mkdirSync(dir, { recursive: true });
    const p = path.join(dir, safeName(payload && payload.name));
    fs.writeFileSync(p, Buffer.from(payload.data));
    if (process.platform === "darwin" && ShareMenu) {
      const menu = new ShareMenu({ filePaths: [p] });
      menu.popup({ window: win || undefined });
      return { ok: true, method: "sharemenu", path: p };
    }
    if (process.platform === "win32") {
      const copied = await copyFileToClipboardWin(p);
      shell.showItemInFolder(p);
      return { ok: true, method: copied ? "clipboard" : "reveal", path: p };
    }
    shell.showItemInFolder(p);
    return { ok: true, method: "reveal", path: p };
  } catch (err) {
    return { ok: false, error: String(err && err.message || err) };
  }
});

/* menu. v3.5.1: Undo/Redo/Save are app commands, not Chromium's editing roles, so
   Cmd/Ctrl+Z reaches the document's undo (the page forwards it to text fields itself).
   Menu clicks arrive as "menu-command"; the page drops a command that duplicates the
   keydown it just handled, whichever of the two arrives first. */
function buildMenu() {
  const mac = process.platform === "darwin";
  const cmd = id => () => { if (win) win.webContents.send("menu-command", id); };
  const template = [
    ...(mac ? [{ role: "appMenu" }] : []),
    { label: "File", submenu: [
      { label: "Open…", accelerator: "CmdOrCtrl+O", click: cmd("open") },
      { type: "separator" },
      { label: "Save", accelerator: "CmdOrCtrl+S", click: cmd("save") },
      { label: "Save As…", accelerator: "CmdOrCtrl+Shift+S", click: cmd("saveas") },
      { type: "separator" },
      { label: "Document Properties…", accelerator: "CmdOrCtrl+D", click: cmd("props") },
      { type: "separator" },
      mac ? { role: "close" } : { role: "quit" },
    ] },
    { label: "Edit", submenu: [
      { label: "Undo", accelerator: "CmdOrCtrl+Z", click: cmd("undo") },
      { label: "Redo", accelerator: mac ? "Shift+Cmd+Z" : "Ctrl+Y", click: cmd("redo") },
      ...(mac ? [] : [{ label: "Redo", accelerator: "Ctrl+Shift+Z", click: cmd("redo"), visible: false }]),
      { type: "separator" },
      { role: "cut" }, { role: "copy" }, { role: "paste" },
      { role: "selectAll" },
    ] },
    { label: "View", submenu: [{ label: "Search Tools and Commands…", accelerator: "CmdOrCtrl+K", click: cmd("palette") }, { type: "separator" }, { role: "reload" }, { role: "togglefullscreen" }, { role: "toggleDevTools" }] },
    { role: "windowMenu" },
    { label: "Help", submenu: [
      { label: "Show log file", click: () => { log("log opened from Help menu"); try { shell.showItemInFolder(logPath || path.join(app.getPath("userData"), "atob-pdf.log")); } catch (e) {} } },
    ] },
  ];
  Menu.setApplicationMenu(Menu.buildFromTemplate(template));
}

/* downloads -> native Save dialog, default to the user's Documents.
   Registered once: session.defaultSession outlives windows (macOS re-creates them). */
function wireDownloads() {
  session.defaultSession.on("will-download", (event, item) => {
    const opts = {
      title: "Save file",
      defaultPath: path.join(app.getPath("documents"), item.getFilename()),
    };
    const target = win ? dialog.showSaveDialogSync(win, opts) : dialog.showSaveDialogSync(opts);
    if (target) item.setSavePath(target);
    else item.cancel();
  });
}

app.whenReady().then(() => {
  if (!gotLock) return;   // losing instance: already quitting, don't open a window
  wireDownloads();
  buildMenu();
  cleanShareTemp();
  createWindow();
  // Windows/Linux: files passed on first launch
  process.argv.slice(1).filter(a => /\.pdf$/i.test(a)).forEach(a => pushFile(path.resolve(a)));
  app.on("activate", () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});
app.on("window-all-closed", () => { if (process.platform !== "darwin") app.quit(); });
