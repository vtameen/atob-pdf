package app.atobpdf.android;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.core.content.FileProvider;
import androidx.webkit.WebViewAssetLoader;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

public class MainActivity extends Activity {

  private static final int FILE_PICK = 71;
  private static final int NOTIF_PERM = 72;
  private WebView web;
  private ValueCallback<Uri[]> pendingChooser;

  /* v3.4: the audio service forwards notification / lock-screen buttons here */
  static WeakReference<MainActivity> sInstance = new WeakReference<>(null);

  /* v3.4: native text-to-speech (Android WebView has no speechSynthesis) */
  private TextToSpeech tts;
  private volatile boolean ttsReady = false;
  private final Map<String, Voice> voiceByName = new HashMap<>();

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    sInstance = new WeakReference<>(this);

    web = new WebView(this);
    setContentView(web);

    WebSettings s = web.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(true);
    s.setAllowFileAccess(false);
    s.setAllowContentAccess(false);
    s.setSupportZoom(true);
    s.setBuiltInZoomControls(true);
    s.setDisplayZoomControls(false);
    s.setLoadWithOverviewMode(true);
    s.setUseWideViewPort(true);
    s.setMediaPlaybackRequiresUserGesture(false);
    // keep the page's JS (the reading queue) alive while the screen is off
    web.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, false);

    final WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
        .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
        .build();

    web.setWebViewClient(new WebViewClient() {
      @Override
      public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
        return assetLoader.shouldInterceptRequest(request.getUrl());
      }
    });

    web.setWebChromeClient(new WebChromeClient() {
      @Override
      public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                       FileChooserParams params) {
        if (pendingChooser != null) pendingChooser.onReceiveValue(null);
        pendingChooser = callback;
        Intent it = new Intent(Intent.ACTION_GET_CONTENT);
        it.addCategory(Intent.CATEGORY_OPENABLE);
        it.setType("*/*");
        String[] accept = params.getAcceptTypes();
        if (accept != null && accept.length > 0 && accept[0] != null && !accept[0].trim().isEmpty()) {
          it.putExtra(Intent.EXTRA_MIME_TYPES, accept);
        }
        if (params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE) {
          it.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        }
        try {
          startActivityForResult(Intent.createChooser(it, "Choose files"), FILE_PICK);
        } catch (Exception e) {
          pendingChooser = null;
          callback.onReceiveValue(null);
          return false;
        }
        return true;
      }
    });

    web.addJavascriptInterface(new Bridge(), "AndroidBridge");
    web.loadUrl("https://appassets.androidplatform.net/assets/AtoB-PDF.html");
  }

  @Override
  protected void onDestroy() {
    if (tts != null) {
      try { tts.stop(); tts.shutdown(); } catch (Exception ignored) {}
      tts = null;
    }
    try { stopService(new Intent(this, ReaderAudioService.class)); } catch (Exception ignored) {}
    if (sInstance.get() == this) sInstance = new WeakReference<>(null);
    super.onDestroy();
  }

  @Override
  protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    if (requestCode == FILE_PICK) {
      Uri[] result = null;
      if (resultCode == RESULT_OK && data != null) {
        if (data.getClipData() != null) {
          int n = data.getClipData().getItemCount();
          result = new Uri[n];
          for (int i = 0; i < n; i++) result[i] = data.getClipData().getItemAt(i).getUri();
        } else if (data.getData() != null) {
          result = new Uri[]{ data.getData() };
        }
      }
      if (pendingChooser != null) { pendingChooser.onReceiveValue(result); pendingChooser = null; }
      return;
    }
    super.onActivityResult(requestCode, resultCode, data);
  }

  /* ---- JS event channel: window.__atobNative({type:...}) ---- */
  void emit(final JSONObject evt) {
    final String js = "window.__atobNative&&window.__atobNative(" + evt.toString() + ")";
    runOnUiThread(() -> { if (web != null) web.evaluateJavascript(js, null); });
  }
  void emitMedia(String action) {
    try { emit(new JSONObject().put("type", "media").put("action", action)); } catch (Exception ignored) {}
  }

  private void toast(final String msg) {
    runOnUiThread(() -> Toast.makeText(MainActivity.this, msg, Toast.LENGTH_LONG).show());
  }

  /* ---- TTS ---- */
  private void initTts() {
    if (tts != null) {
      if (ttsReady) try { emit(new JSONObject().put("type", "tts-ready").put("ok", true)); } catch (Exception ignored) {}
      return;
    }
    tts = new TextToSpeech(getApplicationContext(), status -> {
      ttsReady = status == TextToSpeech.SUCCESS;
      if (ttsReady) {
        tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
          @Override public void onStart(String id) { ttsEvent("start", id, -1, -1, null); }
          @Override public void onDone(String id) { ttsEvent("done", id, -1, -1, null); }
          @Override @Deprecated public void onError(String id) { ttsEvent("error", id, -1, -1, "error"); }
          @Override public void onError(String id, int code) { ttsEvent("error", id, -1, -1, "code-" + code); }
          @Override public void onStop(String id, boolean interrupted) { ttsEvent("stop", id, -1, -1, null); }
          @Override public void onRangeStart(String id, int start, int end, int frame) { ttsEvent("range", id, start, end, null); }
        });
        refreshVoices();
      }
      try { emit(new JSONObject().put("type", "tts-ready").put("ok", ttsReady)); } catch (Exception ignored) {}
    });
  }
  private void ttsEvent(String type, String id, int start, int end, String err) {
    try {
      JSONObject o = new JSONObject().put("type", "tts").put("event", type).put("id", id);
      if (start >= 0) o.put("start", start).put("end", end);
      if (err != null) o.put("error", err);
      emit(o);
    } catch (Exception ignored) {}
  }
  private void refreshVoices() {
    voiceByName.clear();
    try {
      Set<Voice> vs = tts.getVoices();
      if (vs != null) for (Voice v : vs) voiceByName.put(v.getName(), v);
    } catch (Exception ignored) {}
  }

  private static String safeName(String name) {
    String safe = (name == null || name.trim().isEmpty()) ? "atob-pdf-output" : name.trim();
    return safe.replaceAll("[\\\\/:*?\"<>|]", "_");
  }

  private class Bridge {
    @JavascriptInterface
    public void saveFile(final String name, final String base64) {
      try {
        byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
        String safe = safeName(name);
        String mime = guessMime(safe);

        ContentValues v = new ContentValues();
        v.put(MediaStore.Downloads.DISPLAY_NAME, safe);
        v.put(MediaStore.Downloads.MIME_TYPE, mime);
        v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);

        Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
        if (uri == null) throw new RuntimeException("MediaStore insert failed");
        try (OutputStream out = getContentResolver().openOutputStream(uri)) {
          out.write(bytes);
        }
        toast("Saved to Downloads: " + safe);
      } catch (Exception e) {
        toast("Could not save file: " + e.getMessage());
      }
    }

    /* v3.4: share a file. target = "whatsapp" | "email" | "any" */
    @JavascriptInterface
    public void shareFile(final String name, final String base64, final String target) {
      try {
        byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
        String safe = safeName(name);
        File dir = new File(getCacheDir(), "share");
        if (!dir.exists() && !dir.mkdirs()) throw new RuntimeException("cache folder unavailable");
        File[] old = dir.listFiles();
        if (old != null) for (File f : old) if (System.currentTimeMillis() - f.lastModified() > 86400000L) f.delete();
        File f = new File(dir, safe);
        try (FileOutputStream out = new FileOutputStream(f)) { out.write(bytes); }
        final Uri uri = FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".fileprovider", f);
        final String mime = guessMime(safe);
        runOnUiThread(() -> launchShare(uri, mime, safe, target == null ? "any" : target));
      } catch (Exception e) {
        toast("Could not share: " + e.getMessage());
      }
    }

    @JavascriptInterface
    public String platformInfo() {
      try {
        return new JSONObject().put("sdk", Build.VERSION.SDK_INT).put("app", "3.4.0").toString();
      } catch (Exception e) { return "{}"; }
    }

    /* ---- v3.4 text-to-speech ---- */
    @JavascriptInterface
    public void ttsInit() { runOnUiThread(MainActivity.this::initTts); }

    @JavascriptInterface
    public String ttsVoices() {
      JSONArray arr = new JSONArray();
      if (tts == null || !ttsReady) return arr.toString();
      refreshVoices();
      try {
        String defName = null;
        try { Voice d = tts.getDefaultVoice(); if (d != null) defName = d.getName(); } catch (Exception ignored) {}
        for (Voice v : voiceByName.values()) {
          Set<String> feats = v.getFeatures();
          boolean notInstalled = feats != null && feats.contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED);
          JSONObject o = new JSONObject()
              .put("id", v.getName())
              .put("name", v.getName())
              .put("lang", v.getLocale().toLanguageTag())
              .put("local", !v.isNetworkConnectionRequired())
              .put("quality", v.getQuality())
              .put("installed", !notInstalled)
              .put("default", v.getName().equals(defName));
          arr.put(o);
        }
      } catch (Exception ignored) {}
      return arr.toString();
    }

    /* 0 = available, 1 = needs data download, 2 = not supported */
    @JavascriptInterface
    public int ttsLangStatus(String tag) {
      if (tts == null || !ttsReady) return 2;
      int r = tts.isLanguageAvailable(Locale.forLanguageTag(tag));
      if (r >= TextToSpeech.LANG_AVAILABLE) return 0;
      if (r == TextToSpeech.LANG_MISSING_DATA) return 1;
      return 2;
    }

    /* json: {flush, rate, pitch, items:[{id, text, lang, voice}]} */
    @JavascriptInterface
    public String ttsSpeak(String json) {
      if (tts == null || !ttsReady) return "not-ready";
      try {
        JSONObject o = new JSONObject(json);
        boolean flush = o.optBoolean("flush", true);
        tts.setSpeechRate((float) o.optDouble("rate", 1.0));
        tts.setPitch((float) o.optDouble("pitch", 1.0));
        JSONArray items = o.getJSONArray("items");
        List<String> problems = new ArrayList<>();
        for (int i = 0; i < items.length(); i++) {
          JSONObject it = items.getJSONObject(i);
          String id = it.getString("id");
          String voice = it.optString("voice", "");
          String lang = it.optString("lang", "en");
          Voice v = voice.isEmpty() ? null : voiceByName.get(voice);
          int res = TextToSpeech.SUCCESS;
          if (v != null) res = tts.setVoice(v);
          if (v == null || res != TextToSpeech.SUCCESS) {
            int lr = tts.setLanguage(Locale.forLanguageTag(lang));
            if (lr == TextToSpeech.LANG_MISSING_DATA || lr == TextToSpeech.LANG_NOT_SUPPORTED) {
              problems.add(id);
              ttsEvent("error", id, -1, -1, lr == TextToSpeech.LANG_MISSING_DATA ? "lang-missing-data" : "lang-not-supported");
              continue;
            }
          }
          Bundle params = new Bundle();
          params.putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, id);
          int mode = (i == 0 && flush) ? TextToSpeech.QUEUE_FLUSH : TextToSpeech.QUEUE_ADD;
          tts.speak(it.getString("text"), mode, params, id);
        }
        return problems.isEmpty() ? "ok" : "partial";
      } catch (Exception e) {
        return "error:" + e.getMessage();
      }
    }

    @JavascriptInterface
    public void ttsStop() { if (tts != null) try { tts.stop(); } catch (Exception ignored) {} }

    @JavascriptInterface
    public void ttsOpenSettings() {
      runOnUiThread(() -> {
        try {
          Intent it = new Intent("com.android.settings.TTS_SETTINGS");
          it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
          startActivity(it);
        } catch (Exception e) {
          try { startActivity(new Intent(Settings.ACTION_SETTINGS)); } catch (Exception ignored) {}
        }
      });
    }

    @JavascriptInterface
    public void ttsInstallData() {
      runOnUiThread(() -> {
        try {
          Intent it = new Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA);
          it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
          startActivity(it);
        } catch (Exception e) {
          try {
            Intent it = new Intent("com.android.settings.TTS_SETTINGS");
            it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(it);
          } catch (Exception ignored) {}
        }
      });
    }

    /* ---- v3.4 background playback: foreground media service ---- */
    @JavascriptInterface
    public void mediaStart(String title, String subtitle, boolean playing) {
      runOnUiThread(() -> {
        askNotificationPermissionOnce();
        Intent it = new Intent(MainActivity.this, ReaderAudioService.class);
        it.setAction(ReaderAudioService.ACTION_UPDATE);
        it.putExtra("title", title);
        it.putExtra("subtitle", subtitle);
        it.putExtra("playing", playing);
        try { startForegroundService(it); } catch (Exception e) {
          try { startService(it); } catch (Exception ignored) {}
        }
      });
    }

    @JavascriptInterface
    public void mediaUpdate(String title, String subtitle, boolean playing) {
      if (!ReaderAudioService.isRunning()) return;
      runOnUiThread(() -> {
        Intent it = new Intent(MainActivity.this, ReaderAudioService.class);
        it.setAction(ReaderAudioService.ACTION_UPDATE);
        it.putExtra("title", title);
        it.putExtra("subtitle", subtitle);
        it.putExtra("playing", playing);
        try { startService(it); } catch (Exception ignored) {}
      });
    }

    @JavascriptInterface
    public void mediaStop() {
      runOnUiThread(() -> {
        try { stopService(new Intent(MainActivity.this, ReaderAudioService.class)); } catch (Exception ignored) {}
      });
    }
  }

  private boolean askedNotif = false;
  private void askNotificationPermissionOnce() {
    if (askedNotif || Build.VERSION.SDK_INT < 33) return;
    askedNotif = true;
    if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
      requestPermissions(new String[]{ Manifest.permission.POST_NOTIFICATIONS }, NOTIF_PERM);
    }
  }

  private boolean isInstalled(String pkg) {
    try { getPackageManager().getPackageInfo(pkg, 0); return true; }
    catch (PackageManager.NameNotFoundException e) { return false; }
  }

  private Intent baseSend(Uri uri, String mime, String name) {
    Intent send = new Intent(Intent.ACTION_SEND);
    send.setType(mime);
    send.putExtra(Intent.EXTRA_STREAM, uri);
    send.putExtra(Intent.EXTRA_SUBJECT, name);
    send.setClipData(ClipData.newRawUri(name, uri));
    send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
    return send;
  }

  private void launchShare(Uri uri, String mime, String name, String target) {
    try {
      if ("whatsapp".equals(target)) {
        boolean wa = isInstalled("com.whatsapp"), wb = isInstalled("com.whatsapp.w4b");
        if (wa || wb) {
          Intent primary = baseSend(uri, mime, name);
          primary.setPackage(wa ? "com.whatsapp" : "com.whatsapp.w4b");
          if (wa && wb) {
            Intent second = baseSend(uri, mime, name);
            second.setPackage("com.whatsapp.w4b");
            Intent chooser = Intent.createChooser(primary, "Share via WhatsApp");
            chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{ second });
            startActivity(chooser);
          } else {
            startActivity(primary);
          }
          return;
        }
        toast("WhatsApp isn't installed — choose another app");
        startActivity(Intent.createChooser(baseSend(uri, mime, name), "Share " + name));
        return;
      }
      if ("email".equals(target)) {
        Intent send = baseSend(uri, mime, name);
        send.setSelector(new Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:")));
        try {
          startActivity(Intent.createChooser(send, "Send by email"));
        } catch (ActivityNotFoundException e) {
          toast("No email app found — choose another app");
          startActivity(Intent.createChooser(baseSend(uri, mime, name), "Share " + name));
        }
        return;
      }
      startActivity(Intent.createChooser(baseSend(uri, mime, name), "Share " + name));
    } catch (Exception e) {
      toast("Could not share: " + e.getMessage());
    }
  }

  private static String guessMime(String name) {
    String n = name.toLowerCase();
    if (n.endsWith(".pdf")) return "application/pdf";
    if (n.endsWith(".png")) return "image/png";
    if (n.endsWith(".jpg") || n.endsWith(".jpeg")) return "image/jpeg";
    if (n.endsWith(".zip")) return "application/zip";
    if (n.endsWith(".txt")) return "text/plain";
    if (n.endsWith(".md")) return "text/markdown";
    if (n.endsWith(".docx"))
      return "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
    return "application/octet-stream";
  }

  @Override
  public void onBackPressed() {
    if (web != null) {
      // let the web app close sheets / the reader first
      web.evaluateJavascript("window.__atobBack?window.__atobBack():false", v -> {
        if ("true".equals(v)) return;
        if (web.canGoBack()) { web.goBack(); return; }
        moveTaskToBack(true);
      });
      return;
    }
    moveTaskToBack(true);
  }
}
