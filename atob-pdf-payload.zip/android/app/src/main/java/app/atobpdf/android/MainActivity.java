package app.atobpdf.android;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.webkit.WebViewAssetLoader;

import java.io.OutputStream;

public class MainActivity extends Activity {

  private static final int FILE_PICK = 71;
  private WebView web;
  private ValueCallback<Uri[]> pendingChooser;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);

    web = new WebView(this);
    setContentView(web);

    WebSettings s = web.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(true);
    s.setAllowFileAccess(false);
    s.setAllowContentAccess(false);
    s.setSupportZoom(true);
    s.setBuiltInZoomControls(true);
    s.setDisplayZoomControls(false);
    s.setLoadWithOverviewMode(true);
    s.setUseWideViewPort(true);

    final WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
        .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
        .build();

    web.setWebViewClient(new WebViewClient() {
      @Override
      public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
        return assetLoader.shouldInterceptRequest(request.getUrl());
      }
    });

    web.setWebChromeClient(new WebChromeClient() {
      @Override
      public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                       FileChooserParams params) {
        if (pendingChooser != null) pendingChooser.onReceiveValue(null);
        pendingChooser = callback;
        Intent it = new Intent(Intent.ACTION_GET_CONTENT);
        it.addCategory(Intent.CATEGORY_OPENABLE);
        it.setType("*/*");
        String[] accept = params.getAcceptTypes();
        if (accept != null && accept.length > 0 && accept[0] != null && !accept[0].trim().isEmpty()) {
          it.putExtra(Intent.EXTRA_MIME_TYPES, accept);
        }
        if (params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE) {
          it.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        }
        try {
          startActivityForResult(Intent.createChooser(it, "Choose files"), FILE_PICK);
        } catch (Exception e) {
          pendingChooser = null;
          callback.onReceiveValue(null);
          return false;
        }
        return true;
      }
    });

    web.addJavascriptInterface(new Bridge(), "AndroidBridge");
    web.loadUrl("https://appassets.androidplatform.net/assets/AtoB-PDF.html");
  }

  @Override
  protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    if (requestCode == FILE_PICK) {
      Uri[] result = null;
      if (resultCode == RESULT_OK && data != null) {
        if (data.getClipData() != null) {
          int n = data.getClipData().getItemCount();
          result = new Uri[n];
          for (int i = 0; i < n; i++) result[i] = data.getClipData().getItemAt(i).getUri();
        } else if (data.getData() != null) {
          result = new Uri[]{ data.getData() };
        }
      }
      if (pendingChooser != null) { pendingChooser.onReceiveValue(result); pendingChooser = null; }
      return;
    }
    super.onActivityResult(requestCode, resultCode, data);
  }

  private class Bridge {
    @JavascriptInterface
    public void saveFile(final String name, final String base64) {
      try {
        byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
        String safe = (name == null || name.trim().isEmpty()) ? "atob-pdf-output" : name.trim();
        safe = safe.replaceAll("[\\\\/:*?\"<>|]", "_");
        String mime = guessMime(safe);

        ContentValues v = new ContentValues();
        v.put(MediaStore.Downloads.DISPLAY_NAME, safe);
        v.put(MediaStore.Downloads.MIME_TYPE, mime);
        v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);

        Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
        if (uri == null) throw new RuntimeException("MediaStore insert failed");
        try (OutputStream out = getContentResolver().openOutputStream(uri)) {
          out.write(bytes);
        }
        final String msg = "Saved to Downloads: " + safe;
        runOnUiThread(() -> Toast.makeText(MainActivity.this, msg, Toast.LENGTH_LONG).show());
      } catch (Exception e) {
        runOnUiThread(() -> Toast.makeText(MainActivity.this,
            "Could not save file: " + e.getMessage(), Toast.LENGTH_LONG).show());
      }
    }
  }

  private static String guessMime(String name) {
    String n = name.toLowerCase();
    if (n.endsWith(".pdf")) return "application/pdf";
    if (n.endsWith(".png")) return "image/png";
    if (n.endsWith(".jpg") || n.endsWith(".jpeg")) return "image/jpeg";
    if (n.endsWith(".zip")) return "application/zip";
    if (n.endsWith(".txt")) return "text/plain";
    if (n.endsWith(".docx"))
      return "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
    return "application/octet-stream";
  }

  @Override
  public void onBackPressed() {
    if (web != null && web.canGoBack()) { web.goBack(); return; }
    moveTaskToBack(true);
  }
}
