package app.atobpdf.android;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.media.MediaMetadata;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.IBinder;
import android.os.PowerManager;

/* v3.4 audio reader: keeps speech going with the screen off and puts
   play/pause/next/previous on the notification shade and lock screen.
   The reading queue itself lives in the WebView (JS); button presses are
   forwarded to it through MainActivity.emitMedia(). */
public class ReaderAudioService extends Service {

  static final String ACTION_UPDATE = "app.atobpdf.audio.UPDATE";
  static final String ACTION_TOGGLE = "app.atobpdf.audio.TOGGLE";
  static final String ACTION_NEXT = "app.atobpdf.audio.NEXT";
  static final String ACTION_PREV = "app.atobpdf.audio.PREV";
  static final String ACTION_STOP = "app.atobpdf.audio.STOP";

  private static final String CHANNEL = "atob-reader";
  private static final int NOTIF_ID = 4101;
  private static volatile boolean running = false;

  private MediaSession session;
  private PowerManager.WakeLock wake;
  private String title = "AtoB PDF";
  private String subtitle = "";
  private boolean playing = false;

  static boolean isRunning() { return running; }

  @Override
  public void onCreate() {
    super.onCreate();
    running = true;
    NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
    NotificationChannel ch = new NotificationChannel(CHANNEL, "Read aloud", NotificationManager.IMPORTANCE_LOW);
    ch.setDescription("Controls for the AtoB PDF audio reader");
    ch.setShowBadge(false);
    nm.createNotificationChannel(ch);

    session = new MediaSession(this, "AtoBReader");
    session.setCallback(new MediaSession.Callback() {
      @Override public void onPlay() { forward("play"); }
      @Override public void onPause() { forward("pause"); }
      @Override public void onSkipToNext() { forward("next"); }
      @Override public void onSkipToPrevious() { forward("prev"); }
      @Override public void onStop() { forward("stop"); }
    });
    session.setActive(true);

    PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
    wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "AtoBPDF:reader");
    wake.setReferenceCounted(false);
  }

  private void forward(String action) {
    MainActivity a = MainActivity.sInstance.get();
    if (a != null) a.emitMedia(action);
  }

  @Override
  public int onStartCommand(Intent intent, int flags, int startId) {
    String action = intent != null ? intent.getAction() : null;
    if (ACTION_TOGGLE.equals(action)) { forward(playing ? "pause" : "play"); }
    else if (ACTION_NEXT.equals(action)) { forward("next"); }
    else if (ACTION_PREV.equals(action)) { forward("prev"); }
    else if (ACTION_STOP.equals(action)) { forward("stop"); stopSelf(); return START_NOT_STICKY; }
    else if (intent != null) {
      if (intent.hasExtra("title")) title = intent.getStringExtra("title");
      if (intent.hasExtra("subtitle")) subtitle = intent.getStringExtra("subtitle");
      playing = intent.getBooleanExtra("playing", playing);
    }
    publish();
    return START_NOT_STICKY;
  }

  private PendingIntent pi(String action, int code) {
    Intent it = new Intent(this, ReaderAudioService.class).setAction(action);
    return PendingIntent.getService(this, code, it, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
  }

  private void publish() {
    long actions = PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE | PlaybackState.ACTION_PLAY_PAUSE
        | PlaybackState.ACTION_SKIP_TO_NEXT | PlaybackState.ACTION_SKIP_TO_PREVIOUS | PlaybackState.ACTION_STOP;
    session.setPlaybackState(new PlaybackState.Builder()
        .setActions(actions)
        .setState(playing ? PlaybackState.STATE_PLAYING : PlaybackState.STATE_PAUSED, PlaybackState.PLAYBACK_POSITION_UNKNOWN, 1f)
        .build());
    session.setMetadata(new MediaMetadata.Builder()
        .putString(MediaMetadata.METADATA_KEY_TITLE, title)
        .putString(MediaMetadata.METADATA_KEY_ARTIST, subtitle)
        .putString(MediaMetadata.METADATA_KEY_ALBUM, "AtoB PDF")
        .build());

    Intent open = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
    PendingIntent content = PendingIntent.getActivity(this, 1, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

    Notification.Action prev = new Notification.Action.Builder(android.R.drawable.ic_media_previous, "Previous", pi(ACTION_PREV, 11)).build();
    Notification.Action toggle = new Notification.Action.Builder(
        playing ? android.R.drawable.ic_media_pause : android.R.drawable.ic_media_play,
        playing ? "Pause" : "Play", pi(ACTION_TOGGLE, 12)).build();
    Notification.Action next = new Notification.Action.Builder(android.R.drawable.ic_media_next, "Next", pi(ACTION_NEXT, 13)).build();

    Notification n = new Notification.Builder(this, CHANNEL)
        .setSmallIcon(android.R.drawable.ic_lock_silent_mode_off)
        .setContentTitle(title)
        .setContentText(subtitle)
        .setContentIntent(content)
        .setDeleteIntent(pi(ACTION_STOP, 14))
        .setOngoing(playing)
        .setShowWhen(false)
        .setVisibility(Notification.VISIBILITY_PUBLIC)
        .addAction(prev).addAction(toggle).addAction(next)
        .setStyle(new Notification.MediaStyle()
            .setMediaSession(session.getSessionToken())
            .setShowActionsInCompactView(0, 1, 2))
        .build();

    startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
    if (playing) { if (!wake.isHeld()) wake.acquire(3 * 60 * 60 * 1000L); }
    else if (wake.isHeld()) wake.release();
  }

  @Override
  public void onDestroy() {
    running = false;
    try { if (wake != null && wake.isHeld()) wake.release(); } catch (Exception ignored) {}
    try { session.setActive(false); session.release(); } catch (Exception ignored) {}
    stopForeground(STOP_FOREGROUND_REMOVE);
    super.onDestroy();
  }

  @Override
  public IBinder onBind(Intent intent) { return null; }
}
