/* AtoB PDF shared runtime: shell, components, pdf.js plumbing */
"use strict";

/* ---------------- icons ---------------- */
const ICONS = {
  logo:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M7 3h7l5 5v13H7z" fill="currentColor" stroke="none" opacity="0"/><path d="M6 3h8l5 5v13H6z"/><path d="M14 3v5h5"/></svg>',
  organize:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="8" height="8" rx="1.5"/><rect x="13" y="13" width="8" height="8" rx="1.5"/><path d="M17 3v4h4M3 17h4v4"/></svg>',
  merge:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 5h5l3 4h8"/><path d="M4 19h5l3-4h8"/><path d="M17 6l3 3-3 3M17 12l3 3-3 3"/></svg>',
  split:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="6" cy="6" r="2.6"/><circle cx="6" cy="18" r="2.6"/><path d="M8.2 7.6 20 18M8.2 16.4 20 6"/></svg>',
  extract:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M8 3h8l4 4v6"/><path d="M16 3v4h4"/><rect x="4" y="11" width="10" height="10" rx="1.5"/></svg>',
  rotate:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M20 8a8 8 0 1 0 2 6"/><path d="M20 3v5h-5"/></svg>',
  compress:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v6m0 0 3-3m-3 3L9 6M12 21v-6m0 0 3 3m-3-3-3 3"/><path d="M4 12h16"/></svg>',
  watermark:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3s6 6.6 6 11a6 6 0 1 1-12 0c0-4.4 6-11 6-11z"/><path d="M9.5 14a2.5 2.5 0 0 0 2.5 2.5"/></svg>',
  numbers:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M9 4 7 20M17 4l-2 16M5 9h15M4 15h15"/></svg>',
  img2pdf:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="13" height="11" rx="1.5"/><circle cx="7.5" cy="9" r="1.3"/><path d="m3 14 3.5-3 4 3.5L14 11l2 2"/><path d="M20 8v11h-9"/></svg>',
  pdf2img:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19V4h9l4 4v3"/><path d="M13 4v4h4"/><rect x="11" y="13" width="10" height="8" rx="1.5"/><circle cx="14" cy="16" r="1"/><path d="m11 19.5 2.5-2 2.5 2 2-1.5 3 2.3"/></svg>',
  view:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12z"/><circle cx="12" cy="12" r="3"/></svg>',
  back:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m14 6-6 6 6 6"/></svg>',
  close:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 6l12 12M18 6 6 18"/></svg>',
  check:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="m4.5 12.5 5 5 10-11"/></svg>',
  download:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 4v11m0 0 4.5-4.5M12 15l-4.5-4.5"/><path d="M4 19h16"/></svg>',
  drop:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v10m0 0 4-4m-4 4L8 9"/><path d="M3 14v4a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-4"/></svg>',
  sun:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><circle cx="12" cy="12" r="4.2"/><path d="M12 2.5v2.2M12 19.3v2.2M2.5 12h2.2M19.3 12h2.2M5 5l1.6 1.6M17.4 17.4 19 19M19 5l-1.6 1.6M6.6 17.4 5 19"/></svg>',
  moon:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M20 14.5A8.5 8.5 0 0 1 9.5 4a8.5 8.5 0 1 0 10.5 10.5z"/></svg>',
  themeauto:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="8.5"/><path d="M12 3.5v17A8.5 8.5 0 0 0 12 3.5z" fill="currentColor" stroke="none"/></svg>',
  trash:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 7h16M9 7V5h6v2M6.5 7l1 13h9l1-13"/><path d="M10 11v5M14 11v5"/></svg>',
  rotcw:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 8a8 8 0 1 1-2 6"/><path d="M4 3v5h5"/></svg>',
  grip:'<svg viewBox="0 0 24 24" fill="currentColor"><circle cx="9" cy="6" r="1.4"/><circle cx="15" cy="6" r="1.4"/><circle cx="9" cy="12" r="1.4"/><circle cx="15" cy="12" r="1.4"/><circle cx="9" cy="18" r="1.4"/><circle cx="15" cy="18" r="1.4"/></svg>',
  plus:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>',
  up:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="m6 14 6-6 6 6"/></svg>',
  down:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="m6 10 6 6 6-6"/></svg>',
  file:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M6 3h8l5 5v13H6z"/><path d="M14 3v5h5"/></svg>',
  zip:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="4" width="16" height="16" rx="2"/><path d="M12 4v3m0 2v2m0 2v2"/></svg>',
  image:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="8.5" cy="9.5" r="1.6"/><path d="m3 17 5-4.5 4.5 4L17 13l4 3.5"/></svg>',
  minus:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M5 12h14"/></svg>',
  home:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 11l8-7 8 7v9a1 1 0 0 1-1 1h-4v-6H9v6H5a1 1 0 0 1-1-1z"/></svg>',
  grid:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="4" width="7" height="7" rx="2"/><rect x="13" y="4" width="7" height="7" rx="2"/><rect x="4" y="13" width="7" height="7" rx="2"/><rect x="13" y="13" width="7" height="7" rx="2"/></svg>',
  clock:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="8"/><path d="M12 8v4l3 2"/></svg>',
  search:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="6.5"/><path d="M20 20l-4.2-4.2"/></svg>',
  folder:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 7a2 2 0 0 1 2-2h4l2 2h6a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2z"/></svg>',
  chevron:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M9 6l6 6-6 6"/></svg>',
  pages:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="4" width="7" height="9" rx="1.5"/><rect x="13" y="4" width="7" height="9" rx="1.5"/><rect x="4" y="15" width="7" height="5" rx="1.5"/><rect x="13" y="15" width="7" height="5" rx="1.5"/></svg>',
  pen:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 20c4-1 5-3 6-6l7-7 3 3-7 7c-3 1-5 2-6 6z"/><path d="M14 7l3 3"/></svg>',
  share:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="18" cy="5" r="2.5"/><circle cx="6" cy="12" r="2.5"/><circle cx="18" cy="19" r="2.5"/><path d="M8.2 10.8l7.6-4.6M8.2 13.2l7.6 4.6"/></svg>',
  more:'<svg viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="5" r="1.6"/><circle cx="12" cy="12" r="1.6"/><circle cx="12" cy="19" r="1.6"/></svg>',
};

Object.assign(ICONS, {
  sun: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="4"/><path d="M12 2.5v2M12 19.5v2M4.6 4.6l1.4 1.4M18 18l1.4 1.4M2.5 12h2M19.5 12h2M4.6 19.4 6 18M18 6l1.4-1.4"/></svg>',
  moon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M20 14.5A8 8 0 1 1 9.5 4a6.5 6.5 0 0 0 10.5 10.5z"/></svg>',
  monitor: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="12" rx="2"/><path d="M8 20h8M12 16v4"/></svg>',
  keyboard: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="2.5" y="6" width="19" height="12" rx="2"/><path d="M6 10h.01M9.5 10h.01M13 10h.01M16.5 10h.01M7 14h10"/></svg>',
});

const APP_VERSION = "3.8.1";
/* one id per page load: recovery entries are tagged with it (v3.5.1) */
const SESSION_ID = Date.now().toString(36) + Math.random().toString(36).slice(2, 8);

/* ---------------- phone layout ---------------- */
const MOBILE_MQ = window.matchMedia ? window.matchMedia("(max-width: 860px)") : { matches: false };
function isMobile() { return !!MOBILE_MQ.matches; }
function icon(name, cls) {
  const s = document.createElement("span");
  if (cls) s.className = cls;
  s.style.display = "inline-flex";
  s.innerHTML = ICONS[name] || "";
  return s;
}

/* ---------------- dom helper ---------------- */
function h(tag, attrs, ...children) {
  const el = document.createElement(tag);
  if (attrs) for (const k in attrs) {
    const v = attrs[k];
    if (v == null) continue;
    if (k === "class") el.className = v;
    else if (k === "style") el.style.cssText = v;
    else if (k.startsWith("on")) el.addEventListener(k.slice(2), v);
    else if (k === "html") el.innerHTML = v;
    else el.setAttribute(k, v);
  }
  for (const c of children.flat(9)) {
    if (c == null || c === false) continue;
    el.append(c.nodeType ? c : document.createTextNode(c));
  }
  return el;
}

/* ---------------- toasts ---------------- */
const toastHost = h("div", { class: "toasts" });
let lastToast = { msg: "", t: 0 };
function toast(msg, kind, ms) {
  const now = Date.now();
  if (msg === lastToast.msg && now - lastToast.t < 1500) return;
  lastToast = { msg, t: now };
  const el = h("div", { class: "toast" + (kind === "err" ? " err" : "") }, msg);
  toastHost.append(el);
  setTimeout(() => { el.style.opacity = "0"; el.style.transition = "opacity 250ms"; setTimeout(() => el.remove(), 300); }, ms || (kind === "err" ? 5200 : 3200));
}

/* ---------------- modal ---------------- */
/* onCancel(close) runs when the modal is dismissed without an explicit choice
   (backdrop click, Android Back, switching views). Promise-based prompts must pass it
   so their promise settles; the default just closes. */
function showModal({ title, body, actions, dismissable = true, onCancel, cls }) {
  const wrap = h("div", { class: "modal-wrap" });
  const close = () => wrap.remove();
  const cancel = () => { if (!wrap.isConnected) return; if (onCancel) onCancel(close); else close(); };
  const m = h("div", { class: "modal" + (cls ? " " + cls : "") },
    h("h3", null, title),
    body,
    actions ? h("div", { class: "mrow" }, actions.map(a =>
      h("button", { class: "btn " + (a.primary ? "primary" : "secondary"), onclick: () => a.onClick(close) }, a.label))) : null,
  );
  if (dismissable) wrap.addEventListener("click", e => { if (e.target === wrap) cancel(); });
  wrap.__cancel = cancel;
  wrap.append(m);
  document.body.append(wrap);
  return close;
}
/* dismiss a modal the way the user would, so pending prompts resolve */
function cancelModal(wrap) {
  if (!wrap) return;
  try { if (wrap.__cancel) wrap.__cancel(); } catch (e) { console.warn(e); }
  if (wrap.isConnected) wrap.remove();
}
function passwordPrompt(filename, wrong) {
  return new Promise(resolve => {
    const input = h("input", { type: "password", placeholder: "Password", autofocus: "" });
    const done = (val, close) => { close(); resolve(val); };
    const close = showModal({
      title: "Password required",
      dismissable: false,
      onCancel: c => done(null, c),
      body: h("div", null,
        h("p", null, wrong ? "That password didn't work. Try again for " : "Enter the password to open ", h("b", null, filename), "."),
        input),
      actions: [
        { label: "Cancel", onClick: c => done(null, c) },
        { label: "Open", primary: true, onClick: c => done(input.value, c) },
      ],
    });
    input.addEventListener("keydown", e => { if (e.key === "Enter") done(input.value, close); });
    setTimeout(() => input.focus(), 30);
  });
}

/* ---------------- pdf.js plumbing ---------------- */
const openDocs = new Set();
async function openPdf(rec) {
  const task = pdfjsLib.getDocument({
    data: new Uint8Array(rec.buf.slice(0)),
    isEvalSupported: false,
    disableFontFace: false,
  });
  let attempts = 0;
  task.onPassword = async (updatePassword, reason) => {
    const pw = await passwordPrompt(rec.name, reason === 2 || attempts > 0);
    attempts++;
    if (pw == null) { task.destroy(); return; }
    updatePassword(pw);
  };
  const doc = await task.promise;
  openDocs.add(doc);
  return doc;
}
function closePdf(doc) {
  if (!doc) return;
  try { doc.destroy(); } catch (e) {}
  openDocs.delete(doc);
}
async function renderPageToCanvas(doc, pageNo, targetDim, opts) {
  const page = await doc.getPage(pageNo);
  const base = page.getViewport({ scale: 1 });
  let scale;
  if (opts && opts.dpi) scale = opts.dpi / 72;
  else scale = targetDim / Math.max(base.width, base.height);
  const capped = Math.min(scale, 8000 / Math.max(base.width, base.height));
  const vp = page.getViewport({ scale: capped });
  const canvas = document.createElement("canvas");
  canvas.width = Math.max(1, Math.round(vp.width));
  canvas.height = Math.max(1, Math.round(vp.height));
  const ctx = canvas.getContext("2d", { alpha: false });
  ctx.fillStyle = "#ffffff";
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  await page.render({ canvasContext: ctx, viewport: vp }).promise;
  return { canvas, cssW: vp.width, cssH: vp.height, capped: capped < scale - 1e-9 };
}

/* v3.6 bookmarks (outline) as a tree with resolved 0-based page indexes (null if unresolved).
   Shared by the viewer's Bookmarks panel and the reader's Contents. */
async function pdfOutlineTree(doc, maxDepth) {
  maxDepth = maxDepth == null ? 12 : maxDepth;
  let ol = null;
  try { ol = await doc.getOutline(); } catch (e) { return []; }
  const walk = async (items, depth) => {
    const out = [];
    for (const it of items || []) {
      let page = null;
      try {
        let dest = it.dest;
        if (typeof dest === "string") dest = await doc.getDestination(dest);
        if (Array.isArray(dest) && dest[0] != null) page = typeof dest[0] === "number" ? dest[0] : await doc.getPageIndex(dest[0]);
      } catch (e) {}
      out.push({ title: String(it.title || "").trim() || "(untitled)", page, items: depth < maxDepth ? await walk(it.items, depth + 1) : [] });
    }
    return out;
  };
  return walk(ol, 0);
}
function flattenOutline(tree, maxDepth) {
  const out = [];
  const go = (items, depth) => { for (const it of items) { out.push({ title: it.title, page: it.page, depth }); if (depth < maxDepth) go(it.items, depth + 1); } };
  go(tree, 0);
  return out;
}

/* sequential thumbnail queue */
class ThumbQueue {
  constructor(doc) { this.doc = doc; this.q = []; this.busy = false; this.dead = false; this.cache = new Map(); }
  render(pageNo, dim = 300) {
    if (this.cache.has(pageNo)) return Promise.resolve(this.cache.get(pageNo));
    return new Promise((resolve, reject) => {
      this.q.push({ pageNo, dim, resolve, reject });
      this.pump();
    });
  }
  async pump() {
    if (this.busy || this.dead) return;
    const job = this.q.shift();
    if (!job) return;
    this.busy = true;
    try {
      const { canvas } = await renderPageToCanvas(this.doc, job.pageNo, job.dim);
      this.cache.set(job.pageNo, canvas);
      job.resolve(canvas);
    } catch (e) { job.reject(e); }
    this.busy = false;
    if (!this.dead) this.pump();
  }
  kill() { this.dead = true; this.q.length = 0; }
}

/* ---------------- files ---------------- */
async function readFileRec(file) {
  const buf = await file.arrayBuffer();
  const rec = { name: file.name, size: file.size, buf };
  // v3.5.1 desktop: remember where the file lives so Save can write it back in place
  if (window.pdeskAPI && typeof window.pdeskAPI.pathForFile === "function") {
    try { const p = window.pdeskAPI.pathForFile(file); if (p) rec.path = p; } catch (e) {}
  }
  return rec;
}
function bytesOf(rec) { return new Uint8Array(rec.buf.slice(0)); }
const heldUrls = [];
function downloadBytes(name, bytes, mime) {
  const blob = bytes instanceof Blob ? bytes : new Blob([bytes], { type: mime || "application/octet-stream" });
  if (window.AndroidBridge && typeof window.AndroidBridge.saveFile === "function") {
    // Android app: hand the bytes to the native side, which saves into Downloads.
    const fr = new FileReader();
    fr.onload = () => {
      try { window.AndroidBridge.saveFile(name, String(fr.result).split(",")[1] || ""); }
      catch (e) { toast("Could not save " + name, "err"); }
    };
    fr.readAsDataURL(blob);
    return blob.size;
  }
  const url = URL.createObjectURL(blob);
  heldUrls.push(url);
  const a = h("a", { href: url, download: name, style: "display:none" });
  document.body.append(a);
  a.click();
  setTimeout(() => { a.remove(); }, 1000);
  setTimeout(() => { try { URL.revokeObjectURL(url); } catch (e) {} }, 60000);
  return blob.size;
}
function isPdfFile(f) { return /\.pdf$/i.test(f.name) || f.type === "application/pdf"; }
function isImgFile(f) { return /\.(png|jpe?g|webp|gif|bmp|avif)$/i.test(f.name) || /^image\//.test(f.type); }
const BIG_WARN = 120 * 1024 * 1024;

/* dropzone component */
const DROP_ACCEPTS = {
  pdf: { test: isPdfFile, attr: "application/pdf,.pdf", msg: "not a PDF" },
  image: { test: isImgFile, attr: "image/*,.png,.jpg,.jpeg,.webp,.gif,.bmp,.avif", msg: "not an image" },
  docx: { test: f => /\.docx$/i.test(f.name), attr: ".docx,application/vnd.openxmlformats-officedocument.wordprocessingml.document", msg: "not a .docx file" },
  text: { test: f => /\.(txt|md|markdown|text)$/i.test(f.name) || f.type === "text/plain", attr: ".txt,.md,.markdown,text/plain", msg: "not a text file" },
};
function makeDrop({ accept = "pdf", multiple = false, big, sub, compact, onFiles }) {
  const spec = DROP_ACCEPTS[accept] || DROP_ACCEPTS.pdf;
  const test = spec.test;
  const acceptAttr = spec.attr;
  const input = h("input", { type: "file", accept: acceptAttr, style: "display:none" });
  if (multiple) input.setAttribute("multiple", "");
  let bigText = big || (multiple ? "Drop files here" : "Drop a file here");
  let subText = sub || "or click to browse. Files never leave this device.";
  if (isMobile()) {
    bigText = bigText.replace(/^Drop\b/, "Choose").replace(/ here\b/, "");
    if (!sub) subText = "Tap to pick from your files. Nothing leaves this phone.";
  }
  const el = h("div", { class: "drop" + (compact ? " compact" : "") },
    icon("drop"),
    h("div", null,
      h("div", { class: "big" }, bigText),
      h("div", { class: "sub" }, subText)),
    input);
  const handle = async fl => {
    const files = Array.from(fl).filter(test);
    const rejected = fl.length - files.length;
    if (rejected > 0) toast(rejected + " file(s) skipped: " + spec.msg, "err");
    if (!files.length) return;
    for (const f of files) if (f.size > BIG_WARN) toast(f.name + " is large. Processing may take a while.");
    const recs = [];
    for (const f of files) recs.push(await readFileRec(f));
    onFiles(multiple ? recs : recs.slice(0, 1));
  };
  el.addEventListener("click", e => { if (e.target !== input) input.click(); });
  input.addEventListener("change", () => { if (input.files.length) { handle(input.files); input.value = ""; } });
  ["dragover", "dragenter"].forEach(t => el.addEventListener(t, e => { e.preventDefault(); e.stopPropagation(); el.classList.add("over"); }));
  ["dragleave", "drop"].forEach(t => el.addEventListener(t, e => { e.preventDefault(); e.stopPropagation(); el.classList.remove("over"); }));
  el.addEventListener("drop", e => { if (e.dataTransfer.files.length) handle(e.dataTransfer.files); });
  return el;
}

/* ---------------- small controls ---------------- */
function segmented(options, value, onChange) {
  const el = h("div", { class: "seg" });
  const btns = new Map();
  const set = v => { value = v; btns.forEach((b, bv) => b.classList.toggle("on", bv === v)); };
  for (const o of options) {
    const b = h("button", { type: "button", onclick: () => { set(o.v); onChange && onChange(o.v); } }, o.label);
    btns.set(o.v, b);
    el.append(b);
  }
  set(value);
  return { el, get: () => value, set };
}
function posGrid(value, onChange) {
  const cells = ["tl","tc","tr","ml","mc","mr","bl","bc","br"];
  const el = h("div", { class: "posgrid" });
  const btns = new Map();
  const set = v => { value = v; btns.forEach((b, bv) => b.classList.toggle("on", bv === v)); };
  for (const c of cells) {
    const b = h("button", { type: "button", title: c, "aria-label": "position " + c, onclick: () => { set(c); onChange && onChange(c); } });
    btns.set(c, b);
    el.append(b);
  }
  set(value);
  return { el, get: () => value, set };
}
function slider(min, max, step, value, fmt, onChange) {
  const val = h("span", { class: "rangeval" }, fmt(value));
  const input = h("input", { type: "range", min, max, step, value });
  input.addEventListener("input", () => { val.textContent = fmt(+input.value); onChange && onChange(+input.value); });
  return { el: h("div", { class: "field" }, input, val), get: () => +input.value, set: v => { input.value = v; val.textContent = fmt(v); } };
}
function checkbox(label, checked, onChange) {
  const input = h("input", { type: "checkbox" });
  input.checked = !!checked;
  input.addEventListener("change", () => onChange && onChange(input.checked));
  const el = h("label", { class: "check" }, input, h("span", { class: "box" }, icon("check")), h("span", null, label));
  return { el, get: () => input.checked, set: v => { input.checked = v; } };
}
function swatches(colors, value, onChange) {
  const el = h("div", { class: "swatches" });
  const btns = [];
  const custom = h("input", { type: "color", value: colors.includes(value) ? "#888888" : value, title: "Custom color" });
  const set = v => { value = v; btns.forEach(b => b.classList.toggle("on", b.dataset.c === v)); };
  for (const c of colors) {
    const b = h("button", { type: "button", "data-c": c, style: "background:" + c, title: c, onclick: () => { set(c); onChange && onChange(c); } });
    btns.push(b); el.append(b);
  }
  custom.addEventListener("input", () => { set("__custom"); onChange && onChange(custom.value); });
  el.append(custom);
  set(value);
  return { el, get: () => (value === "__custom" ? custom.value : value) };
}
function optSection(label, ...rows) {
  return h("div", { class: "opt-section" }, h("div", { class: "opt-label" }, label), ...rows);
}

/* ---------------- progress / results ---------------- */
function progressPanel(label) {
  const fill = h("div", { class: "fill" });
  const left = h("span", null, label || "Working");
  const right = h("span", null, "");
  const el = h("div", { class: "progress" }, h("div", { class: "bar" }, fill), h("div", { class: "stat" }, left, right));
  return {
    el,
    set(frac, text, rightText) {
      fill.style.width = Math.round(Math.min(1, Math.max(0, frac)) * 100) + "%";
      if (text != null) left.textContent = text;
      if (rightText != null) right.textContent = rightText;
    },
  };
}

/* files: [{name, bytes, mime}] ; opts: {title, meta, deltaText, deltaGood, zipName} */
function resultScreen(container, files, opts, onAgain) {
  container.innerHTML = "";
  opts = opts || {};
  const multi = files.length > 1;
  let primaryAction, fileList = null;
  if (multi) {
    const zipName = opts.zipName || "atob-pdf-output.zip";
    primaryAction = () => {
      const bytes = PDCore.zipStore(files.map(f => ({ name: f.name, data: f.bytes })));
      downloadBytes(zipName, bytes, "application/zip");
    };
    fileList = h("div", { class: "files" }, files.map(f =>
      h("button", { onclick: () => downloadBytes(f.name, f.bytes, f.mime) },
        icon("file"), h("span", { style: "min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" }, f.name),
        h("span", { class: "sz" }, PDCore.fmtBytes(f.bytes.length)))));
  } else {
    primaryAction = () => downloadBytes(files[0].name, files[0].bytes, files[0].mime);
  }
  const el = h("div", { class: "result" },
    h("div", { class: "ok-ring" }, icon("check")),
    h("h2", null, opts.title || "Done"),
    h("div", { class: "rmeta" },
      multi
        ? h("span", null, files.length + " files · " + PDCore.fmtBytes(files.reduce((a, f) => a + f.bytes.length, 0)))
        : h("span", null, h("span", { class: "strong" }, files[0].name), " · " + PDCore.fmtBytes(files[0].bytes.length))),
    opts.meta ? h("div", { class: "rmeta" }, opts.meta) : null,
    opts.deltaText ? h("div", { class: "delta " + (opts.deltaGood ? "good" : "bad") }, opts.deltaText) : null,
    h("div", { class: "btns" },
      h("button", { class: "btn primary", onclick: primaryAction }, icon("download"),
        window.AndroidBridge ? (multi ? "Save ZIP to Downloads" : "Save to Downloads") : (multi ? "Download all (ZIP)" : "Download")),
      canShareFiles() ? h("button", { class: "btn secondary", onclick: () => {
        if (multi) shareFile(opts.zipName || "atob-pdf-output.zip", PDCore.zipStore(files.map(f => ({ name: f.name, data: f.bytes }))), "application/zip", "any");
        else shareFile(files[0].name, files[0].bytes, files[0].mime, "any");
      } }, icon("share"), "Share") : null,
      h("button", { class: "btn secondary", onclick: onAgain }, "Run again"),
      h("button", { class: "btn secondary", onclick: () => showView("home") }, "Done"),
      (files.length === 1 && files[0].mime === "application/pdf")
        ? h("button", { class: "btn secondary", onclick: () => {
            const b = files[0].bytes;
            openDocTab({ name: files[0].name, size: b.length, buf: b.slice().buffer });
            toast("Opened " + files[0].name + " in a new tab");
          } }, "Continue with this result")
        : null),
    fileList);
  container.append(el);
  primaryAction(); // auto-download once
  if (!window.AndroidBridge) toast(multi ? "ZIP download started" : "Download started");
}

/* v3.8: a tool ran on the open document — its result is now part of that document */
function appliedScreen(container, t, label, opts, onAgain) {
  container.innerHTML = "";
  opts = opts || {};
  const el = h("div", { class: "result applied" },
    h("div", { class: "ok-ring" }, icon("check")),
    h("h2", null, opts.title || PDCore.pastTense(label)),
    h("div", { class: "rmeta" }, h("span", null, "Applied to "), h("span", { class: "strong" }, t.rec.name), " · " + PDCore.fmtBytes(t.rec.size)),
    opts.meta ? h("div", { class: "rmeta" }, opts.meta) : null,
    opts.deltaText ? h("div", { class: "delta " + (opts.deltaGood ? "good" : "bad") }, opts.deltaText) : null,
    h("div", { class: "rmeta subtle" }, "Not saved to disk yet. Keep going with other tools — every change stays in this document and can be undone."),
    h("div", { class: "btns" },
      h("button", { class: "btn primary ap-doc", onclick: () => showView("view") }, icon("file"), "Back to document"),
      h("button", { class: "btn secondary ap-undo", onclick: () => undoTabStep(t).then(ok => { if (ok) showView("view"); }) }, icon("undo"), "Undo"),
      h("button", { class: "btn secondary ap-save", onclick: () => saveDocTab(t) }, icon("download"), "Save"),
      h("button", { class: "btn secondary", onclick: onAgain }, "Run again")),
    h("div", { class: "ap-next" }, h("span", null, "Next:"), ["edit", "sign", "watermark", "numbers", "compress"].filter(i => VIEWS[i]).map(i =>
      h("button", { class: "textbtn", onclick: () => showView(i) }, VIEWS[i].name))));
  container.append(el);
  toast(PDCore.pastTense(label) + " · Undo with " + MOD_KEY + "Z in the document");
}
/* v3.8: original vs. edited, side by side, page by page */
async function openCompare(t, startPage) {
  if (!t) return;
  let a = null, b = null, page = startPage || 0, closed = false;
  try { a = await openPdf({ name: t.origName, buf: t.origBuf }); b = await openPdf(t.rec); }
  catch (e) { toast("Couldn't open both versions: " + (e && e.message || e), "err"); if (a) closePdf(a); return; }
  const total = Math.max(a.numPages, b.numPages);
  page = Math.min(page, total - 1);
  const cA = document.createElement("canvas"), cB = document.createElement("canvas");
  const info = h("span", { class: "cmp-info" });
  const same = h("div", { class: "cmp-same" });
  const colA = h("div", { class: "cmp-col" }, h("div", { class: "cmp-lbl" }, "Original"), h("div", { class: "cmp-frame" }, cA));
  const colB = h("div", { class: "cmp-col" }, h("div", { class: "cmp-lbl" }, "With your changes"), h("div", { class: "cmp-frame" }, cB));
  const draw = async (d, c, i, frame) => {
    frame.classList.toggle("missing", i >= d.numPages);
    if (i >= d.numPages) { c.width = c.height = 1; return; }
    const pg = await d.getPage(i + 1);
    const v1 = pg.getViewport({ scale: 1 });
    const cssW = Math.min(420, (Math.min(window.innerWidth, 1000) - 90) / 2);
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const vp = pg.getViewport({ scale: cssW / v1.width * dpr });
    c.width = Math.round(vp.width); c.height = Math.round(vp.height);
    c.style.width = cssW + "px";
    const x = c.getContext("2d", { alpha: false });
    x.fillStyle = "#fff"; x.fillRect(0, 0, c.width, c.height);
    await pg.render({ canvasContext: x, viewport: vp }).promise;
  };
  const go = async i => {
    page = Math.max(0, Math.min(total - 1, i));
    info.textContent = "Page " + (page + 1) + " of " + total + (a.numPages !== b.numPages ? " (original " + a.numPages + ", now " + b.numPages + ")" : "");
    try {
      await Promise.all([draw(a, cA, page, colA.lastChild), draw(b, cB, page, colB.lastChild)]);
      if (closed) return;
      let diff = true;
      try { diff = cA.width !== cB.width || cA.height !== cB.height || cA.toDataURL() !== cB.toDataURL(); } catch (e) {}
      same.textContent = diff ? "This page changed" : "No visible change on this page";
      same.classList.toggle("changed", diff);
    } catch (e) { same.textContent = "Couldn't draw this page"; }
  };
  const close = showModal({
    title: "Compare with original",
    cls: "cmp-dlg",
    onCancel: c => c(),
    body: h("div", null,
      h("div", { class: "cmp-bar" },
        h("button", { class: "iconbtn", title: "Previous page", "aria-label": "Previous page", onclick: () => go(page - 1) }, icon("back")),
        info,
        h("button", { class: "iconbtn", title: "Next page", "aria-label": "Next page", style: "transform:rotate(180deg)", onclick: () => go(page + 1) }, icon("back")),
        same),
      h("div", { class: "cmp-cols" }, colA, colB)),
    actions: [{ label: "Close", primary: true, onClick: c => c() }],
  });
  const wrap = document.querySelector(".modal-wrap:last-of-type");
  const obs = new MutationObserver(() => { if (wrap && !wrap.isConnected) { closed = true; obs.disconnect(); closePdf(a); closePdf(b); } });
  obs.observe(document.body, { childList: true });
  void close;
  go(page);
}
/* undo the last step of a tab from outside its viewer */
async function undoTabStep(t) {
  if (!t || !t.hist.canUndo) return false;
  if (t.api && t.api.undo) { await t.api.undo(); return true; }
  const st = t.hist.undo({ buf: t.rec.buf, size: t.rec.size });
  t.rec.buf = st.buf; t.rec.size = st.size;
  refreshTabView(t);
  toast("Undone: " + lcFirstWord(st.label));
  return true;
}

function errorBack(container, err, onRetry) {
  container.innerHTML = "";
  container.append(h("div", { class: "result" },
    h("div", { class: "ok-ring", style: "background:var(--err-soft);color:var(--err)" }, icon("close")),
    h("h2", null, "That didn't work"),
    h("div", { class: "rmeta", style: "max-width:52ch;margin:0 auto" }, String(err && err.message || err)),
    h("div", { class: "btns" },
      h("button", { class: "btn primary", onclick: onRetry }, "Try again"),
      h("button", { class: "btn secondary", onclick: () => showView("home") }, "Done"))));
}

/* action bar */
function actionBar(summaryText, buttonLabel, onClick) {
  const summary = h("div", { class: "summary" }, summaryText || "");
  const btn = h("button", { class: "btn primary", disabled: "", onclick: () => onClick() }, buttonLabel);
  const el = h("div", { class: "actionbar" }, h("div", { class: "inner" }, summary, h("div", { class: "spacer" }), btn));
  return {
    el, btn,
    setSummary: t => { summary.textContent = t; },
    enable: on => { if (on) btn.removeAttribute("disabled"); else btn.setAttribute("disabled", ""); },
    setLabel: t => { btn.textContent = t; },
  };
}

/* ---------------- lazy engines (restored: lost in the v3 shell rewrite) ---------------- */
function b64ToBytes(b64) {
  const bin = atob(b64);
  const u = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
  return u;
}
function b64ToText(b64) { return new TextDecoder().decode(b64ToBytes(b64)); }
const ASSETS = () => (window.PD_ASSETS || {});

let _mupdfPromise = null;
function loadMuPDF() {
  if (_mupdfPromise) return _mupdfPromise;
  _mupdfPromise = (async () => {
    const A = ASSETS();
    if (!A.mupdfWasm || typeof window.__mupdfFactory !== "function")
      throw new Error("The MuPDF engine isn't embedded in this build.");
    globalThis["$libmupdf_wasm_Module"] = { wasmBinary: b64ToBytes(A.mupdfWasm), locateFile: f => f };
    const timeout = new Promise((_, rej) => setTimeout(() => rej(new Error("MuPDF engine took too long to start (60s). This browser may block WebAssembly here.")), 60000));
    return await Promise.race([window.__mupdfFactory(), timeout]);
  })();
  _mupdfPromise.catch(() => { _mupdfPromise = null; });
  return _mupdfPromise;
}
function mupdfOpen(mupdf, bytes) {
  return mupdf.Document.openDocument(bytes, "application/pdf");
}

const TESS_SHIM = '(function(){\n' +
  'var dec=function(b){var s=atob(b),u=new Uint8Array(s.length);for(var i=0;i<s.length;i++)u[i]=s.charCodeAt(i);return u;};\n' +
  'var of_=self.fetch?self.fetch.bind(self):null;\n' +
  'self.fetch=function(u){var m=String(u).match(/([A-Za-z_\\-]+)\\.traineddata(\\.gz)?$/);if(m&&self.PD_LANGS&&self.PD_LANGS[m[1]])return Promise.resolve(new Response(dec(self.PD_LANGS[m[1]]).buffer));return of_?of_.apply(self,arguments):Promise.reject(new Error("offline"));};\n' +
  'var oi_=self.importScripts?self.importScripts.bind(self):null;\n' +
  'self.importScripts=function(){var a=Array.prototype.filter.call(arguments,function(u){return !/tesseract-core/.test(String(u));});if(a.length&&oi_)oi_.apply(self,a);};\n' +
  '})();\n';

const _tessWorkerURLs = new Map();
/* one worker blob per language set: only the traineddata that's needed is embedded */
function tessWorkerURL(langs) {
  const A = ASSETS();
  if (!A.tessWorker || !A.tessCore) throw new Error("The OCR engine isn't embedded in this build.");
  const all = A.langs || {};
  const want = String(langs || "").split("+").map(s => s.trim()).filter(l => all[l]);
  const key = want.slice().sort().join("+") || "*";
  if (_tessWorkerURLs.has(key)) return _tessWorkerURLs.get(key);
  const pick = {};
  (want.length ? want : Object.keys(all)).forEach(l => { pick[l] = all[l]; });
  const parts = [
    "self.PD_LANGS=" + JSON.stringify(pick) + ";\n",
    TESS_SHIM,
    b64ToText(A.tessCore), "\n;\n",
    b64ToText(A.tessWorker),
  ];
  const url = URL.createObjectURL(new Blob(parts, { type: "text/javascript" }));
  _tessWorkerURLs.set(key, url);
  return url;
}
async function createTessWorker(langs, logger) {
  if (typeof Tesseract === "undefined") throw new Error("The OCR engine isn't embedded in this build.");
  return await Tesseract.createWorker(langs, 1, {
    workerPath: tessWorkerURL(langs),
    workerBlobURL: false,
    corePath: "tesseract-core-inline.js",
    langPath: "pdfdesk-inline",
    gzip: false,
    cacheMethod: "none",
    logger: typeof logger === "function" ? logger : () => {},
  });
}
const LANG_NAMES = { eng: "English", ara: "Arabic", hin: "Hindi", urd: "Urdu", fra: "French", deu: "German", spa: "Spanish", ita: "Italian", por: "Portuguese", rus: "Russian", tur: "Turkish", nld: "Dutch", pol: "Polish", chi_sim: "Chinese (simplified)", chi_tra: "Chinese (traditional)", jpn: "Japanese", kor: "Korean", mal: "Malayalam", tam: "Tamil", tel: "Telugu", ben: "Bengali", fas: "Persian" };
const LATIN_LANGS = new Set(["eng", "fra", "deu", "spa", "ita", "por", "nld", "pol", "tur"]);

/* =====================================================================
   v3.4 — sharing (sheet + native bridges) and the saved-signature store
   ===================================================================== */
Object.assign(ICONS, {
  mail: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="18" height="14" rx="2.5"/><path d="m4 7 8 6 8-6"/></svg>',
  chat: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M20 12a8 8 0 0 1-11.8 7L4 20l1.1-4A8 8 0 1 1 20 12z"/><path d="M9 10.5c.3 1.6 1.9 3.3 3.6 3.8l1.2-1.1 1.7.8"/></svg>',
  star: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"><path d="m12 3.5 2.6 5.4 5.9.8-4.3 4.1 1 5.8L12 16.9l-5.2 2.7 1-5.8-4.3-4.1 5.9-.8z"/></svg>',
  starfill: '<svg viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"><path d="m12 3.5 2.6 5.4 5.9.8-4.3 4.1 1 5.8L12 16.9l-5.2 2.7 1-5.8-4.3-4.1 5.9-.8z"/></svg>',
  save: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M5 4h11l3 3v13H5z"/><path d="M8 4v5h7V4M8 20v-6h8v6"/></svg>',
});

function blobToB64(blob) {
  return new Promise((resolve, reject) => {
    const fr = new FileReader();
    fr.onload = () => resolve(String(fr.result).split(",")[1] || "");
    fr.onerror = () => reject(fr.error);
    fr.readAsDataURL(blob);
  });
}
function platformKind() {
  if (window.AndroidBridge) return "android";
  if (window.pdeskAPI) {
    const p = window.pdeskAPI.platform || "";
    return p === "darwin" ? "mac" : p === "win32" ? "win" : "desktop";
  }
  return "browser";
}
function webShareFilesOK(file) {
  try { return !!(navigator.canShare && navigator.share && navigator.canShare({ files: [file] })); } catch (e) { return false; }
}
function canShareFiles() {
  if (window.AndroidBridge && typeof window.AndroidBridge.shareFile === "function") return true;
  if (window.pdeskAPI && typeof window.pdeskAPI.shareFile === "function") return true;
  return webShareFilesOK(new File([new Uint8Array(1)], "x.pdf", { type: "application/pdf" }));
}
/* target: "email" | "whatsapp" | "any". Resolves to a short status string. */
async function shareFile(name, bytes, mime, target) {
  mime = mime || "application/octet-stream";
  target = target || "any";
  const blob = bytes instanceof Blob ? bytes : new Blob([bytes], { type: mime });
  const label = target === "whatsapp" ? "WhatsApp" : target === "email" ? "email" : "an app";
  if (window.AndroidBridge && typeof window.AndroidBridge.shareFile === "function") {
    window.AndroidBridge.shareFile(name, await blobToB64(blob), target);
    return "android";
  }
  if (window.pdeskAPI && typeof window.pdeskAPI.shareFile === "function") {
    const res = await window.pdeskAPI.shareFile({ name, data: await blob.arrayBuffer(), target });
    if (res && res.method === "clipboard") toast("Copied " + name + " — paste it into " + (target === "any" ? "WhatsApp or your email" : label) + " with Ctrl+V", null, 7000);
    else if (res && res.method === "reveal") toast("Saved to a temporary folder — drag it into " + label, null, 6000);
    else if (res && !res.ok) toast("Could not share: " + (res.error || "unknown error"), "err");
    return res && res.method || "desktop";
  }
  const file = new File([blob], name, { type: mime });
  if (webShareFilesOK(file)) {
    try { await navigator.share({ files: [file], title: name }); return "webshare"; }
    catch (e) { if (e && e.name === "AbortError") return "cancelled"; }
  }
  downloadBytes(name, blob, mime);
  toast("Sharing isn't available here — downloaded " + name + " so you can attach it in " + label, null, 6000);
  return "download";
}

/* bottom sheet (phone) / centered card (desktop) */
function showSheet({ title, sub, items, onClose }) {
  const wrap = h("div", { class: "sheet-wrap" });
  let closed = false;
  const close = why => {
    if (closed) return;
    closed = true;
    wrap.classList.add("out");
    setTimeout(() => wrap.remove(), 180);
    onClose && onClose(why);
  };
  const list = h("div", { class: "sheet-list" }, items.filter(Boolean).map(it =>
    h("button", { class: "sheet-item" + (it.primary ? " primary" : ""), "data-act": it.id || "", onclick: async () => {
      if (it.closes !== false) close(it.id);
      try { await it.onClick(close); } catch (e) { toast(String(e && e.message || e), "err"); }
    } },
      h("span", { class: "si-ico" }, icon(it.icon)),
      h("span", { class: "si-txt" }, h("span", { class: "si-title" }, it.label), it.sub ? h("span", { class: "si-sub" }, it.sub) : null))));
  const sheet = h("div", { class: "sheet", role: "dialog", "aria-label": title },
    h("div", { class: "sheet-grab" }),
    h("div", { class: "sheet-head" },
      h("div", { class: "sheet-ring" }, icon("check")),
      h("div", { class: "grow" }, h("div", { class: "sheet-title" }, title), sub ? h("div", { class: "sheet-sub" }, sub) : null),
      h("button", { class: "iconbtn", title: "Close", "aria-label": "Close", onclick: () => close("x") }, icon("close"))),
    list);
  wrap.addEventListener("click", e => { if (e.target === wrap) close("backdrop"); });
  wrap.append(sheet);
  document.body.append(wrap);
  return close;
}

/* after-signing sheet: Keep editing / Download / Email / WhatsApp */
function signedSheet(file, { onKeepEditing, onDone }) {
  const kind = platformKind();
  const how = kind === "win" ? "Copies the file so you can paste it" : kind === "mac" ? "Opens the macOS share menu" : kind === "android" ? null : null;
  return showSheet({
    title: "Signed",
    sub: file.name + " · " + PDCore.fmtBytes(file.bytes.length),
    onClose: why => { if (why === "x" || why === "backdrop") onDone && onDone(); },
    items: [
      { id: "keep", icon: "pen", label: "Keep editing", sub: "Add another signature or initials", onClick: () => onKeepEditing && onKeepEditing() },
      { id: "download", icon: "download", label: window.AndroidBridge ? "Save to Downloads" : "Download", closes: false, onClick: () => { downloadBytes(file.name, file.bytes, file.mime); if (!window.AndroidBridge) toast("Download started"); } },
      { id: "email", icon: "mail", label: "Share via Email", sub: how, closes: false, onClick: () => shareFile(file.name, file.bytes, file.mime, "email") },
      { id: "whatsapp", icon: "chat", label: "Share via WhatsApp", sub: how, closes: false, onClick: () => shareFile(file.name, file.bytes, file.mime, "whatsapp") },
    ],
  });
}

/* ---- saved signatures & initials (IndexedDB, trimmed PNGs) ---- */
function sigDB() {
  return new Promise((resolve, reject) => {
    if (!window.indexedDB) return reject(new Error("no idb"));
    const req = indexedDB.open("atobpdf-sigs", 1);
    req.onupgradeneeded = () => { req.result.createObjectStore("items", { keyPath: "id" }); };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}
function idbDone(tx) { return new Promise((res, rej) => { tx.oncomplete = () => res(); tx.onerror = () => rej(tx.error); tx.onabort = () => rej(tx.error); }); }
const SigStore = {
  async all() {
    try {
      const db = await sigDB();
      return await new Promise((resolve, reject) => {
        const r = db.transaction("items").objectStore("items").getAll();
        r.onsuccess = () => resolve((r.result || []).sort((a, b) => (b.def - a.def) || (b.at - a.at)));
        r.onerror = () => reject(r.error);
      });
    } catch (e) { return []; }
  },
  async add(kind, sig) {
    const db = await sigDB();
    const existing = (await SigStore.all()).filter(s => s.kind === kind);
    const item = { id: "s" + Date.now().toString(36) + Math.random().toString(36).slice(2, 6), kind, w: sig.w, h: sig.h,
      png: sig.bytes.slice().buffer, at: Date.now(), def: existing.some(s => s.def) ? 0 : 1 };
    const tx = db.transaction("items", "readwrite");
    tx.objectStore("items").put(item);
    await idbDone(tx);
    return item;
  },
  async remove(id) {
    const db = await sigDB();
    const all = await SigStore.all();
    const gone = all.find(s => s.id === id);
    const tx = db.transaction("items", "readwrite");
    const st = tx.objectStore("items");
    st.delete(id);
    if (gone && gone.def) { const next = all.find(s => s.kind === gone.kind && s.id !== id); if (next) st.put(Object.assign({}, next, { def: 1 })); }
    await idbDone(tx);
  },
  async setDefault(id) {
    const db = await sigDB();
    const all = await SigStore.all();
    const target = all.find(s => s.id === id);
    if (!target) return;
    const tx = db.transaction("items", "readwrite");
    const st = tx.objectStore("items");
    for (const s of all) if (s.kind === target.kind) st.put(Object.assign({}, s, { def: s.id === id ? 1 : 0 }));
    await idbDone(tx);
  },
  toSig(item) {
    const bytes = new Uint8Array(item.png.slice(0));
    return { bytes, isPng: true, w: item.w, h: item.h, url: URL.createObjectURL(new Blob([bytes], { type: "image/png" })), savedId: item.id };
  },
};
/* white → transparent (soft edge) for photographed / scanned signatures */
function knockoutWhite(imgData, cut) {
  cut = cut || 225;
  const d = imgData.data, soft = 40;
  for (let i = 0; i < d.length; i += 4) {
    const lum = Math.min(d[i], d[i + 1], d[i + 2]);
    if (lum >= cut) d[i + 3] = 0;
    else if (lum > cut - soft) d[i + 3] = Math.round(d[i + 3] * (cut - lum) / soft);
  }
  return imgData;
}
/* canvas → trimmed PNG {bytes, isPng, w, h, url} (null when blank) */
async function trimToPng(canvas, opts) {
  opts = opts || {};
  const c0 = canvas.getContext("2d", { willReadFrequently: true });
  let data = c0.getImageData(0, 0, canvas.width, canvas.height);
  if (opts.knockout) { data = knockoutWhite(data, opts.cut); }
  const bb = PDCore.inkBBox(data.data, canvas.width, canvas.height, { alphaMin: 10 });
  if (!bb) return null;
  const pad = Math.round(opts.pad != null ? opts.pad : 6);
  const x = Math.max(0, bb.x - pad), y = Math.max(0, bb.y - pad);
  const w = Math.min(canvas.width - x, bb.w + pad * 2), hh = Math.min(canvas.height - y, bb.h + pad * 2);
  const src = document.createElement("canvas");
  src.width = canvas.width; src.height = canvas.height;
  src.getContext("2d").putImageData(data, 0, 0);
  const out = document.createElement("canvas");
  out.width = w; out.height = hh;
  out.getContext("2d").drawImage(src, x, y, w, hh, 0, 0, w, hh);
  const blob = await new Promise(r => out.toBlob(r, "image/png"));
  return { bytes: new Uint8Array(await blob.arrayBuffer()), isPng: true, w, h: hh, url: URL.createObjectURL(blob) };
}

/* ---------------- shell / router (Acrobat-style workspace) ---------------- */
const VIEWS = {};           // id -> {name, desc, group, hint, icon, build}
let currentView = null;
let workspace = null;       // the open FileRec
const viewRoot = h("div");
let sideFileBox = null, sideNav = null;

const STEP_LABELS = { forms: "Fill form", watermark: "Add watermark", numbers: "Add page numbers", organize: "Reorganize pages", delete: "Delete pages",
  rotate: "Rotate pages", crop: "Crop pages", ocr: "Add OCR text layer", compress: "Compress", flatten: "Flatten", repair: "Repair", unlock: "Unlock" };
function registerTool(def) {
  if (DOC_TOOLS.includes(def.id)) { def.modifies = true; if (!def.stepLabel && STEP_LABELS[def.id]) def.stepLabel = STEP_LABELS[def.id]; }
  VIEWS[def.id] = def;
}

function showView(id, preloadOverride) {
  /* v3.8: a tool with unapplied work (the editor) finishes it into the document first,
     so the next tool or the viewer opens on top of it */
  if (currentView && currentView.beforeLeave) {
    const fn = currentView.beforeLeave;
    currentView.beforeLeave = null;
    return Promise.resolve().then(fn).catch(e => toast("Couldn't keep those edits: " + (e && e.message || e), "err", 7000))
      .then(() => showView(id, preloadOverride));
  }
  if (id === "home") id = isMobile() ? "mhome" : (workspace ? "view" : "welcome");
  if (id === "welcome" && isMobile()) id = "mhome";
  if (currentView && currentView.cleanup) { try { currentView.cleanup(); } catch (e) {} }
  hideDocPane();
  closeCtxMenu();
  document.querySelectorAll(".actionbar").forEach(e => e.remove());
  document.querySelectorAll(".modal-wrap").forEach(cancelModal);
  viewRoot.innerHTML = "";
  window.scrollTo(0, 0);
  markActive(id);
  document.body.classList.toggle("tabs-on", id === "mhome" || id === "tools");
  document.body.classList.toggle("in-tool", id !== "mhome" && id !== "tools" && id !== "welcome");
  document.body.dataset.view = id;
  renderTabs();
  // v3.5: an open document lives in its own persistent pane (one per tab)
  if (id === "view" && workspace) {
    const t = tabOf(workspace) || addDocTab(workspace);
    showDocPane(t);
    return;
  }
  if (id === "welcome") { currentView = { id }; buildWelcome(viewRoot); return; }
  if (id === "mhome") { currentView = { id }; buildHome(viewRoot); return; }
  if (id === "tools") { currentView = { id }; buildToolsIndex(viewRoot); return; }
  const def = VIEWS[id];
  if (!def) return;
  const preload = preloadOverride !== undefined ? preloadOverride
    : (def.acceptsPdf === false ? null : workspace);
  const tab = preload && preload === workspace ? activeTab : null;
  const wrap = h("div", { class: "view" + (tab ? " on-doc" : "") });
  const head = h("div", { class: "tool-head" },
    h("button", { class: "iconbtn back", title: workspace ? "Back to the document (keeps your changes)" : "Back", "aria-label": "Back", onclick: () => showView(workspace ? "view" : (isMobile() ? "home" : "welcome")) }, icon("back")),
    h("div", { class: "th-text" },
      h("h1", null, def.name),
      isMobile() && def.desc ? h("div", { class: "th-desc" }, def.desc) : null),
    def.hint ? h("div", { class: "hint" }, def.hint) : null,
    tab ? toolSwitcher(id) : null);
  const body = h("div", { class: "tool-body" });
  wrap.append(head, body);
  viewRoot.append(wrap);
  currentView = { id, cleanup: null };
  const ctx = {
    body,
    setCleanup: fn => { if (currentView && currentView.id === id) currentView.cleanup = fn; },
    /* v3.5.1: a tool with its own undo/redo (the editor) exposes it to the menu commands */
    setCommands: cmds => { if (currentView && currentView.id === id) currentView.cmds = cmds; },
    /* v3.8: async work to finish before another view opens (the editor applies its edits) */
    setBeforeLeave: fn => { if (currentView && currentView.id === id) currentView.beforeLeave = fn; },
    preload,
    tab,                        // the open document this tool works on (null for a picked file)
    modifies: !!def.modifies,
    restart: () => showView(id),
  };
  def.build(ctx);
}

/* v3.8: tools that change the open document; their result is applied to the tab */
const DOC_TOOLS = ["edit", "sign", "forms", "watermark", "numbers", "organize", "delete", "rotate", "crop", "ocr", "compress", "flatten", "repair", "unlock"];
function toolSwitcher(cur) {
  const ids = ["edit", "sign", "forms", "watermark", "numbers", "organize", "ocr", "compress"].filter(i => VIEWS[i]);
  return h("div", { class: "tool-switch", role: "toolbar", "aria-label": "Switch tool" },
    h("button", { class: "ts-btn ts-doc", title: "Back to the document (keeps every change)", onclick: () => showView("view") }, icon("file"), h("span", null, "Document")),
    ids.map(i => h("button", { class: "ts-btn" + (i === cur ? " on" : ""), "data-tool": i, title: VIEWS[i].name + " — works on the edited document", "aria-label": VIEWS[i].name,
      onclick: () => { if (i !== cur) showView(i); } }, icon(VIEWS[i].icon), h("span", null, VIEWS[i].name))));
}
const TOOL_GROUPS = [
  { name: "View & edit", ids: ["view", "read", "edit", "sign", "forms", "watermark", "numbers"] },
  { name: "Pages", ids: ["organize", "merge", "split", "extract", "delete", "rotate", "crop"] },
  { name: "Convert", ids: ["toword", "toexcel", "totext", "fromword", "fromtxt", "img2pdf", "pdf2img", "ocr"] },
  { name: "Secure & optimize", ids: ["protect", "unlock", "compress", "flatten", "repair"] },
];

/* ---- recents (IndexedDB, phone shell) ---- */
const RECENTS_MAX = 6, RECENTS_CAP = 40 * 1024 * 1024;
function recentsDB() {
  return new Promise((resolve, reject) => {
    if (!window.indexedDB) return reject(new Error("no idb"));
    const req = indexedDB.open("atobpdf-recents", 1);
    req.onupgradeneeded = () => { req.result.createObjectStore("files", { keyPath: "name" }); };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}
async function recentsAll() {
  try {
    const db = await recentsDB();
    return await new Promise((resolve, reject) => {
      const r = db.transaction("files").objectStore("files").getAll();
      r.onsuccess = () => resolve((r.result || []).sort((a, b) => b.at - a.at));
      r.onerror = () => reject(r.error);
    });
  } catch (e) { return []; }
}
async function recentsPut(rec) {
  try {
    if (!rec || rec.size > RECENTS_CAP) return;
    const db = await recentsDB();
    const all = await recentsAll();
    const tx = db.transaction("files", "readwrite");
    const st = tx.objectStore("files");
    st.put({ name: rec.name, size: rec.size, buf: rec.buf, at: Date.now() });
    all.filter(r => r.name !== rec.name).slice(RECENTS_MAX - 1).forEach(r => st.delete(r.name));
  } catch (e) { /* recents are best-effort */ }
}
async function recentsRemove(name) {
  try { const db = await recentsDB(); db.transaction("files", "readwrite").objectStore("files").delete(name); } catch (e) {}
}
function relTime(t) {
  const d = Date.now() - t, m = Math.round(d / 60000);
  if (m < 2) return "Just now";
  if (m < 60) return m + " min ago";
  const hrs = Math.round(m / 60);
  if (hrs < 24) return hrs + " h ago";
  const days = Math.round(hrs / 24);
  if (days === 1) return "Yesterday";
  if (days < 7) return days + " days ago";
  return new Date(t).toLocaleDateString();
}

/* ---- workspace file = the active document tab (v3.5) ----
   Home is a tab of its own; every opened PDF gets a tab with a persistent viewer
   pane, so several documents stay open side by side (Acrobat-style). Tools in the
   sidebar always work on the active tab's document. */
const docTabs = [];          // {id, key, rec, pane, api, cleanup, hist: PDCore.EditHistory}
let activeTab = null;        // null = Home
let tabSeq = 0;
const tabStrip = h("div", { class: "doctabs", role: "tablist", "aria-label": "Open documents" });
const docHost = h("div", { class: "dochost" });

function tabOf(rec) { return rec ? docTabs.find(t => t.rec === rec) || null : null; }
function tabDirty(t) { return !!t && !!t.hist && t.hist.dirty; }
function newTabKey() { return SESSION_ID + "-" + (++tabSeq) + "-" + Math.random().toString(36).slice(2, 7); }
function addDocTab(rec) {
  const t = { id: "d" + (++tabSeq), key: newTabKey(), rec, origName: rec.name, origSize: rec.size, origBuf: rec.buf, pane: null, api: null, cleanup: null,
    hist: new PDCore.EditHistory({ max: 20, maxBytes: 120 * 1024 * 1024 }) };
  docTabs.push(t);
  recentsPut(rec);
  return t;
}
/* an already-open tab for this file: the same path on desktop (never two tabs writing one
   file), else the same name + size with no edits */
function findOpenTab(rec) {
  return tabOf(rec)
    || (rec.path ? docTabs.find(x => x.rec.path === rec.path) : null)
    || docTabs.find(x => !x.rec.path && !rec.path && x.origName === rec.name && x.origSize === rec.size && !tabDirty(x))
    || null;
}
/* open (or switch to) a document tab */
function openDocTab(rec, goto) {
  let t = findOpenTab(rec);
  if (!t) t = addDocTab(rec);
  activateTab(t, goto);
  return t;
}
function activateTab(t, goto) {
  activeTab = t;
  workspace = t ? t.rec : null;
  renderSideFile();
  refreshNavDisabled();
  showView(t ? (goto || "view") : "home");
}
function setWorkspaceFile(rec, goto) { openDocTab(rec, goto); }
/* the active document was replaced by a derived file (e.g. signed): keep the tab, swap its contents */
function replaceWorkspace(rec) {
  const t = activeTab || tabOf(workspace);
  workspace = rec;
  if (t) {
    destroyDocPane(t);
    Recovery.drop(t);
    t.rec = rec; t.origName = rec.name; t.origSize = rec.size; t.origBuf = rec.buf; t.edLayer = null; t.hist.reset();
  } else addDocTab(rec);
  recentsPut(rec);
  renderSideFile();
  renderTabs();
}
function destroyDocPane(t) {
  if (t.cleanup) { try { t.cleanup(); } catch (e) {} }
  if (t.pane) t.pane.remove();
  t.pane = t.api = t.cleanup = null;
}
/* v3.8: a tool's result becomes the next step of the open document (one undo step),
   so every tool works on top of the previous edits instead of the original file */
function applyToTab(t, label, bytes, idx) {
  if (!t || !bytes) return false;
  const b = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
  t.hist.push(label, { buf: t.rec.buf, size: t.rec.size }, idx || null);
  t.rec.buf = b.buffer.slice(b.byteOffset, b.byteOffset + b.byteLength);
  t.rec.size = b.byteLength;
  // t.edLayer stays: it is tied to a history state, so undoing back to it revives the editor objects
  refreshTabView(t);
  return true;
}
/* bytes changed outside the viewer (tool, undo from the history panel): redraw it now if
   it is showing, else when it is shown next */
function refreshTabView(t) {
  t.stale = true;
  if (t.pane && t.api && t.api.refresh && currentView && currentView.tab === t) { t.stale = false; t.api.refresh(); }
  renderTabs();
  renderSideFile();
  Recovery.soon();
}
function showDocPane(t) {
  activeTab = t;
  if (!t.pane) {
    t.pane = h("div", { class: "docpane", "data-tab": t.id });
    docHost.append(t.pane);
    const ctx = {
      body: t.pane, tab: t, preload: t.rec,
      isActive: () => !!(currentView && currentView.tab === t),
      setCleanup: fn => { t.cleanup = fn; },
      setApi: api => { t.api = api; },
      restart: () => { destroyDocPane(t); if (currentView && currentView.tab === t) showView("view"); },
    };
    try { buildViewer(ctx, t.rec); } catch (e) { errorBack(t.pane, e, ctx.restart); }
  }
  currentView = { id: "view", tab: t, cleanup: null };
  docHost.querySelectorAll(".docpane").forEach(p => p.classList.toggle("on", p === t.pane));
  document.body.classList.add("pane-on");
  renderTabs();
  if (t.api && t.api.onShow) t.api.onShow();
  if (t.stale && t.api && t.api.refresh) { t.stale = false; t.api.refresh(); }
}
function hideDocPane() {
  const t = currentView && currentView.tab;
  document.body.classList.remove("pane-on");
  docHost.querySelectorAll(".docpane.on").forEach(p => p.classList.remove("on"));
  if (t && t.api && t.api.onHide) { try { t.api.onHide(); } catch (e) {} }
}
/* v3.5.1 Save: desktop files opened from disk are written back in place (atomic, via
   the main process); everything else (plain HTML, Android, derived files) downloads.
   asNew = Save As. Resolves true when the bytes reached disk / the download started. */
const savingTabs = new Set();
async function saveDocTab(t, asNew) {
  if (!t || savingTabs.has(t)) return false;
  savingTabs.add(t);
  try {
    const state = t.hist.state;
    const data = t.rec.buf.slice(0);
    const api = window.pdeskAPI;
    let how = "download";
    if (api && typeof api.saveFile === "function" && t.rec.path && !asNew) {
      const res = await api.saveFile({ path: t.rec.path, data });
      if (res && res.ok) how = "inplace";
      else {
        toast("Couldn't save over " + t.rec.name + ": " + (res && res.error || "unknown error") + ". Choose where to save a copy.", "err", 7000);
        asNew = true;
      }
    }
    if (how === "download" && api && typeof api.saveAs === "function") {
      const res = await api.saveAs({ name: t.rec.name, path: t.rec.path || "", data });
      if (!res || !res.ok) {
        if (res && res.error) toast("Couldn't save: " + res.error, "err", 6000);
        return false;
      }
      t.rec.path = res.path;
      t.rec.name = res.name || t.rec.name;
      t.origName = t.rec.name;
      how = "saveas";
    } else if (how === "download") {
      downloadBytes(t.rec.name, new Uint8Array(data), "application/pdf");
    }
    if (t.hist.state === state) t.hist.markSaved();
    t.origSize = t.rec.size;
    Recovery.drop(t);
    recentsPut(t.rec);
    renderTabs();
    renderSideFile();
    if (t.api && t.api.onSaved) t.api.onSaved();
    if (how === "inplace") toast("Saved " + t.rec.name);
    else if (how === "saveas") toast("Saved as " + t.rec.name);
    else if (!window.AndroidBridge) toast("Saved " + t.rec.name + " (downloaded a copy)");
    return true;
  } catch (e) {
    toast("Couldn't save " + t.rec.name + ": " + (e && e.message || e), "err");
    return false;
  } finally { savingTabs.delete(t); }
}
function closeDocTab(t, force) {
  if (!force && tabDirty(t)) {
    showModal({
      title: "Save changes to " + t.rec.name + "?",
      body: h("p", null, "Your changes will be lost if you close without saving."),
      actions: [
        { label: "Don't save", onClick: c => { c(); closeDocTab(t, true); } },
        { label: "Cancel", onClick: c => c() },
        { label: "Save", primary: true, onClick: async c => { c(); if (await saveDocTab(t)) closeDocTab(t, true); } },
      ],
    });
    return;
  }
  const i = docTabs.indexOf(t);
  if (i < 0) return;
  Recovery.drop(t);
  const wasShown = currentView && currentView.tab === t;
  const wasActive = activeTab === t;
  if (wasShown) { hideDocPane(); currentView = null; }
  docTabs.splice(i, 1);
  destroyDocPane(t);
  if (wasActive) activateTab(isMobile() ? null : (docTabs[i] || docTabs[i - 1] || null));
  else renderTabs();
}

/* ---- v3.5.1 leaving the app with unsaved tabs (window close, quit, Android Back) ----
   One combined prompt. Resolves true when it's fine to go (saved, or the user chose
   Don't save), false on Cancel. */
let leavePrompt = null;
let leavingApp = false;      // the user confirmed: beforeunload / pagehide stand down
function confirmLeave(verb) {
  const dirty = docTabs.filter(tabDirty);
  if (!dirty.length) return Promise.resolve(true);
  if (leavePrompt) return leavePrompt;
  leavePrompt = new Promise(resolve => {
    const done = (ok, c) => { if (c) c(); leavePrompt = null; resolve(ok); };
    const one = dirty.length === 1;
    const list = h("ul", { class: "leave-list" }, dirty.map(t => h("li", null,
      h("span", { class: "fname" }, t.rec.name),
      h("span", { class: "fmeta" }, t.hist.depth ? " · " + t.hist.depth + (t.hist.depth === 1 ? " change" : " changes") : " · recovered"))));
    showModal({
      title: one ? "Save changes to " + dirty[0].rec.name + "?" : dirty.length + " documents have unsaved changes",
      cls: "leave-dlg",
      onCancel: c => done(false, c),
      body: h("div", null,
        h("p", null, one ? "Your changes will be lost if you " + verb + " without saving." : "Save them before you " + verb + "?"),
        one ? null : list),
      actions: [
        { label: "Don't save", onClick: c => { dirty.forEach(t => Recovery.drop(t)); done(true, c); } },
        { label: "Cancel", onClick: c => done(false, c) },
        { label: one ? "Save" : "Save all", primary: true, onClick: async c => {
          c();
          for (const t of dirty) {
            if (!tabDirty(t)) continue;
            if (!(await saveDocTab(t))) { leavePrompt = null; resolve(false); return; }
          }
          leavePrompt = null; resolve(true);
        } },
      ],
    });
  });
  return leavePrompt;
}
function renderTabs() {
  tabStrip.innerHTML = "";
  document.body.classList.toggle("has-docs", docTabs.length > 0);
  document.body.classList.toggle("multi-docs", docTabs.length > 1);
  const onHome = !activeTab && (!currentView || currentView.id === "welcome" || currentView.id === "mhome");
  const home = h("button", { class: "dt dt-home" + (onHome ? " on" : ""), role: "tab", "aria-selected": onHome ? "true" : "false", title: "Home", onclick: () => activateTab(null) },
    icon("home"), h("span", { class: "dt-name" }, "Home"));
  tabStrip.append(home);
  for (const t of docTabs) {
    const on = activeTab === t;
    const dirty = tabDirty(t);
    const x = h("span", { class: "dt-x", role: "button", title: "Close", "aria-label": "Close " + t.rec.name, onclick: e => { e.stopPropagation(); closeDocTab(t); } }, icon("close"));
    const b = h("button", { class: "dt" + (on ? " on" : "") + (dirty ? " dirty" : ""), role: "tab", "aria-selected": on ? "true" : "false", "data-tab": t.id, title: (t.rec.path || t.rec.name) + (dirty ? " — unsaved changes" : ""),
      onclick: () => { if (!(on && currentView && currentView.tab === t)) activateTab(t); } },
      icon("file", "dt-ico"), h("span", { class: "dt-name" }, t.rec.name), h("span", { class: "dt-dot", "aria-hidden": "true" }), x);
    b.addEventListener("auxclick", e => { if (e.button === 1) { e.preventDefault(); closeDocTab(t); } });
    tabStrip.append(b);
  }
  tabStrip.append(h("button", { class: "dt-add iconbtn", title: "Open a PDF in a new tab", "aria-label": "Open a PDF in a new tab", onclick: openPicker }, icon("plus")));
  tabStrip.append(titleTools());
  const cur = tabStrip.querySelector(".dt.on");
  if (cur && cur.scrollIntoView) try { cur.scrollIntoView({ block: "nearest", inline: "nearest" }); } catch (e) {}
}

/* ---- v3.5.1 autosave + crash recovery ----
   Every 60 s, and whenever the page is hidden or unloaded, each tab with unsaved edits is
   copied to IndexedDB "atobpdf-recovery". Saving the tab, closing it with "Don't save" or
   undoing back to the saved state removes its entry. On the next launch, entries whose
   session is no longer running (Web Locks; heartbeats where locks are missing) are offered
   back. A session holds the lock "atob-session-<id>" for its lifetime, so a crash frees it. */
const Recovery = (() => {
  const DB = "atobpdf-recovery", EVERY = 60000, BEAT_STALE = 150000;
  let dbP = null, timer = 0, flushing = null;
  const written = new Map();        // tab key -> hist.state last written
  function db() {
    if (!dbP) dbP = new Promise((resolve, reject) => {
      if (!window.indexedDB) return reject(new Error("no idb"));
      const req = indexedDB.open(DB, 1);
      req.onupgradeneeded = () => {
        req.result.createObjectStore("docs", { keyPath: "key" });
        req.result.createObjectStore("beats", { keyPath: "session" });
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
    dbP.catch(() => { dbP = null; });
    return dbP;
  }
  const reqP = r => new Promise((res, rej) => { r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); });
  async function store(name, mode) { return (await db()).transaction(name, mode || "readonly").objectStore(name); }
  async function put(t) {
    const e = { key: t.key, session: SESSION_ID, name: t.rec.name, path: t.rec.path || "", size: t.rec.size,
      buf: t.rec.buf.slice(0), depth: t.hist.depth, at: Date.now() };
    await reqP((await store("docs", "readwrite")).put(e));
  }
  async function del(key) { await reqP((await store("docs", "readwrite")).delete(key)); }
  /* write every changed dirty tab; drop entries of tabs that are clean again */
  async function flush() {
    if (flushing) return flushing;
    flushing = (async () => {
      for (const t of docTabs.slice()) {
        try {
          if (tabDirty(t)) {
            if (written.get(t.key) === t.hist.state) continue;
            await put(t);
            written.set(t.key, t.hist.state);
          } else if (written.has(t.key)) {
            written.delete(t.key);
            await del(t.key);
          }
        } catch (e) { /* storage full / private mode: autosave is best-effort */ }
      }
      beat();
    })();
    try { await flushing; } finally { flushing = null; }
  }
  /* v3.8: write a few seconds after each edit, not only once a minute */
  let soonT = 0;
  function soon() { clearTimeout(soonT); soonT = setTimeout(() => { flush().catch(() => {}); }, 3000); }
  function drop(t) {
    if (!t || !t.key) return;
    written.delete(t.key);
    del(t.key).catch(() => {});
  }
  function beat() { store("beats", "readwrite").then(st => st.put({ session: SESSION_ID, at: Date.now() })).catch(() => {}); }
  async function liveSessions() {
    const live = [];
    if (navigator.locks && navigator.locks.query) {
      try {
        const q = await navigator.locks.query();
        for (const l of (q.held || [])) if (/^atob-session-/.test(l.name)) live.push(l.name.slice(13));
        return live;
      } catch (e) { /* fall through to heartbeats */ }
    }
    try {
      const beats = await reqP((await store("beats")).getAll());
      for (const b of beats || []) if (Date.now() - b.at < BEAT_STALE) live.push(b.session);
    } catch (e) {}
    return live;
  }
  async function pending() {
    const all = await reqP((await store("docs")).getAll());
    return PDCore.recoveryOrphans(all, await liveSessions(), SESSION_ID);
  }
  /* reopen an entry as a tab that is dirty from the start */
  function reopen(e) {
    const rec = { name: e.name, size: e.size, buf: e.buf };
    if (e.path) rec.path = e.path;
    const t = addDocTab(rec);
    t.key = e.key;            // keep autosaving into the same entry
    t.recovered = true;
    t.hist.markUnsaved();
    written.set(t.key, null);
    return t;
  }
  async function offer() {
    let list;
    try { list = await pending(); } catch (e) { return; }
    if (!list.length) return;
    const n = list.length;
    const rows = h("div", { class: "rec-list" });
    let close = null, last = null;
    const left = () => rows.querySelectorAll(".rec-row").length;
    const finish = () => { if (close) close(); if (last) activateTab(last); };
    const rowDone = row => { row.remove(); if (!left()) finish(); };
    for (const e of list) {
      const row = h("div", { class: "rec-row", "data-key": e.key },
        docThumb(),
        h("div", { class: "grow" },
          h("div", { class: "fname", title: e.path || e.name }, e.name),
          h("div", { class: "fmeta" }, PDCore.fmtBytes(e.size) + " · " + relTime(e.at) +
            (e.depth ? " · " + e.depth + (e.depth === 1 ? " change" : " changes") : ""))),
        h("button", { class: "btn secondary sm rec-discard", onclick: () => { del(e.key).catch(() => {}); rowDone(row); } }, "Discard"),
        h("button", { class: "btn primary sm rec-recover", onclick: () => { last = reopen(e); rowDone(row); } }, "Recover"));
      rows.append(row);
    }
    close = showModal({
      title: "AtoB PDF didn't close normally",
      cls: "rec-dlg",
      onCancel: c => c(),        // decide later: entries stay for the next launch
      body: h("div", null,
        h("p", null, "Recover " + n + (n === 1 ? " document" : " documents") + " with unsaved changes? Recovered documents open in tabs, still unsaved."),
        rows),
      actions: [
        { label: "Decide later", onClick: c => { c(); if (last) activateTab(last); } },
        { label: n === 1 ? "Recover" : "Recover all", primary: true, onClick: () => {
          for (const e of list) { const row = rows.querySelector('.rec-row[data-key="' + CSS.escape(e.key) + '"]'); if (row) { last = reopen(e); row.remove(); } }
          finish();
        } },
      ],
    });
  }
  function start() {
    try {
      if (navigator.locks && navigator.locks.request)
        navigator.locks.request("atob-session-" + SESSION_ID, () => new Promise(() => {})).catch(() => {});
    } catch (e) {}
    beat();
    clearInterval(timer);
    timer = setInterval(flush, EVERY);
    document.addEventListener("visibilitychange", () => { if (document.visibilityState === "hidden" && !leavingApp) flush(); });
    window.addEventListener("pagehide", () => { if (!leavingApp) flush(); });
    // tidy heartbeats older than a day
    store("beats", "readwrite").then(async st => {
      for (const b of (await reqP(st.getAll())) || []) if (Date.now() - b.at > 86400000) st.delete(b.session);
    }).catch(() => {});
  }
  return { start, flush, soon, drop, offer, pending, reopen };
})();
window.__atobAutosave = () => { if (!leavingApp) Recovery.flush(); };

/* ---- v3.5.1 Android: Back on Home would send the app to the background, where the
   system may kill it. With unsaved tabs, ask first. Returns true when Back was handled. */
let backPassUntil = 0;
function backFromHome() {
  if (!docTabs.some(tabDirty) || Date.now() < backPassUntil) return false;
  confirmLeave("leave").then(ok => {
    if (!ok) return;
    docTabs.filter(tabDirty).forEach(t => closeDocTab(t, true));   // "Don't save" = discard them
    if (window.AndroidBridge && typeof window.AndroidBridge.leaveApp === "function") {
      try { window.AndroidBridge.leaveApp(); return; } catch (e) {}
    }
    backPassUntil = Date.now() + 4000;
    toast("Press Back again to leave");
  });
  return true;
}

/* ---- v3.6 command registry: the palette, keyboard shortcuts, the shortcuts sheet and the
   Electron menu all come from one list. A command: {id, label, group, keys:["Mod+S"], icon,
   run, enabled(), whyDisabled, keyWhen() (keys only act when true; otherwise the key passes
   through untouched), inFields (works while typing), swallow (always eat the key), quiet
   (disabled = silently ignore), palette:false (hidden from the palette), keywords, sub}. ---- */
const IS_MAC = /Mac|iPhone|iPad/.test(navigator.platform || "");
const isEditable = el => !!el && (el.tagName === "INPUT" || el.tagName === "TEXTAREA" || el.tagName === "SELECT" || el.isContentEditable);
const COMMANDS = [];
const CMD_BY_ID = new Map();
const CMD_GROUP_ORDER = ["Document", "Pages", "Panels", "File", "Edit", "View & edit", "Convert", "Secure & optimize", "Open documents", "Recent files", "App"];
function registerCommand(c) {
  c.group = c.group || "App";
  const old = CMD_BY_ID.get(c.id);
  if (old) { Object.assign(old, c); return old; }
  COMMANDS.push(c);
  CMD_BY_ID.set(c.id, c);
  return c;
}
function cmdEnabled(c) { try { return !c.enabled || !!c.enabled(); } catch (e) { return false; } }
function cmdLabel(c) { return typeof c.label === "function" ? c.label() : c.label; }
function cmdWhy(c) { return (typeof c.whyDisabled === "function" ? c.whyDisabled() : c.whyDisabled) || "Not available right now"; }
function cmdKeys(c) { return (c.keys || []).map(k => PDCore.keysLabel(k, IS_MAC)); }
const CMD_RECENT_KEY = "atob.cmd.recent";
function recentCmdIds() { try { return JSON.parse(localStorage.getItem(CMD_RECENT_KEY) || "[]"); } catch (e) { return []; } }
function rememberCmd(id) {
  if (!id || /^(tab|recent|goto):/.test(id)) return;
  try { localStorage.setItem(CMD_RECENT_KEY, JSON.stringify([id].concat(recentCmdIds().filter(x => x !== id)).slice(0, 6))); } catch (e) {}
}
function runCommand(idOrCmd) {
  const c = typeof idOrCmd === "string" ? CMD_BY_ID.get(idOrCmd) : idOrCmd;
  if (!c) return false;
  if (!cmdEnabled(c)) { if (!c.quiet) toast(cmdWhy(c)); return false; }
  rememberCmd(c.id);
  try { const r = c.run(); if (r && r.catch) r.catch(e => toast(String(e && e.message || e), "err")); }
  catch (e) { toast(String(e && e.message || e), "err"); }
  return true;
}
function commandForKey(e) {
  for (const c of COMMANDS) if (c.keys && c.keys.some(k => PDCore.keysMatch(k, e))) return c;
  return null;
}
/* the tab whose viewer is on screen (null in tools, the reader, Home) */
function viewerTab() { const t = activeTab; return t && currentView && currentView.tab === t && t.api ? t : null; }
const NEED_VIEWER = "Open a PDF in the viewer first";
const NEED_PDF = "Open a PDF first";
function registerCoreCommands() {
  const vt = viewerTab;
  const api = (name, ...args) => { const t = vt(); if (t && t.api[name]) return t.api[name](...args); };
  const hasApi = name => () => { const t = vt(); return !!(t && t.api[name]); };
  [
    { id: "app.palette", label: "Search tools and commands", keys: ["Mod+K"], inFields: true, swallow: true, palette: false, run: () => openPalette() },
    { id: "app.shortcuts", label: "Keyboard shortcuts", icon: "keyboard", keys: ["Mod+/"], inFields: true, swallow: true, keywords: "keys help", run: () => showShortcuts() },
    { id: "file.open", group: "File", label: "Open a PDF…", icon: "folder", keys: ["Mod+O"], inFields: true, swallow: true, run: () => openPicker() },
    { id: "file.save", group: "File", icon: "download", keys: ["Mod+S"], inFields: true, swallow: true,
      label: () => activeTab && activeTab.rec.path ? "Save" : "Save (downloads a copy)",
      enabled: () => !!activeTab, whyDisabled: NEED_PDF,
      run: () => { const t = activeTab; if (tabDirty(t) || !t.rec.path) saveDocTab(t); else toast("No changes to save"); } },
    { id: "file.saveas", group: "File", label: "Save as…", icon: "download", keys: ["Mod+Shift+S"], inFields: true, swallow: true,
      enabled: () => !!activeTab, whyDisabled: NEED_PDF, run: () => saveDocTab(activeTab, true) },
    { id: "file.close", group: "File", label: "Close this tab", icon: "close", enabled: () => !!activeTab, whyDisabled: "No document is open", run: () => closeDocTab(activeTab) },
    { id: "edit.undo", group: "Edit", icon: "undo", keys: ["Mod+Z"], quiet: true,
      label: () => { const t = vt(); return t && t.hist.canUndo ? "Undo " + lcFirstWord(t.hist.undoLabel) : "Undo"; },
      keyWhen: () => !!vt(),
      enabled: () => { const t = vt(); return t ? t.hist.canUndo : !!(currentView && currentView.cmds && currentView.cmds.undo); },
      whyDisabled: "Nothing to undo",
      run: () => { const t = vt(); if (t) t.api.undo(); else currentView.cmds.undo(); } },
    { id: "edit.redo", group: "Edit", icon: "redo", keys: ["Mod+Shift+Z", "Ctrl+Y"], quiet: true,
      label: () => { const t = vt(); return t && t.hist.canRedo ? "Redo " + lcFirstWord(t.hist.redoLabel) : "Redo"; },
      keyWhen: () => !!vt(),
      enabled: () => { const t = vt(); return t ? t.hist.canRedo : !!(currentView && currentView.cmds && currentView.cmds.redo); },
      whyDisabled: "Nothing to redo",
      run: () => { const t = vt(); if (t) t.api.redo(); else currentView.cmds.redo(); } },
    { id: "doc.find", group: "Document", label: "Find in document", icon: "search", keys: ["Mod+F"], inFields: true, keyWhen: () => !!vt(), enabled: hasApi("find"), whyDisabled: NEED_VIEWER, run: () => api("find") },
    { id: "doc.goto", group: "Document", label: "Go to page…", icon: "pages", keywords: "jump page number", enabled: hasApi("gotoPrompt"), whyDisabled: NEED_VIEWER, run: () => api("gotoPrompt") },
    { id: "doc.print", group: "Document", label: "Print", icon: "printer", keys: ["Mod+P"], keyWhen: () => !!vt(), enabled: hasApi("print"), whyDisabled: NEED_VIEWER, run: () => api("print") },
    { id: "doc.props", group: "Document", label: "Document properties…", icon: "info", keys: ["Mod+D"], keywords: "title author metadata fonts security info", keyWhen: () => !!vt(), enabled: hasApi("props"), whyDisabled: NEED_VIEWER, run: () => api("props") },
    { id: "doc.comment", group: "Document", label: "Comment: highlight, notes, shapes, stamps", icon: "comment", keywords: "annotate markup highlight underline strike note draw ink stamp", enabled: hasApi("comment"), whyDisabled: NEED_VIEWER, run: () => api("comment", true) },
    { id: "view.panel.comments", group: "Panels", label: "Show comments", icon: "comment", keywords: "annotations list", enabled: hasApi("setPanel"), whyDisabled: NEED_VIEWER, run: () => api("setPanel", "comments") },
    { id: "view.panel.outline", group: "Panels", label: "Show bookmarks", icon: "bookmark", keywords: "outline contents toc", enabled: hasApi("setPanel"), whyDisabled: NEED_VIEWER, run: () => api("setPanel", "outline") },
    { id: "view.panel.attach", group: "Panels", label: "Show attachments", icon: "paperclip", keywords: "attached files embedded", enabled: hasApi("setPanel"), whyDisabled: NEED_VIEWER, run: () => api("setPanel", "attach") },
    { id: "view.panel.fields", group: "Panels", label: "Show form fields", icon: "forms", keywords: "form fields widgets", enabled: hasApi("setPanel"), whyDisabled: NEED_VIEWER, run: () => api("setPanel", "fields") },
    { id: "view.panel.pages", group: "Panels", label: "Show page thumbnails", icon: "pages", keywords: "pages thumbnails sidebar", enabled: hasApi("setPanel"), whyDisabled: NEED_VIEWER, run: () => api("setPanel", "pages") },
    { id: "view.panel.hide", group: "Panels", label: "Hide the side panel", icon: "sidebar", enabled: () => { const t = vt(); return !!(t && t.api.panel && t.api.panel()); }, whyDisabled: "No panel is open", run: () => api("setPanel", "") },
    { id: "doc.reader", group: "Document", label: "Open in the reader", icon: "book", keywords: "reflow kindle read", enabled: () => !!activeTab, whyDisabled: NEED_PDF, run: () => showView("read") },
    { id: "doc.listen", group: "Document", label: "Read aloud", icon: "headphones", keywords: "audio tts speak", enabled: hasApi("listen"), whyDisabled: NEED_VIEWER, run: () => api("listen") },
    { id: "page.rotcw", group: "Pages", label: "Rotate clockwise", icon: "rotr", sub: "Current or selected pages", enabled: hasApi("rotate"), whyDisabled: NEED_VIEWER, run: () => api("rotate", 90) },
    { id: "page.rotccw", group: "Pages", label: "Rotate counter-clockwise", icon: "rotl", sub: "Current or selected pages", enabled: hasApi("rotate"), whyDisabled: NEED_VIEWER, run: () => api("rotate", -90) },
    { id: "page.rot180", group: "Pages", label: "Rotate 180°", icon: "rot180", enabled: hasApi("rotate"), whyDisabled: NEED_VIEWER, run: () => api("rotate", 180) },
    { id: "page.crop", group: "Pages", label: "Crop pages…", icon: "crop", enabled: hasApi("crop"), whyDisabled: NEED_VIEWER, run: () => api("crop") },
    { id: "page.delete", group: "Pages", label: "Delete pages…", icon: "delpages", keywords: "remove", enabled: () => !!activeTab, whyDisabled: NEED_PDF, run: () => showView("delete") },
    { id: "page.selall", group: "Pages", label: "Select all pages", icon: "selall", enabled: hasApi("selectAll"), whyDisabled: NEED_VIEWER, run: () => api("selectAll") },
    { id: "view.theme.light", label: "Theme: Light", icon: "sun", keywords: "appearance mode", run: () => setTheme("light") },
    { id: "view.theme.dark", label: "Theme: Dark", icon: "moon", keywords: "appearance mode night", run: () => setTheme("dark") },
    { id: "view.theme.system", label: "Theme: Match system", icon: "monitor", keywords: "appearance mode auto", run: () => setTheme("system") },
    { id: "view.theme.toggle", label: () => isDarkNow() ? "Switch to light mode" : "Switch to dark mode", icon: "moon", keywords: "theme dark light toggle", run: () => setTheme(isDarkNow() ? "light" : "dark") },
  ].forEach(registerCommand);
}
function lcFirstWord(s) { return s ? s.charAt(0).toLowerCase() + s.slice(1) : s; }
/* every sidebar tool is a command too (registered at boot, after the tool files ran) */
function registerToolCommands() {
  for (const g of TOOL_GROUPS) for (const id of g.ids) {
    const def = VIEWS[id];
    if (!def || id === "view") continue;
    const needsPdf = def.acceptsPdf !== false && !def.standalone;
    registerCommand({ id: "tool." + id, group: g.name, label: def.name, sub: def.desc, icon: def.icon, keywords: def.desc,
      enabled: () => !needsPdf || !!workspace, whyDisabled: NEED_PDF, run: () => showView(id) });
  }
}
/* the Electron menu's accelerator and the page's keydown can both deliver one shortcut;
   whichever arrives second within 400 ms is dropped */
const MENU_TO_CMD = { undo: "edit.undo", redo: "edit.redo", save: "file.save", saveas: "file.saveas", open: "file.open", props: "doc.props", palette: "app.palette" };
let lastKeyCmd = { cmd: null, at: 0, editable: false };
document.addEventListener("keydown", e => {
  const c = commandForKey(e);
  if (c) lastKeyCmd = { cmd: c.id, at: Date.now(), editable: isEditable(document.activeElement) };
}, true);
document.addEventListener("keydown", e => {
  if (e.defaultPrevented || e.isComposing || paletteEl) return;
  const c = commandForKey(e);
  if (!c) return;
  if (isEditable(document.activeElement) && !c.inFields) return;
  if (c.keyWhen && !c.keyWhen()) return;
  if (document.querySelector(".modal-wrap")) { if (c.swallow) e.preventDefault(); return; }
  if (!cmdEnabled(c) && c.quiet) return;
  e.preventDefault();
  runCommand(c);
});
function onMenuCommand(cmd) {
  const id = MENU_TO_CMD[cmd] || cmd;
  const recent = lastKeyCmd.cmd === id && Date.now() - lastKeyCmd.at < 400;
  if (cmd === "undo" || cmd === "redo") {
    if (recent) { if (lastKeyCmd.editable && IS_MAC) document.execCommand(cmd); return; }
    if (isEditable(document.activeElement)) { document.execCommand(cmd); return; }
  } else if (recent) return;
  if (document.querySelector(".modal-wrap") && cmd !== "open") return;
  runCommand(id);
}
/* kept for older callers */
function appCommand(cmd) { return runCommand(MENU_TO_CMD[cmd] || cmd); }

/* ---- v3.6 ⌘K palette ---- */
let paletteEl = null, paletteClose = null;
function closePalette() { if (paletteClose) paletteClose(); }
function openPalette(initial) {
  if (paletteEl) { closePalette(); return; }
  closeCtxMenu();
  const prevFocus = document.activeElement;
  const input = h("input", { class: "cmdk-input", type: "text", placeholder: "Search tools and commands", "aria-label": "Search tools and commands",
    autocomplete: "off", spellcheck: "false", role: "combobox", "aria-expanded": "true", "aria-controls": "cmdk-list" });
  const list = h("div", { class: "cmdk-list", id: "cmdk-list", role: "listbox" });
  const box = h("div", { class: "cmdk", role: "dialog", "aria-modal": "true", "aria-label": "Command palette" },
    h("div", { class: "cmdk-top" }, icon("search", "cmdk-ico"), input,
      isMobile() ? h("button", { class: "textbtn cmdk-cancel", onclick: () => closePalette() }, "Cancel") : h("kbd", { class: "cmdk-esc" }, "Esc")),
    list,
    isMobile() ? null : h("div", { class: "cmdk-foot" }, h("span", null, h("kbd", null, "↑"), h("kbd", null, "↓"), " move"), h("span", null, h("kbd", null, "Enter"), " run"),
      h("span", { class: "grow" }), h("button", { class: "textbtn", onclick: () => { closePalette(); showShortcuts(); } }, "All shortcuts " + PDCore.keysLabel("Mod+/", IS_MAC))));
  const wrap = h("div", { class: "cmdk-wrap" + (isMobile() ? " full" : "") }, box);
  wrap.addEventListener("pointerdown", e => { if (e.target === wrap) closePalette(); });
  let items = [], sel = 0, recents = [];
  recentsAll().then(l => { recents = l || []; if (paletteEl === wrap) render(); });
  function pool(q) {
    const out = COMMANDS.filter(c => c.palette !== false);
    for (const t of docTabs) out.push({ id: "tab:" + t.id, group: "Open documents", icon: "file", label: "Switch to " + t.rec.name, sub: (tabDirty(t) ? "Unsaved changes · " : "") + PDCore.fmtBytes(t.rec.size), run: () => activateTab(t), enabled: () => activeTab !== t || !(currentView && currentView.tab === t), whyDisabled: "Already open" });
    for (const r of recents) if (!docTabs.some(t => t.rec.name === r.name && t.rec.size === r.size))
      out.push({ id: "recent:" + r.name, group: "Recent files", icon: "file", label: "Open " + r.name, sub: PDCore.fmtBytes(r.size) + " · " + relTime(r.at), run: () => openDocTab({ name: r.name, size: r.size, buf: r.buf }) });
    const num = /^(?:go\s*to\s*|page\s*|p\.?\s*)?(\d{1,5})$/i.exec(q || "");
    const t = viewerTab();
    if (num && t && t.api.gotoPage) out.unshift({ id: "goto:" + num[1], group: "Document", icon: "pages", label: "Go to page " + num[1], run: () => t.api.gotoPage(+num[1] - 1) });
    return out;
  }
  function render() {
    const q = input.value.trim();
    const all = pool(q);
    let rows;
    if (q) {
      rows = all.map(c => ({ c, s: PDCore.fuzzyScore(q, cmdLabel(c) + " · " + (c.keywords || "") + " " + (c.sub || "") + " " + c.group) }))
        .filter(x => x.s != null)
        .map(x => ({ c: x.c, s: x.s + (cmdEnabled(x.c) ? 3 : 0) + (/^goto:/.test(x.c.id) ? 50 : 0) + (PDCore.fuzzyScore(q, cmdLabel(x.c)) != null ? 4 : 0) }))
        .sort((a, b) => b.s - a.s).slice(0, 60).map(x => x.c);
    } else {
      const rec = recentCmdIds().map(id => CMD_BY_ID.get(id)).filter(Boolean);
      const rest = all.filter(c => !rec.includes(c)).sort((a, b) => {
        const ga = CMD_GROUP_ORDER.indexOf(a.group), gb = CMD_GROUP_ORDER.indexOf(b.group);
        return (ga < 0 ? 99 : ga) - (gb < 0 ? 99 : gb);
      });
      rows = rec.map(c => Object.assign(Object.create(c), { _recent: true })).concat(rest);
    }
    items = rows;
    sel = Math.max(0, Math.min(sel, items.length - 1));
    list.innerHTML = "";
    if (!items.length) { list.append(h("div", { class: "cmdk-empty" }, "Nothing matches “" + q + "”.")); return; }
    let lastGroup = null;
    items.forEach((c, i) => {
      const g = c._recent ? "Recently used" : c.group;
      if (!q && g !== lastGroup) { list.append(h("div", { class: "cmdk-group" }, g)); lastGroup = g; }
      const on = cmdEnabled(c);
      const keys = cmdKeys(c);
      const row = h("div", { class: "cmdk-row" + (i === sel ? " sel" : "") + (on ? "" : " off"), role: "option", id: "cmdk-o" + i, "aria-selected": i === sel ? "true" : "false", "aria-disabled": on ? "false" : "true", "data-id": c.id },
        h("span", { class: "cmdk-ricon" }, icon(c.icon || "chevron")),
        h("span", { class: "cmdk-text" }, h("span", { class: "cmdk-label" }, cmdLabel(c)),
          on ? (c.sub ? h("span", { class: "cmdk-sub" }, c.sub) : null) : h("span", { class: "cmdk-sub why" }, cmdWhy(c))),
        q ? h("span", { class: "cmdk-tag" }, c.group) : null,
        keys.length ? h("span", { class: "cmdk-keys" }, keys.slice(0, 1).map(k => h("kbd", null, k))) : null);
      row.addEventListener("pointermove", () => { if (sel !== i) { sel = i; paintSel(); } });
      row.addEventListener("click", () => { sel = i; pick(); });
      list.append(row);
    });
    paintSel(true);
  }
  function paintSel(noScroll) {
    list.querySelectorAll(".cmdk-row").forEach((r, i) => { r.classList.toggle("sel", i === sel); r.setAttribute("aria-selected", i === sel ? "true" : "false"); });
    input.setAttribute("aria-activedescendant", "cmdk-o" + sel);
    const r = list.querySelector("#cmdk-o" + sel);
    if (r && !noScroll) r.scrollIntoView({ block: "nearest" });
    else if (r && noScroll && sel === 0) list.scrollTop = 0;
  }
  function pick() {
    const c = items[sel];
    if (!c) return;
    if (!cmdEnabled(c)) { toast(cmdWhy(c)); return; }
    close(false);
    runCommand(c);
  }
  input.addEventListener("input", () => { sel = 0; render(); });
  input.addEventListener("keydown", e => {
    e.stopPropagation();
    if (e.key === "ArrowDown") { e.preventDefault(); sel = Math.min(items.length - 1, sel + 1); paintSel(); }
    else if (e.key === "ArrowUp") { e.preventDefault(); sel = Math.max(0, sel - 1); paintSel(); }
    else if (e.key === "PageDown") { e.preventDefault(); sel = Math.min(items.length - 1, sel + 8); paintSel(); }
    else if (e.key === "PageUp") { e.preventDefault(); sel = Math.max(0, sel - 8); paintSel(); }
    else if (e.key === "Enter") { e.preventDefault(); pick(); }
    else if (e.key === "Escape" || PDCore.keysMatch("Mod+K", e)) { e.preventDefault(); close(true); }
    else if (e.key === "Tab") e.preventDefault();
  });
  function close(restore) {
    if (paletteEl !== wrap) return;
    wrap.remove();
    paletteEl = paletteClose = null;
    if (restore && prevFocus && prevFocus.focus && prevFocus.isConnected) try { prevFocus.focus({ preventScroll: true }); } catch (e) {}
  }
  paletteEl = wrap;
  paletteClose = () => close(true);
  document.body.append(wrap);
  if (initial) input.value = initial;
  render();
  setTimeout(() => input.focus(), 0);
  return wrap;
}
function showShortcuts() {
  const groups = new Map();
  for (const c of COMMANDS) if (c.keys && c.keys.length) {
    if (!groups.has(c.group)) groups.set(c.group, []);
    groups.get(c.group).push(c);
  }
  const extra = [["Next / previous match", "Enter / Shift+Enter"], ["Select several pages", (IS_MAC ? "⌘" : "Ctrl") + "-click, Shift-click"], ["Select all pages (thumbnails)", PDCore.keysLabel("Mod+A", IS_MAC)]];
  const body = h("div", { class: "kbd-sheet" },
    Array.from(groups.entries()).sort((a, b) => CMD_GROUP_ORDER.indexOf(a[0]) - CMD_GROUP_ORDER.indexOf(b[0])).map(([g, cs]) => h("div", { class: "kbd-grp" },
      h("div", { class: "kbd-h" }, g),
      cs.map(c => h("div", { class: "kbd-row" }, h("span", null, typeof c.label === "function" ? (c.id === "edit.undo" ? "Undo" : c.id === "edit.redo" ? "Redo" : c.id === "file.save" ? "Save" : cmdLabel(c)) : c.label),
        h("span", { class: "kbd-keys" }, cmdKeys(c).map(k => h("kbd", null, k))))))),
    h("div", { class: "kbd-grp" }, h("div", { class: "kbd-h" }, "In the viewer"),
      extra.map(([a, b]) => h("div", { class: "kbd-row" }, h("span", null, a), h("span", { class: "kbd-keys" }, h("kbd", null, b))))));
  showModal({ title: "Keyboard shortcuts", body, cls: "kbd-dlg", actions: [{ label: "Close", primary: true, onClick: c => c() }] });
}

/* ---- v3.6 theme: Light / Dark / Match system (the page itself is never inverted) ---- */
const THEME_KEY = "atob.theme";
const DARK_MQ = window.matchMedia ? window.matchMedia("(prefers-color-scheme: dark)") : { matches: false };
function themePref() { try { const v = localStorage.getItem(THEME_KEY); return v === "light" || v === "dark" ? v : "system"; } catch (e) { return "system"; } }
function isDarkNow() { const p = themePref(); return p === "dark" || (p === "system" && !!DARK_MQ.matches); }
const themeButtons = new Set();
function applyTheme() {
  const p = themePref(), r = document.documentElement;
  if (p === "system") r.removeAttribute("data-theme"); else r.setAttribute("data-theme", p);
  const dark = isDarkNow();
  r.classList.toggle("is-dark", dark);
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute("content", dark ? "#1d1b19" : "#f7f5f1");
  if (themeButtons.size > 12) themeButtons.forEach(b => { if (!b.isConnected) themeButtons.delete(b); });
  themeButtons.forEach(b => {
    b.innerHTML = "";
    b.append(icon(p === "system" ? "monitor" : dark ? "moon" : "sun"));
    b.title = "Theme: " + (p === "system" ? "match system (" + (dark ? "dark" : "light") + ")" : p);
  });
}
function setTheme(p) {
  try { if (p === "system") localStorage.removeItem(THEME_KEY); else localStorage.setItem(THEME_KEY, p); } catch (e) {}
  applyTheme();
}
function themeButton(cls) {
  const b = h("button", { class: "iconbtn theme-btn" + (cls ? " " + cls : ""), "aria-label": "Theme", onclick: e => {
    const r = b.getBoundingClientRect(), p = themePref();
    showCtxMenu(r.left, r.bottom + 4, [{ head: "Theme" },
      { label: "Light", icon: p === "light" ? "check" : "sun", onClick: () => setTheme("light") },
      { label: "Dark", icon: p === "dark" ? "check" : "moon", onClick: () => setTheme("dark") },
      { label: "Match system", icon: p === "system" ? "check" : "monitor", onClick: () => setTheme("system") }]);
  } });
  themeButtons.add(b);
  applyTheme();
  return b;
}
applyTheme();
if (DARK_MQ.addEventListener) DARK_MQ.addEventListener("change", applyTheme);

/* v3.6 right end of the title bar: ⌘K search + theme */
let titleToolsEl = null;
function titleTools() {
  if (!titleToolsEl) titleToolsEl = h("div", { class: "dt-tools" },
    h("button", { class: "dt-search", title: "Search tools and commands (" + PDCore.keysLabel("Mod+K", IS_MAC) + ")", onclick: () => openPalette() },
      icon("search"), h("span", { class: "dt-search-l" }, "Search tools & commands"), h("kbd", null, PDCore.keysLabel("Mod+K", IS_MAC))),
    themeButton());
  return titleToolsEl;
}

/* ---- right-click / long-press context menu ---- */
let ctxMenuEl = null;
function closeCtxMenu() {
  if (!ctxMenuEl) return;
  ctxMenuEl.remove();
  ctxMenuEl = null;
  window.removeEventListener("pointerdown", ctxOutside, true);
  window.removeEventListener("keydown", ctxKey, true);
  window.removeEventListener("resize", closeCtxMenu);
  window.removeEventListener("blur", closeCtxMenu);
  window.removeEventListener("wheel", ctxWheel, true);
}
function ctxWheel(e) { if (ctxMenuEl && !ctxMenuEl.contains(e.target)) closeCtxMenu(); }
function ctxOutside(e) { if (ctxMenuEl && !ctxMenuEl.contains(e.target)) closeCtxMenu(); }
function ctxKey(e) {
  if (!ctxMenuEl) return;
  const items = Array.from(ctxMenuEl.querySelectorAll(".cm-item:not(:disabled)"));
  const i = items.indexOf(document.activeElement);
  if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); closeCtxMenu(); }
  else if (e.key === "ArrowDown") { e.preventDefault(); (items[i + 1] || items[0]).focus(); }
  else if (e.key === "ArrowUp") { e.preventDefault(); (items[i - 1] || items[items.length - 1]).focus(); }
}
/* items: [{label, icon, kbd, onClick, disabled} | "-" | {head}] */
function showCtxMenu(x, y, items) {
  closeCtxMenu();
  const menu = h("div", { class: "ctxmenu", role: "menu" });
  for (const it of items) {
    if (!it) continue;
    if (it === "-") { menu.append(h("div", { class: "cm-sep", role: "separator" })); continue; }
    if (it.head) { menu.append(h("div", { class: "cm-head" }, it.head)); continue; }
    const b = h("button", { class: "cm-item", role: "menuitem", onclick: () => { closeCtxMenu(); it.onClick && it.onClick(); } },
      h("span", { class: "cm-ico" }, it.icon ? icon(it.icon) : null),
      h("span", { class: "cm-label" }, it.label),
      it.kbd ? h("span", { class: "cm-kbd" }, it.kbd) : null);
    if (it.disabled) b.disabled = true;
    menu.append(b);
  }
  document.body.append(menu);
  const r = menu.getBoundingClientRect();
  const left = Math.max(6, Math.min(x, window.innerWidth - r.width - 6));
  const top = y + r.height > window.innerHeight - 6 ? Math.max(6, y - r.height) : y;
  menu.style.left = left + "px";
  menu.style.top = top + "px";
  ctxMenuEl = menu;
  setTimeout(() => {
    if (ctxMenuEl !== menu) return;
    window.addEventListener("pointerdown", ctxOutside, true);
    window.addEventListener("keydown", ctxKey, true);
    window.addEventListener("resize", closeCtxMenu);
    window.addEventListener("blur", closeCtxMenu);
    window.addEventListener("wheel", ctxWheel, { capture: true, passive: true });
  }, 0);
  const first = menu.querySelector(".cm-item:not(:disabled)");
  if (first) first.focus({ preventScroll: true });
  return menu;
}

const pickerInput = h("input", { type: "file", accept: "application/pdf,.pdf", multiple: "", style: "display:none" });
pickerInput.addEventListener("change", async () => {
  const files = Array.from(pickerInput.files || []);
  pickerInput.value = "";
  if (!files.length) return;
  const pdfs = files.filter(isPdfFile);
  if (!pdfs.length) { toast("That doesn't look like a PDF", "err"); return; }
  await openFilesInTabs(pdfs);
});
async function openFilesInTabs(files) {
  let last = null;
  for (const f of files) {
    if (f.size > BIG_WARN) toast(f.name + " is large. Processing may take a while.");
    const rec = f.buf ? f : await readFileRec(f);
    last = findOpenTab(rec) || addDocTab(rec);
  }
  if (last) activateTab(last);
  if (files.length > 1) toast("Opened " + files.length + " PDFs in tabs");
}
function openPicker() { pickerInput.click(); }

/* ---- sidebar ---- */
function buildSidebar() {
  sideFileBox = h("div");
  sideNav = h("nav", { class: "side-nav" });
  for (const g of TOOL_GROUPS) {
    sideNav.append(h("div", { class: "side-group" }, g.name));
    for (const tid of g.ids) {
      const t = VIEWS[tid];
      if (!t) continue;
      const b = h("button", { class: "side-item", "data-tool": tid, title: t.name + " — " + t.desc },
        h("span", { class: "si-ico" }, icon(t.icon)), h("span", { class: "label" }, t.name));
      b.addEventListener("click", () => { if (!b.disabled) showView(tid); });
      sideNav.append(b);
    }
  }
  const aside = h("aside", { class: "side" },
    h("div", { class: "side-brand" },
      h("span", { class: "brand-mark" }, icon("logo")),
      h("span", { class: "brand-name" }, "AtoB PDF")),
    sideFileBox, sideNav,
    h("div", { class: "side-foot" },
      h("div", { class: "offline-badge" }, h("span", { class: "dot" }), h("span", null, "Offline · files stay here")),
      h("div", { class: "links" },
        h("button", { onclick: runSelfTestUI }, "Self-test"),
        h("button", { onclick: showAbout }, "About"),
        h("span", null, "v" + APP_VERSION))));
  renderSideFile();
  refreshNavDisabled();
  return aside;
}
function renderSideFile() {
  if (!sideFileBox) return;
  sideFileBox.innerHTML = "";
  if (workspace) {
    sideFileBox.append(h("div", { class: "side-file" },
      h("div", { class: "fname", title: workspace.name }, workspace.name),
      h("div", { class: "fmeta" }, PDCore.fmtBytes(workspace.size)),
      h("button", { class: "btn secondary", onclick: openPicker }, "Open another PDF")));
    if (tabDirty(activeTab)) sideFileBox.lastChild.insertBefore(h("div", { class: "fdirty" }, "Unsaved changes"), sideFileBox.lastChild.lastChild);
  } else {
    sideFileBox.append(h("div", { class: "side-file empty", onclick: openPicker }, "Open a PDF to begin"));
  }
}
function refreshNavDisabled() {
  if (!sideNav) return;
  sideNav.querySelectorAll(".side-item").forEach(b => {
    const t = VIEWS[b.dataset.tool];
    const needsPdf = !t || t.acceptsPdf !== false;
    b.disabled = needsPdf && !workspace && !t.standalone;
  });
}
function markActive(id) {
  if (sideNav) sideNav.querySelectorAll(".side-item").forEach(b => b.classList.toggle("on", b.dataset.tool === id));
  document.querySelectorAll(".tabbar .tab").forEach(b => b.classList.toggle("on", b.dataset.tab === id || (b.dataset.tab === "file" && id === "view")));
}

/* ---- desktop Home tab ---- */
/* v3.8: what the app can do, on Home (desktop welcome + phone home) */
const FEATURE_GUIDE = [
  { title: "Work on one document, all tools", icon: "pages", items: [
    "Open a PDF once — Edit, Sign, Watermark, Page numbers, OCR, Compress and the rest all work on the same document, with every earlier change included",
    "Tools sit on the right of the document (Tools panel), and a tool bar at the top of each tool switches between them",
    "Edits made in the editor stay movable: come back to Edit later and your text boxes, images and signatures are still there to move, resize or delete",
    "Several PDFs open at once, each in its own tab" ] },
  { title: "Never lose work", icon: "history", items: [
    "Undo / redo every step from any tool (" + (/Mac|iPhone|iPad/.test(navigator.platform || "") ? "⌘Z / ⇧⌘Z" : "Ctrl+Z / Ctrl+Y") + ")",
    "Edit history panel: click any step to go back to it",
    "Compare with original: before and after, side by side",
    "Autosave a few seconds after each change; after a crash or closed app, AtoB offers to bring the document back",
    "The original file is never touched until you choose Save — or use Save as copy" ] },
  { title: "Edit & sign", icon: "edit", items: [
    "Retype existing text, add text, whiteout, redact for real, insert or remove images",
    "Highlights, boxes, ovals, arrows, sticky notes, stamps (Approved, Paid, Received, Draft)",
    "Signatures and initials: draw, type or upload once, reuse from your saved library",
    "Put a signature or initials on every page in one click, with an optional date",
    "Fill in PDF forms" ] },
  { title: "Pages", icon: "organize", items: ["Merge, split, extract, delete, reorder, rotate, crop", "Page numbers and watermarks", "Bookmarks, attachments and form fields panels"] },
  { title: "Convert", icon: "toword", items: ["PDF to Word, Excel (tables), text, images", "Word, text and images to PDF", "OCR in English, Arabic, Urdu, Hindi, Malayalam and Tamil"] },
  { title: "Secure & optimize", icon: "lock", items: ["Password-protect or unlock", "Compress", "Flatten comments and forms", "Repair damaged PDFs"] },
  { title: "Read & listen", icon: "headphones", items: ["Kindle-style reader with themes, bookmarks, highlights and notes", "Read aloud in several languages", "Search (Ctrl/⌘+F), print, and a command search (Ctrl/⌘+K) for every tool"] },
];
function featureGuide(compact) {
  const box = h("div", { class: "fguide" + (compact ? " compact" : "") });
  for (const g of FEATURE_GUIDE) {
    box.append(h("details", { class: "fg-card", open: compact ? null : "" },
      h("summary", null, h("span", { class: "fg-ico" }, icon(ICONS[g.icon] ? g.icon : "file")), h("span", { class: "fg-title" }, g.title)),
      h("ul", null, g.items.map(t => h("li", null, t)))));
  }
  return h("div", { class: "fg-wrap" }, h("div", { class: "dh-sec mh-sec" }, "What AtoB PDF can do"), box);
}
function buildWelcome(root) {
  const drop = makeDrop({ multiple: true, big: "Drop PDFs here", sub: "or click to browse. Each file opens in its own tab — nothing leaves this device.", onFiles: recs => openFilesInTabs(recs) });
  const page = h("div", { class: "welcome dhome" },
    h("h1", null, docTabs.length ? "Home" : "Open a PDF to get started"),
    h("p", null, "View, edit, organize, compress, protect and OCR — entirely offline. Open several PDFs and switch between them with the tabs above."),
    drop,
    h("div", { class: "alt" }, "No PDF yet? ", h("button", { onclick: () => showView("img2pdf") }, "Build one from images")),
    defaultAppHint());
  if (docTabs.length) {
    page.append(h("div", { class: "dh-sec" }, "Open now"),
      h("div", { class: "dh-list" }, docTabs.map(t => h("button", { class: "dh-row", onclick: () => activateTab(t) },
        docThumb(),
        h("span", { class: "grow" }, h("span", { class: "fname" }, t.rec.name),
          h("span", { class: "fmeta" }, PDCore.fmtBytes(t.rec.size) + (tabDirty(t) ? " · unsaved changes" : ""))),
        h("span", { class: "dh-go" }, "Switch to tab")))));
  }
  const recBox = h("div", { class: "dh-list" });
  const recSec = h("div", { class: "dh-sec hidden" }, "Recent");
  page.append(recSec, recBox);
  recentsAll().then(list => {
    if (!list.length || !recBox.isConnected) return;
    recSec.classList.remove("hidden");
    for (const r of list) {
      recBox.append(h("button", { class: "dh-row", onclick: () => openDocTab({ name: r.name, size: r.size, buf: r.buf }) },
        docThumb(),
        h("span", { class: "grow" }, h("span", { class: "fname" }, r.name), h("span", { class: "fmeta" }, PDCore.fmtBytes(r.size) + " · " + relTime(r.at))),
        h("span", { class: "dh-go" }, "Open")));
    }
  });
  page.append(featureGuide(false));
  root.append(page);
}

/* v3.5.1 Windows app: Windows lets only the user pick the default PDF app, so offer the way there */
function defaultAppHint() {
  const api = window.pdeskAPI;
  if (!api || api.platform !== "win32" || typeof api.openDefaultApps !== "function") return null;
  const go = async () => {
    const r = await api.openDefaultApps();
    if (r && r.ok) toast("In Settings, set .pdf to AtoB PDF. Then double-clicking a PDF opens it here.", null, 9000);
    else toast("Open Settings > Apps > Default apps, find .pdf and choose AtoB PDF", null, 9000);
  };
  return h("div", { class: "alt dh-default" }, "Want PDFs to open here when you double-click them? ",
    h("button", { onclick: go }, "Make AtoB PDF your PDF app"));
}

/* ---- phone shell: home, tools index, tab bar ---- */
const QUICK_TOOLS = ["read", "sign", "merge", "compress"];
function docThumb() {
  return h("span", { class: "docthumb", "aria-hidden": "true" },
    h("i", { style: "width:70%;background:var(--line-strong)" }), h("i"), h("i"), h("i", { style: "width:55%" }));
}
function greeting() {
  const hr = new Date().getHours();
  return hr < 5 ? "Working late." : hr < 12 ? "Good morning." : hr < 17 ? "Good afternoon." : "Good evening.";
}
function toolTile(tid, cls) {
  const t = VIEWS[tid];
  if (!t) return null;
  return h("button", { class: cls || "ttile", "data-tool": tid, onclick: () => showView(tid) },
    h("span", { class: "tt-ico" }, icon(t.icon)),
    h("span", { class: "tt-name" }, t.name));
}
function buildHome(root) {
  const hasFile = docTabs.length > 0;
  const page = h("div", { class: "mhome" });
  page.append(
    h("div", { class: "mh-top" },
      h("div", { class: "brand" }, h("span", { class: "brand-mark" }, icon("logo")), h("span", { class: "brand-name" }, "AtoB PDF")),
      h("div", { class: "mh-topr" }, h("div", { class: "offline-badge pill" }, h("span", { class: "dot" }), h("span", null, "Offline · on-device")), themeButton("mh-theme"))),
    h("button", { class: "mh-search", onclick: () => openPalette(), "aria-label": "Search tools and commands" }, icon("search"), h("span", null, "Search tools and commands")),
    h("h1", { class: "mh-title" }, greeting(), h("br"), hasFile ? "Keep working, or start fresh." : "What are we fixing today?"));

  for (const t of docTabs) {
    page.append(h("div", { class: "mh-current" },
      docThumb(),
      h("div", { class: "grow" },
        h("div", { class: "mh-label" }, t === activeTab ? "Working on" : "Also open"),
        h("div", { class: "fname" }, t.rec.name),
        h("div", { class: "fmeta" }, PDCore.fmtBytes(t.rec.size) + (tabDirty(t) ? " · unsaved" : ""))),
      h("button", { class: "iconbtn", title: "Close", "aria-label": "Close " + t.rec.name, onclick: () => closeDocTab(t) }, icon("close")),
      h("button", { class: "btn primary sm", onclick: () => activateTab(t) }, "Open")));
  }

  page.append(h("div", { class: "mh-cards" },
    h("button", { class: "mh-card primary", onclick: openPicker },
      icon("folder"),
      h("span", { class: "grow" }),
      h("span", { class: "c-title" }, hasFile ? "Open another PDF" : "Open a PDF"),
      h("span", { class: "c-sub" }, "From this phone's files")),
    h("button", { class: "mh-card", onclick: () => showView("tools") },
      icon("grid"),
      h("span", { class: "grow" }),
      h("span", { class: "c-title" }, "All tools"),
      h("span", { class: "c-sub" }, Object.keys(VIEWS).length + " tools · " + TOOL_GROUPS.length + " groups"))));

  page.append(h("div", { class: "mh-sec" }, "Quick tools"),
    h("div", { class: "mh-quick" }, QUICK_TOOLS.map(id => toolTile(id, "qtile"))));

  const recBox = h("div", { class: "mh-recent" }, h("div", { class: "mh-empty" }, "Files you open will show up here."));
  page.append(h("div", { class: "mh-sec row" }, h("span", null, "Recent"), h("button", { class: "textbtn", onclick: openPicker }, "Browse files")), recBox);
  recentsAll().then(list => {
    if (!list.length || (currentView && currentView.id !== "mhome")) return;
    recBox.innerHTML = "";
    for (const r of list) {
      const row = h("button", { class: "mh-row", onclick: () => { openDocTab({ name: r.name, size: r.size, buf: r.buf }); } },
        docThumb(),
        h("span", { class: "grow" },
          h("span", { class: "fname" }, r.name),
          h("span", { class: "fmeta" }, PDCore.fmtBytes(r.size) + " · " + relTime(r.at))),
        icon("chevron", "chev"));
      recBox.append(row);
    }
  });
  page.append(featureGuide(true));
  root.append(page);
}

function buildToolsIndex(root) {
  const page = h("div", { class: "mtools" });
  const q = h("input", { type: "search", placeholder: "Search " + Object.keys(VIEWS).length + " tools", "aria-label": "Search tools", autocomplete: "off" });
  const groupsEl = h("div", { class: "mt-groups" });
  const render = () => {
    const needle = q.value.trim().toLowerCase();
    groupsEl.innerHTML = "";
    let shown = 0;
    for (const g of TOOL_GROUPS) {
      const ids = g.ids.filter(id => VIEWS[id] && (!needle || (VIEWS[id].name + " " + VIEWS[id].desc).toLowerCase().includes(needle)));
      if (!ids.length) continue;
      shown += ids.length;
      groupsEl.append(h("div", { class: "mt-group" },
        h("div", { class: "mh-sec" }, g.name),
        h("div", { class: "mt-grid" }, ids.map(id => toolTile(id)))));
    }
    if (!shown) groupsEl.append(h("div", { class: "mh-empty" }, "No tool matches “" + q.value.trim() + "”."));
  };
  q.addEventListener("input", render);
  page.append(
    h("div", { class: "mt-head" },
      h("h1", { class: "mh-title sm" }, "All tools"),
      workspace ? h("div", { class: "mt-file" }, "Working on ", h("b", null, workspace.name)) : h("div", { class: "mt-file" }, "Tools ask for a file when they need one")),
    h("label", { class: "mt-search" }, icon("search"), q),
    groupsEl);
  render();
  root.append(page);
}

function buildTabBar() {
  const tab = (id, ic, label, onclick) => h("button", { class: "tab", "data-tab": id, onclick }, icon(ic), h("span", null, label));
  const bar = h("nav", { class: "tabbar", "aria-label": "Main" },
    tab("mhome", "home", "Home", () => showView("home")),
    tab("tools", "grid", "Tools", () => showView("tools")),
    tab("file", "file", "File", () => { const t = activeTab || docTabs[docTabs.length - 1]; if (t) activateTab(t); else openPicker(); }));
  return bar;
}

function showAbout() {
  showModal({
    title: "AtoB PDF",
    body: h("div", { class: "licenses" },
      h("p", null, "A fully offline PDF workbench. This one file contains the whole app. Your documents are processed in this browser window and never leave your device."),
      h("p", null, h("b", null, "Share it:"), " send this HTML file to anyone. It works on Windows, macOS and Linux in Chrome, Edge, Firefox or Safari."),
      h("p", null, h("b", null, "Open-source engines inside:")),
      h("p", null, h("b", null, "PDF.js"), " (Mozilla, Apache-2.0) renders pages. ", h("b", null, "pdf-lib"), " (MIT) writes and restructures PDFs. ", h("b", null, "MuPDF"), " (Artifex, AGPL-3.0) powers editing, protect, unlock and repair. ", h("b", null, "Tesseract"), " (Apache-2.0) powers OCR. UI and everything else written for AtoB PDF.")),
    actions: [{ label: "Close", primary: true, onClick: c => c() }],
  });
}

/* ---- global drop: opens/replaces the workspace file ---- */
function setupGlobalDrop() {
  const overlay = h("div", { class: "drag-overlay" }, h("div", { class: "frame" }), h("div", { class: "msg" }, "Drop to open in AtoB PDF"));
  document.body.append(overlay);
  let depth = 0;
  window.addEventListener("dragenter", e => {
    if (!e.dataTransfer || !Array.from(e.dataTransfer.types).includes("Files")) return;
    if (e.target && e.target.closest && e.target.closest(".drop")) return;
    depth++;
    overlay.classList.add("on");
  });
  window.addEventListener("dragleave", () => { depth = Math.max(0, depth - 1); if (!depth) overlay.classList.remove("on"); });
  window.addEventListener("dragover", e => { if (overlay.classList.contains("on")) e.preventDefault(); });
  window.addEventListener("drop", async e => {
    if (!overlay.classList.contains("on")) return;
    e.preventDefault();
    depth = 0;
    overlay.classList.remove("on");
    const pdfs = Array.from(e.dataTransfer.files).filter(isPdfFile);
    if (!pdfs.length) { toast("That doesn't look like a PDF", "err"); return; }
    const recs = [];
    for (const f of pdfs) recs.push(await readFileRec(f));
    if (recs.length === 1) {
      setWorkspaceFile(recs[0]);
      toast("Opened " + recs[0].name);
      return;
    }
    showModal({
      title: recs.length + " PDFs dropped",
      body: h("p", null, "Open each one in its own tab, or merge them into one document?"),
      actions: [
        { label: "Merge all " + recs.length, onClick: c => { c(); showView("merge", recs); } },
        { label: "Open in " + recs.length + " tabs", primary: true, onClick: c => { c(); openFilesInTabs(recs); } },
      ],
    });
  });
}

/* ---------------- error surface ---------------- */
window.addEventListener("unhandledrejection", e => {
  const m = String(e.reason && e.reason.message || e.reason || "Unexpected error");
  // cancelled password prompt / document closed mid-load (pdf.js internals). Our own
  // "wrong password" errors must still surface, so don't match the bare word.
  if (/onPassword callback|^Worker was destroyed/.test(m) || (e.reason && e.reason.name === "PasswordException")) return;
  toast(m, "err");
});

/* ---------------- self test ---------------- */
async function runSelfTest() {
  const results = [];
  const t = async (name, fn) => {
    try { await fn(); results.push({ name, ok: true }); }
    catch (e) { results.push({ name, ok: false, err: String(e && e.message || e) }); }
  };
  const { PDFDocument, StandardFonts, rgb } = PDFLib;

  async function samplePdf(pages, big) {
    const d = await PDFDocument.create();
    const font = await d.embedFont(StandardFonts.Helvetica);
    for (let i = 0; i < pages; i++) {
      const p = d.addPage([595.28, 841.89]);
      p.drawText("Sample page " + (i + 1), { x: 60, y: 760, size: 28, font, color: rgb(0.15, 0.15, 0.2) });
      if (big) for (let k = 0; k < 40; k++)
        p.drawText("Lorem ipsum dolor sit amet " + k, { x: 60, y: 700 - k * 16, size: 11, font });
    }
    return await d.save();
  }

  let s5, s3;
  await t("pdf-lib creates documents", async () => {
    s5 = await samplePdf(5); s3 = await samplePdf(3);
    if (s5.length < 500) throw new Error("too small");
  });
  await t("merge 5+3 pages", async () => {
    const out = await PDCore.mergePdfs([s5, s3], [null, null]);
    const d = await PDFDocument.load(out);
    if (d.getPageCount() !== 8) throw new Error("got " + d.getPageCount());
  });
  await t("merge with ranges", async () => {
    const out = await PDCore.mergePdfs([s5, s3], ["1-2", "3"]);
    const d = await PDFDocument.load(out);
    if (d.getPageCount() !== 3) throw new Error("got " + d.getPageCount());
  });
  await t("split into groups", async () => {
    const groups = PDCore.parseRangeGroups("1-2,3-5", 5);
    const outs = await PDCore.splitPdf(s5, groups);
    if (outs.length !== 2) throw new Error("files " + outs.length);
    const d = await PDFDocument.load(outs[1]);
    if (d.getPageCount() !== 3) throw new Error("pages " + d.getPageCount());
  });
  await t("extract pages", async () => {
    const out = await PDCore.extractPages(s5, [0, 2, 4]);
    const d = await PDFDocument.load(out);
    if (d.getPageCount() !== 3) throw new Error("got " + d.getPageCount());
  });
  await t("rotate pages", async () => {
    const out = await PDCore.rotatePdf(s5, [0, 1], 90);
    const d = await PDFDocument.load(out);
    if (d.getPage(0).getRotation().angle % 360 !== 90) throw new Error("rot " + d.getPage(0).getRotation().angle);
    if (d.getPage(2).getRotation().angle % 360 !== 0) throw new Error("page3 rotated");
  });
  await t("organize reorder+delete", async () => {
    const out = await PDCore.organizePdf(s5, [{ srcIdx: 4 }, { srcIdx: 0, rotDelta: 180 }]);
    const d = await PDFDocument.load(out);
    if (d.getPageCount() !== 2) throw new Error("count");
    if (d.getPage(1).getRotation().angle % 360 !== 180) throw new Error("rot");
  });
  await t("page numbers", async () => {
    const out = await PDCore.addPageNumbers(s3, { pos: "bc", format: "pnt", size: 11, margin: "md" });
    if (out.length <= s3.length * 0.5) throw new Error("suspicious size");
    await PDFDocument.load(out);
  });
  await t("text watermark (tiled)", async () => {
    const out = await PDCore.addTextWatermark(s3, { text: "CONFIDENTIAL", tile: true, size: 48, opacity: 0.2, angle: -45 });
    await PDFDocument.load(out);
  });
  await t("range parser edge cases", async () => {
    const g = PDCore.parseRangeGroups("3-1, 5, 4-", 5);
    if (JSON.stringify(g) !== JSON.stringify([[2, 1, 0], [4], [3, 4]])) throw new Error(JSON.stringify(g));
    let threw = false;
    try { PDCore.parsePageSet("9", 5); } catch (e) { threw = e.code === "RANGE"; }
    if (!threw) throw new Error("no range error");
  });
  await t("zip writer", async () => {
    const z = PDCore.zipStore([{ name: "a.txt", data: new TextEncoder().encode("hello") }, { name: "b/c.pdf", data: s3 }]);
    const dv = new DataView(z.buffer, z.byteLength - 22, 22);
    if (dv.getUint32(0, true) !== 0x06054b50) throw new Error("no EOCD");
  });
  await t("pdf.js renders a page", async () => {
    const doc = await pdfjsLib.getDocument({ data: new Uint8Array(s3.slice(0)) }).promise;
    const page = await doc.getPage(1);
    const vp = page.getViewport({ scale: 0.5 });
    const c = document.createElement("canvas");
    c.width = vp.width; c.height = vp.height;
    await page.render({ canvasContext: c.getContext("2d"), viewport: vp }).promise;
    const px = c.getContext("2d").getImageData(0, 0, c.width, c.height).data;
    let nonWhite = 0;
    for (let i = 0; i < px.length; i += 4) if (px[i] < 240) nonWhite++;
    if (nonWhite < 20) throw new Error("blank render");
    doc.destroy();
  });
  await t("compress rebuild pipeline", async () => {
    const doc = await pdfjsLib.getDocument({ data: new Uint8Array(s3.slice(0)) }).promise;
    const pages = [];
    for (let i = 1; i <= doc.numPages; i++) {
      const { canvas } = await renderPageToCanvas(doc, i, 0, { dpi: 72 });
      const blob = await new Promise(r => canvas.toBlob(r, "image/jpeg", 0.6));
      const jpeg = new Uint8Array(await blob.arrayBuffer());
      const page = await doc.getPage(i);
      const vp = page.getViewport({ scale: 1 });
      pages.push({ jpeg, wPt: vp.width, hPt: vp.height });
    }
    doc.destroy();
    const out = await PDCore.rebuildFromJpegs(pages);
    const d = await PDFDocument.load(out);
    if (d.getPageCount() !== 3) throw new Error("count");
  });
  await t("images to pdf", async () => {
    const c = document.createElement("canvas");
    c.width = 320; c.height = 200;
    const ctx = c.getContext("2d");
    ctx.fillStyle = "#dd4422"; ctx.fillRect(0, 0, 320, 200);
    ctx.fillStyle = "#ffffff"; ctx.fillRect(40, 40, 100, 60);
    const blob = await new Promise(r => c.toBlob(r, "image/png"));
    const bytes = new Uint8Array(await blob.arrayBuffer());
    const out = await PDCore.imagesToPdf([{ bytes, isPng: true, w: 320, h: 200 }], { pageSize: "a4", orient: "auto", marginPct: 3 });
    const d = await PDFDocument.load(out);
    if (d.getPageCount() !== 1) throw new Error("count");
  });
  /* ---- Phase 2 checks ---- */
  await t("form fill + flatten", async () => {
    const d = await PDFDocument.create();
    const page = d.addPage([400, 300]);
    const form = d.getForm();
    const tf = form.createTextField("who");
    tf.addToPage(page, { x: 40, y: 200, width: 200, height: 24 });
    const cb = form.createCheckBox("agree");
    cb.addToPage(page, { x: 40, y: 150, width: 18, height: 18 });
    const src = await d.save();
    const fields = await PDCore.listFormFields(src);
    if (fields.length !== 2) throw new Error("fields " + fields.length);
    const res = await PDCore.fillForm(src, [
      { name: "who", kind: "text", value: "Ameen" },
      { name: "agree", kind: "check", value: true },
    ], { flatten: false });
    if (res.problems.length) throw new Error(res.problems[0]);
    const back = await PDCore.listFormFields(res.bytes);
    if (back.find(f => f.name === "who").value !== "Ameen") throw new Error("value lost");
    const flat = await PDCore.fillForm(src, [{ name: "who", kind: "text", value: "X" }], { flatten: true });
    if ((await PDCore.listFormFields(flat.bytes)).length !== 0) throw new Error("not flattened");
  });
  await t("signature placement", async () => {
    const c = document.createElement("canvas");
    c.width = 200; c.height = 80;
    const m = c.getContext("2d");
    m.strokeStyle = "#1b2a52"; m.lineWidth = 3;
    m.beginPath(); m.moveTo(10, 60); m.bezierCurveTo(50, 10, 120, 70, 190, 20); m.stroke();
    const blob = await new Promise(r => c.toBlob(r, "image/png"));
    const png = new Uint8Array(await blob.arrayBuffer());
    const out = await PDCore.placeSignature(s3, png, true, { pageIdx: 0, cx: 400, cy: 150, wPt: 140, dateStr: "22 Aug 2026" });
    await PDFDocument.load(out);
  });
  await t("ocr overlay writer", async () => {
    const out = await PDCore.ocrOverlay(s3, [{ pageIdx: 0, dpi: 300, words: [
      { text: "Hello", x0: 100, y0: 100, x1: 400, y1: 160 },
      { text: "world", x0: 420, y0: 100, x1: 700, y1: 160 },
    ]}]);
    if (out.placed !== 2) throw new Error("placed " + out.placed);
    await PDFDocument.load(out.bytes);
  });
  if ((window.PD_ASSETS || {}).mupdfWasm) {
    await t("MuPDF: protect + unlock roundtrip", async () => {
      const mupdf = await loadMuPDF();
      const doc = mupdf.Document.openDocument(s3.slice(0), "application/pdf");
      const enc = PDCore.mupdfSave(doc, "encrypt=aes-256,user-password=pw1,owner-password=pw2,permissions=-4");
      doc.destroy();
      const doc2 = mupdf.Document.openDocument(enc.slice(0), "application/pdf");
      if (!doc2.needsPassword()) throw new Error("not locked");
      if (doc2.authenticatePassword("pw1") === 0) throw new Error("auth failed");
      const dec = PDCore.mupdfSave(doc2, "encrypt=none");
      doc2.destroy();
      if ((await PDFDocument.load(dec)).getPageCount() !== 3) throw new Error("pages lost");
    });
    await t("MuPDF: repair truncated file", async () => {
      const mupdf = await loadMuPDF();
      const broken = s5.slice(0, s5.length - 300);
      const doc = mupdf.Document.openDocument(broken, "application/pdf");
      let out;
      try { out = PDCore.mupdfSave(doc, "garbage=deduplicate,clean=yes,sanitize=yes"); }
      catch (e) {
        const fresh = new mupdf.PDFDocument();
        let ok = 0;
        for (let i = 0; i < doc.countPages(); i++) { try { fresh.graftPage(ok, doc, i); ok++; } catch (err) {} }
        out = PDCore.mupdfSave(fresh, "garbage=deduplicate,clean=yes");
        fresh.destroy();
      }
      doc.destroy();
      if ((await PDFDocument.load(out)).getPageCount() < 1) throw new Error("no pages");
    });
  } else {
    results.push({ name: "MuPDF checks skipped (engine not embedded)", ok: true });
  }
  await t("editor: overlay ops (shapes, text, note)", async () => {
    const res = await PDCore.applyOverlay(s3, [{ pageIdx: 0, ops: [
      { type: "whiteout", x: 50, y: 50, w: 200, h: 40 },
      { type: "highlight", x: 60, y: 120, w: 180, h: 20 },
      { type: "text", x: 60, y: 200, size: 16, text: "Editor test", family: "serif" },
      { type: "rect", x: 100, y: 300, w: 120, h: 60, stroke: "#c0392b", strokeW: 2 },
      { type: "line", x1: 60, y1: 400, x2: 300, y2: 440, stroke: "#333", strokeW: 2, arrow: true },
      { type: "note", x: 500, y: 60, text: "selftest note" },
    ]}]);
    if (res.problems.length) throw new Error(res.problems[0]);
    const d = await PDFDocument.load(res.bytes);
    const annots = d.getPage(0).node.lookup(PDFLib.PDFName.of("Annots"));
    if (!annots || annots.size() !== 1) throw new Error("note annotation missing");
  });
  if ((window.PD_ASSETS || {}).mupdfWasm) {
    await t("editor: in-place text replace (redact + retype)", async () => {
      const mupdf = await loadMuPDF();
      const dd = await PDFDocument.create();
      const f = await dd.embedFont(StandardFonts.Helvetica);
      const pp = dd.addPage([500, 400]);
      pp.drawText("Keep this", { x: 50, y: 300, size: 20, font: f });
      pp.drawText("Replace this", { x: 50, y: 250, size: 20, font: f });
      const src = await dd.save();
      const st = JSON.parse(mupdf.Document.openDocument(src.slice(0), "application/pdf").loadPage(0).toStructuredText().asJSON());
      const target = PDCore.parseStext(st).lines.find(l => /Replace/.test(l.text));
      if (!target) throw new Error("stext line not found");
      const redacted = PDCore.redactRegions(mupdf, src.slice(0), [{ pageIdx: 0, rects: [target], mode: "text" }]);
      const res = await PDCore.applyOverlay(redacted, [{ pageIdx: 0, ops: [
        { type: "editline", x: target.x, baseline: target.baseline, size: target.size, text: "New words", family: target.family },
      ]}]);
      const st2 = JSON.parse(mupdf.Document.openDocument(res.bytes.slice(0), "application/pdf").loadPage(0).toStructuredText().asJSON());
      const txt = PDCore.parseStext(st2).lines.map(l => l.text).join(" ");
      if (!/Keep this/.test(txt) || /Replace this/.test(txt) || !/New words/.test(txt))
        throw new Error("replace flow got: " + txt);
    });
  }
  await t("docx roundtrip + text layout (converters)", async () => {
    const docx = PDCore.buildDocx([[{ text: "Round trip", size: 14, bold: true }]]);
    const files = await PDCore.unzipBytes(docx);
    const paras = PDCore.docxParas(new TextDecoder().decode(files["word/document.xml"]));
    if (!/Round trip/.test(paras[0].text)) throw new Error("docx roundtrip lost text");
    const pdf = await PDCore.parasToPdf(paras);
    if ((await PDFDocument.load(pdf.bytes)).getPageCount() < 1) throw new Error("layout failed");
  });
  if ((window.PD_ASSETS || {}).tessCore && (window.PD_ASSETS.langs || {}).eng) {
    await t("OCR: recognizes rendered text", async () => {
      const c = document.createElement("canvas");
      c.width = 640; c.height = 200;
      const m = c.getContext("2d");
      m.fillStyle = "#fff"; m.fillRect(0, 0, 640, 200);
      m.fillStyle = "#111"; m.font = "bold 56px Arial";
      m.fillText("OPEN 42 NOW", 40, 120);
      const worker = await createTessWorker("eng", null);
      try {
        const res = await worker.recognize(c, {}, { text: true, tsv: true });
        if (!/OPEN/i.test(res.data.text)) throw new Error("read: " + (res.data.text || "").slice(0, 40));
      } finally { try { await worker.terminate(); } catch (e) {} }
    });
    const extra = ["ara", "hin", "mal", "tam", "urd"].filter(l => (window.PD_ASSETS.langs || {})[l]);
    if (extra.length) await t("OCR: " + extra.map(l => LANG_NAMES[l]).join(", ") + " language data loads", async () => {
      const c = document.createElement("canvas");
      c.width = 520; c.height = 140;
      const m = c.getContext("2d");
      m.fillStyle = "#fff"; m.fillRect(0, 0, 520, 140);
      m.fillStyle = "#111"; m.font = "56px 'Geeza Pro', 'Noto Naskh Arabic', 'Segoe UI', Tahoma, sans-serif";
      m.direction = "rtl"; m.textAlign = "right";
      m.fillText("\u0645\u0631\u062d\u0628\u0627 \u0628\u0643", 490, 90);
      const worker = await createTessWorker(extra.join("+"), null);
      try {
        const res = await worker.recognize(c, {}, { text: true });
        if (!/[\u0600-\u06FF]/.test(res.data.text || "")) throw new Error("no Arabic-script text recognised: " + JSON.stringify((res.data.text || "").slice(0, 30)));
      } finally { try { await worker.terminate(); } catch (e) {} }
    });
  } else {
    results.push({ name: "OCR check skipped (engine not embedded)", ok: true });
  }
  const pass = results.every(r => r.ok);
  return { pass, results };
}
window.PDSelfTest = runSelfTest;

async function runSelfTestUI() {
  const body = h("div", { class: "licenses" }, h("p", null, "Running checks…"));
  const close = showModal({ title: "Self-test", body, actions: [{ label: "Close", primary: true, onClick: c => c() }] });
  try {
    const { pass, results } = await runSelfTest();
    body.innerHTML = "";
    body.append(h("p", null, pass ? "All " + results.length + " checks passed. This copy is working correctly." : "Some checks failed:"));
    for (const r of results)
      body.append(h("p", { style: r.ok ? "" : "color:var(--err)" }, (r.ok ? "✓ " : "✗ ") + r.name + (r.err ? ": " + r.err : "")));
  } catch (e) {
    body.innerHTML = "";
    body.append(h("p", { style: "color:var(--err)" }, "Self-test crashed: " + (e && e.message || e)));
  }
}

/* test fixture (UI test, screenshots): 3 pages with bookmarks, an attached file and a form field */
async function uitestRichPdf() {
  const d = await PDFLib.PDFDocument.create();
  const f = await d.embedFont(PDFLib.StandardFonts.Helvetica);
  for (let i = 0; i < 3; i++) { const p = d.addPage([420, 595]); p.drawText("Chapter " + (i + 1), { x: 40, y: 540, size: 22, font: f }); }
  PDCore.writeOutline(d, [
    { title: "Chapter 1", page: 0, open: true, items: [{ title: "Section 1.1 Scope", page: 0 }, { title: "Section 1.2 Terms", page: 1 }] },
    { title: "Chapter 2", page: 1 }, { title: "Appendix", page: 2 }]);
  await d.attach(new TextEncoder().encode("rate,qty\n10,2\n"), "rates.csv", { mimeType: "text/csv", description: "Rate card" });
  const form = d.getForm();
  const tf = form.createTextField("tenant.name");
  tf.setText("Ahmed");
  tf.addToPage(d.getPage(2), { x: 40, y: 400, width: 200, height: 24 });
  const cb = form.createCheckBox("agree");
  cb.addToPage(d.getPage(2), { x: 40, y: 360, width: 16, height: 16 });
  const b = await d.save();
  return { name: "uitest-rich.pdf", size: b.length, buf: b.buffer.slice(b.byteOffset, b.byteOffset + b.byteLength) };
}

/* ---------------- UI self-test (drives the real editor with synthetic events) ---------------- */
const UILOG = [];
window.addEventListener("error", e => UILOG.push("winerr:" + String(e.message).slice(0, 90)));
async function runUITest() {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const report = t => {
    document.title = t.slice(0, 480);
    let d = document.getElementById("pduitest");
    if (!d) {
      d = h("pre", { id: "pduitest", style: "position:fixed;bottom:0;left:0;right:0;z-index:999998;background:#10241a;color:#b8f2cf;margin:0;padding:10px 14px;font:12px/1.5 monospace;white-space:pre-wrap;max-height:40vh;overflow:auto" });
      document.body.append(d);
    }
    d.textContent = t;
    if (/FAIL|ERR/.test(t)) { d.style.background = "#2a1210"; d.style.color = "#f6c8c0"; }
  };
  const steps = [];
  const fail = (step, msg) => { report("UITEST:FAIL:" + step + ":" + String(msg).slice(0, 220) + "|LOG:" + UILOG.join(";").slice(0, 150) + "|STATE:" + (window.__edState ? window.__edState() : "?")); };
  const pe = (el, type, x, y, opts) => el.dispatchEvent(new PointerEvent(type, Object.assign({
    bubbles: true, cancelable: true, clientX: x, clientY: y, pointerId: 1, isPrimary: true, button: 0, pointerType: "mouse",
  }, opts)));
  try {
    // 1. build a sample pdf and open it
    const d = await PDFLib.PDFDocument.create();
    const f = await d.embedFont(PDFLib.StandardFonts.Helvetica);
    const p = d.addPage([595, 842]);
    p.drawText("Heading text here", { x: 60, y: 760, size: 24, font: f });
    p.drawText("Body line for retyping.", { x: 60, y: 700, size: 12, font: f });
    const bytes = await d.save();
    setWorkspaceFile({ name: "uitest.pdf", size: bytes.length, buf: bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength) }, "edit");
    steps.push("open");
    // 2. wait for editor stage render
    let stage = null;
    for (let i = 0; i < 60 && !stage; i++) { await sleep(200); stage = document.querySelector(".ed-stage canvas.pagecanvas"); if (stage && stage.width < 10) stage = null; }
    if (!stage) return fail("stage", "editor canvas never rendered");
    const stEl = document.querySelector(".ed-stage");
    steps.push("stage");
    // 3. add text: click the mode button, then click the page
    const btn = Array.from(document.querySelectorAll(".ed-tool")).find(b => b.title === "Add text");
    if (!btn) return fail("addtext-btn", "mode button missing");
    btn.click();
    await sleep(100);
    const r = stEl.getBoundingClientRect();
    const cx = r.left + r.width * 0.4, cy = r.top + r.height * 0.4;
    pe(stEl, "pointerdown", cx, cy);
    pe(window, "pointerup", cx, cy);
    await sleep(250);
    const tobj = document.querySelector(".ed-obj.textobj");
    if (!tobj) return fail("addtext-create", "no text object appeared after click");
    if (!tobj.isContentEditable) return fail("addtext-edit", "text object not editable (focus flow broke)");
    if (document.activeElement !== tobj) return fail("addtext-focus", "editable box did not receive focus; active=" + (document.activeElement && document.activeElement.tagName));
    steps.push("addtext-open");
    // 4. type into it (execCommand fires real input events, like typing) and commit
    document.execCommand("insertText", false, "Hello from UI test");
    tobj.blur();
    await sleep(250);
    const persisted = Array.from(document.querySelectorAll(".ed-obj.textobj")).find(e => /Hello from UI test/.test(e.textContent));
    if (!persisted) return fail("addtext-commit", "typed text did not persist after blur");
    steps.push("addtext-commit");
    // 5. select + drag it (re-query AFTER mode switch: renders replace nodes)
    const selBtn = Array.from(document.querySelectorAll(".ed-tool")).find(b => b.title === "Select & move");
    selBtn.click(); await sleep(120);
    const target = Array.from(document.querySelectorAll(".ed-obj.textobj")).find(e => /Hello from UI test/.test(e.textContent));
    if (!target) return fail("drag-pre", "text object missing before drag");
    const r0 = target.getBoundingClientRect();
    pe(target, "pointerdown", r0.left + 5, r0.top + 5);
    pe(window, "pointermove", r0.left + 45, r0.top + 35);
    pe(window, "pointermove", r0.left + 85, r0.top + 65);
    pe(window, "pointerup", r0.left + 85, r0.top + 65);
    await sleep(250);
    const moved = Array.from(document.querySelectorAll(".ed-obj.textobj")).find(e => /Hello from UI test/.test(e.textContent));
    if (!moved) return fail("drag", "text object vanished during drag");
    const r1 = moved.getBoundingClientRect();
    if (Math.abs(r1.left - r0.left) < 30) return fail("drag-move", "object did not move (dx=" + Math.round(r1.left - r0.left) + ")");
    steps.push("drag");
    // 6. whiteout drag-draw
    const wBtn = Array.from(document.querySelectorAll(".ed-tool")).find(b => b.title === "Whiteout");
    wBtn.click(); await sleep(80);
    pe(stEl, "pointerdown", r.left + 60, r.top + 80);
    pe(window, "pointermove", r.left + 180, r.top + 130);
    pe(window, "pointerup", r.left + 180, r.top + 130);
    await sleep(250);
    if (!document.querySelector(".ed-obj.whiteout")) return fail("whiteout", "no whiteout object after drag");
    steps.push("whiteout");
    // 7. edit-text mode (requires MuPDF; skip cleanly on lean builds)
    if ((window.PD_ASSETS || {}).mupdfWasm) {
      const eBtn = Array.from(document.querySelectorAll(".ed-tool")).find(b => b.title === "Edit existing text");
      eBtn.click();
      let hits = null;
      for (let i = 0; i < 100 && !hits; i++) { await sleep(300); const hh = document.querySelectorAll(".ed-hit"); if (hh.length) hits = hh; }
      if (!hits) return fail("edittext-lines", "no clickable text lines appeared (stext/mupdf failed?)");
      hits[0].click();
      await sleep(400);
      const eobj = Array.from(document.querySelectorAll(".ed-obj.textobj")).find(e => e.isContentEditable);
      if (!eobj) return fail("edittext-open", "clicking a line did not open the inline editor");
      document.execCommand("selectAll");
      document.execCommand("insertText", false, "Retyped by UI test");
      eobj.blur();
      await sleep(250);
      if (!Array.from(document.querySelectorAll(".ed-obj.textobj")).some(e => /Retyped by UI test/.test(e.textContent)))
        return fail("edittext-commit", "retyped text did not persist");
      steps.push("edittext");
    } else steps.push("edittext-skipped");
    const edTab = activeTab;
    // 8. sign tool placement accuracy: click at 30%,70% of the preview and
    //    verify the recorded placement matches that fraction of the page.
    showView("sign");
    let ov = null;
    for (let i = 0; i < 50 && !ov; i++) { await sleep(200); const c = document.querySelector(".preview-wrap canvas"); if (c && c.getBoundingClientRect().width > 50) ov = c; }
    if (!ov) return fail("sign-preview", "sign preview never rendered");
    // v3.8: leaving the editor put its edits into the document (one undo step), so Sign works on them
    if (!edTab || edTab.hist.depth !== 1 || edTab.hist.undoLabel !== "Edit page content" || !edTab.edLayer)
      return fail("carry-edit", "editor edits not applied to the tab: depth " + (edTab && edTab.hist.depth) + " label " + (edTab && edTab.hist.undoLabel));
    if (!document.querySelector(".tool-switch .ts-btn.on[data-tool=sign]")) return fail("tool-switch", "tool switcher missing on Sign");
    steps.push("carry-edit");
    // draw a quick signature on the pad so placement is armed
    const padEl = document.querySelector('canvas[style*="crosshair"]');
    if (!padEl) return fail("sign-pad", "draw pad missing");
    const pr = padEl.getBoundingClientRect();
    pe(padEl, "pointerdown", pr.left + 30, pr.top + 60);
    pe(padEl, "pointermove", pr.left + 150, pr.top + 90);
    pe(padEl, "pointerup", pr.left + 150, pr.top + 90);
    // wait until the signature is actually registered (marker becomes visible at its default spot)
    let sigEl = null;
    for (let i = 0; i < 40 && !sigEl; i++) {
      await sleep(250);
      const im = document.querySelector(".preview-wrap img");
      if (im && im.style.display === "block") sigEl = im;
    }
    if (!sigEl) return fail("sign-place", "signature was never registered after drawing");
    const ovWrap = ov.parentElement.querySelector("div"); // overlay div above canvas
    const or = ov.getBoundingClientRect();
    const clickX = or.left + or.width * 0.3, clickY = or.top + or.height * 0.7;
    pe(ovWrap || ov, "pointerdown", clickX, clickY);
    pe(window, "pointerup", clickX, clickY);
    await sleep(300);
    const sr = sigEl.getBoundingClientRect();
    const cxFrac = ((sr.left + sr.width / 2) - or.left) / or.width;
    const cyFrac = ((sr.top + sr.height / 2) - or.top) / or.height;
    if (Math.abs(cxFrac - 0.3) > 0.03 || Math.abs(cyFrac - 0.7) > 0.03)
      return fail("sign-accuracy", "marker at " + cxFrac.toFixed(2) + "," + cyFrac.toFixed(2) + " expected 0.30,0.70");
    steps.push("sign-place");
    // 8b. saved signatures: save → chip appears
    const saveB = document.querySelector(".sig-save");
    if (!saveB || saveB.classList.contains("hidden")) return fail("sig-save-btn", "Save signature button not offered after drawing");
    const chipsBefore = document.querySelectorAll(".sig-chip").length;
    saveB.click();
    let chips = 0;
    for (let i = 0; i < 30 && chips <= chipsBefore; i++) { await sleep(150); chips = document.querySelectorAll(".sig-chip").length; }
    if (chips <= chipsBefore) return fail("sig-save", "saved signature did not appear in the strip");
    const savedIds = Array.from(document.querySelectorAll(".sig-chip")).map(c => c.dataset.id);
    steps.push("sig-save");
    // 8c. sign → share sheet (no auto-download) → Keep editing reopens the signed file
    const signBtn = document.querySelector(".actionbar .btn.primary");
    if (!signBtn || signBtn.disabled) return fail("sign-run", "Sign PDF button not enabled");
    signBtn.click();
    let sheet = null;
    for (let i = 0; i < 40 && !sheet; i++) { await sleep(150); sheet = document.querySelector(".sheet-wrap .sheet"); }
    if (!sheet) return fail("sign-sheet", "share sheet did not appear after signing");
    const acts = Array.from(sheet.querySelectorAll(".sheet-item")).map(b => b.dataset.act).join(",");
    if (acts !== "keep,download,email,whatsapp") return fail("sign-sheet-items", "sheet items: " + acts);
    if (workspace !== edTab.rec || edTab.hist.depth !== 2 || !/signature/.test(edTab.hist.undoLabel))
      return fail("sign-workspace", "signing did not add a step to the open document: depth " + edTab.hist.depth + " label " + edTab.hist.undoLabel);
    sheet.querySelector('[data-act="keep"]').click();
    let pill = null;
    for (let i = 0; i < 40 && !pill; i++) { await sleep(150); const f = document.querySelector(".filepill .fname"); if (f && f.textContent === edTab.rec.name && currentView && currentView.id === "sign") pill = f; }
    if (!pill) return fail("sign-keep", "Keep editing did not reopen Sign on the document");
    // default signature is pre-loaded on the fresh Sign screen
    let pre = null;
    for (let i = 0; i < 30 && !pre; i++) { await sleep(150); const im = document.querySelector(".preview-wrap img"); if (im && im.style.display === "block") pre = im; }
    if (!pre) return fail("sig-default", "default saved signature was not pre-loaded");
    for (const id of savedIds) { try { await SigStore.remove(id); } catch (e) {} }
    steps.push("sign-sheet");
    // 9. viewer: text layer + search
    showView("view");
    let ti = null;
    for (let i = 0; i < 50 && !ti; i++) { await sleep(200); ti = document.querySelector(".docpane.on .pdfind"); }
    if (!ti) return fail("viewer-ui", "search input missing");
    let spans = 0;
    for (let i = 0; i < 50 && !spans; i++) { await sleep(200); spans = document.querySelectorAll(".docpane.on .textLayer span").length; }
    if (!spans) return fail("viewer-textlayer", "no selectable text layer rendered");
    // v3.8: the editor retyped the heading and that edit is in the document now
    ti.value = (window.PD_ASSETS || {}).mupdfWasm ? "retyped" : "heading";
    ti.dispatchEvent(new Event("input", { bubbles: true }));
    let found = false;
    for (let i = 0; i < 40 && !found; i++) {
      await sleep(200);
      const info = document.querySelector(".docpane.on .pdfindinfo");
      if (info && /\d+ \/ \d+/.test(info.textContent)) found = true;
    }
    if (!found) return fail("viewer-search", "search found no matches for " + ti.value);
    steps.push("viewer-search");
    // v3.8: the editor's text is in the document the viewer shows (carried through Sign)
    ti.value = "hello from ui";
    ti.dispatchEvent(new Event("input", { bubbles: true }));
    found = false;
    for (let i = 0; i < 40 && !found; i++) { await sleep(200); const info = document.querySelector(".docpane.on .pdfindinfo"); if (info && /\d+ \/ \d+/.test(info.textContent)) found = true; }
    if (!found) return fail("carry-viewer", "editor text not found in the viewer after signing");
    ti.value = ""; ti.dispatchEvent(new Event("input", { bubbles: true }));
    steps.push("carry-viewer");
    // v3.8: undo the signature, then Edit brings the editor's objects back, still movable
    await edTab.api.undo();
    if (edTab.hist.depth !== 1) return fail("layer-undo", "undo did not remove the signature step");
    await showView("edit");
    let liveObj = null;
    for (let i = 0; i < 60 && !liveObj; i++) { await sleep(200); liveObj = Array.from(document.querySelectorAll(".ed-obj.textobj")).find(e => /Hello from UI test/.test(e.textContent)); }
    if (!liveObj) return fail("layer-resume", "editor objects did not come back as live objects");
    if (edTab.hist.depth !== 0) return fail("layer-base", "editor did not step back to the bytes under its objects: depth " + edTab.hist.depth);
    document.querySelector(".ed-apply").click();
    for (let i = 0; i < 60 && !(currentView && currentView.id === "view"); i++) await sleep(200);
    if (!(currentView && currentView.id === "view") || edTab.hist.depth !== 1 || !edTab.edLayer) return fail("layer-done", "Done did not return to the document with one edit step: depth " + edTab.hist.depth);
    steps.push("layer-resume");
    // v3.8 panels: Tools + Edit history + compare
    edTab.api.setPanel("tools");
    await sleep(300);
    if (document.querySelectorAll(".docpane.on .tp-item").length < 10) return fail("tools-panel", "tools panel is empty");
    edTab.api.setPanel("history");
    let rows = 0;
    for (let i = 0; i < 20 && rows < 2; i++) { await sleep(150); rows = document.querySelectorAll(".docpane.on .hist-row").length; }
    if (rows < 2) return fail("history-panel", "history panel rows: " + rows);
    openCompare(edTab, 0);
    let cmp = null;
    for (let i = 0; i < 40 && !cmp; i++) { await sleep(200); const cs = document.querySelectorAll(".cmp-dlg canvas"); if (cs.length === 2 && cs[1].width > 10) cmp = cs; }
    if (!cmp) return fail("compare", "compare dialog did not draw both pages");
    for (let i = 0; i < 20 && !/changed/.test((document.querySelector(".cmp-same") || {}).textContent || ""); i++) await sleep(150);
    if (!/This page changed/.test(document.querySelector(".cmp-same").textContent)) return fail("compare-diff", "compare did not notice the change: " + document.querySelector(".cmp-same").textContent);
    document.querySelectorAll(".modal-wrap").forEach(cancelModal);
    edTab.api.setPanel("pages");
    edTab.hist.markSaved(); renderTabs();     // later steps count unsaved documents
    steps.push("panels");
    // 10. read aloud in the viewer (scripted speech engine: deterministic, no audio)
    const spoken = [];
    const fakeTTS = {
      kind: "test", onevent: null, timers: [], voiceList: [
        { id: "en-test", name: "Test English", lang: "en-US", local: true, installed: true },
        { id: "ar-test", name: "Test Arabic", lang: "ar-SA", local: true, installed: true }],
      async ready() { return true; },
      async voices() { return this.voiceList; },
      speak(items, o) {
        if (o.flush) this.stop();
        let t = this.timers.length ? this._end || 0 : 0;
        for (const it of items) {
          spoken.push({ id: it.id, lang: it.lang, voice: it.voice, text: it.text });
          const words = Array.from(it.text.matchAll(/\S+/g));
          const at = (ms, fn) => this.timers.push(setTimeout(fn, ms));
          const T0 = t;
          at(T0 + 5, () => this.onevent && this.onevent({ type: "start", id: it.id }));
          words.forEach((w, k) => at(T0 + 10 + k * 12, () => this.onevent && this.onevent({ type: "range", id: it.id, start: w.index, end: w.index + w[0].length })));
          t = T0 + 20 + words.length * 12;
          at(t, () => this.onevent && this.onevent({ type: "done", id: it.id }));
        }
        this._end = t;
      },
      stop() { this.timers.forEach(clearTimeout); this.timers = []; this._end = 0; },
      langStatus() { return 0; },
    };
    window.__atobTTSOverride = fakeTTS; _tts = null;
    const lb = document.querySelector(".docpane.on .vlisten") || Array.from(document.querySelectorAll(".docpane.on .vpill .iconbtn")).find(b => b.title === "Read aloud");
    if (!lb) return fail("audio-btn", "Listen button missing in viewer");
    lb.click();
    await sleep(150);
    const abar = document.querySelector(".abar");
    if (!abar) return fail("audio-bar", "player bar did not open");
    abar.querySelector(".ab-play").click();
    let word = null;
    for (let i = 0; i < 60 && !word; i++) { await sleep(100); word = document.querySelector(".docpane.on .vpage .tts-layer .tts-word"); }
    if (!word) return fail("audio-highlight", "no word highlight while speaking; spoken=" + spoken.length);
    if (!/Heading|Body|Hello|Retyped/.test(abar.querySelector(".ab-sent").textContent)) return fail("audio-sentence", "sentence preview: " + abar.querySelector(".ab-sent").textContent);
    abar.querySelector(".ab-play").click(); // pause
    await sleep(80);
    if (abar.querySelector(".ab-play").getAttribute("aria-label") !== "Play") return fail("audio-pause", "pause did not stop playback");
    // tap a word → reading starts there
    const bodySpan = Array.from(document.querySelectorAll(".docpane.on .vpage .textLayer span")).find(s => /Body line/.test(s.textContent));
    if (!bodySpan) return fail("audio-tap-target", "body text span missing");
    const bs = bodySpan.getBoundingClientRect();
    const nBefore = spoken.length;
    bodySpan.dispatchEvent(new MouseEvent("click", { bubbles: true, clientX: bs.left + bs.width * 0.6, clientY: bs.top + bs.height / 2 }));
    for (let i = 0; i < 30 && spoken.length === nBefore; i++) await sleep(60);
    const firstNew = spoken[nBefore];
    if (!firstNew || /Heading/.test(firstNew.text) || !/retyping/.test(firstNew.text)) return fail("audio-tap", "tap-to-start spoke: " + (firstNew && firstNew.text));
    window.__viewerAudio && window.__viewerAudio.toggle(false);
    steps.push("audio-viewer");
    // 11. language switching + missing-voice prompt (Hindi has no voice in the test engine)
    const mixed = finishModel(Object.assign(PDCore.buildPageText([{ str: "Hello there. مرحبا بك يا صديقي. नमस्ते दोस्त। Goodbye now.", x: 10, y: 10, w: 400, h: 12, eol: true }]), { w: 500, h: 500 }));
    const ar2 = new AudioReader({ pageCount: 1, title: "t", getPage: async () => mixed, showPage: async () => {}, highlight: () => {}, currentPage: () => 0 });
    await ar2.voicesReady;
    spoken.length = 0;
    ar2.play(0, 0);
    let prompt = null;
    for (let i = 0; i < 40 && !prompt; i++) { await sleep(80); prompt = Array.from(document.querySelectorAll(".modal h3")).find(x => /No Hindi voice/.test(x.textContent)); }
    if (!prompt) return fail("voice-prompt", "no 'No Hindi voice' prompt; spoken=" + JSON.stringify(spoken.map(s => s.lang)));
    Array.from(document.querySelectorAll(".modal .btn")).find(b => /Skip Hindi/.test(b.textContent)).click();
    for (let i = 0; i < 60 && ar2.playing; i++) await sleep(60);
    const seq = spoken.map(s => s.voice).join(",");
    ar2.destroy();
    if (seq !== "en-test,ar-test,en-test") return fail("voice-switch", "voices used: " + seq);
    steps.push("voice-switch");
    // 12. Kindle-style reader on a 6-page book
    const bk = await PDFLib.PDFDocument.create();
    const bf = await bk.embedFont(PDFLib.StandardFonts.TimesRoman);
    const para = "This is a paragraph of reading text that is long enough to wrap across the page and exercise the reflow layout nicely. ";
    for (let i = 0; i < 6; i++) {
      const pg = bk.addPage([420, 595]);
      pg.drawText("Chapter " + (i + 1), { x: 40, y: 540, size: 22, font: bf });
      for (let l = 0; l < 26; l++) pg.drawText((l % 6 === 0 ? "   " : "") + para.slice((l * 17) % 40, (l * 17) % 40 + 58), { x: 40, y: 500 - l * 17, size: 11, font: bf });
    }
    const bkBytes = await bk.save();
    localStorage.removeItem("atob.reader.prefs");
    setWorkspaceFile({ name: "uitest-book.pdf", size: bkBytes.length, buf: bkBytes.buffer.slice(bkBytes.byteOffset, bkBytes.byteOffset + bkBytes.byteLength) }, "read");
    let kpg = null;
    for (let i = 0; i < 80 && !kpg; i++) { await sleep(150); kpg = document.querySelector(".kr .kr-pg canvas"); }
    if (!kpg) return fail("reader-page", "reader never rendered a page");
    for (let i = 0; i < 40 && !document.querySelector(".kr .kr-tl span"); i++) await sleep(150);
    if (!document.querySelector(".kr .kr-tl span")) return fail("reader-textlayer", "no selectable text on the page");
    const R = window.__reader;
    const stg = document.querySelector(".kr-stage").getBoundingClientRect();
    pe(document.querySelector(".kr-stage"), "pointerdown", stg.left + stg.width * 0.9, stg.top + stg.height * 0.5);
    pe(document.querySelector(".kr-stage"), "pointerup", stg.left + stg.width * 0.9, stg.top + stg.height * 0.5);
    for (let i = 0; i < 30 && R.get().loc.page === 0; i++) await sleep(100);
    if (R.get().loc.page < 1) return fail("reader-tap-next", "right-side tap did not turn the page");
    steps.push("reader-page");
    await R.setMode("reflow");
    for (let i = 0; i < 80 && !document.querySelector(".kr-cols .ks"); i++) await sleep(150);
    if (!document.querySelector(".kr-cols .ks")) return fail("reader-reflow", "reflow text never appeared");
    const g0 = R.get();
    if (g0.flowScreens < 2) return fail("reader-reflow-pages", "reflow produced " + g0.flowScreens + " screen(s)");
    const scr0 = g0.flowScreen;
    R.next(); await sleep(350);
    if (R.get().flowScreen !== scr0 + 1) return fail("reader-reflow-next", "screen " + scr0 + " -> " + R.get().flowScreen);
    steps.push("reader-reflow");
    // settings: theme + size keep the reading position
    R.openSettings();
    const darkBtn = document.querySelector(".kr-theme.t-dark");
    if (!darkBtn) return fail("reader-settings", "theme buttons missing");
    darkBtn.click();
    if (document.querySelector(".kr").dataset.theme !== "dark") return fail("reader-theme", "theme did not apply");
    const locBefore = R.get().loc;
    Array.from(document.querySelectorAll(".kr-size .btn")).find(b => /A\+/.test(b.textContent)).click();
    await sleep(300);
    const locAfter = R.get().loc;
    if (locAfter.page !== locBefore.page || Math.abs(locAfter.off - locBefore.off) > 400) return fail("reader-anchor", "position moved " + JSON.stringify(locBefore) + " -> " + JSON.stringify(locAfter));
    document.querySelector(".kr-panel .kr-phead .iconbtn").click();
    steps.push("reader-settings");
    // bookmark
    document.querySelector(".kr-bm").click();
    await sleep(120);
    if (R.get().book.bookmarks.length !== 1 || document.querySelector(".kr-ribbon").classList.contains("hidden")) return fail("reader-bookmark", "bookmark not added/shown");
    // highlight via a real selection
    const segEl = Array.from(document.querySelectorAll(".kr-cols .ks")).find(s => { const r = s.getBoundingClientRect(); return r.width > 0 && r.left >= stg.left && r.right <= stg.right && s.textContent.length > 20; });
    if (!segEl) return fail("reader-hl-target", "no visible text to select");
    const rg = document.createRange();
    rg.setStart(segEl.firstChild, 2); rg.setEnd(segEl.firstChild, 14);
    const sel = window.getSelection(); sel.removeAllRanges(); sel.addRange(rg);
    let dot = null;
    for (let i = 0; i < 20 && !dot; i++) { await sleep(100); const m = document.querySelector(".kr-selmenu:not(.hidden) .kr-dot.c-g"); if (m) dot = m; }
    if (!dot) return fail("reader-selmenu", "selection menu did not appear");
    dot.click();
    await sleep(100);
    const hls = R.get().book.highlights;
    if (hls.length !== 1 || hls[0].color !== "g" || hls[0].text !== segEl.textContent.slice(2, 14)) return fail("reader-highlight", JSON.stringify(hls));
    if (window.CSS && CSS.highlights && (!CSS.highlights.get("kr-g") || CSS.highlights.get("kr-g").size !== 1)) return fail("reader-hl-paint", "highlight range not painted");
    steps.push("reader-annotate");
    // search
    R.openSearch();
    const si = document.querySelector(".kr-search");
    si.value = "chapter 5"; si.dispatchEvent(new Event("input", { bubbles: true }));
    let res = null;
    for (let i = 0; i < 40 && !res; i++) { await sleep(150); res = document.querySelector(".kr-searchp .kr-item.res"); }
    if (!res) return fail("reader-search", "no search results for 'chapter 5'");
    res.click(); await sleep(300);
    if (R.get().loc.page !== 4) return fail("reader-search-go", "search jump went to page " + (R.get().loc.page + 1));
    steps.push("reader-search");
    // contents falls back to detected headings
    await R.openNav("toc");
    await sleep(200);
    const tocItems = document.querySelectorAll(".kr-nav .kr-item");
    if (tocItems.length < 6) return fail("reader-toc", "headings found: " + tocItems.length);
    document.querySelector(".kr-nav").remove();
    // audio inside the reader (reflow): word highlight follows speech
    R.openAudio(true);
    await sleep(100);
    document.querySelector(".kr .abar .ab-play").click();
    let hw = false;
    for (let i = 0; i < 60 && !hw; i++) { await sleep(100); hw = !!(window.CSS && CSS.highlights ? (CSS.highlights.get("kr-tts-w") && CSS.highlights.get("kr-tts-w").size) : document.querySelector(".ks.tts")); }
    if (!hw) return fail("reader-audio", "no spoken-word highlight in reflow");
    R.openAudio(false);
    steps.push("reader-audio");
    // resume: leave and come back
    const lastPage = R.get().loc.page;
    showView("view");
    await sleep(300);
    showView("read");
    let back = null;
    for (let i = 0; i < 80 && !back; i++) { await sleep(150); if (window.__reader && document.querySelector(".kr-cols .ks")) back = window.__reader; }
    if (!back) return fail("reader-resume-open", "reader did not reopen in reflow mode");
    if (back.get().loc.page !== lastPage) return fail("reader-resume", "resumed at page " + (back.get().loc.page + 1) + ", expected " + (lastPage + 1));
    if (back.get().book.highlights.length !== 1 || back.get().book.bookmarks.length !== 1) return fail("reader-persist", "annotations were not persisted");
    steps.push("reader-resume");
    back.setMode("page");
    localStorage.removeItem("atob.reader.prefs");
    showView("view");
    window.__atobTTSOverride = null; _tts = null;
    {
    // 13. v3.5 tabs + thumbnails: rotate from the thumbnail context menu, crop, undo, close
    const tabsBefore = docTabs.length;
    const pd = await PDFLib.PDFDocument.create();
    for (let i = 0; i < 3; i++) pd.addPage([400, 600]);
    const pdBytes = await pd.save();
    openDocTab({ name: "uitest-pages.pdf", size: pdBytes.length, buf: pdBytes.buffer.slice(pdBytes.byteOffset, pdBytes.byteOffset + pdBytes.byteLength) });
    if (docTabs.length !== tabsBefore + 1 || document.querySelectorAll(".doctabs .dt[data-tab]").length !== docTabs.length) return fail("tabs-open", "tab count " + docTabs.length + " vs " + (tabsBefore + 1));
    const ptab = activeTab;
    let th = null;
    for (let i = 0; i < 60 && !th; i++) { await sleep(120); th = document.querySelector('.docpane.on .vt-item[data-i="1"]'); }
    if (!th) return fail("thumbs", "thumbnail panel did not render");
    const pane = document.querySelector(".docpane.on");
    if (!pane.querySelector(".vwrap").classList.contains("thumbs-open")) pane.querySelector(".vthumbs-btn").click();
    const tr = th.getBoundingClientRect();
    th.dispatchEvent(new MouseEvent("contextmenu", { bubbles: true, cancelable: true, clientX: tr.left + 10, clientY: tr.top + 10 }));
    await sleep(60);
    const rotItem = Array.from(document.querySelectorAll(".ctxmenu .cm-item")).find(b => /Rotate clockwise/.test(b.textContent));
    if (!rotItem) return fail("ctx-menu", "thumbnail context menu missing");
    rotItem.click();
    for (let i = 0; i < 60 && !ptab.hist.depth; i++) await sleep(100);
    const rd = await PDFLib.PDFDocument.load(new Uint8Array(ptab.rec.buf.slice(0)));
    if (rd.getPage(1).getRotation().angle !== 90 || rd.getPage(0).getRotation().angle !== 0) return fail("rotate", "page rotations: " + rd.getPages().map(p => p.getRotation().angle));
    if (!tabDirty(ptab) || !document.querySelector('.doctabs .dt.on.dirty')) return fail("rotate-dirty", "tab not marked unsaved");
    steps.push("tabs-rotate");
    // crop page 1 from its hover toolbar
    let cropB = null;
    for (let i = 0; i < 40 && !cropB; i++) { await sleep(100); cropB = pane.querySelector('.vpage[data-i="0"] .vpage-tools .iconbtn[title^="Crop"]'); }
    if (!cropB) return fail("crop-btn", "page crop button missing");
    cropB.click();
    let cstage = null;
    for (let i = 0; i < 30 && !cstage; i++) { await sleep(80); cstage = document.querySelector(".crop-stage"); }
    if (!cstage) return fail("crop-dlg", "crop dialog did not open");
    const sr = cstage.getBoundingClientRect();
    pe(cstage, "pointerdown", sr.left + sr.width * 0.25, sr.top + sr.height * 0.25);
    pe(cstage, "pointermove", sr.left + sr.width * 0.75, sr.top + sr.height * 0.75);
    pe(cstage, "pointerup", sr.left + sr.width * 0.75, sr.top + sr.height * 0.75);
    await sleep(60);
    document.querySelector(".modal .mrow .btn.primary").click();
    for (let i = 0; i < 60 && ptab.hist.depth < 2; i++) await sleep(100);
    const cd = await PDFLib.PDFDocument.load(new Uint8Array(ptab.rec.buf.slice(0)));
    const cb = cd.getPage(0).getCropBox();
    if (Math.abs(cb.width - 200) > 3 || Math.abs(cb.height - 300) > 3) return fail("crop", "crop box " + JSON.stringify(cb));
    steps.push("crop");
    // undo button names the step it undoes
    const idle = async () => { await sleep(30); for (let i = 0; i < 100 && pane.classList.contains("busy"); i++) await sleep(50); };
    await idle();
    const undoB = pane.querySelector(".vundo");
    if (!/^Undo crop page 1/.test(undoB.title)) return fail("undo-label", "undo tooltip: " + undoB.title);
    undoB.click();
    for (let i = 0; i < 60 && ptab.hist.depth > 1; i++) await sleep(100);
    await idle();
    const ud = await PDFLib.PDFDocument.load(new Uint8Array(ptab.rec.buf.slice(0)));
    if (Math.abs(ud.getPage(0).getCropBox().width - 400) > 1 || ud.getPage(1).getRotation().angle !== 90) return fail("undo", "undo did not restore the crop only");
    steps.push("undo");
    // ---- v3.5.1: redo (button + Ctrl/⌘+Shift+Z + Ctrl+Y), named steps, new edit clears redo ----
    const cropW = async () => (await PDFLib.PDFDocument.load(new Uint8Array(ptab.rec.buf.slice(0)))).getPage(0).getCropBox().width;
    const redoB = pane.querySelector(".vredo");
    if (!redoB || redoB.classList.contains("hidden") || !/^Redo crop page 1/.test(redoB.title)) return fail("redo-btn", "redo button: " + (redoB && redoB.title));
    if (!/^Undo rotate page 2 clockwise/.test(undoB.title)) return fail("undo-label2", "undo tooltip after undo: " + undoB.title);
    redoB.click();
    for (let i = 0; i < 60 && ptab.hist.depth < 2; i++) await sleep(100);
    await idle();
    if (Math.abs(await cropW() - 200) > 3) return fail("redo", "redo button did not bring the crop back");
    if (document.activeElement && document.activeElement.blur) document.activeElement.blur();
    const key = (k, o) => document.body.dispatchEvent(new KeyboardEvent("keydown", Object.assign({ key: k, bubbles: true, cancelable: true }, o)));
    key("z", { ctrlKey: true });
    for (let i = 0; i < 60 && ptab.hist.depth > 1; i++) await sleep(100);
    await idle();
    if (Math.abs(await cropW() - 400) > 1) return fail("undo-key", "Ctrl+Z did not undo");
    key("Z", { ctrlKey: true, shiftKey: true });
    for (let i = 0; i < 60 && ptab.hist.depth < 2; i++) await sleep(100);
    await idle();
    if (Math.abs(await cropW() - 200) > 3) return fail("redo-key", "Ctrl+Shift+Z did not redo");
    key("z", { metaKey: true });
    for (let i = 0; i < 60 && ptab.hist.depth > 1; i++) await sleep(100);
    await idle();
    key("y", { ctrlKey: true });
    for (let i = 0; i < 60 && ptab.hist.depth < 2; i++) await sleep(100);
    await idle();
    if (Math.abs(await cropW() - 200) > 3) return fail("redo-y", "Ctrl+Y did not redo");
    // Electron menu + keydown for the same shortcut must undo once, not twice
    key("z", { ctrlKey: true }); onMenuCommand("undo");
    for (let i = 0; i < 60 && ptab.hist.depth > 1; i++) await sleep(100);
    await idle();
    await sleep(300);
    if (ptab.hist.depth !== 1) return fail("menu-dedupe", "depth " + ptab.hist.depth + " after key + menu undo");
    onMenuCommand("redo");                       // a menu click on its own does act
    for (let i = 0; i < 60 && ptab.hist.depth < 2; i++) await sleep(100);
    await idle();
    if (ptab.hist.depth !== 2) return fail("menu-redo", "menu Redo did nothing");
    pane.querySelector(".vundo").click();
    for (let i = 0; i < 60 && ptab.hist.depth > 1; i++) await sleep(100);
    await idle();
    const rot0 = th.getBoundingClientRect();
    th.dispatchEvent(new MouseEvent("contextmenu", { bubbles: true, cancelable: true, clientX: rot0.left + 10, clientY: rot0.top + 10 }));
    await sleep(60);
    Array.from(document.querySelectorAll(".ctxmenu .cm-item")).find(b => /Rotate 180/.test(b.textContent)).click();
    for (let i = 0; i < 60 && ptab.hist.depth < 2; i++) await sleep(100);
    await idle();
    if (ptab.hist.canRedo || !redoB.classList.contains("hidden")) return fail("redo-cleared", "a new edit kept the redo step");
    steps.push("redo");
    // ---- v3.5.1: autosave → crash recovery ----
    await Recovery.flush();
    const rdb = await new Promise((res, rej) => { const q = indexedDB.open("atobpdf-recovery", 1); q.onsuccess = () => res(q.result); q.onerror = () => rej(q.error); });
    const idbGet = (k) => new Promise(res => { const q = rdb.transaction("docs").objectStore("docs").get(k); q.onsuccess = () => res(q.result); q.onerror = () => res(null); });
    const mine = await idbGet(ptab.key);
    if (!mine || mine.depth !== 2 || mine.size !== ptab.rec.size || mine.name !== "uitest-pages.pdf") return fail("autosave", "recovery entry: " + JSON.stringify(mine && { depth: mine.depth, size: mine.size }));
    if ((await Recovery.pending()).some(e => e.key === ptab.key)) return fail("autosave-own", "this session's entry was offered for recovery");
    // an entry left behind by a session that died: offered on launch, Recover opens it unsaved
    const ghost = { key: "uitest-ghost", session: "uitest-dead-session", name: "crashed-doc.pdf", path: "", size: ptab.rec.size, buf: ptab.rec.buf.slice(0), depth: 3, at: Date.now() - 60000 };
    await new Promise(res => { const tx = rdb.transaction("docs", "readwrite"); tx.objectStore("docs").put(ghost); tx.oncomplete = res; tx.onerror = res; });
    const tabsMid = docTabs.length;
    Recovery.offer();
    let recDlg = null;
    for (let i = 0; i < 30 && !recDlg; i++) { await sleep(100); recDlg = Array.from(document.querySelectorAll(".modal h3")).find(x => /didn't close normally/.test(x.textContent)); }
    if (!recDlg) return fail("recover-prompt", "no recovery prompt for an orphaned entry");
    const recRow = document.querySelector('.rec-row[data-key="uitest-ghost"]');
    if (!recRow || !/3 changes/.test(recRow.textContent)) return fail("recover-row", "row: " + (recRow && recRow.textContent));
    recRow.querySelector(".rec-recover").click();
    let rtab = null;
    for (let i = 0; i < 40 && !rtab; i++) { await sleep(100); rtab = docTabs.find(x => x.rec.name === "crashed-doc.pdf"); }
    if (!rtab || docTabs.length !== tabsMid + 1) return fail("recover-open", "recovered tab not opened");
    if (!tabDirty(rtab) || document.querySelector(".modal-wrap")) return fail("recover-dirty", "recovered tab should open unsaved, dialog closed");
    for (let i = 0; i < 40 && !document.querySelector('.docpane.on .vt-item[data-i="0"]'); i++) await sleep(100);
    // ---- v3.5.1: leaving with unsaved tabs: beforeunload + one combined prompt ----
    const bu = new Event("beforeunload", { cancelable: true });
    window.dispatchEvent(bu);
    if (!bu.defaultPrevented) return fail("beforeunload", "unload was not blocked with unsaved tabs");
    let leaveP = confirmLeave("close");
    await sleep(80);
    const lh = Array.from(document.querySelectorAll(".modal h3")).find(x => /2 documents have unsaved changes/.test(x.textContent));
    if (!lh || document.querySelectorAll(".leave-list li").length !== 2) return fail("leave-prompt", "combined prompt missing: " + (lh && lh.textContent));
    Array.from(document.querySelectorAll(".modal .btn")).find(b => b.textContent === "Cancel").click();
    if (await leaveP !== false) return fail("leave-cancel", "Cancel did not keep the window open");
    // Android Back on Home asks too
    activateTab(null);
    if (!backFromHome()) return fail("android-back", "Back on Home with unsaved tabs was not intercepted");
    await sleep(80);
    if (!document.querySelector(".modal-wrap .leave-list")) return fail("android-back-prompt", "no prompt on Back");
    cancelModal(document.querySelector(".modal-wrap"));
    await sleep(50);
    // "Don't save" closes the recovered document and forgets its recovery copy
    activateTab(rtab);
    closeDocTab(rtab);
    await sleep(60);
    Array.from(document.querySelectorAll(".modal .btn")).find(b => /Don't save/.test(b.textContent)).click();
    for (let i = 0; i < 20 && await idbGet("uitest-ghost"); i++) await sleep(100);
    if (docTabs.includes(rtab) || await idbGet("uitest-ghost")) return fail("recover-discard", "recovered tab or its entry survived Don't save");
    activateTab(ptab);
    steps.push("recovery");
    // ---- v3.5.1: Save writes in place on desktop, Save As picks a new file (main process mocked) ----
    const realApi = window.pdeskAPI;
    const calls = [];
    window.pdeskAPI = {
      saveFile: async p => { calls.push({ kind: "inplace", path: p.path, n: p.data.byteLength }); return { ok: true, path: p.path }; },
      saveAs: async p => { calls.push({ kind: "saveas", name: p.name, from: p.path, n: p.data.byteLength }); return { ok: true, path: "/home/u/Documents/renamed.pdf", name: "renamed.pdf" }; },
    };
    try {
      ptab.rec.path = "/home/u/Documents/uitest-pages.pdf";
      key("s", { ctrlKey: true });
      for (let i = 0; i < 40 && tabDirty(ptab); i++) await sleep(100);
      if (tabDirty(ptab) || calls.length !== 1 || calls[0].kind !== "inplace" || calls[0].path !== ptab.rec.path || calls[0].n !== ptab.rec.size)
        return fail("save-inplace", JSON.stringify(calls));
      if (await idbGet(ptab.key)) return fail("save-drops-recovery", "recovery entry kept after Save");
      const tt = document.querySelector('.doctabs .dt[data-tab="' + ptab.id + '"]');
      if (!tt || tt.title !== "/home/u/Documents/uitest-pages.pdf") return fail("tab-tooltip", "tab tooltip: " + (tt && tt.title));
      key("S", { ctrlKey: true, shiftKey: true });
      for (let i = 0; i < 40 && calls.length < 2; i++) await sleep(100);
      await sleep(100);
      if (calls.length !== 2 || calls[1].kind !== "saveas" || calls[1].from !== "/home/u/Documents/uitest-pages.pdf") return fail("save-as", JSON.stringify(calls));
      if (ptab.rec.name !== "renamed.pdf" || ptab.rec.path !== "/home/u/Documents/renamed.pdf" || !document.querySelector('.doctabs .dt[title="/home/u/Documents/renamed.pdf"]'))
        return fail("save-as-rename", "tab now " + ptab.rec.name + " @ " + ptab.rec.path);
      // Windows: Home offers the way to Settings > Default apps
      let opened = 0;
      window.pdeskAPI.platform = "win32";
      window.pdeskAPI.openDefaultApps = async () => { opened++; return { ok: true }; };
      const wbox = h("div");
      buildWelcome(wbox);
      const defB = Array.from(wbox.querySelectorAll(".dh-default button")).find(b => /Make AtoB PDF your PDF app/.test(b.textContent));
      if (!defB) return fail("default-app-hint", "no default-app button on the Windows Home");
      defB.click();
      await sleep(50);
      if (opened !== 1) return fail("default-app-open", "Settings was not opened");
      window.pdeskAPI.platform = "darwin";
      const mbox = h("div"); buildWelcome(mbox);
      if (mbox.querySelector(".dh-default")) return fail("default-app-mac", "hint shown outside Windows");
    } finally {
      if (realApi) window.pdeskAPI = realApi; else delete window.pdeskAPI;
      delete ptab.rec.path;
    }
    steps.push("save-inplace");
    // edit again so the close prompt below has something to ask about
    pane.querySelector(".vundo").click();
    for (let i = 0; i < 60 && !tabDirty(ptab); i++) await sleep(100);
    await idle();
    rdb.close();
    // closing an unsaved tab asks first; "Don't save" closes it
    document.querySelector('.doctabs .dt.on .dt-x').click();
    await sleep(60);
    const dont = Array.from(document.querySelectorAll(".modal .btn")).find(b => /Don't save/.test(b.textContent));
    if (!dont) return fail("close-prompt", "no save prompt for an unsaved tab");
    dont.click();
    await sleep(100);
    if (docTabs.includes(ptab) || docTabs.length !== tabsBefore) return fail("close-tab", "tab still open");
    steps.push("close-tab");
    }
    // ---- v3.6: ⌘K palette, shortcuts sheet, side panels with badges, notices, theme ----
    {
      const key = (k, o) => document.body.dispatchEvent(new KeyboardEvent("keydown", Object.assign({ key: k, bubbles: true, cancelable: true }, o)));
      const pkey = (k, o) => document.querySelector(".cmdk-input").dispatchEvent(new KeyboardEvent("keydown", Object.assign({ key: k, bubbles: true, cancelable: true }, o)));
      const typeQ = q => { const inp = document.querySelector(".cmdk-input"); inp.value = q; inp.dispatchEvent(new Event("input", { bubbles: true })); };
      // on Home: viewer commands are listed but disabled, with the reason
      activateTab(null);
      await sleep(100);
      if (document.activeElement && document.activeElement.blur) document.activeElement.blur();
      key("k", { ctrlKey: true });
      await sleep(80);
      if (!document.querySelector(".cmdk-wrap .cmdk-input")) return fail("palette-open", "Ctrl+K did not open the palette");
      typeQ("print");
      await sleep(50);
      const pr = document.querySelector('.cmdk-row[data-id="doc.print"]');
      if (!pr || !pr.classList.contains("off") || !/viewer first/.test(pr.textContent)) return fail("palette-disabled", "print row: " + (pr && pr.outerHTML.slice(0, 200)));
      pkey("Escape");
      await sleep(50);
      if (document.querySelector(".cmdk-wrap")) return fail("palette-esc", "Esc did not close the palette");
      // open the rich test document: bookmarks, an attachment, form fields
      const rich = await uitestRichPdf();
      openDocTab(rich);
      const rtab2 = activeTab;
      for (let i = 0; i < 60 && !(rtab2.api && rtab2.api.counts && rtab2.api.counts().fields); i++) await sleep(100);
      const cnt = rtab2.api.counts();
      if (cnt.outline !== 3 || cnt.attach !== 1 || cnt.fields !== 2) return fail("panel-counts", JSON.stringify(cnt));
      const rp = document.querySelector(".docpane.on");
      const badges = ["outline", "attach", "fields"].filter(id => rp.querySelector('.vrail-btn[data-panel="' + id + '"]').classList.contains("has"));
      if (badges.length !== 3 || rp.querySelector('.vrail-btn[data-panel="pages"]').classList.contains("has")) return fail("badges", "badges on: " + badges);
      // notices: form first, then attachments
      const notice = () => { const m = rp.querySelector(".vmsg"); return m && !m.classList.contains("hidden") ? m.dataset.notice : null; };
      if (notice() !== "form" || !/2 form fields/.test(rp.querySelector(".vmsg-text").textContent)) return fail("notice-form", "notice " + notice() + " / " + rtab2.api.notices());
      rp.querySelector(".vmsg-x").click();
      await sleep(30);
      if (notice() !== "attach") return fail("notice-next", "after dismiss: " + notice());
      rp.querySelector(".vmsg-act").click();
      await sleep(60);
      if (rtab2.api.panel() !== "attach" || notice() !== null) return fail("notice-action", "panel " + rtab2.api.panel() + ", notice " + notice());
      let atRow = null;
      for (let i = 0; i < 30 && !atRow; i++) { await sleep(80); atRow = rp.querySelector('.vpanel[data-panel="attach"] .at-row'); }
      if (!atRow || !/rates\.csv/.test(atRow.textContent)) return fail("attachments", "row: " + (atRow && atRow.textContent));
      const realDl2 = downloadBytes; let dl2 = null;
      downloadBytes = (name, bytes) => { dl2 = { name, text: new TextDecoder().decode(bytes) }; return bytes.length; };
      try { Array.from(atRow.querySelectorAll(".btn")).find(b => b.textContent === "Save").click(); } finally { downloadBytes = realDl2; }
      if (!dl2 || dl2.name !== "rates.csv" || !/10,2/.test(dl2.text)) return fail("attachment-save", JSON.stringify(dl2));
      // bookmarks: tree, filter, jump
      const panelBtn = id => isMobile() ? rp.querySelector('.vs-tab[data-panel="' + id + '"]') : rp.querySelector('.vrail-btn[data-panel="' + id + '"]');
      if (isMobile()) rtab2.api.setPanel("pages");
      panelBtn("outline").click();
      let olRows = [];
      for (let i = 0; i < 30 && olRows.length < 5; i++) { await sleep(80); olRows = rp.querySelectorAll('.vpanel[data-panel="outline"] .ol-row'); }
      if (olRows.length !== 5) return fail("outline-tree", "rows " + olRows.length);
      const filt = rp.querySelector('.vpanel[data-panel="outline"] .vp-search');
      filt.value = "terms"; filt.dispatchEvent(new Event("input", { bubbles: true }));
      await sleep(30);
      const fr = Array.from(rp.querySelectorAll('.vpanel[data-panel="outline"] .ol-row')).map(r => r.querySelector(".ol-t").textContent);
      if (fr.join("|") !== "Chapter 1|Section 1.2 Terms") return fail("outline-filter", fr.join("|"));
      rp.querySelectorAll('.vpanel[data-panel="outline"] .ol-row')[1].click();
      for (let i = 0; i < 30 && rp.querySelector(".pageinfo input").value !== "2"; i++) await sleep(80);
      if (rp.querySelector(".pageinfo input").value !== "2") return fail("outline-jump", "page " + rp.querySelector(".pageinfo input").value);
      // form fields: list, click flashes the field
      if (isMobile()) rtab2.api.setPanel("pages");
      panelBtn("fields").click();
      let fdRows = [];
      for (let i = 0; i < 40 && fdRows.length < 2; i++) { await sleep(80); fdRows = rp.querySelectorAll('.vpanel[data-panel="fields"] .fd-row'); }
      if (fdRows.length !== 2 || !/tenant\.name/.test(fdRows[0].textContent) || !/Ahmed/.test(fdRows[0].textContent)) return fail("fields-panel", Array.from(fdRows).map(r => r.textContent).join(" / "));
      fdRows[0].click();
      let fl = null;
      for (let i = 0; i < 30 && !fl; i++) { await sleep(80); fl = rp.querySelector('.vpage[data-i="2"] .vflash'); }
      if (!fl) return fail("fields-jump", "no highlight on page 3");
      // palette runs viewer commands: fuzzy "rot clock" + Enter rotates; "3" goes to page 3
      rtab2.api.setPanel(isMobile() ? "" : "pages");
      if (document.activeElement && document.activeElement.blur) document.activeElement.blur();
      key("k", { metaKey: true });
      await sleep(60);
      typeQ("rot clock");
      await sleep(40);
      const first = document.querySelector(".cmdk-row.sel");
      if (!first || first.dataset.id !== "page.rotcw") return fail("palette-fuzzy", "top hit " + (first && first.dataset.id));
      pkey("Enter");
      for (let i = 0; i < 60 && !rtab2.hist.depth; i++) await sleep(100);
      if (rtab2.hist.depth !== 1 || !/^Rotate (page \d+|\d+ pages) clockwise$/.test(rtab2.hist.undoLabel)) return fail("palette-run", "history: " + rtab2.hist.undoLabel);
      for (let i = 0; i < 40 && rp.classList.contains("busy"); i++) await sleep(50);
      openPalette("1");
      await sleep(40);
      if (document.querySelector(".cmdk-row.sel").dataset.id !== "goto:1") return fail("palette-goto", "top hit " + document.querySelector(".cmdk-row.sel").dataset.id);
      pkey("Enter");
      for (let i = 0; i < 30 && rp.querySelector(".pageinfo input").value !== "1"; i++) await sleep(80);
      if (rp.querySelector(".pageinfo input").value !== "1") return fail("palette-goto-run", "page " + rp.querySelector(".pageinfo input").value);
      // recently used commands lead the list when the box is empty
      openPalette();
      await sleep(40);
      const firstGroup = document.querySelector(".cmdk-group");
      if (!firstGroup || firstGroup.textContent !== "Recently used" || document.querySelector(".cmdk-row").dataset.id !== "page.rotcw") return fail("palette-recent", (firstGroup && firstGroup.textContent) + " / " + document.querySelector(".cmdk-row").dataset.id);
      closePalette();
      // shortcuts sheet from the registry
      key("/", { ctrlKey: true });
      await sleep(60);
      const sheet = document.querySelector(".modal.kbd-dlg");
      if (!sheet || !/Save as/.test(sheet.textContent) || !sheet.querySelector("kbd")) return fail("shortcuts", "sheet missing");
      cancelModal(document.querySelector(".modal-wrap"));
      // theme: dark is an explicit choice, pages are not inverted, system is the default again
      const bg0 = getComputedStyle(document.body).backgroundColor;
      setTheme("dark");
      const bg1 = getComputedStyle(document.body).backgroundColor;
      const cv = rp.querySelector(".vpage canvas");
      if (document.documentElement.dataset.theme !== "dark" || bg0 === bg1 || (cv && getComputedStyle(cv).filter !== "none")) return fail("theme-dark", bg0 + " -> " + bg1);
      setTheme("system");
      if (document.documentElement.hasAttribute("data-theme")) return fail("theme-system", "data-theme still set");
      if (isMobile()) {
        activateTab(null);
        await sleep(100);
        const ms = document.querySelector(".mh-search");
        if (!ms || !document.querySelector(".mh-theme svg")) return fail("mobile-home-search", "search field or theme button missing on Home");
        ms.click();
        await sleep(60);
        if (!document.querySelector(".cmdk-wrap.full")) return fail("mobile-palette", "Home search did not open the palette");
        closePalette();
      } else if (!document.querySelector(".dt-tools .dt-search") || !document.querySelector(".dt-tools .theme-btn svg")) return fail("title-tools", "search / theme missing from the title bar");
      closeDocTab(rtab2, true);
      steps.push("palette", "panels", "notices", "theme");
    }
    // ---- v3.7: real comments (selection menu, tools, Comments panel), properties, merge bookmarks ----
    {
      const cd = await PDFLib.PDFDocument.create();
      const cf = await cd.embedFont(PDFLib.StandardFonts.Helvetica);
      const cp = cd.addPage([595, 842]);
      cp.drawText("Tenancy agreement: rent is due on the first of each month.", { x: 50, y: 760, size: 13, font: cf });
      cd.addPage([595, 842]);
      const cb = await cd.save();
      openDocTab({ name: "uitest-comments.pdf", size: cb.length, buf: cb.buffer.slice(cb.byteOffset, cb.byteOffset + cb.byteLength) });
      const ct = activeTab;
      const cpane = document.querySelector(".docpane.on");
      const cidle = async () => { await sleep(30); for (let i = 0; i < 100 && cpane.classList.contains("busy"); i++) await sleep(50); };
      let span = null;
      for (let i = 0; i < 60 && !span; i++) { await sleep(100); span = Array.from(cpane.querySelectorAll('.vpage[data-i="0"] .textLayer span')).find(x => /rent is due/.test(x.textContent)); }
      if (!span) return fail("comment-text", "text layer not ready");
      const tn = span.firstChild, at = tn.textContent.indexOf("rent is due");
      const rg = document.createRange(); rg.setStart(tn, at); rg.setEnd(tn, at + 11);
      getSelection().removeAllRanges(); getSelection().addRange(rg);
      let hlBtn = null;
      for (let i = 0; i < 30 && !hlBtn; i++) { await sleep(100); const m = cpane.querySelector(".vselmenu:not(.hidden) [data-act='highlight']"); if (m) hlBtn = m; }
      if (!hlBtn) return fail("selmenu", "no menu over the selected text");
      hlBtn.click();
      for (let i = 0; i < 60 && !ct.hist.depth; i++) await sleep(100);
      await cidle();
      if (!/^Highlight text on page 1$/.test(ct.hist.undoLabel)) return fail("highlight", "step: " + ct.hist.undoLabel);
      // tools: box (drag), stamp (click), note (click + text)
      const hd = () => cpane.querySelector('.vpage[data-i="0"]');
      const hr = hd().getBoundingClientRect();
      ct.api.annotTool("box");
      const target = hd().querySelector("canvas") || hd();
      pe(target, "pointerdown", hr.left + hr.width * 0.15, hr.top + hr.height * 0.3);
      pe(cpane.querySelector(".viewer-pages"), "pointermove", hr.left + hr.width * 0.3, hr.top + hr.height * 0.35);
      pe(cpane.querySelector(".viewer-pages"), "pointermove", hr.left + hr.width * 0.45, hr.top + hr.height * 0.4);
      pe(cpane.querySelector(".viewer-pages"), "pointerup", hr.left + hr.width * 0.45, hr.top + hr.height * 0.4);
      for (let i = 0; i < 60 && ct.hist.depth < 2; i++) await sleep(100);
      await cidle();
      ct.api.annotTool("stamp");
      pe(hd().querySelector("canvas") || hd(), "pointerdown", hr.left + hr.width * 0.6, hr.top + hr.height * 0.6);
      for (let i = 0; i < 60 && ct.hist.depth < 3; i++) await sleep(100);
      await cidle();
      ct.api.annotTool("note");
      pe(hd().querySelector("canvas") || hd(), "pointerdown", hr.left + hr.width * 0.8, hr.top + hr.height * 0.2);
      let ta = null;
      for (let i = 0; i < 20 && !ta; i++) { await sleep(60); ta = document.querySelector(".modal .va-note-input"); }
      if (!ta) return fail("note-prompt", "no note box");
      ta.value = "Check the due date";
      Array.from(document.querySelectorAll(".modal .btn")).find(b => b.textContent === "Save").click();
      for (let i = 0; i < 60 && ct.hist.depth < 4; i++) await sleep(100);
      await cidle();
      ct.api.comment(false);
      const kinds = PDCore.listAnnots(await loadMuPDF(), bytesOf(ct.rec)).map(c => c.kind).sort().join(",");
      if (kinds !== "box,highlight,note,stamp") return fail("annots-in-file", kinds + " / steps " + ct.hist.depth);
      // Comments panel: list, edit, delete, undo
      ct.api.setPanel("comments");
      let rows = [];
      for (let i = 0; i < 40 && rows.length < 4; i++) { await sleep(100); rows = cpane.querySelectorAll('.vpanel[data-panel="comments"] .cm-row'); }
      if (rows.length !== 4) return fail("comments-panel", "rows " + rows.length);
      if (!cpane.querySelector('.vrail-btn[data-panel="comments"]').classList.contains("has")) return fail("comments-badge", "no badge");
      const noteRow = Array.from(rows).find(r => r.dataset.kind === "note");
      if (!/Check the due date/.test(noteRow.textContent)) return fail("comments-note", noteRow.textContent);
      Array.from(noteRow.querySelectorAll(".textbtn")).find(b => b.textContent === "Edit").click();
      for (let i = 0; i < 20 && !document.querySelector(".modal .va-note-input"); i++) await sleep(60);
      document.querySelector(".modal .va-note-input").value = "Due on the 1st";
      Array.from(document.querySelectorAll(".modal .btn")).find(b => b.textContent === "Save").click();
      for (let i = 0; i < 60 && ct.hist.depth < 5; i++) await sleep(100);
      await cidle();
      let nr = null;
      for (let i = 0; i < 40 && !nr; i++) { await sleep(80); nr = Array.from(cpane.querySelectorAll('.vpanel[data-panel="comments"] .cm-row')).find(r => /Due on the 1st/.test(r.textContent)); }
      if (!nr) return fail("comments-edit", "edited text not shown");
      const boxRow = Array.from(cpane.querySelectorAll('.vpanel[data-panel="comments"] .cm-row')).find(r => r.dataset.kind === "box");
      boxRow.querySelector(".cm-del").click();
      for (let i = 0; i < 60 && ct.hist.depth < 6; i++) await sleep(100);
      await cidle();
      let left = 0;
      for (let i = 0; i < 40; i++) { await sleep(80); left = cpane.querySelectorAll('.vpanel[data-panel="comments"] .cm-row').length; if (left === 3) break; }
      if (left !== 3) return fail("comments-delete", "rows after delete " + left);
      ct.api.undo ? ct.api.undo() : null;
      for (let i = 0; i < 60 && ct.hist.depth > 5; i++) await sleep(100);
      await cidle();
      for (let i = 0; i < 40; i++) { await sleep(80); left = cpane.querySelectorAll('.vpanel[data-panel="comments"] .cm-row').length; if (left === 4) break; }
      if (left !== 4) return fail("comments-undo", "rows after undo " + left);
      steps.push("comments");
      // Document properties (Ctrl+D): read fonts, save a new title as an undoable step
      ct.api.setPanel(isMobile() ? "" : "pages");
      if (document.activeElement && document.activeElement.blur) document.activeElement.blur();
      document.body.dispatchEvent(new KeyboardEvent("keydown", { key: "d", ctrlKey: true, bubbles: true, cancelable: true }));
      let props = null;
      for (let i = 0; i < 40 && !props; i++) { await sleep(80); props = document.querySelector(".modal.props-dlg"); }
      if (!props || !/Helvetica/.test(props.textContent) || !/Not embedded/.test(props.textContent) || !/A4/.test(props.textContent)) return fail("props", props ? props.textContent.slice(0, 200) : "dialog missing");
      props.querySelector('[data-key="Title"]').value = "Lease – Camp 7";
      Array.from(props.querySelectorAll(".btn")).find(b => /Save description/.test(b.textContent)).click();
      for (let i = 0; i < 60 && ct.hist.undoLabel !== "Edit document properties"; i++) await sleep(100);
      await cidle();
      const inf = await PDCore.docInfo(bytesOf(ct.rec));
      if (inf.title !== "Lease – Camp 7") return fail("props-save", "title " + inf.title);
      closeDocTab(ct, true);
      steps.push("properties");
      // Merge keeps bookmarks: two outlined files → one entry per file
      const m1 = await uitestRichPdf(), m2 = await uitestRichPdf();
      m1.name = "First.pdf"; m2.name = "Second.pdf";
      showView("merge", [m1, m2]);
      let mgo = null;
      for (let i = 0; i < 40 && !mgo; i++) { await sleep(100); const b = Array.from(document.querySelectorAll(".actionbar .btn.primary")).find(x => /Merge/.test(x.textContent)); if (b && !b.disabled) mgo = b; }
      if (!mgo || !document.querySelector(".merge-opts:not(.hidden) input")) return fail("merge-ui", "merge button or bookmark option missing");
      const realDl3 = downloadBytes; let mout = null;
      downloadBytes = (name, bytes) => { mout = bytes; return bytes.length; };
      try {
        mgo.click();
        let rb = null;
        for (let i = 0; i < 80 && !rb; i++) { await sleep(100); rb = document.querySelector(".result .btn.primary"); }
        if (!rb) return fail("merge-run", "no result");
        rb.click();
      } finally { downloadBytes = realDl3; }
      const mdoc = await PDFLib.PDFDocument.load(mout);
      const mol = PDCore.readOutline(mdoc);
      if (mol.map(o => o.title).join("|") !== "First|Second" || mol[1].items.length !== 3 || mdoc.getPages().findIndex(p => p.ref === mol[1].items[1].dest.get(0)) !== 4) return fail("merge-bookmarks", JSON.stringify(mol.map(o => [o.title, o.items.length])));
      steps.push("merge-bookmarks");
    }
    // ---- v3.5.1: PDF -> Excel from the Convert group ----
    {
      const td = await PDFLib.PDFDocument.create();
      const tf = await td.embedFont(PDFLib.StandardFonts.Helvetica);
      const tp = td.addPage([595, 842]);
      [["Item", "Qty", "Amount"], ["Diesel", "40", "1,250.00"], ["Water", "12", "96.50"]].forEach((r, i) =>
        r.forEach((c, j) => tp.drawText(c, { x: [60, 260, 420][j], y: 760 - i * 22, size: 11, font: tf })));
      const tb = await td.save();
      setWorkspaceFile({ name: "uitest-table.pdf", size: tb.length, buf: tb.buffer.slice(tb.byteOffset, tb.byteOffset + tb.byteLength) }, "toexcel");
      const xlTab = activeTab;
      if (!document.querySelector('.side-item[data-tool="toexcel"]') && !isMobile()) return fail("excel-nav", "PDF to Excel missing from the sidebar");
      let go = null;
      for (let i = 0; i < 40 && !go; i++) { await sleep(100); go = Array.from(document.querySelectorAll(".actionbar .btn.primary")).find(b => /Convert to Excel/.test(b.textContent)); }
      if (!go) return fail("excel-open", "Convert to Excel button missing");
      const realDl = downloadBytes;
      let got = null;
      downloadBytes = (name, bytes) => { got = { name, bytes }; return bytes.length; };
      try {
        go.click();
        let dl = null;
        for (let i = 0; i < 100 && !dl; i++) { await sleep(150); dl = document.querySelector(".result .btn.primary"); }
        if (!dl) return fail("excel-run", "no result: " + (document.querySelector(".view") || document.body).textContent.slice(0, 160));
        dl.click();
      } finally { downloadBytes = realDl; }
      if (!got || got.name !== "uitest-table.xlsx") return fail("excel-file", "download: " + (got && got.name));
      const xf = await PDCore.unzipBytes(new Uint8Array(got.bytes));
      const sx = new TextDecoder().decode(xf["xl/worksheets/sheet1.xml"] || new Uint8Array());
      if (!/<c r="C2" s="2"><v>1250<\/v>/.test(sx) || !/>Diesel</.test(sx) || !/<c r="B3"><v>12<\/v>/.test(sx)) return fail("excel-cells", sx.slice(0, 300));
      steps.push("pdf-to-excel");
      closeDocTab(xlTab, true);
    }
    report("UITEST:PASS:" + steps.join(","));
  } catch (e) {
    fail("crash", (e && e.message || e) + " @ " + steps.join(","));
  }
}
window.PDUITest = runUITest;

/* ---------------- boot ---------------- */
function boot() {
  pdfjsLib.GlobalWorkerOptions.workerSrc = "pdfdesk.worker.inline";
  const app = document.getElementById("app");
  const main = h("main", { class: "main" }, tabStrip, viewRoot, docHost);
  renderTabs();
  app.append(h("div", { class: "shell" }, buildSidebar(), main), buildTabBar(), toastHost, pickerInput);
  setupGlobalDrop();
  registerCoreCommands();
  registerToolCommands();
  showView("welcome");
  if (MOBILE_MQ.addEventListener) MOBILE_MQ.addEventListener("change", () => {
    const id = currentView && currentView.id;
    if (id === "welcome" || id === "mhome" || id === "tools") showView("home");
  });
  // Native desktop shell bridge (Electron): receive files opened via
  // double-click / "Open with" and load them straight into the workspace.
  /* v3.5.1: don't let a closing browser tab / window take unsaved edits with it */
  window.addEventListener("beforeunload", e => {
    if (leavingApp || !docTabs.some(tabDirty)) return;
    if (!window.pdeskAPI) Recovery.flush();      // plain HTML: keep a copy even if the user leaves
    e.preventDefault();
    e.returnValue = "";
    return "";
  });
  Recovery.start();
  setTimeout(() => Recovery.offer(), 400);
  if (window.pdeskAPI) {
    if (typeof window.pdeskAPI.onCloseRequest === "function") {
      window.pdeskAPI.onCloseRequest(async info => {
        const ok = await confirmLeave(info && info.quitting ? "quit" : "close");
        if (ok) leavingApp = true;
        window.pdeskAPI.closeReply(ok);
      });
    }
    if (typeof window.pdeskAPI.onMenuCommand === "function") window.pdeskAPI.onMenuCommand(onMenuCommand);
    const handleBatch = list => {
      try {
        const recs = list.map(f => { const r = { name: f.name, size: f.data.byteLength, buf: f.data }; if (f.path) r.path = f.path; return r; });
        if (recs.length > 1) { showView("merge", recs); toast(recs.length + " PDFs ready to merge"); }
        else if (recs.length === 1) { setWorkspaceFile(recs[0]); toast("Opened " + recs[0].name); }
      } catch (e) { toast("Could not open the dropped files", "err"); }
    };
    if (typeof window.pdeskAPI.onOpenFiles === "function") window.pdeskAPI.onOpenFiles(handleBatch);
    else if (typeof window.pdeskAPI.onOpenFile === "function") window.pdeskAPI.onOpenFile(f => handleBatch([f]));
    window.pdeskAPI.ready && window.pdeskAPI.ready();
  }
  if (window.PD_DEBUG && location.hash !== "#manual" && location.hash !== "#selftest") setTimeout(runUITest, 600);
  if (location.hash === "#selftest") {
    const pre = document.createElement("pre");
    pre.id = "selftest-out";
    pre.style.cssText = "position:fixed;top:12px;right:12px;width:min(520px,90vw);max-height:88vh;overflow:auto;z-index:999;background:#141311;color:#d9f2df;padding:14px 16px;border-radius:10px;font:12px/1.55 ui-monospace,Menlo,Consolas,monospace;box-shadow:0 12px 40px rgba(0,0,0,.4);white-space:pre-wrap";
    pre.textContent = "Self-test running…";
    document.body.append(pre);
    runSelfTest().then(r => {
      document.title = (r.pass ? "SELFTEST:PASS" : "SELFTEST:FAIL");
      pre.textContent = (r.pass ? "SELFTEST: ALL PASS\n\n" : "SELFTEST: FAILURES\n\n") +
        r.results.map(x => (x.ok ? "ok   " : "FAIL ") + x.name + (x.err ? "\n     " + x.err : "")).join("\n");
      if (!r.pass) pre.style.color = "#f2c8c2";
    }).catch(e => {
      document.title = "SELFTEST:CRASH";
      pre.textContent = "CRASH " + (e && e.stack || e);
      pre.style.color = "#f2c8c2";
    });
  }
}
document.addEventListener("DOMContentLoaded", boot);
