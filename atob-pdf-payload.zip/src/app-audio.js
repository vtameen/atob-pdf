/* AtoB PDF v3.4 — audio reader: TTS engines, page text models, OCR-on-demand,
   the shared playback controller and its player bar. Used by the normal viewer
   and by the Kindle-style reader (app-reader.js). */
"use strict";

Object.assign(ICONS, {
  headphones: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 15v-3a8 8 0 0 1 16 0v3"/><rect x="3" y="14" width="4.5" height="7" rx="1.6"/><rect x="16.5" y="14" width="4.5" height="7" rx="1.6"/></svg>',
  play: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M8 5.5v13a1 1 0 0 0 1.5.9l10.2-6.5a1 1 0 0 0 0-1.7L9.5 4.6A1 1 0 0 0 8 5.5z"/></svg>',
  pause: '<svg viewBox="0 0 24 24" fill="currentColor"><rect x="6.5" y="5" width="4" height="14" rx="1.2"/><rect x="13.5" y="5" width="4" height="14" rx="1.2"/></svg>',
  sprev: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6 11 12l7 6z" fill="currentColor"/><path d="M7 6v12"/></svg>',
  snext: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m6 6 7 6-7 6z" fill="currentColor"/><path d="M17 6v12"/></svg>',
  pprev: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M13 7l-5 5 5 5"/><path d="M19 7l-5 5 5 5"/></svg>',
  pnext: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="m11 7 5 5-5 5"/><path d="m5 7 5 5-5 5"/></svg>',
  sliders: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M4 7h10M18 7h2M4 17h4M12 17h8"/><circle cx="16" cy="7" r="2"/><circle cx="10" cy="17" r="2"/></svg>',
  moonz: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M19 14.5A7.5 7.5 0 0 1 9.5 5a7.5 7.5 0 1 0 9.5 9.5z"/><path d="M15 4h4l-4 4h4"/></svg>',
});

/* ---------------- speech engines ---------------- */
const nativeListeners = new Set();
window.__atobNative = evt => { for (const fn of Array.from(nativeListeners)) { try { fn(evt); } catch (e) {} } };

class WebTTS {
  constructor() { this.kind = "web"; this.onevent = null; this._keep = null; this._byId = new Map(); }
  async ready() { return "speechSynthesis" in window; }
  async voices() {
    const ss = window.speechSynthesis;
    let v = ss.getVoices();
    if (!v.length) {
      await new Promise(res => {
        const t = setTimeout(res, 1500);
        ss.addEventListener("voiceschanged", function once() { clearTimeout(t); ss.removeEventListener("voiceschanged", once); res(); });
      });
      v = ss.getVoices();
    }
    this._voices = v;
    return v.map(x => ({ id: x.voiceURI || x.name, name: x.name, lang: String(x.lang || "").replace("_", "-"), local: !!x.localService, installed: true, default: !!x.default }));
  }
  speak(items, o) {
    const ss = window.speechSynthesis;
    if (o.flush) ss.cancel();
    const go = () => {
      for (const it of items) {
        const u = new SpeechSynthesisUtterance(it.text);
        const vv = (this._voices || ss.getVoices()).find(x => (x.voiceURI || x.name) === it.voice);
        if (vv) u.voice = vv;
        u.lang = it.lang;
        u.rate = o.rate; u.pitch = o.pitch;
        const emit = (type, extra) => this.onevent && this.onevent(Object.assign({ type, id: it.id }, extra || {}));
        u.onstart = () => { emit("start"); this._keepAlive(vv); };
        u.onend = () => emit("done");
        u.onerror = e => { const er = e && e.error; if (er === "interrupted" || er === "canceled") emit("stop"); else emit("error", { error: er || "error" }); };
        u.onboundary = e => {
          if (e.name && e.name !== "word") return;
          let len = e.charLength;
          if (!len) { const m = it.text.slice(e.charIndex).match(/^[\p{L}\p{N}\p{M}'’‌‍]+/u); len = m ? m[0].length : 1; }
          emit("range", { start: e.charIndex, end: e.charIndex + len });
        };
        ss.speak(u);
      }
    };
    if (o.flush) setTimeout(go, 40); else go();
  }
  _keepAlive(v) {
    // Chrome desktop silently stops long network-voice utterances after ~15s
    clearInterval(this._keep);
    if (!v || v.localService || /Android/i.test(navigator.userAgent)) return;
    this._keep = setInterval(() => {
      const ss = window.speechSynthesis;
      if (!ss.speaking) { clearInterval(this._keep); return; }
      ss.pause(); ss.resume();
    }, 9000);
  }
  stop() { clearInterval(this._keep); try { window.speechSynthesis.cancel(); } catch (e) {} }
  langStatus() { return 0; }
}

class AndroidTTS {
  constructor() {
    this.kind = "android";
    this.onevent = null;
    this._ready = null;
    nativeListeners.add(evt => {
      if (evt && evt.type === "tts" && this.onevent) this.onevent({ type: evt.event === "stop" ? "stop" : evt.event, id: evt.id, start: evt.start, end: evt.end, error: evt.error });
    });
  }
  ready() {
    if (this._ready) return this._ready;
    this._ready = new Promise(resolve => {
      const t = setTimeout(() => resolve(false), 8000);
      const fn = evt => { if (evt && evt.type === "tts-ready") { clearTimeout(t); nativeListeners.delete(fn); resolve(!!evt.ok); } };
      nativeListeners.add(fn);
      try { window.AndroidBridge.ttsInit(); } catch (e) { resolve(false); }
    });
    this._ready.then(ok => { if (!ok) this._ready = null; });
    return this._ready;
  }
  async voices() {
    if (!(await this.ready())) return [];
    try { return JSON.parse(window.AndroidBridge.ttsVoices() || "[]"); } catch (e) { return []; }
  }
  speak(items, o) {
    const r = window.AndroidBridge.ttsSpeak(JSON.stringify({ flush: !!o.flush, rate: o.rate, pitch: o.pitch, items }));
    if (r && /^error|not-ready/.test(r) && this.onevent) this.onevent({ type: "error", id: items[0] && items[0].id, error: r });
  }
  stop() { try { window.AndroidBridge.ttsStop(); } catch (e) {} }
  langStatus(tag) { try { return window.AndroidBridge.ttsLangStatus(tag); } catch (e) { return 0; } }
  openSettings() { try { window.AndroidBridge.ttsOpenSettings(); } catch (e) {} }
  installData() { try { window.AndroidBridge.ttsInstallData(); } catch (e) {} }
}

class NullTTS {
  constructor() { this.kind = "none"; this.onevent = null; }
  async ready() { return false; }
  async voices() { return []; }
  speak() {}
  stop() {}
  langStatus() { return 2; }
}

let _tts = null;
function ttsEngine() {
  if (_tts) return _tts;
  if (window.__atobTTSOverride) _tts = window.__atobTTSOverride;            // tests
  else if (window.AndroidBridge && typeof window.AndroidBridge.ttsSpeak === "function") _tts = new AndroidTTS();
  else if ("speechSynthesis" in window && window.SpeechSynthesisUtterance) _tts = new WebTTS();
  else _tts = new NullTTS();
  return _tts;
}

/* ---- voices per language ---- */
const VOICE_KEY = "atob.voice.";
function lsGet(k, d) { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } }
function lsSet(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }
function voicesFor(lang, voices) {
  const code = (PDCore.LANG_INFO[lang] || { bcp: lang }).bcp.toLowerCase();
  return voices.filter(v => { const l = String(v.lang || "").toLowerCase(); return l === code || l.startsWith(code + "-") || l.startsWith(code + "_"); });
}
function pickVoice(lang, voices) {
  const list = voicesFor(lang, voices).filter(v => v.installed !== false);
  if (!list.length) return null;
  const saved = lsGet(VOICE_KEY + lang, null);
  const hit = saved && list.find(v => v.id === saved);
  if (hit) return hit;
  const score = v => (v.local ? 4 : 0) + (v.default ? 2 : 0) + (/en-(US|GB)/i.test(v.lang) ? 1 : 0) + (v.quality || 0) / 1000 +
    (/natural|neural|premium|enhanced|google/i.test(v.name) ? 1.5 : 0);
  return list.slice().sort((a, b) => score(b) - score(a))[0];
}
function setVoicePref(lang, id) { lsSet(VOICE_KEY + lang, id || null); }

/* ---------------- page text models ---------------- */
function pdfjsRuns(tc, vp1) {
  const runs = [];
  tc.items.forEach((it, k) => {
    if (typeof it.str !== "string") return;
    const tx = pdfjsLib.Util.transform(vp1.transform, it.transform);
    const hgt = Math.hypot(tx[2], tx[3]) || 10;
    const vertical = Math.abs(tx[1]) > Math.abs(tx[0]) * 2;
    const w = vertical ? hgt : (it.width * vp1.scale || it.str.length * hgt * 0.5);
    runs.push({ str: it.str, x: tx[4], y: tx[5] - hgt, w, h: hgt, eol: !!it.hasEOL, size: hgt, font: it.fontName, src: k });
  });
  return runs;
}
async function pdfjsPageModel(doc, i) {
  const page = await doc.getPage(i + 1);
  const vp1 = page.getViewport({ scale: 1 });
  const tc = await page.getTextContent();
  const m = PDCore.buildPageText(pdfjsRuns(tc, vp1));
  m.w = vp1.width; m.h = vp1.height; m.source = "pdfjs"; m.tc = tc;
  return finishModel(m);
}
function mupdfPageModel(mdoc, i) {
  const page = mdoc.loadPage(i);
  let res;
  try {
    const stp = page.toStructuredText("preserve-whitespace");
    try { res = PDCore.stextWordRuns(stp); } finally { try { stp.destroy(); } catch (e) {} }
  } finally { }
  const b = page.getBounds();
  try { page.destroy(); } catch (e) {}
  const m = PDCore.buildPageText(res.runs);
  m.w = b[2] - b[0]; m.h = b[3] - b[1]; m.source = "mupdf";
  return finishModel(m);
}
/* MuPDF gives far better text than pdf.js for Indic scripts and RTL ligatures;
   open it lazily for reading (null when not embedded / locked / mismatched) */
async function openMupdfForText(rec, pageCount) {
  if (!(ASSETS().mupdfWasm)) return null;
  try {
    const mupdf = await loadMuPDF();
    const d = mupdf.Document.openDocument(bytesOf(rec), "application/pdf");
    if ((d.needsPassword && d.needsPassword()) || d.countPages() !== pageCount) { try { d.destroy(); } catch (e) {} return null; }
    return d;
  } catch (e) { return null; }
}
function finishModel(m) {
  m.sentences = PDCore.sentencesWithLang(m.text, m.lang || "en");
  m.words = PDCore.countWords(m.text);
  return m;
}

/* ---- OCR on demand (scanned pages, garbled legacy-font text) ---- */
const OCR_LANGS = ["eng", "ara", "urd", "hin", "mal", "tam"];
const OCR_TO_LANG = { eng: "en", ara: "ar", urd: "ur", hin: "hi", mal: "ml", tam: "ta" };
function ocrLangsAvailable() { const L = ASSETS().langs || {}; return OCR_LANGS.filter(l => L[l]).concat(Object.keys(L).filter(l => !OCR_LANGS.includes(l))); }
let _ocrWorker = null, _ocrKey = "";
async function ocrWorkerFor(langs) {
  const key = langs.slice().sort().join("+");
  if (_ocrWorker && _ocrKey === key) return _ocrWorker;
  if (_ocrWorker) { try { await _ocrWorker.terminate(); } catch (e) {} _ocrWorker = null; }
  _ocrWorker = await createTessWorker(langs.join("+"), null);
  _ocrKey = key;
  return _ocrWorker;
}
async function releaseOcrWorker() { if (_ocrWorker) { const w = _ocrWorker; _ocrWorker = null; _ocrKey = ""; try { await w.terminate(); } catch (e) {} } }
function tsvToRuns(tsv, dpi) {
  const k = 72 / dpi, words = [];
  for (const line of String(tsv || "").split("\n")) {
    const c = line.split("\t");
    if (c.length < 12 || c[0] !== "5") continue;
    const text = c.slice(11).join("\t").trim();
    if (!text || parseFloat(c[10]) < 15) continue;
    words.push({ key: c[2] + "." + c[3] + "." + c[4], str: text, x: +c[6] * k, y: +c[7] * k, w: +c[8] * k, h: +c[9] * k });
  }
  const runs = [];
  words.forEach((w, i) => {
    const next = words[i + 1];
    runs.push({ str: (next && next.key === w.key) ? w.str + " " : w.str, x: w.x, y: w.y, w: w.w, h: w.h, eol: !next || next.key !== w.key, size: w.h });
  });
  return runs;
}
async function ocrPageModel(pdfDoc, i, langs, onProgress) {
  const dpi = 250;
  const r = await renderPageToCanvas(pdfDoc, i + 1, 0, { dpi });
  onProgress && onProgress(0.3);
  const worker = await ocrWorkerFor(langs);
  onProgress && onProgress(0.5);
  const res = await worker.recognize(r.canvas, {}, { text: true, tsv: true });
  r.canvas.width = 1; r.canvas.height = 1;
  const srcRuns = tsvToRuns(res.data.tsv, dpi);
  const m = PDCore.buildPageText(srcRuns, { fixOrder: false, ocr: true });
  m.srcRuns = srcRuns;
  const page = await pdfDoc.getPage(i + 1);
  const vp1 = page.getViewport({ scale: 1 });
  m.w = vp1.width; m.h = vp1.height; m.source = "ocr"; m.ocrLangs = langs.slice();
  return finishModel(m);
}
/* ask which languages to OCR with. reason: "scan" | "garbled" */
function offerOcr(reason, suggestLang) {
  return new Promise(resolve => {
    const avail = ocrLangsAvailable();
    if (!avail.length || typeof Tesseract === "undefined") {
      showModal({ title: reason === "scan" ? "This page is a scan" : "This text can't be read aloud",
        body: h("p", null, "The OCR engine isn't included in this build, so scanned or legacy-font pages can't be read."),
        actions: [{ label: "OK", primary: true, onClick: c => { c(); resolve(null); } }] });
      return;
    }
    const remembered = lsGet("atob.ocr.langs", ["eng"]);
    const sug = suggestLang ? (PDCore.LANG_INFO[suggestLang] || {}).ocr : null;
    const pre = new Set(sug ? [sug] : remembered);
    if (!pre.size) pre.add("eng");
    const checks = avail.map(l => ({ l, c: checkbox(LANG_NAMES[l] || l, pre.has(l)) }));
    let done = false;
    const finish = (v, close) => { if (done) return; done = true; close(); resolve(v); };
    showModal({
      title: reason === "scan" ? "This page looks like a scan" : "This page's text is garbled",
      dismissable: false,
      body: h("div", null,
        h("p", null, reason === "scan"
          ? "There's no text layer to read. AtoB PDF can recognise the text with OCR first — on this device, a few seconds per page."
          : "The PDF uses a legacy font" + (sug ? " (it looks like " + (LANG_NAMES[sug] || sug) + ")" : "") + ", so the stored text is gibberish. Read it with OCR instead?"),
        h("div", { class: "opt-label" }, "Languages on the page"),
        h("div", { class: "opt-row ocr-langs" }, checks.map(x => x.c.el))),
      actions: [
        { label: "Not now", onClick: c => finish(null, c) },
        { label: "Read with OCR", primary: true, onClick: c => {
          const langs = checks.filter(x => x.c.get()).map(x => x.l);
          if (!langs.length) { toast("Pick at least one language"); return; }
          lsSet("atob.ocr.langs", langs);
          finish(langs, c);
        } },
      ],
    });
  });
}

/* ---------------- playback controller ----------------
   host: {
     pageCount, title,
     getPage(i)        -> Promise<model|null>   (text model with .sentences)
     showPage(i)       -> Promise               (auto page turn)
     highlight(i, sentRange|null, wordRange|null)
     currentPage()     -> int
     needsOcr(i, model)-> Promise<model|null>   (host offers OCR; null = skip)
   } */
const SPEED_KEY = "atob.tts.rate", PITCH_KEY = "atob.tts.pitch";
class AudioReader {
  constructor(host) {
    this.host = host;
    this.engine = ttsEngine();
    this.rate = lsGet(SPEED_KEY, 1);
    this.pitch = lsGet(PITCH_KEY, 1);
    this.page = host.currentPage();
    this.sIdx = 0;
    this.wordOff = 0;          // offset inside current sentence where speech resumes
    this.playing = false;
    this.gen = 0;
    this.queued = new Map();   // id -> {page, s, base}
    this.lastQueued = -1;
    this.skipLangs = new Set();
    this.readAnyway = new Set();
    this.opts = { words: lsGet("atob.tts.words", true), autoTurn: lsGet("atob.tts.autoturn", true) };
    this.sleep = { mode: "off", timer: null, until: 0 };
    this.listeners = new Set();
    this.voices = [];
    this.engine.onevent = e => this._onEvent(e);
    this._media = evt => {
      if (!evt || evt.type !== "media") return;
      if (evt.action === "play") this.play();
      else if (evt.action === "pause") this.pause();
      else if (evt.action === "next") this.nextSentence();
      else if (evt.action === "prev") this.prevSentence();
      else if (evt.action === "stop") this.pause();
    };
    nativeListeners.add(this._media);
    this.voicesReady = this.engine.voices().then(v => { this.voices = v; this._emit(); return v; }).catch(() => []);
  }
  on(fn) { this.listeners.add(fn); return () => this.listeners.delete(fn); }
  _emit(extra) { for (const fn of this.listeners) { try { fn(this, extra); } catch (e) {} } }
  async model(i) {
    let m = await this.host.getPage(i);
    if (m && (m.quality.empty || m.quality.garbled) && m.source !== "ocr" && this.host.needsOcr) {
      const o = await this.host.needsOcr(i, m);
      if (o) m = o;
    }
    return m;
  }
  current() { return this._cur || null; }
  async play(page, offset) {
    if (this.engine.kind === "none") { noVoicePrompt(this, null); return; }
    if (!(await this.engine.ready())) { toast("Text-to-speech isn't available on this device", "err"); return; }
    await this.voicesReady;
    if (page != null) {
      this.page = page;
      const m = await this.model(page);
      let s = m ? m.sentences.findIndex(x => x.end > offset) : 0;
      if (s < 0) { s = m ? Math.max(0, m.sentences.length - 1) : 0; offset = m && m.sentences[s] ? m.sentences[s].start : 0; }
      this.sIdx = s;
      this.wordOff = m && m.sentences[s] ? Math.max(0, offset - m.sentences[s].start) : 0;
    }
    this.playing = true;
    this._mediaStart();
    this._emit();
    await this._speakFrom(this.page, this.sIdx, this.wordOff);
  }
  pause() {
    if (!this.playing) return;
    this.playing = false;
    this.gen++;
    this.engine.stop();
    this._mediaUpdate();
    this._emit();
  }
  toggle() { this.playing ? this.pause() : this.play(); }
  stop() {
    this.pause();
    this.host.highlight(this.page, null, null);
    try { window.AndroidBridge && window.AndroidBridge.mediaStop && window.AndroidBridge.mediaStop(); } catch (e) {}
  }
  destroy() {
    this.stop();
    this._setSleep("off");
    nativeListeners.delete(this._media);
    this.engine.onevent = null;
    this.listeners.clear();
  }
  setRate(r) { this.rate = Math.max(0.5, Math.min(3, r)); lsSet(SPEED_KEY, this.rate); this._restart(); this._emit(); }
  setPitch(p) { this.pitch = Math.max(0.5, Math.min(2, p)); lsSet(PITCH_KEY, this.pitch); this._restart(); this._emit(); }
  setVoice(lang, id) { setVoicePref(lang, id); this.readAnyway.delete(lang); this.skipLangs.delete(lang); this._restart(); this._emit(); }
  setOpt(k, v) { this.opts[k] = v; lsSet("atob.tts." + (k === "words" ? "words" : "autoturn"), v); this._emit(); }
  _restart() { if (this.playing) { this.gen++; this.engine.stop(); this._speakFrom(this.page, this.sIdx, this.wordOff); } }
  async nextSentence() {
    const m = await this.model(this.page);
    if (!m) return;
    if (this.sIdx + 1 < m.sentences.length) return this._jump(this.page, this.sIdx + 1);
    return this.nextPage();
  }
  async prevSentence() {
    if (this.sIdx > 0) return this._jump(this.page, this.sIdx - 1);
    if (this.page > 0) {
      const m = await this.model(this.page - 1);
      return this._jump(this.page - 1, Math.max(0, (m ? m.sentences.length : 1) - 1));
    }
  }
  nextPage() { if (this.page + 1 < this.host.pageCount) return this._jump(this.page + 1, 0); }
  prevPage() { return this._jump(Math.max(0, this.page - (this.sIdx > 0 ? 0 : 1)), 0); }
  async _jump(page, s) {
    const turned = page !== this.page;
    this.page = page; this.sIdx = s; this.wordOff = 0;
    if (turned) { await this.host.showPage(page); this._mediaUpdate(); }
    const m = await this.model(page);
    if (m && m.sentences[s]) this.host.highlight(page, m.sentences[s], null);
    this._emit();
    if (this.playing) { this.gen++; this.engine.stop(); await this._speakFrom(page, s, 0); }
  }
  /* voice + skip decision per sentence */
  _voiceFor(lang) {
    const v = pickVoice(lang, this.voices);
    if (v) return { voice: v.id, lang: v.lang || lang };
    if (this.readAnyway.has(lang)) return { voice: "", lang: (PDCore.LANG_INFO[lang] || { bcp: lang }).bcp };
    return null;
  }
  async _speakFrom(page, s, off) {
    const gen = ++this.gen;
    const m = await this.model(page);
    if (gen !== this.gen || !this.playing) return;
    if (!m || !m.sentences.length) {
      if (page + 1 < this.host.pageCount) {
        this.page = page + 1; this.sIdx = 0; this.wordOff = 0;
        if (this.opts.autoTurn) await this.host.showPage(this.page);
        return this._speakFrom(this.page, 0, 0);
      }
      return this._finished();
    }
    this._cur = m;
    this.page = page; this.sIdx = Math.min(s, m.sentences.length - 1);
    this.queued.clear();
    this.lastQueued = this.sIdx - 1;
    const ok = await this._enqueue(m, gen, true, off);
    if (!ok && gen === this.gen && this.playing) this._pageDone(gen);
  }
  /* queue a few sentences ahead so there's no gap between them */
  async _enqueue(m, gen, flush, firstOff) {
    const items = [];
    let k = this.lastQueued + 1;
    while (k < m.sentences.length && items.length < 3) {
      const sen = m.sentences[k];
      const lang = sen.lang || m.lang || "en";
      let v = this._voiceFor(lang);
      if (!v && !this.skipLangs.has(lang)) {
        const choice = await noVoicePrompt(this, lang);
        if (gen !== this.gen || !this.playing) return true;
        if (choice === "anyway") { this.readAnyway.add(lang); v = this._voiceFor(lang); }
        else if (choice === "skip") this.skipLangs.add(lang);
        else { this.pause(); return true; }
      }
      if (v) {
        const base = (flush && !items.length && firstOff) ? sen.start + firstOff : sen.start;
        const text = m.text.slice(base, sen.end);
        if (/[\p{L}\p{N}]/u.test(text)) {
          const id = "g" + gen + "p" + this.page + "s" + k;
          this.queued.set(id, { page: this.page, s: k, base, end: sen.end });
          items.push({ id, text, lang: v.lang, voice: v.voice });
        }
      }
      this.lastQueued = k;
      k++;
    }
    if (!items.length) return false;
    this.engine.speak(items, { flush, rate: this.rate, pitch: this.pitch });
    return true;
  }
  _onEvent(e) {
    const q = this.queued.get(e.id);
    if (!q || !e.id.startsWith("g" + this.gen + "p")) return;   // stale utterance
    const m = this._cur;
    if (e.type === "start") {
      this.sIdx = q.s; this.wordOff = q.base - m.sentences[q.s].start;
      this.host.highlight(q.page, m.sentences[q.s], null);
      this._emit({ sentence: m.text.slice(m.sentences[q.s].start, m.sentences[q.s].end), lang: m.sentences[q.s].lang });
      // keep two sentences queued ahead
      if (this.lastQueued - q.s < 2 && this.lastQueued < m.sentences.length - 1) this._enqueue(m, this.gen, false, 0);
      if (this.lastQueued >= m.sentences.length - 2) this._prefetch(q.page + 1);
    } else if (e.type === "range") {
      const a = q.base + (e.start || 0), b = Math.min(q.end, q.base + (e.end || e.start + 1));
      this.wordOff = a - m.sentences[q.s].start;
      if (this.opts.words) this.host.highlight(q.page, m.sentences[q.s], { start: a, end: b });
    } else if (e.type === "done" || (e.type === "error" && !/interrupted|canceled/.test(e.error || ""))) {
      if (e.type === "error" && /lang-missing|lang-not-supported/.test(e.error || "")) {
        const lang = m.sentences[q.s].lang;
        this.queued.delete(e.id);
        if (!this.skipLangs.has(lang)) { const g = this.gen; noVoicePrompt(this, lang).then(ch => { if (g !== this.gen) return; if (ch === "skip") { this.skipLangs.add(lang); } else if (ch === "anyway") this.readAnyway.add(lang); else { this.pause(); } }); }
      }
      this.queued.delete(e.id);
      this.wordOff = 0;
      const moreQueued = Array.from(this.queued.values()).some(x => x.s > q.s);
      if (!moreQueued) {
        if (this.lastQueued < m.sentences.length - 1) { this.sIdx = this.lastQueued + 1; this._enqueue(m, this.gen, false, 0).then(ok => { if (!ok) this._pageDone(this.gen); }); }
        else this._pageDone(this.gen);
      }
    }
  }
  _prefetch(i) { if (i < this.host.pageCount && !this._prefetching) { this._prefetching = true; Promise.resolve(this.host.getPage(i)).catch(() => {}).finally(() => { this._prefetching = false; }); } }
  async _pageDone(gen) {
    if (gen !== this.gen || !this.playing) return;
    if (this.sleep.mode === "page") { this.pause(); this._setSleep("off"); toast("Sleep timer: stopped at the end of the page"); return; }
    if (this.page + 1 >= this.host.pageCount) return this._finished();
    this.page++; this.sIdx = 0; this.wordOff = 0;
    if (this.opts.autoTurn) await this.host.showPage(this.page);
    this._mediaUpdate();
    this._emit();
    if (gen !== this.gen) return;
    await this._speakFrom(this.page, 0, 0);
  }
  _finished() {
    this.playing = false;
    this.host.highlight(this.page, null, null);
    this._mediaUpdate();
    this._emit();
    toast("Finished reading");
  }
  /* sleep timer: "off" | minutes | "page" */
  _setSleep(mode) {
    clearTimeout(this.sleep.timer);
    this.sleep = { mode: "off", timer: null, until: 0 };
    if (mode === "page") this.sleep.mode = "page";
    else if (typeof mode === "number" && mode > 0) {
      this.sleep = { mode: "min", until: Date.now() + mode * 60000,
        timer: setTimeout(() => { this.pause(); this.sleep = { mode: "off", timer: null, until: 0 }; toast("Sleep timer: reading paused"); this._emit(); }, mode * 60000) };
    }
    this._emit();
  }
  setSleep(mode) { this._setSleep(mode); }
  _mediaStart() {
    try { if (window.AndroidBridge && window.AndroidBridge.mediaStart) window.AndroidBridge.mediaStart(this.host.title || "AtoB PDF", "Page " + (this.page + 1) + " of " + this.host.pageCount, true); } catch (e) {}
  }
  _mediaUpdate() {
    try { if (window.AndroidBridge && window.AndroidBridge.mediaUpdate) window.AndroidBridge.mediaUpdate(this.host.title || "AtoB PDF", "Page " + (this.page + 1) + " of " + this.host.pageCount, this.playing); } catch (e) {}
  }
}

/* "no voice for this language" prompt. Resolves "skip" | "anyway" | "stop". */
const _voicePrompts = new Map();
function noVoicePrompt(ar, lang) {
  if (_voicePrompts.has(lang)) return _voicePrompts.get(lang);
  const name = lang ? (PDCore.LANG_INFO[lang] || { name: lang }).name : null;
  const eng = ar && ar.engine;
  const kind = platformKind();
  const how = kind === "android"
    ? "Install a " + (name || "") + " voice in Android's text-to-speech settings (Google Speech Services → Install voice data), then come back."
    : kind === "mac" || /Mac/i.test(navigator.platform)
      ? "Add a voice in System Settings → Accessibility → Spoken Content → System voice → Manage Voices."
      : /Win/i.test(navigator.platform)
        ? "Add the language's speech pack in Settings → Time & language → Speech → Manage voices, then restart AtoB PDF."
        : "Install a " + (name || "") + " voice for your system's speech engine.";
  const p = new Promise(resolve => {
    let done = false;
    const fin = (v, c) => { if (done) return; done = true; c(); _voicePrompts.delete(lang); resolve(v); };
    const actions = [];
    if (lang) actions.push({ label: "Skip " + name + " text", onClick: c => fin("skip", c) });
    if (eng && eng.kind === "android") actions.push({ label: "Open TTS settings", onClick: c => { eng.installData ? eng.installData() : eng.openSettings(); fin("stop", c); } });
    if (lang) actions.push({ label: "Read with default voice", primary: true, onClick: c => fin("anyway", c) });
    else actions.push({ label: "OK", primary: true, onClick: c => fin("stop", c) });
    showModal({
      title: name ? "No " + name + " voice installed" : "No text-to-speech voice",
      dismissable: false,
      body: h("div", { class: "voice-prompt" },
        h("p", null, name ? "This part of the document is in " + name + ", but this device doesn't have a " + name + " voice yet." : "This device has no speech voices available."),
        h("p", null, how)),
      actions,
    });
  });
  _voicePrompts.set(lang, p);
  return p;
}

/* ---------------- player bar ---------------- */
function audioBar(ar, opts) {
  opts = opts || {};
  const playBtn = h("button", { class: "ab-play", title: "Play / pause (Space)", "aria-label": "Play" }, icon("play"));
  const sentEl = h("div", { class: "ab-sent" }, "Tap play, or tap a word to start there");
  const langChip = h("span", { class: "ab-lang hidden" });
  const pageEl = h("span", { class: "ab-page" });
  const speedBtn = h("button", { class: "ab-speed", title: "Speed" }, "1.0×");
  const sleepChip = h("span", { class: "ab-sleep hidden" }, icon("moonz"));
  const panel = h("div", { class: "ab-panel hidden" });
  const bar = h("div", { class: "abar" + (opts.cls ? " " + opts.cls : ""), role: "region", "aria-label": "Read aloud" },
    h("div", { class: "ab-top" }, langChip, sentEl, sleepChip, pageEl,
      h("button", { class: "iconbtn ab-close", title: "Close player", "aria-label": "Close player", onclick: () => opts.onClose && opts.onClose() }, icon("close"))),
    h("div", { class: "ab-main" },
      h("button", { class: "iconbtn", title: "Previous page", "aria-label": "Previous page", onclick: () => ar.prevPage() }, icon("pprev")),
      h("button", { class: "iconbtn", title: "Previous sentence", "aria-label": "Previous sentence", onclick: () => ar.prevSentence() }, icon("sprev")),
      playBtn,
      h("button", { class: "iconbtn", title: "Next sentence", "aria-label": "Next sentence", onclick: () => ar.nextSentence() }, icon("snext")),
      h("button", { class: "iconbtn", title: "Next page", "aria-label": "Next page", onclick: () => ar.nextPage() }, icon("pnext")),
      speedBtn,
      h("button", { class: "iconbtn ab-more", title: "Voice, pitch, sleep timer", "aria-label": "Audio settings", onclick: () => togglePanel() }, icon("sliders"))),
    panel);
  playBtn.addEventListener("click", () => ar.toggle());
  const SPEEDS = [0.5, 0.75, 1, 1.25, 1.5, 1.75, 2, 2.5, 3];
  speedBtn.addEventListener("click", () => {
    const i = SPEEDS.findIndex(s => s >= ar.rate - 0.01);
    ar.setRate(SPEEDS[(i + 1) % SPEEDS.length]);
  });
  function togglePanel(force) {
    const show = force != null ? force : panel.classList.contains("hidden");
    panel.classList.toggle("hidden", !show);
    if (show) buildPanel();
  }
  function buildPanel() {
    panel.innerHTML = "";
    const rateS = slider(0.5, 3, 0.05, ar.rate, v => v.toFixed(2).replace(/0$/, "") + "×", v => ar.setRate(v));
    const pitchS = slider(0.5, 2, 0.05, ar.pitch, v => v.toFixed(2).replace(/0$/, ""), v => ar.setPitch(v));
    const sleepSeg = segmented([{ v: "off", label: "Off" }, { v: 5, label: "5m" }, { v: 15, label: "15m" }, { v: 30, label: "30m" }, { v: 60, label: "60m" }, { v: "page", label: "End of page" }],
      ar.sleep.mode === "page" ? "page" : "off", v => ar.setSleep(v));
    const langs = new Set(opts.langs ? opts.langs() : []);
    const m = ar.current();
    if (m) { if (m.lang) langs.add(m.lang); m.sentences.forEach(s => s.lang && langs.add(s.lang)); }
    if (!langs.size) langs.add("en");
    const voiceRows = Array.from(langs).filter(l => PDCore.LANG_INFO[l]).map(l => {
      const list = voicesFor(l, ar.voices);
      const sel = h("select", { "aria-label": PDCore.LANG_INFO[l].name + " voice" },
        h("option", { value: "" }, list.length ? "Automatic" : "No voice installed"),
        list.map(v => h("option", { value: v.id }, v.name + (v.installed === false ? " (download)" : v.local === false ? " (online)" : ""))));
      sel.value = lsGet(VOICE_KEY + l, "") || "";
      sel.addEventListener("change", () => ar.setVoice(l, sel.value));
      return h("div", { class: "ab-voice" }, h("span", { class: "ab-vl" }, PDCore.LANG_INFO[l].name), sel,
        !list.length ? h("button", { class: "textbtn", onclick: () => noVoicePrompt(ar, l) }, "How to add") : null);
    });
    const wordsC = checkbox("Highlight each word", ar.opts.words, v => ar.setOpt("words", v));
    const turnC = checkbox("Turn pages automatically", ar.opts.autoTurn, v => ar.setOpt("autoTurn", v));
    panel.append(
      h("div", { class: "ab-row" }, h("span", { class: "ab-k" }, "Speed"), rateS.el),
      h("div", { class: "ab-row" }, h("span", { class: "ab-k" }, "Pitch"), pitchS.el),
      h("div", { class: "ab-k ab-sec" }, "Voices"), ...voiceRows,
      h("div", { class: "ab-k ab-sec" }, "Sleep timer"), h("div", { class: "ab-row" }, sleepSeg.el),
      h("div", { class: "ab-row wrap" }, wordsC.el, turnC.el),
      h("div", { class: "ab-tip" }, ar.engine.kind === "none" ? "This browser has no speech engine." : "Tip: tap any word on the page to start reading from there."));
  }
  const refresh = (_, extra) => {
    playBtn.innerHTML = "";
    playBtn.append(icon(ar.playing ? "pause" : "play"));
    playBtn.setAttribute("aria-label", ar.playing ? "Pause" : "Play");
    bar.classList.toggle("playing", ar.playing);
    speedBtn.textContent = (Math.round(ar.rate * 100) / 100).toString().replace(/^(\d)$/, "$1.0") + "×";
    pageEl.textContent = "p. " + (ar.page + 1) + "/" + ar.host.pageCount;
    if (extra && extra.sentence) {
      sentEl.textContent = extra.sentence;
      sentEl.dir = "auto";
      const L = PDCore.LANG_INFO[extra.lang];
      langChip.textContent = L ? L.name : "";
      langChip.classList.toggle("hidden", !L || !ar.voices.length);
    }
    const sl = ar.sleep.mode !== "off";
    sleepChip.classList.toggle("hidden", !sl);
    sleepChip.title = ar.sleep.mode === "page" ? "Stops at the end of the page" : sl ? "Stops at " + new Date(ar.sleep.until).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) : "";
  };
  ar.on(refresh);
  refresh(ar, null);
  const key = e => {
    if (!document.body.contains(bar)) return;
    if (e.target && /INPUT|TEXTAREA|SELECT/.test(e.target.tagName) || (e.target && e.target.isContentEditable)) return;
    if (e.key === " " && !e.ctrlKey && !e.metaKey) { e.preventDefault(); ar.toggle(); }
  };
  document.addEventListener("keydown", key);
  return { el: bar, destroy: () => { document.removeEventListener("keydown", key); bar.remove(); }, panel: togglePanel };
}

/* draw audio highlight boxes (top-origin pts × scale) into a layer element */
function drawTtsBoxes(layer, model, sent, word, scale) {
  if (!layer) return;
  layer.innerHTML = "";
  if (!model || !sent) return;
  for (const b of PDCore.boxesForRange(model, sent.start, sent.end))
    layer.append(h("div", { class: "tts-sent", style: "left:" + (b.x * scale - 1) + "px;top:" + (b.y * scale - 1) + "px;width:" + (b.w * scale + 2) + "px;height:" + (b.h * scale + 2) + "px" }));
  if (word) for (const b of PDCore.boxesForRange(model, word.start, word.end))
    layer.append(h("div", { class: "tts-word", style: "left:" + (b.x * scale - 1) + "px;top:" + (b.y * scale - 1) + "px;width:" + (b.w * scale + 2) + "px;height:" + (b.h * scale + 2) + "px" }));
}
