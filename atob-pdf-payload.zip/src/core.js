/* AtoB PDF core — pure PDF operations on top of pdf-lib (global PDFLib).
   Runs in browser and Node (for tests). No DOM usage in this file. */
(function (root, factory) {
  if (typeof module === "object" && module.exports) module.exports = factory();
  else root.PDCore = factory();
})(typeof self !== "undefined" ? self : globalThis, function () {
  "use strict";

  function lib() {
    const L = (typeof self !== "undefined" ? self : globalThis).PDFLib;
    if (!L) throw new Error("pdf-lib not loaded");
    return L;
  }

  /* ---------------- page range parsing ---------------- */
  // "1-3, 5, 8-" -> groups of 0-based index arrays. Throws {code:'RANGE', message}
  function parseRangeGroups(str, numPages) {
    const s = String(str || "").trim();
    if (!s) throw rangeErr("Enter a page range, e.g. 1-3, 5");
    const groups = [];
    for (let part of s.split(",")) {
      part = part.trim();
      if (!part) continue;
      const m = part.match(/^(\d+)?\s*-\s*(\d+)?$|^(\d+)$/);
      if (!m) throw rangeErr('"' + part + '" is not a page or range');
      let a, b;
      if (m[3] !== undefined) { a = b = parseInt(m[3], 10); }
      else {
        if (m[1] === undefined && m[2] === undefined) throw rangeErr('"-" needs at least one page number');
        a = m[1] !== undefined ? parseInt(m[1], 10) : 1;
        b = m[2] !== undefined ? parseInt(m[2], 10) : numPages;
      }
      if (a < 1 || b < 1 || a > numPages || b > numPages)
        throw rangeErr("Pages must be between 1 and " + numPages);
      const g = [];
      if (a <= b) { for (let i = a; i <= b; i++) g.push(i - 1); }
      else { for (let i = a; i >= b; i--) g.push(i - 1); }
      groups.push(g);
    }
    if (!groups.length) throw rangeErr("Enter a page range, e.g. 1-3, 5");
    return groups;
  }
  // flat ordered unique set
  function parsePageSet(str, numPages) {
    const seen = new Set(), out = [];
    for (const g of parseRangeGroups(str, numPages))
      for (const i of g) if (!seen.has(i)) { seen.add(i); out.push(i); }
    return out;
  }
  function rangeErr(message) { const e = new Error(message); e.code = "RANGE"; return e; }

  /* ---------------- loading ---------------- */
  async function loadDoc(bytes, opts) {
    const { PDFDocument } = lib();
    try {
      return await PDFDocument.load(bytes, Object.assign({ updateMetadata: false }, opts));
    } catch (err) {
      const msg = String(err && err.message || err);
      if (/encrypted/i.test(msg)) {
        const e = new Error("This PDF is password-protected. Unlock support arrives in Phase 2.");
        e.code = "ENCRYPTED";
        throw e;
      }
      const e = new Error("Could not read this PDF. It may be corrupted.");
      e.code = "PARSE"; e.cause = err;
      throw e;
    }
  }

  /* ---------------- operations ---------------- */
  async function mergePdfs(buffers, rangeStrs, onProgress) {
    const { PDFDocument } = lib();
    const out = await PDFDocument.create();
    for (let f = 0; f < buffers.length; f++) {
      const src = await loadDoc(buffers[f]);
      const n = src.getPageCount();
      let idx;
      if (rangeStrs && rangeStrs[f] && String(rangeStrs[f]).trim()) {
        idx = [];
        for (const g of parseRangeGroups(rangeStrs[f], n)) idx.push.apply(idx, g);
      } else {
        idx = Array.from({ length: n }, (_, i) => i);
      }
      const pages = await out.copyPages(src, idx);
      for (const p of pages) out.addPage(p);
      if (onProgress) onProgress(f + 1, buffers.length);
    }
    return out.save({ useObjectStreams: true });
  }

  async function extractPages(buffer, indices) {
    const { PDFDocument } = lib();
    const src = await loadDoc(buffer);
    const out = await PDFDocument.create();
    const pages = await out.copyPages(src, indices);
    for (const p of pages) out.addPage(p);
    return out.save({ useObjectStreams: true });
  }

  async function splitPdf(buffer, groups, onProgress) {
    const { PDFDocument } = lib();
    const src = await loadDoc(buffer);
    const outs = [];
    for (let i = 0; i < groups.length; i++) {
      const out = await PDFDocument.create();
      const pages = await out.copyPages(src, groups[i]);
      for (const p of pages) out.addPage(p);
      outs.push(await out.save({ useObjectStreams: true }));
      if (onProgress) onProgress(i + 1, groups.length);
    }
    return outs;
  }

  function norm360(d) { return ((d % 360) + 360) % 360; }

  async function rotatePdf(buffer, indices, delta) {
    const { degrees } = lib();
    const doc = await loadDoc(buffer);
    const pages = doc.getPages();
    for (const i of indices) {
      const p = pages[i];
      p.setRotation(degrees(norm360(p.getRotation().angle + delta)));
    }
    return doc.save({ useObjectStreams: true });
  }

  // items: [{srcIdx, rotDelta}] in final order (deleted pages simply absent)
  async function organizePdf(buffer, items) {
    const { PDFDocument, degrees } = lib();
    const src = await loadDoc(buffer);
    const out = await PDFDocument.create();
    const pages = await out.copyPages(src, items.map(it => it.srcIdx));
    for (let i = 0; i < pages.length; i++) {
      const p = pages[i];
      const d = items[i].rotDelta || 0;
      if (d) p.setRotation(degrees(norm360(p.getRotation().angle + d)));
      out.addPage(p);
    }
    return out.save({ useObjectStreams: true });
  }

  async function resavePdf(buffer) {
    const doc = await loadDoc(buffer);
    return doc.save({ useObjectStreams: true });
  }

  /* ---- geometry helpers ---- */
  const MARGINS = { sm: 24, md: 36, lg: 54 };
  // Returns {x,y} bottom-left coords for an element of elW×elH on a W×H page.
  function posXY(pos, W, H, elW, elH, margin) {
    const m = margin == null ? MARGINS.md : margin;
    let x, y;
    switch (pos[1]) {
      case "l": x = m; break;
      case "r": x = W - m - elW; break;
      default: x = (W - elW) / 2;
    }
    switch (pos[0]) {
      case "t": y = H - m - elH; break;
      case "b": y = m; break;
      default: y = (H - elH) / 2;
    }
    return { x, y };
  }
  function hexToRgb01(hex) {
    const h = hex.replace("#", "");
    const v = h.length === 3 ? h.split("").map(c => c + c).join("") : h;
    return {
      r: parseInt(v.slice(0, 2), 16) / 255,
      g: parseInt(v.slice(2, 4), 16) / 255,
      b: parseInt(v.slice(4, 6), 16) / 255,
    };
  }

  /* effective (rotation-aware) page box: width/height as displayed */
  function effSize(page) {
    const rot = norm360(page.getRotation().angle);
    const { width, height } = page.getSize();
    return rot === 90 || rot === 270 ? { w: height, h: width, rot } : { w: width, h: height, rot };
  }

  /* Convert display-space coords (origin bottom-left of the page AS VIEWED)
     into raw pdf coords + rotation for drawing on a rotated page. */
  function displayToRaw(page, dx, dy, angleDeg) {
    const rot = norm360(page.getRotation().angle);
    const { width: W, height: H } = page.getSize(); // raw box
    let x, y, a;
    switch (rot) {
      case 90:  x = W - dy; y = dx; a = angleDeg + 90; break;
      case 180: x = W - dx; y = H - dy; a = angleDeg + 180; break;
      case 270: x = dy; y = H - dx; a = angleDeg - 90; break;
      default:  x = dx; y = dy; a = angleDeg;
    }
    return { x, y, a };
  }

  /* ---------------- page numbers ---------------- */
  const NUM_FORMATS = {
    n:   (n, t) => String(n),
    nt:  (n, t) => n + " / " + t,
    pn:  (n, t) => "Page " + n,
    pnt: (n, t) => "Page " + n + " of " + t,
  };

  async function addPageNumbers(buffer, o) {
    const { StandardFonts, rgb, degrees } = lib();
    const doc = await loadDoc(buffer);
    const font = await doc.embedFont(StandardFonts.Helvetica);
    const pages = doc.getPages();
    const total = pages.length;
    const fmt = NUM_FORMATS[o.format] || NUM_FORMATS.n;
    const col = hexToRgb01(o.color || "#4b4640");
    const size = o.size || 11;
    const margin = MARGINS[o.margin || "md"];
    const targets = o.indices || pages.map((_, i) => i);
    let shown = o.start != null ? o.start : 1;
    for (const i of targets) {
      if (o.skipFirst && i === 0) { shown++; continue; }
      const p = pages[i];
      const text = fmt(shown, total);
      const w = font.widthOfTextAtSize(text, size);
      const h = size * 0.72;
      const e = effSize(p);
      const { x, y } = posXY(o.pos || "bc", e.w, e.h, w, h, margin);
      const r = displayToRaw(p, x, y, 0);
      p.drawText(text, { x: r.x, y: r.y, size, font, color: rgb(col.r, col.g, col.b), rotate: degrees(r.a) });
      shown++;
    }
    return doc.save({ useObjectStreams: true });
  }

  /* ---------------- watermark ---------------- */
  async function addTextWatermark(buffer, o) {
    const { StandardFonts, rgb, degrees } = lib();
    const doc = await loadDoc(buffer);
    let font;
    try {
      font = await doc.embedFont(StandardFonts.Helvetica);
      // trigger encoding errors early
      font.widthOfTextAtSize(o.text, 10);
    } catch (err) {
      const e = new Error("Watermark text has characters Helvetica can't encode. Use basic Latin text for now.");
      e.code = "ENCODING";
      throw e;
    }
    const col = hexToRgb01(o.color || "#9a9186");
    const size = o.size || 64;
    const angle = o.angle != null ? o.angle : -45;
    const opacity = o.opacity != null ? o.opacity : 0.25;
    const pages = doc.getPages();
    const targets = o.indices || pages.map((_, i) => i);
    const tw = font.widthOfTextAtSize(o.text, size);
    const th = size * 0.72;
    const rad = angle * Math.PI / 180;
    for (const i of targets) {
      const p = pages[i];
      const e = effSize(p);
      const draw = (cx, cy) => {
        // place so the text box center sits at (cx, cy), display space
        const bx = cx - (tw / 2) * Math.cos(rad) + (th / 2) * Math.sin(rad);
        const by = cy - (tw / 2) * Math.sin(rad) - (th / 2) * Math.cos(rad);
        const r = displayToRaw(p, bx, by, angle);
        p.drawText(o.text, {
          x: r.x, y: r.y, size, font,
          color: rgb(col.r, col.g, col.b), opacity,
          rotate: degrees(r.a),
        });
      };
      if (o.tile) {
        const stepX = tw + 110, stepY = Math.max(130, th + 110);
        const diag = Math.sqrt(e.w * e.w + e.h * e.h);
        for (let y = -diag * 0.1; y <= e.h + diag * 0.1; y += stepY)
          for (let x = -diag * 0.1; x <= e.w + diag * 0.1; x += stepX)
            draw(x + tw / 2, y + th / 2);
      } else {
        const m = 46;
        const box = posXY(o.pos || "mc", e.w, e.h, Math.min(tw, e.w - 2 * m), th, m);
        draw(box.x + Math.min(tw, e.w - 2 * m) / 2, box.y + th / 2);
      }
    }
    return doc.save({ useObjectStreams: true });
  }

  async function addImageWatermark(buffer, imgBytes, isPng, o) {
    const doc = await loadDoc(buffer);
    const img = isPng ? await doc.embedPng(imgBytes) : await doc.embedJpg(imgBytes);
    const opacity = o.opacity != null ? o.opacity : 0.4;
    const pages = doc.getPages();
    const targets = o.indices || pages.map((_, i) => i);
    for (const i of targets) {
      const p = pages[i];
      const e = effSize(p);
      const iw = e.w * (o.scalePct || 40) / 100;
      const ih = iw * img.height / img.width;
      const drawAt = (dx, dy) => {
        const r = displayToRaw(p, dx, dy, 0);
        p.drawImage(img, { x: r.x, y: r.y, width: iw, height: ih, opacity, rotate: lib().degrees(r.a) });
      };
      if (o.tile) {
        const stepX = iw + 70, stepY = ih + 70;
        for (let y = -ih / 2; y <= e.h; y += stepY)
          for (let x = -iw / 2; x <= e.w; x += stepX) drawAt(x, y);
      } else {
        const box = posXY(o.pos || "mc", e.w, e.h, iw, ih, 40);
        drawAt(box.x, box.y);
      }
    }
    return doc.save({ useObjectStreams: true });
  }

  /* ---------------- images -> pdf ---------------- */
  const PAGE_SIZES = { a4: [595.28, 841.89], letter: [612, 792] };

  async function imagesToPdf(images, o) {
    const { PDFDocument } = lib();
    const doc = await PDFDocument.create();
    const marginPct = o.marginPct || 0;
    for (const im of images) {
      const img = im.isPng ? await doc.embedPng(im.bytes) : await doc.embedJpg(im.bytes);
      let pw, ph;
      if (o.pageSize === "fit") {
        pw = img.width * 0.75; ph = img.height * 0.75; // px @96dpi -> pt
      } else {
        const base = PAGE_SIZES[o.pageSize] || PAGE_SIZES.a4;
        let landscape;
        if (o.orient === "p") landscape = false;
        else if (o.orient === "l") landscape = true;
        else landscape = img.width > img.height;
        pw = landscape ? base[1] : base[0];
        ph = landscape ? base[0] : base[1];
      }
      const page = doc.addPage([pw, ph]);
      const m = Math.min(pw, ph) * marginPct / 100;
      const availW = pw - 2 * m, availH = ph - 2 * m;
      const s = Math.min(availW / img.width, availH / img.height);
      const w = img.width * s, h = img.height * s;
      page.drawImage(img, { x: (pw - w) / 2, y: (ph - h) / 2, width: w, height: h });
    }
    return doc.save({ useObjectStreams: true });
  }

  /* ---------------- compressed rebuild ---------------- */
  // pages: [{jpeg:Uint8Array, wPt, hPt}]
  async function rebuildFromJpegs(pages, onProgress) {
    const { PDFDocument } = lib();
    const doc = await PDFDocument.create();
    for (let i = 0; i < pages.length; i++) {
      const pg = pages[i];
      const img = await doc.embedJpg(pg.jpeg);
      const page = doc.addPage([pg.wPt, pg.hPt]);
      page.drawImage(img, { x: 0, y: 0, width: pg.wPt, height: pg.hPt });
      if (onProgress) onProgress(i + 1, pages.length);
    }
    return doc.save({ useObjectStreams: true });
  }

  /* ---------------- zip (store) ---------------- */
  const CRC_TABLE = (() => {
    const t = new Int32Array(256);
    for (let n = 0; n < 256; n++) {
      let c = n;
      for (let k = 0; k < 8; k++) c = c & 1 ? (c >>> 1) ^ 0xedb88320 : c >>> 1;
      t[n] = c;
    }
    return t;
  })();
  function crc32(data) {
    let c = -1;
    for (let i = 0; i < data.length; i++) c = (c >>> 8) ^ CRC_TABLE[(c ^ data[i]) & 0xff];
    return (c ^ -1) >>> 0;
  }
  function dosDateTime(d) {
    d = d || new Date();
    const time = (d.getHours() << 11) | (d.getMinutes() << 5) | (d.getSeconds() >> 1);
    const date = (((d.getFullYear() - 1980) & 0x7f) << 9) | ((d.getMonth() + 1) << 5) | d.getDate();
    return { time, date };
  }
  // entries: [{name, data:Uint8Array}] -> Uint8Array (STORE zip)
  function zipStore(entries) {
    const enc = new TextEncoder();
    const { time, date } = dosDateTime();
    const parts = [], central = [];
    let offset = 0;
    for (const e of entries) {
      const name = enc.encode(e.name);
      const crc = crc32(e.data);
      const lh = new DataView(new ArrayBuffer(30));
      lh.setUint32(0, 0x04034b50, true);
      lh.setUint16(4, 20, true);        // version needed
      lh.setUint16(6, 0x0800, true);    // UTF-8 flag
      lh.setUint16(8, 0, true);         // store
      lh.setUint16(10, time, true);
      lh.setUint16(12, date, true);
      lh.setUint32(14, crc, true);
      lh.setUint32(18, e.data.length, true);
      lh.setUint32(22, e.data.length, true);
      lh.setUint16(26, name.length, true);
      lh.setUint16(28, 0, true);
      parts.push(new Uint8Array(lh.buffer), name, e.data);
      const ch = new DataView(new ArrayBuffer(46));
      ch.setUint32(0, 0x02014b50, true);
      ch.setUint16(4, 20, true);
      ch.setUint16(6, 20, true);
      ch.setUint16(8, 0x0800, true);
      ch.setUint16(10, 0, true);
      ch.setUint16(12, time, true);
      ch.setUint16(14, date, true);
      ch.setUint32(16, crc, true);
      ch.setUint32(20, e.data.length, true);
      ch.setUint32(24, e.data.length, true);
      ch.setUint16(28, name.length, true);
      ch.setUint32(42, offset, true);
      central.push(new Uint8Array(ch.buffer), name);
      offset += 30 + name.length + e.data.length;
    }
    let cdSize = 0;
    for (const c of central) cdSize += c.length;
    const eocd = new DataView(new ArrayBuffer(22));
    eocd.setUint32(0, 0x06054b50, true);
    eocd.setUint16(8, entries.length, true);
    eocd.setUint16(10, entries.length, true);
    eocd.setUint32(12, cdSize, true);
    eocd.setUint32(16, offset, true);
    const total = offset + cdSize + 22;
    const out = new Uint8Array(total);
    let p = 0;
    for (const part of parts) { out.set(part, p); p += part.length; }
    for (const part of central) { out.set(part, p); p += part.length; }
    out.set(new Uint8Array(eocd.buffer), p);
    return out;
  }

  /* ---------------- signature ---------------- */
  // Place an image (signature) centered at display-space point (cx,cy) on one page.
  async function placeSignature(buffer, imgBytes, isPng, o) {
    const { StandardFonts, rgb, degrees } = lib();
    const doc = await loadDoc(buffer);
    const img = isPng ? await doc.embedPng(imgBytes) : await doc.embedJpg(imgBytes);
    const pages = doc.getPages();
    const p = pages[o.pageIdx];
    if (!p) throw new Error("Page " + (o.pageIdx + 1) + " does not exist");
    const w = o.wPt;
    const hgt = w * img.height / img.width;
    const r = displayToRaw(p, o.cx - w / 2, o.cy - hgt / 2, 0);
    p.drawImage(img, { x: r.x, y: r.y, width: w, height: hgt, rotate: degrees(r.a) });
    if (o.dateStr) {
      const font = await doc.embedFont(StandardFonts.Helvetica);
      const size = Math.max(8, Math.min(12, w * 0.055));
      const tw = font.widthOfTextAtSize(o.dateStr, size);
      const rd = displayToRaw(p, o.cx - tw / 2, o.cy - hgt / 2 - size * 1.5, 0);
      p.drawText(o.dateStr, { x: rd.x, y: rd.y, size, font, color: rgb(0.25, 0.24, 0.22), rotate: degrees(rd.a) });
    }
    return doc.save({ useObjectStreams: true });
  }

  /* ---------------- forms ---------------- */
  // Duck-typed: constructor names are mangled in the minified pdf-lib build.
  function fieldKind(f) {
    if (typeof f.isChecked === "function" && typeof f.check === "function") return "check";
    if (typeof f.setText === "function" && typeof f.getText === "function") return "text";
    if (typeof f.getOptions === "function") {
      if (typeof f.isEditable === "function") return "dropdown";
      if (typeof f.isMultiselect === "function") return "optionlist";
      return "radio";
    }
    return "other";
  }
  async function listFormFields(buffer) {
    const doc = await loadDoc(buffer);
    let form;
    try { form = doc.getForm(); } catch (e) { return []; }
    const out = [];
    for (const f of form.getFields()) {
      const kind = fieldKind(f);
      const item = { name: f.getName(), kind };
      try {
        if (kind === "text") { item.value = f.getText() || ""; item.multiline = !!(f.isMultiline && f.isMultiline()); }
        else if (kind === "check") item.value = f.isChecked();
        else if (kind === "radio") { item.options = f.getOptions(); item.value = f.getSelected(); }
        else if (kind === "dropdown") { item.options = f.getOptions(); item.value = (f.getSelected() || [])[0] || ""; }
        else if (kind === "optionlist") { item.options = f.getOptions(); item.value = f.getSelected() || []; }
      } catch (e) { item.error = true; }
      out.push(item);
    }
    return out;
  }
  // entries: [{name, kind, value}]
  async function fillForm(buffer, entries, opts) {
    const { StandardFonts } = lib();
    const doc = await loadDoc(buffer);
    const form = doc.getForm();
    const problems = [];
    for (const e of entries) {
      try {
        if (e.kind === "text") {
          const f = form.getTextField(e.name);
          f.setText(String(e.value == null ? "" : e.value));
        } else if (e.kind === "check") {
          const f = form.getCheckBox(e.name);
          if (e.value) f.check(); else f.uncheck();
        } else if (e.kind === "radio") {
          const f = form.getRadioGroup(e.name);
          if (e.value) f.select(e.value);
        } else if (e.kind === "dropdown") {
          const f = form.getDropdown(e.name);
          if (e.value) f.select(e.value);
        } else if (e.kind === "optionlist") {
          const f = form.getOptionList(e.name);
          f.select(Array.isArray(e.value) ? e.value : [e.value]);
        }
      } catch (err) {
        problems.push(e.name + ": " + (err && err.message || err));
      }
    }
    try {
      const helv = await doc.embedFont(StandardFonts.Helvetica);
      form.updateFieldAppearances(helv);
    } catch (e) { /* appearance regen is best-effort */ }
    if (opts && opts.flatten) {
      try { form.flatten(); }
      catch (e) { problems.push("Flatten failed: " + (e && e.message || e)); }
    }
    const bytes = await doc.save({ useObjectStreams: true });
    return { bytes, problems };
  }

  /* ---------------- OCR overlay ----------------
     pageWords: [{pageIdx, dpi, words:[{text, x0, y0, x1, y1}]}] with coords in
     rendered-image pixels (origin top-left, display orientation). Adds an
     invisible-but-selectable text layer over the original pages. */
  async function ocrOverlay(buffer, pageWords) {
    const { StandardFonts, rgb, degrees } = lib();
    const doc = await loadDoc(buffer);
    const font = await doc.embedFont(StandardFonts.Helvetica);
    const pages = doc.getPages();
    let placed = 0, skipped = 0;
    for (const pw of pageWords) {
      const p = pages[pw.pageIdx];
      if (!p) continue;
      const e = effSize(p);
      const s = 72 / pw.dpi; // image px -> pt
      for (const w of pw.words) {
        const text = (w.text || "").trim();
        if (!text) continue;
        const hPt = Math.max(2, (w.y1 - w.y0) * s);
        const wPt = Math.max(1, (w.x1 - w.x0) * s);
        let size = hPt * 0.92;
        let tw;
        try { tw = font.widthOfTextAtSize(text, size); }
        catch (err) { skipped++; continue; }
        if (tw > 0) size = Math.min(size, size * wPt / tw); // squeeze to box width
        // display-space baseline: bottom of box (y measured from top of image)
        const dx = w.x0 * s;
        const dy = e.h - w.y1 * s + hPt * 0.12;
        const r = displayToRaw(p, dx, dy, 0);
        try {
          p.drawText(text, { x: r.x, y: r.y, size: Math.max(1, size), font, color: rgb(1, 1, 1), opacity: 0, rotate: degrees(r.a) });
          placed++;
        } catch (err) { skipped++; }
      }
    }
    const bytes = await doc.save({ useObjectStreams: true });
    return { bytes, placed, skipped };
  }

  /* ================= Phase 3: editor pipeline =================
     Editor coordinates are TOP-ORIGIN points (matching MuPDF structured text
     and CSS math). Conversions to PDF bottom-origin space happen here. */

  const EDITOR_FONTS = {
    sans: ["Helvetica", "HelveticaBold", "HelveticaOblique", "HelveticaBoldOblique"],
    serif: ["TimesRoman", "TimesRomanBold", "TimesRomanItalic", "TimesRomanBoldItalic"],
    mono: ["Courier", "CourierBold", "CourierOblique", "CourierBoldOblique"],
  };
  async function pickFont(doc, cache, family, bold, italic) {
    const { StandardFonts } = lib();
    const fam = EDITOR_FONTS[family] ? family : "sans";
    const idx = (bold ? 1 : 0) + (italic ? 2 : 0);
    const key = fam + idx;
    if (!cache[key]) cache[key] = await doc.embedFont(StandardFonts[EDITOR_FONTS[fam][idx]]);
    return cache[key];
  }
  function famFromStext(family, style) {
    if (/mono/i.test(family || "")) return "mono";
    if (/serif/i.test(family || "") && !/sans/i.test(family || "")) return "serif";
    return "sans";
  }

  /* pageOps: [{pageIdx, ops:[op...]}] — op.type:
     whiteout {x,y,w,h,color}
     text     {x,y,size,text,color,family,bold,italic}      (y = top of first line)
     editline {baseline,x,size,text,color,family,bold,italic}  (baseline top-origin)
     image    {x,y,w,h,bytes,isPng}
     imgdelete{x,y,w,h}          (visual only here; actual removal via redactRegions)
     rect     {x,y,w,h,stroke,strokeW,fill,opacity}
     ellipse  {x,y,w,h,stroke,strokeW,fill,opacity}
     line     {x1,y1,x2,y2,stroke,strokeW,opacity,arrow}
     highlight{x,y,w,h,color,opacity}
     note     {x,y,text,author}
  */
  async function applyOverlay(buffer, pageOps) {
    const L = lib();
    const { rgb, degrees, PDFName, PDFHexString, PDFString } = L;
    const doc = await loadDoc(buffer);
    const pages = doc.getPages();
    const fontCache = {};
    const problems = [];
    const col = c => { const v = hexToRgb01(c || "#000000"); return rgb(v.r, v.g, v.b); };

    for (const pg of pageOps) {
      const p = pages[pg.pageIdx];
      if (!p) continue;
      const e = effSize(p);
      const toRaw = (dx, dyBottom, ang) => displayToRaw(p, dx, dyBottom, ang || 0);
      const rawRect = (x, y, w, hgt) => { // top-origin box -> raw axis-aligned rect
        const a = toRaw(x, e.h - y - hgt, 0), b = toRaw(x + w, e.h - y, 0);
        return [Math.min(a.x, b.x), Math.min(a.y, b.y), Math.max(a.x, b.x), Math.max(a.y, b.y)];
      };
      const order = { whiteout: 0, imgdelete: 0, highlight: 1, image: 2, rect: 3, ellipse: 3, line: 3, text: 4, editline: 4, note: 5 };
      const ops = pg.ops.slice().sort((A, B) => (order[A.type] ?? 9) - (order[B.type] ?? 9));
      for (const op of ops) {
        try {
          if (op.type === "whiteout") {
            const r = toRaw(op.x, e.h - op.y - op.h);
            p.drawRectangle({ x: r.x, y: r.y, width: op.w, height: op.h, rotate: degrees(r.a), color: col(op.color || "#ffffff"), borderWidth: 0 });
          } else if (op.type === "imgdelete") {
            // actual pixels removed in redact pass; nothing to draw
          } else if (op.type === "highlight") {
            const r = toRaw(op.x, e.h - op.y - op.h);
            p.drawRectangle({ x: r.x, y: r.y, width: op.w, height: op.h, rotate: degrees(r.a), color: col(op.color || "#ffe066"), opacity: op.opacity != null ? op.opacity : 0.4, blendMode: "Multiply", borderWidth: 0 });
          } else if (op.type === "image") {
            const img = op.isPng ? await doc.embedPng(op.bytes) : await doc.embedJpg(op.bytes);
            const r = toRaw(op.x, e.h - op.y - op.h);
            p.drawImage(img, { x: r.x, y: r.y, width: op.w, height: op.h, rotate: degrees(r.a) });
          } else if (op.type === "rect") {
            const r = toRaw(op.x, e.h - op.y - op.h);
            p.drawRectangle({ x: r.x, y: r.y, width: op.w, height: op.h, rotate: degrees(r.a),
              borderColor: col(op.stroke || "#c0392b"), borderWidth: op.strokeW || 2,
              color: op.fill ? col(op.fill) : undefined, opacity: op.opacity != null ? op.opacity : 1,
              borderOpacity: op.opacity != null ? op.opacity : 1 });
          } else if (op.type === "ellipse") {
            const cx = op.x + op.w / 2, cy = op.y + op.h / 2;
            const r = toRaw(cx, e.h - cy);
            const rot = norm360(p.getRotation().angle);
            const swap = rot === 90 || rot === 270;
            p.drawEllipse({ x: r.x, y: r.y, xScale: (swap ? op.h : op.w) / 2, yScale: (swap ? op.w : op.h) / 2,
              borderColor: col(op.stroke || "#c0392b"), borderWidth: op.strokeW || 2,
              color: op.fill ? col(op.fill) : undefined, opacity: op.opacity != null ? op.opacity : 1,
              borderOpacity: op.opacity != null ? op.opacity : 1 });
          } else if (op.type === "line") {
            const a = toRaw(op.x1, e.h - op.y1), b = toRaw(op.x2, e.h - op.y2);
            const w = op.strokeW || 2, c = col(op.stroke || "#c0392b");
            const opa = op.opacity != null ? op.opacity : 1;
            p.drawLine({ start: { x: a.x, y: a.y }, end: { x: b.x, y: b.y }, thickness: w, color: c, opacity: opa });
            if (op.arrow) {
              const ang = Math.atan2(b.y - a.y, b.x - a.x);
              const len = Math.max(8, w * 4);
              for (const da of [Math.PI * 5 / 6, -Math.PI * 5 / 6]) {
                p.drawLine({ start: { x: b.x, y: b.y },
                  end: { x: b.x + len * Math.cos(ang + da), y: b.y + len * Math.sin(ang + da) },
                  thickness: w, color: c, opacity: opa });
              }
            }
          } else if (op.type === "text" || op.type === "editline") {
            const font = await pickFont(doc, fontCache, op.family, op.bold, op.italic);
            const size = op.size || 14;
            const lines = String(op.text || "").split("\n");
            let baseTop = op.type === "editline" ? op.baseline : op.y + size * 0.82;
            for (const lineText of lines) {
              if (lineText.trim()) {
                font.widthOfTextAtSize(lineText, size); // trigger encoding errors early
                const r = toRaw(op.x, e.h - baseTop);
                p.drawText(lineText, { x: r.x, y: r.y, size, font, color: col(op.color || "#1a1a1a"), rotate: degrees(r.a) });
              }
              baseTop += size * 1.25;
            }
          } else if (op.type === "note") {
            const rect = rawRect(op.x, op.y, 22, 22);
            const now = new Date();
            const mdate = "D:" + now.getFullYear() + String(now.getMonth() + 1).padStart(2, "0") + String(now.getDate()).padStart(2, "0");
            const annot = doc.context.obj({
              Type: "Annot", Subtype: "Text", Rect: rect,
              Contents: PDFHexString.fromText(String(op.text || "")),
              T: PDFHexString.fromText(op.author || "AtoB PDF"),
              Name: "Comment", C: [0.98, 0.75, 0.2], CA: 1, F: 4,
              M: PDFString.of(mdate),
            });
            const ref = doc.context.register(annot);
            let annots = p.node.lookup(PDFName.of("Annots"));
            if (!annots) {
              annots = doc.context.obj([]);
              p.node.set(PDFName.of("Annots"), annots);
            }
            annots.push(ref);
          }
        } catch (err) {
          problems.push(op.type + ": " + (err && err.message || err));
        }
      }
    }
    const bytes = await doc.save({ useObjectStreams: true });
    return { bytes, problems };
  }

  /* regions: [{pageIdx, rects:[{x,y,w,h}], mode:'text'|'image'|'black'}] — rects TOP-ORIGIN (MuPDF space).
     'black' = true redaction with a drawn black box (content removed underneath). */
  function redactRegions(mupdf, buffer, regions) {
    const doc = mupdf.Document.openDocument(buffer, "application/pdf");
    const byPage = new Map();
    for (const r of regions) {
      if (!byPage.has(r.pageIdx)) byPage.set(r.pageIdx, { text: [], image: [], black: [] });
      const bucket = r.mode === "image" ? "image" : r.mode === "black" ? "black" : "text";
      byPage.get(r.pageIdx)[bucket].push(...r.rects);
    }
    const P = mupdf.PDFPage;
    for (const [pageIdx, sets] of byPage) {
      const page = doc.loadPage(pageIdx);
      if (sets.text.length) {
        for (const rc of sets.text) {
          const a = page.createAnnotation("Redact");
          a.setRect([rc.x - 0.5, rc.y - 0.5, rc.x + rc.w + 0.5, rc.y + rc.h + 0.5]);
        }
        page.applyRedactions(false, P.REDACT_IMAGE_NONE, undefined, P.REDACT_TEXT_REMOVE);
      }
      if (sets.image.length) {
        for (const rc of sets.image) {
          const a = page.createAnnotation("Redact");
          a.setRect([rc.x, rc.y, rc.x + rc.w, rc.y + rc.h]);
        }
        page.applyRedactions(false, P.REDACT_IMAGE_REMOVE, undefined, P.REDACT_TEXT_NONE);
      }
      if (sets.black.length) {
        for (const rc of sets.black) {
          const a = page.createAnnotation("Redact");
          a.setRect([rc.x, rc.y, rc.x + rc.w, rc.y + rc.h]);
        }
        page.applyRedactions(true, P.REDACT_IMAGE_PIXELS, undefined, P.REDACT_TEXT_REMOVE);
      }
    }
    return doc.saveToBuffer("garbage=compact").asUint8Array();
  }

  /* normalize MuPDF stext JSON into editor line/image lists (all TOP-ORIGIN pts) */
  function parseStext(json) {
    const lines = [], images = [];
    for (const b of json.blocks || []) {
      if (b.type === "text") {
        for (const l of b.lines || []) {
          if (!l.text || !l.text.trim()) continue;
          lines.push({
            text: l.text,
            x: l.bbox.x, y: l.bbox.y, w: l.bbox.w, h: l.bbox.h,
            baseline: l.y,
            size: l.font && l.font.size || Math.max(8, l.bbox.h * 0.75),
            family: famFromStext(l.font && l.font.family),
            bold: /bold/i.test(l.font && l.font.weight || ""),
            italic: /italic|oblique/i.test(l.font && l.font.style || ""),
            fontName: l.font && l.font.name || "",
          });
        }
      } else if (b.type === "image") {
        images.push({ x: b.bbox.x, y: b.bbox.y, w: b.bbox.w, h: b.bbox.h });
      }
    }
    return { lines, images };
  }

  /* ================= LightPDF-parity additions ================= */

  /* ---- crop: box in TOP-ORIGIN display points measured on page 1 ---- */
  async function cropPdf(buffer, box, indices) {
    const doc = await loadDoc(buffer);
    const pages = doc.getPages();
    const targets = indices || pages.map((_, i) => i);
    for (const i of targets) {
      const p = pages[i];
      if (!p) continue;
      const e = effSize(p);
      const x = Math.max(0, Math.min(box.x, e.w - 8));
      const y = Math.max(0, Math.min(box.y, e.h - 8));
      const w = Math.min(box.w, e.w - x), hh = Math.min(box.h, e.h - y);
      const a = displayToRaw(p, x, e.h - y - hh, 0);
      const b = displayToRaw(p, x + w, e.h - y, 0);
      const rx = Math.min(a.x, b.x), ry = Math.min(a.y, b.y);
      const rw = Math.abs(b.x - a.x), rh = Math.abs(b.y - a.y);
      p.setCropBox(rx, ry, rw, rh);
      try { p.setMediaBox(rx, ry, rw, rh); } catch (err) {}
    }
    return doc.save({ useObjectStreams: true });
  }

  /* ---- stext lines -> paragraphs (for text/markdown/docx export) ---- */
  function linesToParas(lines) {
    const paras = [];
    let curP = null, lastBottom = null, lastSize = 12;
    for (const ln of lines) {
      const gap = lastBottom == null ? 0 : ln.y - lastBottom;
      const newPara = !curP || gap > Math.max(6, lastSize * 0.7) || Math.abs(ln.size - curP.size) > 2;
      if (newPara) {
        curP = { text: ln.text.trim(), size: ln.size, bold: ln.bold, italic: ln.italic, family: ln.family };
        paras.push(curP);
      } else {
        curP.text += " " + ln.text.trim();
      }
      lastBottom = ln.y + ln.h;
      lastSize = ln.size;
    }
    return paras;
  }
  function parasToMarkdown(pageParas) {
    const all = pageParas.flat();
    const sizes = all.map(p => p.size).sort((a, b) => a - b);
    const median = sizes.length ? sizes[Math.floor(sizes.length / 2)] : 12;
    return pageParas.map(paras => paras.map(p => {
      let t = p.text;
      if (p.size >= median * 1.7) t = "# " + t;
      else if (p.size >= median * 1.3) t = "## " + t;
      else if (p.bold) t = "**" + t + "**";
      return t;
    }).join("\n\n")).join("\n\n---\n\n");
  }

  /* ---- minimal .docx builder (zipStore-based; Unicode-safe) ---- */
  function xmlEsc(s) {
    return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;").replace(/[\x00-\x08\x0b\x0c\x0e-\x1f]/g, "");
  }
  function buildDocx(pageParas) {
    const enc = new TextEncoder();
    const body = [];
    pageParas.forEach((paras, pi) => {
      if (pi > 0) body.push('<w:p><w:r><w:br w:type="page"/></w:r></w:p>');
      for (const p of paras) {
        const sz = Math.max(2, Math.round((p.size || 11) * 2));
        const rpr = "<w:rPr>" + (p.bold ? "<w:b/>" : "") + (p.italic ? "<w:i/>" : "") +
          '<w:sz w:val="' + sz + '"/><w:szCs w:val="' + sz + '"/></w:rPr>';
        body.push("<w:p><w:r>" + rpr + '<w:t xml:space="preserve">' + xmlEsc(p.text) + "</w:t></w:r></w:p>");
      }
    });
    const documentXml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n' +
      '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">' +
      "<w:body>" + body.join("") + '<w:sectPr><w:pgSz w:w="11906" w:h="16838"/>' +
      '<w:pgMar w:top="1134" w:right="1134" w:bottom="1134" w:left="1134"/></w:sectPr></w:body></w:document>';
    const contentTypes = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n' +
      '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">' +
      '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>' +
      '<Default Extension="xml" ContentType="application/xml"/>' +
      '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>';
    const rels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n' +
      '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' +
      '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>';
    return zipStore([
      { name: "[Content_Types].xml", data: enc.encode(contentTypes) },
      { name: "_rels/.rels", data: enc.encode(rels) },
      { name: "word/document.xml", data: enc.encode(documentXml) },
    ]);
  }

  /* ---- minimal unzip (STORE + DEFLATE via DecompressionStream) ---- */
  async function unzipBytes(bytes) {
    const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    let eocd = -1;
    for (let i = bytes.length - 22; i >= Math.max(0, bytes.length - 65558); i--) {
      if (dv.getUint32(i, true) === 0x06054b50) { eocd = i; break; }
    }
    if (eocd < 0) throw new Error("Not a valid zip/docx file");
    const count = dv.getUint16(eocd + 10, true);
    let off = dv.getUint32(eocd + 16, true);
    const files = {};
    for (let n = 0; n < count; n++) {
      if (dv.getUint32(off, true) !== 0x02014b50) break;
      const method = dv.getUint16(off + 10, true);
      const csize = dv.getUint32(off + 20, true);
      const nameLen = dv.getUint16(off + 28, true);
      const extraLen = dv.getUint16(off + 30, true);
      const commentLen = dv.getUint16(off + 32, true);
      const lho = dv.getUint32(off + 42, true);
      const name = new TextDecoder().decode(bytes.subarray(off + 46, off + 46 + nameLen));
      const lNameLen = dv.getUint16(lho + 26, true);
      const lExtraLen = dv.getUint16(lho + 28, true);
      const dataStart = lho + 30 + lNameLen + lExtraLen;
      const raw = bytes.subarray(dataStart, dataStart + csize);
      if (method === 0) files[name] = raw.slice();
      else if (method === 8) {
        const ds = new DecompressionStream("deflate-raw");
        const stream = new Blob([raw]).stream().pipeThrough(ds);
        files[name] = new Uint8Array(await new Response(stream).arrayBuffer());
      } else throw new Error("Unsupported compression in zip: " + method);
      off += 46 + nameLen + extraLen + commentLen;
    }
    return files;
  }

  /* ---- extract paragraphs from a docx document.xml (regex subset parser) ---- */
  function xmlUnesc(s) {
    return s.replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"')
      .replace(/&apos;/g, "'").replace(/&#x([0-9a-f]+);/gi, (m, h) => String.fromCodePoint(parseInt(h, 16)))
      .replace(/&#(\d+);/g, (m, d) => String.fromCodePoint(+d)).replace(/&amp;/g, "&");
  }
  function docxParas(xml) {
    const paras = [];
    const pRe = /<w:p[\s>][\s\S]*?<\/w:p>|<w:p\/>/g;
    let m;
    while ((m = pRe.exec(xml))) {
      const pxml = m[0];
      let text = "", bold = false, italic = false, size = 0, runs = 0;
      const rRe = /<w:r[\s>][\s\S]*?<\/w:r>/g;
      let r;
      while ((r = rRe.exec(pxml))) {
        const rx = r[0];
        const rpr = (rx.match(/<w:rPr>[\s\S]*?<\/w:rPr>/) || [""])[0];
        if (/<w:b(?:\s[^>]*)?\/>/.test(rpr) && !/w:val="(?:false|0)"/.test((rpr.match(/<w:b\s[^>]*\/>/) || [""])[0])) bold = true;
        if (/<w:i(?:\s[^>]*)?\/>/.test(rpr)) italic = true;
        const sm = rpr.match(/<w:sz w:val="(\d+)"/);
        if (sm) size = Math.max(size, parseInt(sm[1], 10) / 2);
        let t = "";
        const tRe = /<w:t(?:\s[^>]*)?>([\s\S]*?)<\/w:t>|<w:tab\/>|<w:br\/>/g;
        let tm;
        while ((tm = tRe.exec(rx))) {
          if (tm[0] === "<w:tab/>") t += "\t";
          else if (tm[0] === "<w:br/>") t += "\n";
          else t += xmlUnesc(tm[1]);
        }
        text += t;
        runs++;
      }
      const heading = (pxml.match(/<w:pStyle w:val="Heading(\d)"/) || [])[1];
      if (heading && !size) size = [0, 22, 17, 14][+heading] || 13;
      paras.push({ text, bold: bold && runs > 0, italic, size: size || 11 });
    }
    return paras;
  }

  /* ---- paragraphs -> PDF (wrapped text layout) ---- */
  const WINANSI_SAFE = new RegExp("[^\\u0000-\\u00ff\\u0152\\u0153\\u0160\\u0161\\u0178\\u017d\\u017e\\u0192\\u2013\\u2014\\u2018\\u2019\\u201a\\u201c\\u201d\\u201e\\u2020\\u2021\\u2022\\u2026\\u2030\\u2039\\u203a\\u20ac\\u2122]", "g");
  async function parasToPdf(paras, opts) {
    const { PDFDocument, StandardFonts } = lib();
    const doc = await PDFDocument.create();
    const fonts = {};
    const getFont = async (bold, italic) => {
      const k = (bold ? "b" : "") + (italic ? "i" : "");
      if (!fonts[k]) {
        const name = bold && italic ? "HelveticaBoldOblique" : bold ? "HelveticaBold" : italic ? "HelveticaOblique" : "Helvetica";
        fonts[k] = await doc.embedFont(StandardFonts[name]);
      }
      return fonts[k];
    };
    const PW = 595.28, PH = 841.89, M = 64;
    let page = doc.addPage([PW, PH]);
    let y = PH - M;
    let replaced = 0;
    for (const p of paras) {
      const size = Math.max(7, Math.min(36, p.size || 11));
      const font = await getFont(p.bold, p.italic);
      const clean = String(p.text || "").replace(WINANSI_SAFE, () => { replaced++; return "?"; });
      const lineH = size * 1.4;
      const words = clean.split(/\s+/).filter(Boolean);
      if (!words.length) { y -= lineH * 0.6; continue; }
      let line = "";
      const flush = () => {
        if (!line) return;
        if (y < M + size) { page = doc.addPage([PW, PH]); y = PH - M; }
        page.drawText(line, { x: M, y: y - size, size, font });
        y -= lineH;
        line = "";
      };
      for (const w of words) {
        const cand = line ? line + " " + w : w;
        let cw;
        try { cw = font.widthOfTextAtSize(cand, size); } catch (e) { continue; }
        if (cw > PW - 2 * M && line) { flush(); line = w; }
        else line = cand;
      }
      flush();
      y -= lineH * 0.35;
    }
    const bytes = await doc.save({ useObjectStreams: true });
    return { bytes, replaced };
  }

  function textToParas(text) {
    return String(text).replace(/\r\n?/g, "\n").split(/\n{2,}/).map(chunk => ({
      text: chunk.replace(/\n/g, " ").trim(), size: 11,
    })).filter(p => p.text);
  }

  /* ================= v3.4: text, script & language layer =================
     Pure helpers used by the audio reader, the Kindle-style reader and the
     multi-language checks. Page coordinates are TOP-ORIGIN points. */

  const LANGS = ["en", "ar", "ur", "hi", "ml", "ta"];
  const LANG_INFO = {
    en: { name: "English", script: "latin", dir: "ltr", ocr: "eng", bcp: "en" },
    ar: { name: "Arabic", script: "arabic", dir: "rtl", ocr: "ara", bcp: "ar" },
    ur: { name: "Urdu", script: "arabic", dir: "rtl", ocr: "urd", bcp: "ur" },
    hi: { name: "Hindi", script: "devanagari", dir: "ltr", ocr: "hin", bcp: "hi" },
    ml: { name: "Malayalam", script: "malayalam", dir: "ltr", ocr: "mal", bcp: "ml" },
    ta: { name: "Tamil", script: "tamil", dir: "ltr", ocr: "tam", bcp: "ta" },
  };
  function scriptOf(cp) {
    if ((cp >= 0x41 && cp <= 0x5a) || (cp >= 0x61 && cp <= 0x7a) || (cp >= 0xc0 && cp <= 0x24f && cp !== 0xd7 && cp !== 0xf7)) return "latin";
    if ((cp >= 0x600 && cp <= 0x6ff) || (cp >= 0x750 && cp <= 0x77f) || (cp >= 0x8a0 && cp <= 0x8ff) || (cp >= 0xfb50 && cp <= 0xfdff) || (cp >= 0xfe70 && cp <= 0xfeff)) {
      // digits, punctuation and marks inside the block are not letters
      if ((cp >= 0x660 && cp <= 0x66d) || (cp >= 0x6f0 && cp <= 0x6f9) || cp === 0x60c || cp === 0x61b || cp === 0x61f || cp === 0x640) return null;
      return "arabic";
    }
    if ((cp >= 0x900 && cp <= 0x97f) || (cp >= 0xa8e0 && cp <= 0xa8ff)) return (cp === 0x964 || cp === 0x965 || (cp >= 0x966 && cp <= 0x96f)) ? null : "devanagari";
    if (cp >= 0xd00 && cp <= 0xd7f) return (cp >= 0xd66 && cp <= 0xd6f) ? null : "malayalam";
    if (cp >= 0xb80 && cp <= 0xbff) return (cp >= 0xbe6 && cp <= 0xbef) ? null : "tamil";
    return null;
  }
  function scriptCounts(s) {
    const c = { latin: 0, arabic: 0, devanagari: 0, malayalam: 0, tamil: 0, total: 0 };
    for (const ch of String(s || "")) {
      const sc = scriptOf(ch.codePointAt(0));
      if (sc) { c[sc]++; c.total++; }
    }
    return c;
  }
  function detectScript(s) {
    const c = scriptCounts(s);
    if (!c.total) return null;
    let best = null, n = 0;
    for (const k of ["latin", "arabic", "devanagari", "malayalam", "tamil"]) if (c[k] > n) { n = c[k]; best = k; }
    return best;
  }
  // ٹ ڈ ڑ ں ھ ہ ۂ ے ۓ — letters Urdu uses and Arabic doesn't
  const URDU_RE = /[ٹڈڑںھہۂےۓ]/g;
  function detectLang(s) {
    const sc = detectScript(s);
    if (!sc) return null;
    if (sc === "arabic") {
      const t = String(s).normalize("NFKC");
      const marks = (t.match(URDU_RE) || []).length;
      const letters = scriptCounts(t).arabic || 1;
      return marks >= Math.max(1, letters * 0.012) ? "ur" : "ar";
    }
    return { latin: "en", devanagari: "hi", malayalam: "ml", tamil: "ta" }[sc] || null;
  }
  function langDir(lang) { return lang === "ar" || lang === "ur" ? "rtl" : "ltr"; }

  /* NFKC folds Arabic presentation forms (FB50–FDFF, FE70–FEFF) and Latin
     ligatures back to plain letters. Drops soft hyphens, tatweel (kashida
     justification), bidi controls and stray C0 controls. ZWJ/ZWNJ stay:
     Malayalam chillus and Hindi conjuncts depend on them. */
  function normalizeText(s) {
    return String(s || "")
      .normalize("NFKC")
      .replace(/[­ـ]/g, "")
      .replace(/[‎‏‪-‮⁦-⁩﻿]/g, "")
      .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, "")
      .replace(/[  -   　]/g, " ");
  }

  /* Visual-order detection for Arabic-script text. Some PDFs store RTL text
     in drawing (visual) order, so extraction yields each line reversed.
     Arabic words never start with ة ى ے ں and the article ال only starts
     words: count evidence in both directions. */
  function rtlOrderScore(text) {
    // strong: ة ى ے ں only ever end a word; weak: the article ال only starts one
    let normal = 0, reversed = 0, strongN = 0, strongR = 0;
    const words = String(text || "").normalize("NFKC").match(/[\u0621-\u064A\u0671-\u06D3\u06FA-\u06FF]+/g) || [];
    for (const w of words) {
      if (w.length >= 3 && w.startsWith("\u0627\u0644")) normal++;
      if (w.length >= 3 && w.endsWith("\u0644\u0627")) reversed++;
      if (w.length >= 2 && /[\u0629\u0649\u06D2\u06BA]$/.test(w)) strongN++;
      if (w.length >= 2 && /^[\u0629\u0649\u06D2\u06BA]/.test(w)) strongR++;
    }
    return { normal: normal + strongN * 3, reversed: reversed + strongR * 3, strongN, strongR, words: words.length };
  }
  function looksVisualOrder(text) {
    const s = rtlOrderScore(text);
    if (s.strongR + s.strongN >= 2) return s.strongR > s.strongN * 2;
    return s.reversed >= 2 && s.reversed > s.normal * 2;
  }
  /* Ligature repair. A lam-alef ligature glyph carries its two letters as one
     unit, so bidi reordering can flip them: "الأول" comes out "األول" and the
     word "لا" as "ال". Both results are impossible in Arabic, so fixing them is
     safe. Length-preserving, so it can be applied to assembled lines. */
  function repairArabic(s) {
    return String(s)
      .replace(/(^|[^\u0600-\u06FF])\u0627([\u0623\u0625\u0622])\u0644/g, "$1\u0627\u0644$2")
      .replace(/(^|[^\u0600-\u06FF])\u0627\u0644(?=$|[^\u0600-\u06FF])/g, "$1\u0644\u0627");
  }
  /* Indic visual-order repair. Pre-base vowel signs (Hindi ि, Malayalam െ േ ൈ,
     Tamil ெ ே ை) are drawn before their consonant, and some PDFs store them in
     that drawing order: "िहन्दी", "ഇെതാരു", "அைத". A vowel sign can never start
     a syllable, so moving it after the consonant cluster is safe. Length-preserving. */
  const INDIC = [
    { pre: "\u093F", C: "\u0915-\u0939\u0958-\u095F", nukta: "\u093C", virama: "\u094D", post: "" },
    { pre: "\u0D46\u0D47\u0D48", C: "\u0D15-\u0D3A", nukta: "", virama: "\u0D4D", post: "\u0D3E\u0D57" },
    { pre: "\u0BC6\u0BC7\u0BC8", C: "\u0B95-\u0BB9", nukta: "", virama: "\u0BCD", post: "\u0BBE\u0BD7" },
  ].map(x => {
    const cl = "[" + x.C + "]" + (x.nukta ? x.nukta + "?" : "") + "(?:" + x.virama + "[" + x.C + "]" + (x.nukta ? x.nukta + "?" : "") + ")*";
    return new RegExp("(^|[^" + x.C + x.nukta + x.virama + "])([" + x.pre + "])(" + cl + ")", "g");
  });
  function repairIndic(s) {
    let out = String(s);
    for (const re of INDIC) out = out.replace(re, (m, a, v, c) => a + c + v);
    return out;
  }
  const MIRROR = { "(": ")", ")": "(", "[": "]", "]": "[", "{": "}", "}": "{", "<": ">", ">": "<", "«": "»", "»": "«" };
  function reverseVisual(s) {
    const clusters = String(s).match(/\P{M}\p{M}*|\p{M}+/gu) || [];
    let out = clusters.reverse().map(c => MIRROR[c] || c).join("");
    // LTR runs (Latin words, numbers, 12.5%, 2026-09-23) must read forwards again
    out = out.replace(/[0-9A-Za-zÀ-ɏ٠-٩۰-۹](?:[0-9A-Za-zÀ-ɏ٠-٩۰-۹.,:\/%+\-']*[0-9A-Za-zÀ-ɏ٠-٩۰-۹%])?/g,
      m => Array.from(m).reverse().join(""));
    return out;
  }

  /* Garbled / legacy-font text detection. Legacy Indic fonts (ML-TT Karthika,
     FML, Kruti Dev, Bamini…) draw Malayalam/Hindi/Tamil glyphs from Latin
     code points, so extraction returns things like "tIcf kÀ¡mÀ" or "vkSj ;g". */
  const LEGACY_FONTS = [
    [/^(ml-?tt|mlw-?tt|mlb-?tt|fml|manorama|mathrubhumi|karthika|revathi|ambili|nila|panchami|haritha|indulekha|kerala)/i, "ml"],
    [/(kruti|krutidev|devlys|chanakya|shivaji|walkman-chanakya|agra|aman|kundli)/i, "hi"],
    [/^(tam-|tab-|tsc|bamini|vanavil|elcot|stmzh|shree-tam)/i, "ta"],
  ];
  function legacyFontLang(fontNames) {
    for (const f of fontNames || []) {
      const n = String(f || "").replace(/^[A-Z]{6}\+/, "");
      for (const [re, lang] of LEGACY_FONTS) if (re.test(n)) return lang;
    }
    return null;
  }
  function textQuality(text, fontNames) {
    const s = String(text || "");
    const chars = Array.from(s.replace(/\s+/g, ""));
    const n = chars.length;
    const hint = legacyFontLang(fontNames);
    if (n < 16) return { garbled: !!hint && n > 3, empty: n < 4, score: 0, reason: hint ? "legacy-font" : (n < 4 ? "empty" : "short"), hint };
    let pua = 0, bad = 0, l1 = 0, latin = 0, vowels = 0;
    for (const ch of chars) {
      const cp = ch.codePointAt(0);
      if (cp >= 0xe000 && cp <= 0xf8ff) pua++;
      else if (cp === 0xfffd || cp < 0x20) bad++;
      else if ((cp >= 0xa1 && cp <= 0xbf) || cp === 0xd7 || cp === 0xf7) l1++;
      if ((cp >= 0x41 && cp <= 0x5a) || (cp >= 0x61 && cp <= 0x7a)) { latin++; if (/[aeiouyAEIOUY]/.test(ch)) vowels++; }
    }
    const tokens = s.split(/\s+/).filter(t => t.length > 1);
    let weird = 0, accentMix = 0;
    for (const t of tokens) {
      if (/[A-Za-z][;{}\[\]|\\^~`@#$&*=_<>][A-Za-z]|^[;{}\[\]|\\^~`][A-Za-z]/.test(t)) weird++;
      if (/[A-Za-z][¡-ÿ]|[¡-ÿ][A-Za-z]/.test(t) && /[¡-¿À-ÆÐÞ]/.test(t)) accentMix++;
    }
    const nt = Math.max(1, tokens.length);
    const reasons = [];
    const sPua = (pua + bad) / n, sL1 = l1 / n, sWeird = weird / nt, sMix = accentMix / nt;
    const vRatio = latin >= 40 ? vowels / latin : null;
    if (sPua > 0.08) reasons.push("unmapped-glyphs");
    if (sL1 > 0.06 || sMix > 0.2) reasons.push("latin1-soup");
    if (vRatio !== null && vRatio < 0.2) reasons.push("no-vowels");
    if (sWeird > 0.12) reasons.push("symbols-in-words");
    if (hint) reasons.push("legacy-font");
    const score = Math.min(1, sPua * 4 + sL1 * 5 + sMix * 2 + sWeird * 3 + (vRatio !== null ? Math.max(0, 0.28 - vRatio) * 4 : 0) + (hint ? 0.6 : 0));
    return { garbled: reasons.length > 0, empty: false, score, reason: reasons.join(",") || "ok", hint };
  }

  /* Sentence splitting for TTS & highlighting. Returns [{start, end}] ranges
     (trimmed). Breaks on . ! ? … and on ؟ ، ؛ । ॥ and newlines; long runs are
     cut at a comma/space so no single utterance exceeds maxLen. */
  const ABBREV = /(?:^|[\s(])(?:mr|mrs|ms|dr|prof|sr|jr|st|vs|etc|e\.g|i\.e|no|fig|figs|p|pp|vol|ch|sec|approx|dept|inc|ltd|co|mt|ft|jan|feb|mar|apr|jun|jul|aug|sep|sept|oct|nov|dec|[a-z])\.$|(?:^|[\s(])(?:[a-z]\.){2,}$/i;
  function splitSentences(text, maxLen) {
    maxLen = maxLen || 280;
    const s = String(text || "");
    const out = [];
    const push = (a, b) => {
      while (a < b && /\s/.test(s[a])) a++;
      while (b > a && /\s/.test(s[b - 1])) b--;
      if (b <= a) return;
      if (!/[\p{L}\p{N}]/u.test(s.slice(a, b))) { if (out.length && a - out[out.length - 1].end < 3) out[out.length - 1].end = b; return; }
      while (b - a > maxLen) {
        let cut = -1;
        for (let k = a + maxLen; k > a + maxLen * 0.45; k--) if (/[,;:،؛]/.test(s[k])) { cut = k + 1; break; }
        if (cut < 0) for (let k = a + maxLen; k > a + maxLen * 0.45; k--) if (s[k] === " ") { cut = k; break; }
        if (cut < 0) cut = a + maxLen;
        out.push({ start: a, end: cut });
        a = cut;
        while (a < b && /\s/.test(s[a])) a++;
      }
      if (b > a) out.push({ start: a, end: b });
    };
    let start = 0;
    for (let i = 0; i < s.length; i++) {
      const ch = s[i];
      if (ch === "\n") { push(start, i); start = i + 1; continue; }
      if (/[؟،؛।॥]/.test(ch)) { push(start, i + 1); start = i + 1; continue; }
      if (/[.!?…]/.test(ch)) {
        let j = i + 1;
        while (j < s.length && /[.!?…"'”’)\]]/.test(s[j])) j++;
        if (j < s.length && !/\s/.test(s[j])) continue;          // 3.5, e.g.x, URLs
        if (ch === "." && ABBREV.test(s.slice(Math.max(0, i - 8), i + 1))) continue;
        push(start, j); start = j; i = j - 1;
      }
    }
    push(start, s.length);
    return out;
  }

  /* Build a page text model from positioned runs (pdf.js items, MuPDF stext
     lines or OCR words), in stream order. Each run: {str, x, y, w, h, eol,
     size, bold, font, src}. Output:
       text  — normalised page text (lines of a paragraph joined by spaces,
               paragraphs by "\n")
       runs  — [{start, end, x, y, w, h, rtl, src}] char ranges → boxes
       paras — [{start, end, size, bold, heading, lang, dir}]
       lang, dir, quality, visualOrderFixed */
  function buildPageText(input, opts) {
    opts = opts || {};
    const runs = [];
    for (const r of input || []) {
      const str = normalizeText(r.str);
      if (!str.trim()) { if (r.eol && runs.length) runs[runs.length - 1].eol = true; continue; }
      runs.push({ str, x: +r.x || 0, y: +r.y || 0, w: Math.max(0, +r.w || 0), h: Math.max(1, +r.h || 10), eol: !!r.eol,
        size: r.size || r.h || 10, bold: !!r.bold, font: r.font || "", src: r.src != null ? r.src : null });
    }
    // lines
    const lines = [];
    let cur = null;
    for (const r of runs) {
      let newLine = !cur;
      if (cur) {
        const last = cur.runs[cur.runs.length - 1];
        const top = Math.max(last.y, r.y), bot = Math.min(last.y + last.h, r.y + r.h);
        const overlap = (bot - top) / Math.min(last.h, r.h);
        newLine = last.eol || overlap < 0.5;
      }
      if (newLine) { cur = { runs: [] }; lines.push(cur); }
      cur.runs.push(r);
    }
    function assemble(ln) {
      let t = "";
      ln.parts = [];
      let prev = null;
      for (const r of ln.runs) {
        if (prev) {
          const gap = Math.max(r.x - (prev.x + prev.w), prev.x - (r.x + r.w));
          if (gap > Math.min(r.h, prev.h) * 0.18 && !/[\s\u094D]$/.test(t) && !/^\s/.test(r.str)) t += " ";
        }
        ln.parts.push({ run: r, off: t.length });
        t += r.str;
        prev = r;
      }
      ln.text = t;
    }
    for (const ln of lines) assemble(ln);
    // visual-order repair (page-level decision on assembled lines, applied to Arabic-script lines)
    const fixOrder = opts.fixOrder !== false && looksVisualOrder(lines.map(l => l.text).join("\n"));
    if (fixOrder) {
      const LTRRUN = /^[0-9A-Za-z\u00C0-\u024F\u0660-\u0669\u06F0-\u06F9.,:%\/\-+']+$/;
      for (const ln of lines) {
        if (!/[\u0600-\u06FF]/.test(ln.text)) continue;
        // runs are stored left→right as drawn; Arabic reads right→left
        ln.runs.sort((a, b) => (b.x + b.w) - (a.x + a.w));
        for (const r of ln.runs) if (/[\u0600-\u06FF]/.test(r.str)) r.rtl = true;
        // stretches of Latin/number glyph runs must read left→right again
        const out = [];
        for (let i = 0; i < ln.runs.length;) {
          if (LTRRUN.test(ln.runs[i].str)) {
            let j = i;
            while (j + 1 < ln.runs.length && LTRRUN.test(ln.runs[j + 1].str)) j++;
            out.push(...ln.runs.slice(i, j + 1).reverse());
            i = j + 1;
          } else out.push(ln.runs[i++]);
        }
        ln.runs = out;
        assemble(ln);
      }
      // still reads backwards? then the runs themselves hold visual-order text (e.g. one run per line)
      if (looksVisualOrder(lines.map(l => l.text).join("\n"))) {
        for (const ln of lines) {
          if (!/[\u0600-\u06FF]/.test(ln.text)) continue;
          for (const r of ln.runs) if (Array.from(r.str).length > 1) r.str = reverseVisual(r.str);
        }
      }
    }
    for (const r of runs) {
      if (/[\u0600-\u06FF]/.test(r.str)) r.str = r.str.replace(/([\u0600-\u06FF])\s+([\u064B-\u0652\u0670])/g, "$1$2");
      // Devanagari words almost never end in a halant: a space after one is an extraction split
      if (/\u094D\s/.test(r.str)) r.str = r.str.replace(/\u094D\s+(?=[\u0915-\u0939])/g, "\u094D");
    }
    for (const ln of lines) {
      assemble(ln);
      if (/[\u0600-\u06FF\u0900-\u097F\u0B80-\u0BFF\u0D00-\u0D7F]/.test(ln.text)) {
        // ligature / vowel-sign repair works on whole words, which may span several runs
        const fixed = repairIndic(repairArabic(ln.text));
        if (fixed !== ln.text && fixed.length === ln.text.length)
          for (const p of ln.parts) p.run.str = fixed.slice(p.off, p.off + p.run.str.length);
        assemble(ln);
      }
      ln.y = Math.min(...ln.runs.map(r => r.y));
      ln.h = Math.max(...ln.runs.map(r => r.y + r.h)) - ln.y;
      ln.x = Math.min(...ln.runs.map(r => r.x));
      ln.size = Math.max(...ln.runs.map(r => r.size));
      ln.bold = ln.runs.every(r => r.bold);
    }
    // paragraphs
    const paraGroups = [];
    let pg = null, lastLine = null;
    const sizes = lines.map(l => l.size).sort((a, b) => a - b);
    const median = sizes.length ? sizes[Math.floor(sizes.length / 2)] : 12;
    for (const ln of lines) {
      let brk = !pg;
      if (pg && lastLine) {
        const gap = ln.y - (lastLine.y + lastLine.h);
        const lh = Math.max(lastLine.h, ln.h);
        brk = gap > lh * (opts.ocr ? 0.9 : 0.65) || gap < -lh * 1.5 || Math.abs(ln.size - lastLine.size) > Math.max(1.5, median * (opts.ocr ? 0.5 : 0.18)) ||
          (/[.!?:؟।]["'”]?$/.test(lastLine.text.trim()) && lastLine.text.trim().length < 0.6 * Math.max(...pg.lines.map(l => l.text.length)));
      }
      if (brk) { pg = { lines: [] }; paraGroups.push(pg); }
      pg.lines.push(ln);
      lastLine = ln;
    }
    // text assembly with char offsets
    let text = "";
    const outRuns = [], paras = [];
    for (let pi = 0; pi < paraGroups.length; pi++) {
      if (pi > 0) text += "\n";
      const pstart = text.length;
      const pls = paraGroups[pi].lines;
      for (let li = 0; li < pls.length; li++) {
        const ln = pls[li];
        let lt = ln.text;
        let dropHyphen = false;
        if (li < pls.length - 1 && /[a-zß-ÿ]-$/.test(lt) && /^[a-zß-ÿ]/.test(pls[li + 1].text)) { dropHyphen = true; lt = lt.slice(0, -1); }
        if (li > 0 && !/[-\s]$/.test(text) && !(pls[li - 1]._dropped)) text += " ";
        ln._dropped = dropHyphen;
        const base = text.length;
        for (let k = 0; k < ln.parts.length; k++) {
          const p = ln.parts[k];
          let a = base + p.off, b = a + p.run.str.length;
          const lineEnd = base + lt.length;
          if (b > lineEnd) b = lineEnd;
          if (b > a) outRuns.push({ start: a, end: b, x: p.run.x, y: p.run.y, w: p.run.w, h: p.run.h, rtl: !!p.run.rtl || /[֐-ࣿ]/.test(p.run.str), src: p.run.src });
        }
        text += lt;
      }
      const ptxt = text.slice(pstart);
      const pSize = Math.max(...pls.map(l => l.size));
      const lang = detectLang(ptxt);
      paras.push({ start: pstart, end: text.length, size: pSize, bold: pls.every(l => l.bold),
        heading: pls.length <= 3 && ptxt.length < 160 && pSize >= median * 1.25, lang, dir: langDir(lang) });
    }
    const lang = detectLang(text);
    // short Arabic-script paragraphs (headings) without Urdu-only letters follow an Urdu page
    if (lang === "ur") for (const p of paras) if (p.lang === "ar" && !/[\u0629\u0649\u064B-\u0652]/.test(text.slice(p.start, p.end))) p.lang = "ur";
    const fonts = Array.from(new Set(runs.map(r => r.font).filter(Boolean)));
    return { text, runs: outRuns, paras, lang, dir: langDir(lang), quality: textQuality(text, fonts), fonts, visualOrderFixed: fixOrder, median };
  }

  /* MuPDF StructuredText → word runs with exact glyph boxes (walk API).
     One run per word (trailing space included), eol on each line's last word. */
  function stextWordRuns(stext) {
    const runs = [];
    let images = 0, line = null, word = null;
    const flushWord = () => {
      if (word && word.str) runs.push({ str: word.str, x: word.x0, y: word.y0, w: word.x1 - word.x0, h: Math.max(word.y1 - word.y0, word.size * 0.9), size: word.size, font: line.font, bold: /bold|black|heavy/i.test(line.font) });
      word = null;
    };
    stext.walk({
      beginLine() { line = { font: "" }; word = null; },
      onChar(c, origin, font, size, quad) {
        if (!line.font && font) { try { line.font = font.getName() || ""; } catch (e) { line.font = ""; } }
        if (/\s/.test(c)) { if (word) { word.str += " "; flushWord(); } return; }
        const xs = [quad[0], quad[2], quad[4], quad[6]], ys = [quad[1], quad[3], quad[5], quad[7]];
        if (!word) word = { str: "", x0: Infinity, y0: Infinity, x1: -Infinity, y1: -Infinity, size: size || 10 };
        word.str += c;
        word.x0 = Math.min(word.x0, ...xs); word.x1 = Math.max(word.x1, ...xs);
        word.y0 = Math.min(word.y0, ...ys); word.y1 = Math.max(word.y1, ...ys);
        word.size = Math.max(word.size, size || 0);
      },
      endLine() { flushWord(); if (runs.length) runs[runs.length - 1].eol = true; line = null; },
      onImageBlock() { images++; },
    });
    return { runs, images };
  }

  /* character range → boxes (top-origin points), merged per line */
  function boxesForRange(page, start, end) {
    const out = [];
    if (!page || !page.runs) return out;
    for (const r of page.runs) {
      if (r.end <= start || r.start >= end) continue;
      const len = Math.max(1, r.end - r.start);
      const a = (Math.max(start, r.start) - r.start) / len, b = (Math.min(end, r.end) - r.start) / len;
      const x0 = r.rtl ? r.x + r.w * (1 - b) : r.x + r.w * a;
      const x1 = r.rtl ? r.x + r.w * (1 - a) : r.x + r.w * b;
      const last = out[out.length - 1];
      if (last && Math.abs(last.y - r.y) < r.h * 0.5 && Math.abs(last.h - r.h) < r.h * 0.6 && x0 <= last.x + last.w + r.h && x1 >= last.x - r.h) {
        const nx0 = Math.min(last.x, x0), nx1 = Math.max(last.x + last.w, x1);
        last.x = nx0; last.w = nx1 - nx0;
        last.y = Math.min(last.y, r.y); last.h = Math.max(last.h, r.h);
      } else out.push({ x: x0, y: r.y, w: Math.max(1, x1 - x0), h: r.h });
    }
    return out;
  }
  /* point (top-origin pts) → nearest char offset */
  function offsetAtPoint(page, x, y) {
    if (!page || !page.runs || !page.runs.length) return 0;
    let best = null, bd = Infinity;
    for (const r of page.runs) {
      const dy = y < r.y ? r.y - y : (y > r.y + r.h ? y - r.y - r.h : 0);
      const dx = x < r.x ? r.x - x : (x > r.x + r.w ? x - r.x - r.w : 0);
      const d = dy * 4 + dx;
      if (d < bd) { bd = d; best = r; }
    }
    let f = best.w > 0 ? (x - best.x) / best.w : 0;
    f = Math.max(0, Math.min(1, f));
    if (best.rtl) f = 1 - f;
    return best.start + Math.round(f * (best.end - best.start));
  }
  /* word range around an offset */
  function wordRangeAt(text, off) {
    const s = String(text || "");
    let a = Math.max(0, Math.min(off, s.length)), b = a;
    const isW = ch => ch && /[\p{L}\p{N}\p{M}'’‌‍]/u.test(ch);
    while (a > 0 && isW(s[a - 1])) a--;
    while (b < s.length && isW(s[b])) b++;
    return { start: a, end: b };
  }

  /* sentences with a language per sentence (voices switch on this) */
  function sentencesWithLang(text, fallbackLang) {
    let prev = fallbackLang || "en";
    return splitSentences(text).map(r => {
      const piece = text.slice(r.start, r.end);
      let lang = detectLang(piece) || prev;
      // short Urdu sentences may lack Urdu-only letters: keep the surrounding language
      if (lang === "ar" && (fallbackLang === "ur" || prev === "ur") && !/[\u0629\u0649\u064B-\u0652]/.test(piece)) lang = "ur";
      prev = lang;
      return { start: r.start, end: r.end, lang };
    });
  }

  /* quick content hash for per-file reader state (FNV-1a over size + head + tail) */
  function hashBytes(bytes) {
    const u = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
    const n = u.length, chunk = 262144;
    let h1 = 0x811c9dc5 ^ (n & 0xffffffff), h2 = 0x01000193 ^ Math.floor(n / 4294967296);
    const eat = (a, b) => {
      for (let i = a; i < b; i++) {
        h1 ^= u[i]; h1 = Math.imul(h1, 0x01000193) >>> 0;
        h2 ^= u[i] + (i & 255); h2 = Math.imul(h2, 0x01000193) >>> 0;
      }
    };
    eat(0, Math.min(n, chunk));
    if (n > chunk) eat(Math.max(chunk, n - chunk), n);
    return ("00000000" + h1.toString(16)).slice(-8) + ("00000000" + h2.toString(16)).slice(-8) + "-" + n.toString(36);
  }

  /* reading-time estimate */
  function countWords(s) { return (String(s || "").match(/[\p{L}\p{N}][\p{L}\p{N}\p{M}'‌‍]*/gu) || []).length; }
  function fmtDuration(min) {
    if (!isFinite(min) || min < 0) return "";
    if (min < 1) return "less than a minute";
    if (min < 60) return Math.round(min) + " min";
    const h = Math.floor(min / 60), m = Math.round(min % 60);
    return h + " h" + (m ? " " + m + " min" : "");
  }

  /* trim a signature bitmap: bbox of inked pixels (alpha, optionally not-white) */
  function inkBBox(rgba, w, h, opts) {
    opts = opts || {};
    const aMin = opts.alphaMin != null ? opts.alphaMin : 10, white = opts.whiteCut || 0;
    let minX = w, minY = h, maxX = -1, maxY = -1;
    for (let y = 0; y < h; y++) {
      const row = y * w * 4;
      for (let x = 0; x < w; x++) {
        const i = row + x * 4;
        if (rgba[i + 3] <= aMin) continue;
        if (white && rgba[i] >= white && rgba[i + 1] >= white && rgba[i + 2] >= white) continue;
        if (x < minX) minX = x; if (x > maxX) maxX = x;
        if (y < minY) minY = y; if (y > maxY) maxY = y;
      }
    }
    if (maxX < minX) return null;
    return { x: minX, y: minY, w: maxX - minX + 1, h: maxY - minY + 1 };
  }

  /* ---------------- misc ---------------- */
  function fmtBytes(n) {
    if (n < 1024) return n + " B";
    if (n < 1024 * 1024) return (n / 1024).toFixed(n < 10240 ? 1 : 0) + " KB";
    return (n / 1048576).toFixed(n < 10485760 ? 2 : 1) + " MB";
  }
  function baseName(name) { return String(name || "file").replace(/\.pdf$/i, ""); }

  return {
    parseRangeGroups, parsePageSet, loadDoc,
    mergePdfs, extractPages, splitPdf, rotatePdf, organizePdf, resavePdf,
    addPageNumbers, addTextWatermark, addImageWatermark,
    placeSignature, listFormFields, fillForm, ocrOverlay,
    applyOverlay, redactRegions, parseStext,
    cropPdf, linesToParas, parasToMarkdown, buildDocx, unzipBytes, docxParas, parasToPdf, textToParas,
    imagesToPdf, rebuildFromJpegs,
    zipStore, crc32, fmtBytes, baseName, norm360, effSize, posXY, hexToRgb01,
    MARGINS, NUM_FORMATS, PAGE_SIZES,
    LANGS, LANG_INFO, scriptCounts, detectScript, detectLang, langDir, normalizeText,
    rtlOrderScore, looksVisualOrder, reverseVisual, repairArabic, repairIndic, legacyFontLang, textQuality,
    splitSentences, sentencesWithLang, buildPageText, stextWordRuns, boxesForRange, offsetAtPoint, wordRangeAt,
    hashBytes, countWords, fmtDuration, inkBBox,
  };
});
