/* AtoB PDF tools */
"use strict";

function debounce(fn, ms) {
  let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); };
}

/* compact indicator for a loaded file */
function filePill(rec, meta, onClear) {
  return h("div", { class: "fchip filepill", style: "margin-bottom:14px" },
    icon("file"),
    h("span", { class: "fname" }, rec.name),
    h("span", { class: "fmeta" }, meta),
    h("span", { style: "flex:1" }),
    h("button", { class: "iconbtn x", title: "Choose a different file", onclick: onClear }, icon("close")));
}

/* single-PDF tool scaffold. needProbe: validate with pdf-lib (rejects encrypted early) */
function singlePdfTool(ctx, { needProbe = true, big }, onReady) {
  const start = async rec => {
    let pages = null;
    if (needProbe) {
      try {
        const d = await PDCore.loadDoc(bytesOf(rec));
        pages = d.getPageCount();
      } catch (e) {
        if (ctx.preload) { ctx.body.innerHTML = ""; errorBack(ctx.body, e, ctx.restart); return; }
        toast(e.message, "err");
        ctx.restart();
        return;
      }
    }
    ctx.body.innerHTML = "";
    try { await onReady(rec, pages); }
    catch (e) { errorBack(ctx.body, e, ctx.restart); }
  };
  if (ctx.preload) { start(ctx.preload); return; }
  ctx.body.append(makeDrop({ big: big || "Drop a PDF here", onFiles: ([r]) => start(r) }));
}

/* generic run wrapper: swaps body to progress, runs job, shows result */
async function runJob(ctx, label, job, makeFiles) {
  ctx.body.innerHTML = "";
  document.querySelectorAll(".actionbar").forEach(e => e.remove());
  const prog = progressPanel(label);
  ctx.body.append(prog.el);
  try {
    const out = await job(prog);
    const { files, opts } = makeFiles(out);
    /* v3.8: on an open document, a single-PDF result becomes its next edit step */
    const t = ctx.tab;
    if (t && ctx.modifies && files.length === 1 && files[0].mime === "application/pdf" && docTabs.includes(t)) {
      const def = VIEWS[currentView && currentView.id] || {};
      const lbl = (opts && opts.stepLabel) || def.stepLabel || def.name || label;
      applyToTab(t, lbl, files[0].bytes);
      appliedScreen(ctx.body, t, lbl, opts, ctx.restart);
      return;
    }
    resultScreen(ctx.body, files, opts, ctx.restart);
  } catch (e) {
    if (e && e.code === "RANGE") { toast(e.message, "err"); ctx.restart(); return; }
    errorBack(ctx.body, e, ctx.restart);
  }
}

/* live preview: renders page 1 once, then overlays drawFn(ctx2d, w, h, scale) */
function livePreview(rec, caption) {
  const base = document.createElement("canvas");
  const over = document.createElement("canvas");
  over.style.position = "absolute"; over.style.inset = "0"; over.style.width = "100%"; over.style.height = "100%";
  const frame = h("div", { class: "frame", style: "position:relative" }, base, over);
  const el = h("div", { class: "preview-wrap" }, frame, h("div", { class: "cap" }, caption || "Preview · page 1"));
  let pageW = 595, pageH = 842, drawFn = null, ready = false;
  (async () => {
    try {
      const doc = await openPdf(rec);
      const page = await doc.getPage(1);
      const vp1 = page.getViewport({ scale: 1 });
      pageW = vp1.width; pageH = vp1.height;
      const scale = 360 / vp1.width;
      const vp = page.getViewport({ scale });
      base.width = over.width = Math.round(vp.width);
      base.height = over.height = Math.round(vp.height);
      const c2 = base.getContext("2d", { alpha: false });
      c2.fillStyle = "#fff"; c2.fillRect(0, 0, base.width, base.height);
      await page.render({ canvasContext: c2, viewport: vp }).promise;
      closePdf(doc);
      ready = true;
      redraw();
    } catch (e) { /* preview is best-effort */ }
  })();
  function redraw() {
    if (!ready) return;
    const c = over.getContext("2d");
    c.clearRect(0, 0, over.width, over.height);
    if (drawFn) drawFn(c, pageW, pageH, over.width / pageW);
  }
  return { el, setDraw: fn => { drawFn = fn; redraw(); }, redraw: () => redraw(), getPageSize: () => ({ w: pageW, h: pageH }) };
}

/* =============== MERGE =============== */
registerTool({
  id: "merge", name: "Merge", icon: "merge", standalone: true,
  desc: "Combine PDFs into one file",
  hint: "Tip: select several files at once (Ctrl-click)",
  build(ctx) {
    const files = []; // {rec, pages, rangeStr}
    const list = h("div", { class: "filelist" });
    const bar = actionBar("", "Merge PDFs", run);
    ctx.setCleanup(() => bar.el.remove());

    const dropBig = makeDrop({ multiple: true, big: "Drop PDFs here", sub: "Add two or more files - you can select many at once in the picker (Ctrl-click or Ctrl+A).", onFiles: addFiles });
    const dropMore = makeDrop({ multiple: true, compact: true, big: "Add more PDFs", sub: "", onFiles: addFiles });
    dropMore.classList.add("hidden");
    let keepMarks = true;
    const marksBox = checkbox("Add a bookmark for each file (their own bookmarks go inside)", keepMarks, v => { keepMarks = v; });
    const marksRow = h("div", { class: "merge-opts hidden" }, marksBox.el);
    ctx.body.append(dropBig, dropMore, list, marksRow);
    document.body.append(bar.el);
    if (ctx.preload) addFiles(Array.isArray(ctx.preload) ? ctx.preload : [ctx.preload]);

    async function addFiles(recs) {
      for (const rec of recs) {
        try {
          const d = await PDCore.loadDoc(bytesOf(rec));
          files.push({ rec, pages: d.getPageCount(), rangeStr: "" });
        } catch (e) { toast(rec.name + ": " + e.message, "err"); }
      }
      render();
    }
    function selectedCount(f) {
      if (!f.rangeStr.trim()) return f.pages;
      try { return PDCore.parseRangeGroups(f.rangeStr, f.pages).reduce((a, g) => a + g.length, 0); }
      catch (e) { return null; }
    }
    function render() {
      list.innerHTML = "";
      files.forEach((f, i) => {
        const range = h("input", { class: "range", placeholder: "all pages · e.g. 1-3, 7", value: f.rangeStr });
        range.addEventListener("input", debounce(() => {
          f.rangeStr = range.value;
          const ok = selectedCount(f) != null;
          range.classList.toggle("bad", !ok && !!range.value.trim());
          updateBar();
        }, 200));
        list.append(h("div", { class: "fchip" },
          h("span", { class: "updown" },
            h("button", { title: "Move up", onclick: () => { if (i > 0) { files.splice(i - 1, 0, files.splice(i, 1)[0]); render(); } } }, "▲"),
            h("button", { title: "Move down", onclick: () => { if (i < files.length - 1) { files.splice(i + 1, 0, files.splice(i, 1)[0]); render(); } } }, "▼")),
          h("span", { class: "fname" }, f.rec.name),
          h("span", { class: "fmeta" }, f.pages + " pages"),
          range,
          h("button", { class: "iconbtn x", title: "Remove", onclick: () => { files.splice(i, 1); render(); } }, icon("close"))));
      });
      dropBig.classList.toggle("hidden", files.length > 0);
      dropMore.classList.toggle("hidden", files.length === 0);
      marksRow.classList.toggle("hidden", files.length < 2);
      updateBar();
    }
    function updateBar() {
      const counts = files.map(selectedCount);
      const bad = counts.some(c => c == null);
      const total = counts.reduce((a, c) => a + (c || 0), 0);
      bar.setSummary(files.length ? files.length + " files · " + total + " pages" + (bad ? " · check the highlighted range" : "") : "");
      bar.enable(files.length >= 2 && !bad);
    }
    function run() {
      const snapshot = files.slice();
      runJob(ctx, "Merging", async prog => {
        return await PDCore.mergePdfs(
          snapshot.map(f => bytesOf(f.rec)),
          snapshot.map(f => f.rangeStr),
          (done, total) => prog.set(done / total, "Merging " + snapshot[done - 1].rec.name, done + " / " + total),
          { names: snapshot.map(f => f.rec.name), bookmarks: keepMarks });
      }, bytes => ({
        files: [{ name: PDCore.baseName(snapshot[0].rec.name) + "-merged.pdf", bytes, mime: "application/pdf" }],
        opts: { title: "Merged" },
      }));
    }
  },
});

/* =============== SPLIT =============== */
registerTool({
  id: "split", name: "Split", icon: "split",
  desc: "Cut one PDF into several",
  build(ctx) {
    singlePdfTool(ctx, {}, (rec, pages) => {
      const bar = actionBar(pages + " pages", "Split PDF", run);
      ctx.setCleanup(() => bar.el.remove());
      document.body.append(bar.el);

      let mode = "ranges";
      const rangeInput = h("input", { type: "text", class: "wide", placeholder: "e.g. 1-3, 4-6, 7-" + pages, style: "width:min(340px,72vw);padding:7px 10px;border:1px solid var(--line);border-radius:8px;background:var(--surface)" });
      const everyInput = h("input", { type: "number", min: 1, max: pages, value: Math.min(2, pages) , style:"width:70px;padding:7px 10px;border:1px solid var(--line);border-radius:8px;background:var(--surface)"});
      const previewNote = h("div", { class: "opt-note" }, "");

      const rangesRow = h("div", { class: "opt-row" }, rangeInput);
      const everyRow = h("div", { class: "opt-row hidden" }, h("span", { class: "field" }, "Every", everyInput, "pages"));
      const eachRow = h("div", { class: "opt-note hidden" }, "Each of the " + pages + " pages becomes its own PDF.");

      const seg = segmented([
        { v: "ranges", label: "Custom ranges" },
        { v: "every", label: "Every N pages" },
        { v: "each", label: "One file per page" },
      ], mode, v => { mode = v;
        rangesRow.classList.toggle("hidden", v !== "ranges");
        everyRow.classList.toggle("hidden", v !== "every");
        eachRow.classList.toggle("hidden", v !== "each");
        update();
      });

      ctx.body.append(
        filePill(rec, pages + " pages · " + PDCore.fmtBytes(rec.size), ctx.restart),
        optSection("How to split", h("div", { class: "opt-row" }, seg.el), rangesRow, everyRow, eachRow, previewNote));

      function groups() {
        if (mode === "each") return Array.from({ length: pages }, (_, i) => [i]);
        if (mode === "every") {
          const n = Math.max(1, Math.min(pages, Math.floor(+everyInput.value || 1)));
          const g = [];
          for (let i = 0; i < pages; i += n) g.push(Array.from({ length: Math.min(n, pages - i) }, (_, k) => i + k));
          return g;
        }
        return PDCore.parseRangeGroups(rangeInput.value, pages);
      }
      function update() {
        try {
          const g = groups();
          previewNote.textContent = "→ " + g.length + " file" + (g.length === 1 ? "" : "s");
          rangeInput.classList.remove("bad");
          bar.enable(true);
          bar.setSummary(pages + " pages → " + g.length + " files");
        } catch (e) {
          previewNote.textContent = rangeInput.value.trim() ? e.message : "Enter ranges separated by commas. Each range becomes one file.";
          if (rangeInput.value.trim()) rangeInput.classList.add("bad");
          bar.enable(false);
          bar.setSummary(pages + " pages");
        }
      }
      rangeInput.addEventListener("input", debounce(update, 200));
      everyInput.addEventListener("input", debounce(update, 200));
      update();

      function run() {
        let g;
        try { g = groups(); } catch (e) { toast(e.message, "err"); return; }
        const base = PDCore.baseName(rec.name);
        runJob(ctx, "Splitting", async prog => {
          return await PDCore.splitPdf(bytesOf(rec), g, (d, t) => prog.set(d / t, "Writing part " + d, d + " / " + t));
        }, outs => ({
          files: outs.map((bytes, i) => {
            const gr = g[i];
            const label = gr.length === 1 ? "p" + (gr[0] + 1) : "p" + (Math.min(...gr) + 1) + "-" + (Math.max(...gr) + 1);
            return { name: base + "-" + label + ".pdf", bytes, mime: "application/pdf" };
          }),
          opts: { title: "Split into " + outs.length + " files", zipName: base + "-split.zip" },
        }));
      }
    });
  },
});

/* =============== thumbnail grid helper =============== */
async function buildThumbGrid(ctx, rec, { selectable, organize }) {
  const doc = await openPdf(rec);
  const tq = new ThumbQueue(doc);
  ctx.setCleanup(() => { tq.kill(); closePdf(doc); document.querySelectorAll(".actionbar").forEach(e => e.remove()); });
  const grid = h("div", { class: "thumbs" + (organize ? " roomy" : " roomy") });
  const items = []; // organize: {srcIdx, rot, el}; select: {idx, sel, el}
  const n = doc.numPages;
  for (let i = 0; i < n; i++) {
    const holder = h("div", { class: "rotwrap" });
    const frame = h("div", { class: "frame" }, holder);
    const card = h("div", { class: "pcard" }, frame, h("div", { class: "pno" }, String(i + 1)));
    if (selectable) card.append(h("span", { class: "selmark" }, icon("check")));
    grid.append(card);
    items.push(organize ? { srcIdx: i, rot: 0, el: card, holder } : { idx: i, sel: false, el: card });
    tq.render(i + 1, 240).then(c => { holder.innerHTML = ""; holder.append(c); c.style.maxWidth = "100%"; c.style.maxHeight = "100%"; c.style.width = "auto"; c.style.height = "auto"; }).catch(() => {});
  }
  return { doc, grid, items, n, tq };
}

/* =============== EXTRACT =============== */
registerTool({
  id: "extract", name: "Extract pages", icon: "extract",
  desc: "Pull selected pages into a new PDF",
  build(ctx) {
    singlePdfTool(ctx, {}, async (rec, pages) => {
      const { grid, items } = await buildThumbGrid(ctx, rec, { selectable: true });
      const bar = actionBar("", "Extract pages", run);
      document.body.append(bar.el);
      const count = h("span", { class: "count" }, "");
      let lastClicked = -1;

      function setSel(it, v) { it.sel = v; it.el.classList.toggle("sel", v); }
      function refresh() {
        const c = items.filter(i => i.sel).length;
        count.textContent = c + " of " + items.length + " selected";
        bar.setSummary(c + " page" + (c === 1 ? "" : "s") + " selected");
        bar.enable(c > 0);
        bar.setLabel(c > 0 ? "Extract " + c + " page" + (c === 1 ? "" : "s") : "Extract pages");
      }
      items.forEach((it, i) => it.el.addEventListener("click", e => {
        if (e.shiftKey && lastClicked >= 0) {
          const [a, b] = [Math.min(lastClicked, i), Math.max(lastClicked, i)];
          for (let k = a; k <= b; k++) setSel(items[k], true);
        } else setSel(it, !it.sel);
        lastClicked = i;
        refresh();
      }));

      const rangeInput = h("input", { class: "range", placeholder: "or type a range: 1-3, 7", style: "width:200px" });
      rangeInput.addEventListener("input", debounce(() => {
        if (!rangeInput.value.trim()) { rangeInput.classList.remove("bad"); return; }
        try {
          const set = new Set(PDCore.parsePageSet(rangeInput.value, items.length));
          items.forEach((it, i) => setSel(it, set.has(i)));
          rangeInput.classList.remove("bad");
          refresh();
        } catch (e) { rangeInput.classList.add("bad"); }
      }, 250));

      ctx.body.append(
        filePill(rec, pages + " pages", ctx.restart),
        h("div", { class: "thumb-toolbar" },
          h("button", { class: "btn secondary", style: "height:32px;padding:0 12px;font-size:12.5px", onclick: () => { items.forEach(i => setSel(i, true)); refresh(); } }, "All"),
          h("button", { class: "btn secondary", style: "height:32px;padding:0 12px;font-size:12.5px", onclick: () => { items.forEach(i => setSel(i, false)); refresh(); } }, "None"),
          h("button", { class: "btn secondary", style: "height:32px;padding:0 12px;font-size:12.5px", onclick: () => { items.forEach(i => setSel(i, !i.sel)); refresh(); } }, "Invert"),
          rangeInput,
          h("span", { class: "spacer" }), count),
        grid);
      refresh();

      function run() {
        const sel = items.filter(i => i.sel).map(i => i.idx);
        runJob(ctx, "Extracting", async prog => {
          prog.set(0.4, "Copying " + sel.length + " pages");
          return await PDCore.extractPages(bytesOf(rec), sel);
        }, bytes => ({
          files: [{ name: PDCore.baseName(rec.name) + "-extracted.pdf", bytes, mime: "application/pdf" }],
          opts: { title: "Extracted " + sel.length + " page" + (sel.length === 1 ? "" : "s") },
        }));
      }
    });
  },
});

/* =============== ORGANIZE =============== */
registerTool({
  id: "organize", name: "Organize", icon: "organize",
  desc: "Reorder, rotate, delete pages",
  hint: "Drag pages to reorder. Hover a page for actions.",
  build(ctx) {
    singlePdfTool(ctx, {}, async (rec, pages) => {
      const built = await buildThumbGrid(ctx, rec, { organize: true });
      const { grid } = built;
      let items = built.items;
      const bar = actionBar("", "Apply changes", run);
      document.body.append(bar.el);
      const count = h("span", { class: "count" }, "");

      function attach(it) {
        const acts = h("div", { class: "acts" },
          h("button", { title: "Rotate 90°", onclick: e => { e.stopPropagation(); it.rot = (it.rot + 90) % 360; it.holder.style.transform = "rotate(" + it.rot + "deg)"; markDirty(); } }, icon("rotcw")),
          h("button", { title: "Duplicate", onclick: e => { e.stopPropagation(); dup(it); } }, icon("plus")),
          h("button", { title: "Delete", onclick: e => { e.stopPropagation(); items = items.filter(x => x !== it); it.el.remove(); renumber(); markDirty(); } }, icon("trash")));
        it.el.append(acts);
        enableDrag(it);
      }
      function dup(it) {
        const holder = h("div", { class: "rotwrap" });
        const c = it.holder.firstChild;
        if (c && c.tagName === "CANVAS") {
          const copy = document.createElement("canvas");
          copy.width = c.width; copy.height = c.height;
          copy.getContext("2d").drawImage(c, 0, 0);
          copy.style.cssText = c.style.cssText;
          holder.append(copy);
        }
        holder.style.transform = it.holder.style.transform;
        const card = h("div", { class: "pcard" }, h("div", { class: "frame" }, holder), h("div", { class: "pno" }, ""));
        const ni = { srcIdx: it.srcIdx, rot: it.rot, el: card, holder };
        items.splice(items.indexOf(it) + 1, 0, ni);
        it.el.after(card);
        attach(ni);
        renumber(); markDirty();
      }
      function renumber() {
        items.forEach((it, i) => { const pno = it.el.querySelector(".pno"); if (pno) pno.textContent = String(i + 1); });
        count.textContent = items.length + " page" + (items.length === 1 ? "" : "s");
      }
      let dirty = false;
      function markDirty() { dirty = true; bar.enable(items.length > 0); bar.setSummary(items.length + " pages · modified"); }

      /* pointer-based drag reorder */
      function enableDrag(it) {
        it.el.addEventListener("pointerdown", e => {
          if (e.button !== 0 || e.target.closest(".acts")) return;
          const startX = e.clientX, startY = e.clientY;
          let dragging = false, target = null, side = "r";
          const move = ev => {
            if (!dragging && Math.hypot(ev.clientX - startX, ev.clientY - startY) > 7) {
              dragging = true;
              it.el.classList.add("dragging");
              it.el.setPointerCapture && it.el.setPointerCapture(e.pointerId);
            }
            if (!dragging) return;
            ev.preventDefault();
            const elu = document.elementFromPoint(ev.clientX, ev.clientY);
            const card = elu && elu.closest ? elu.closest(".pcard") : null;
            grid.querySelectorAll(".pcard").forEach(c => c.classList.remove("dropside-l", "dropside-r"));
            target = null;
            if (card && card !== it.el && card.parentElement === grid) {
              const r = card.getBoundingClientRect();
              side = ev.clientX < r.left + r.width / 2 ? "l" : "r";
              card.classList.add(side === "l" ? "dropside-l" : "dropside-r");
              target = card;
            }
          };
          const up = () => {
            window.removeEventListener("pointermove", move);
            window.removeEventListener("pointerup", up);
            it.el.classList.remove("dragging");
            grid.querySelectorAll(".pcard").forEach(c => c.classList.remove("dropside-l", "dropside-r"));
            if (dragging && target) {
              const ti = items.find(x => x.el === target);
              const from = items.indexOf(it);
              items.splice(from, 1);
              let to = items.indexOf(ti);
              if (side === "r") to++;
              items.splice(to, 0, it);
              if (side === "l") grid.insertBefore(it.el, target);
              else grid.insertBefore(it.el, target.nextSibling);
              renumber(); markDirty();
            }
          };
          window.addEventListener("pointermove", move, { passive: false });
          window.addEventListener("pointerup", up);
        });
      }
      items.forEach(attach);
      renumber();
      bar.setSummary(items.length + " pages");
      bar.enable(false);

      ctx.body.append(
        filePill(rec, pages + " pages", ctx.restart),
        h("div", { class: "thumb-toolbar" },
          h("button", { class: "btn secondary", style: "height:32px;padding:0 12px;font-size:12.5px", onclick: ctx.restart }, "Reset"),
          h("span", { class: "spacer" }), count),
        grid);

      function run() {
        const order = items.map(it => ({ srcIdx: it.srcIdx, rotDelta: it.rot }));
        runJob(ctx, "Rebuilding", async prog => {
          prog.set(0.4, "Writing " + order.length + " pages");
          return await PDCore.organizePdf(bytesOf(rec), order);
        }, bytes => ({
          files: [{ name: PDCore.baseName(rec.name) + "-organized.pdf", bytes, mime: "application/pdf" }],
          opts: { title: "Pages reorganized" },
        }));
      }
    });
  },
});

/* =============== ROTATE =============== */
registerTool({
  id: "rotate", name: "Rotate", icon: "rotate",
  desc: "Turn all or some pages",
  build(ctx) {
    singlePdfTool(ctx, {}, (rec, pages) => {
      const bar = actionBar(pages + " pages", "Rotate", run);
      ctx.setCleanup(() => bar.el.remove());
      document.body.append(bar.el);
      let scope = "all", angle = 90;
      const rangeInput = h("input", { class: "range hidden", placeholder: "e.g. 2, 5-7", style: "width:170px" });
      const scopeSeg = segmented([
        { v: "all", label: "All pages" }, { v: "odd", label: "Odd" }, { v: "even", label: "Even" }, { v: "custom", label: "Custom" },
      ], scope, v => { scope = v; rangeInput.classList.toggle("hidden", v !== "custom"); update(); });
      const angleSeg = segmented([
        { v: 90, label: "90° right" }, { v: 180, label: "180°" }, { v: 270, label: "90° left" },
      ], angle, v => { angle = v; });
      rangeInput.addEventListener("input", debounce(update, 200));

      ctx.body.append(
        filePill(rec, pages + " pages", ctx.restart),
        optSection("Which pages", h("div", { class: "opt-row" }, scopeSeg.el, rangeInput)),
        optSection("Direction", h("div", { class: "opt-row" }, angleSeg.el)));

      function indices() {
        if (scope === "all") return Array.from({ length: pages }, (_, i) => i);
        if (scope === "odd") return Array.from({ length: pages }, (_, i) => i).filter(i => i % 2 === 0);
        if (scope === "even") return Array.from({ length: pages }, (_, i) => i).filter(i => i % 2 === 1);
        return PDCore.parsePageSet(rangeInput.value, pages);
      }
      function update() {
        try {
          const k = indices().length;
          bar.setSummary("Will rotate " + k + " of " + pages + " pages");
          bar.enable(k > 0);
          rangeInput.classList.remove("bad");
        } catch (e) {
          bar.setSummary(rangeInput.value.trim() ? e.message : "Enter a page range");
          bar.enable(false);
          if (rangeInput.value.trim()) rangeInput.classList.add("bad");
        }
      }
      update();
      function run() {
        let idx;
        try { idx = indices(); } catch (e) { toast(e.message, "err"); return; }
        runJob(ctx, "Rotating", async prog => {
          prog.set(0.5, "Rotating " + idx.length + " pages");
          return await PDCore.rotatePdf(bytesOf(rec), idx, angle);
        }, bytes => ({
          files: [{ name: PDCore.baseName(rec.name) + "-rotated.pdf", bytes, mime: "application/pdf" }],
          opts: { title: "Rotated" },
        }));
      }
    });
  },
});

/* =============== COMPRESS =============== */
registerTool({
  id: "compress", name: "Compress", icon: "compress",
  desc: "Shrink the file size",
  build(ctx) {
    singlePdfTool(ctx, {}, (rec, pages) => {
      const bar = actionBar(PDCore.fmtBytes(rec.size), "Compress", run);
      ctx.setCleanup(() => bar.el.remove());
      document.body.append(bar.el);
      let level = "balanced";
      const NOTES = {
        light: "Rewrites the file structure without touching quality. Typical gain 0–20%.",
        deep: "MuPDF deep clean: deduplicates objects and recompresses streams, fonts and images losslessly. Keeps text selectable. Often the best choice.",
        balanced: "Re-renders pages at 150 DPI. Good quality for reading and printing. Text becomes non-selectable.",
        strong: "Re-renders at 110 DPI. Noticeably smaller, fine on screen. Text becomes non-selectable.",
        extreme: "Re-renders at 72 DPI. Smallest file, visibly softer. Text becomes non-selectable.",
      };
      const note = h("div", { class: "opt-note" }, NOTES[level]);
      const seg = segmented([
        { v: "light", label: "Light (lossless)" },
        { v: "deep", label: "Deep (lossless)" },
        { v: "balanced", label: "Balanced" },
        { v: "strong", label: "Strong" },
        { v: "extreme", label: "Extreme" },
      ], level, v => { level = v; note.textContent = NOTES[v]; note.classList.toggle("warn", v !== "light" && v !== "deep"); });
      ctx.body.append(
        filePill(rec, pages + " pages · " + PDCore.fmtBytes(rec.size), ctx.restart),
        optSection("Compression level", h("div", { class: "opt-row" }, seg.el), note));
      bar.enable(true);

      const DPI = { balanced: 150, strong: 110, extreme: 72 };
      const Q = { balanced: 0.72, strong: 0.62, extreme: 0.5 };
      function run() {
        const before = rec.size;
        runJob(ctx, "Compressing", async prog => {
          if (level === "light") {
            prog.set(0.5, "Rebuilding file structure");
            const out = await PDCore.resavePdf(bytesOf(rec));
            return { out, rasterized: false };
          }
          if (level === "deep") {
            prog.set(0.15, "Loading MuPDF engine (one-time)");
            const mupdf = await loadMuPDF();
            prog.set(0.6, "Deduplicating and recompressing");
            const doc = mupdfOpen(mupdf, bytesOf(rec));
            try {
              const out = PDCore.mupdfSave(doc, "garbage=deduplicate,compress=yes,compress-fonts=yes,compress-images=yes,clean=yes");
              return { out, rasterized: false };
            } finally { try { doc.destroy(); } catch (e) {} }
          }
          const doc = await openPdf(rec);
          try {
            const pageJpegs = [];
            for (let i = 1; i <= doc.numPages; i++) {
              prog.set((i - 1) / doc.numPages, "Rendering page " + i, i + " / " + doc.numPages);
              const { canvas } = await renderPageToCanvas(doc, i, 0, { dpi: DPI[level] });
              const blob = await new Promise(r => canvas.toBlob(r, "image/jpeg", Q[level]));
              const page = await doc.getPage(i);
              const vp = page.getViewport({ scale: 1 });
              pageJpegs.push({ jpeg: new Uint8Array(await blob.arrayBuffer()), wPt: vp.width, hPt: vp.height });
              canvas.width = 1; canvas.height = 1;
            }
            prog.set(0.96, "Assembling PDF");
            const out = await PDCore.rebuildFromJpegs(pageJpegs);
            return { out, rasterized: true };
          } finally { closePdf(doc); }
        }, res => {
          let bytes = res.out, kept = false;
          if (bytes.length >= before) {
            if (!res.rasterized) { bytes = new Uint8Array(rec.buf.slice(0)); kept = true; }
          }
          const after = bytes.length;
          const pct = Math.round((1 - after / before) * 100);
          return {
            files: [{ name: PDCore.baseName(rec.name) + "-compressed.pdf", bytes, mime: "application/pdf" }],
            opts: {
              title: kept ? "Already optimized" : "Compressed",
              meta: PDCore.fmtBytes(before) + " → " + PDCore.fmtBytes(after),
              deltaText: kept ? "This PDF was already efficient. Kept the original quality untouched."
                : (pct >= 0 ? pct + "% smaller" : "Result came out larger. Try a stronger level, or the original may already be optimized."),
              deltaGood: pct > 0 && !kept,
            },
          };
        });
      }
    });
  },
});

/* =============== WATERMARK =============== */
registerTool({
  id: "watermark", name: "Watermark", icon: "watermark",
  desc: "Stamp text or an image",
  build(ctx) {
    singlePdfTool(ctx, {}, (rec, pages) => {
      const bar = actionBar(pages + " pages", "Add watermark", run);
      ctx.setCleanup(() => bar.el.remove());
      document.body.append(bar.el);
      let mode = "text", imgRec = null, imgIsPng = true, imgEl = null;

      const preview = livePreview(rec);
      const textInput = h("input", { type: "text", class: "wide", value: "CONFIDENTIAL", style: "padding:8px 11px;border:1px solid var(--line);border-radius:8px;background:var(--surface);width:min(300px,70vw)" });
      const sizeS = slider(24, 140, 2, 64, v => v + " pt", redraw);
      const opacS = slider(5, 100, 5, 25, v => v + "%", redraw);
      const scaleS = slider(10, 100, 5, 40, v => v + "%", redraw);
      let angle = 45;
      const angleSeg = segmented([{ v: 45, label: "45°" }, { v: 0, label: "0°" }, { v: -45, label: "-45°" }, { v: 90, label: "90°" }], angle, v => { angle = v; redraw(); });
      const colorSw = swatches(["#9a9186", "#b3362a", "#2c4a6e", "#3d7a4f"], "#9a9186", redraw);
      let tiled = true, pos = "mc";
      const posG = posGrid(pos, v => { pos = v; tileC.set(false); tiled = false; redraw(); });
      const tileC = checkbox("Tile across the page", true, v => { tiled = v; redraw(); });
      const rangeInput = h("input", { class: "range", placeholder: "all pages · e.g. 2-", style: "width:170px" });
      rangeInput.addEventListener("input", debounce(update, 250));
      textInput.addEventListener("input", debounce(redraw, 150));

      const imgDrop = makeDrop({ accept: "image", compact: true, big: "Choose a watermark image", sub: "PNG with transparency works best", onFiles: async ([r]) => {
        imgRec = r;
        imgIsPng = !/\.jpe?g$/i.test(r.name);
        const blob = new Blob([r.buf]);
        imgEl = new Image();
        imgEl.onload = redraw;
        imgEl.src = URL.createObjectURL(blob);
        imgDrop.querySelector(".big").textContent = r.name;
        update();
      }});

      const textOpts = h("div", null,
        optSection("Text", h("div", { class: "opt-row" }, textInput, colorSw.el)),
        optSection("Size & angle", h("div", { class: "opt-row" }, sizeS.el, angleSeg.el)));
      const imgOpts = h("div", { class: "hidden" },
        optSection("Image", h("div", { class: "opt-row" }, imgDrop)),
        optSection("Size", h("div", { class: "opt-row" }, scaleS.el, h("span", { class: "muted", style: "font-size:12.5px" }, "of page width"))));

      const modeSeg = segmented([{ v: "text", label: "Text" }, { v: "image", label: "Image" }], mode, v => {
        mode = v;
        textOpts.classList.toggle("hidden", v !== "text");
        imgOpts.classList.toggle("hidden", v !== "image");
        update(); redraw();
      });

      ctx.body.append(
        filePill(rec, pages + " pages", ctx.restart),
        h("div", { class: "preview-cols" },
          h("div", { class: "opts" },
            optSection("Watermark type", h("div", { class: "opt-row" }, modeSeg.el)),
            textOpts, imgOpts,
            optSection("Placement", h("div", { class: "opt-row" }, posG.el, tileC.el)),
            optSection("Opacity & pages", h("div", { class: "opt-row" }, opacS.el, rangeInput))),
          preview.el));

      preview.setDraw(draw);
      function redraw() { if (tiled) posGridDim(true); else posGridDim(false); preview.redraw(); }
      function posGridDim(dim) { posG.el.style.opacity = dim ? "0.45" : "1"; }
      tileC.el.addEventListener("click", () => {}); // handled in onChange

      function draw(c, pw, ph, s) {
        c.globalAlpha = opacS.get() / 100;
        if (mode === "text") {
          const text = textInput.value || " ";
          const sizePx = sizeS.get() * s;
          c.fillStyle = colorSw.get();
          c.font = "600 " + sizePx + "px Helvetica, Arial, sans-serif";
          const tw = c.measureText(text).width;
          const th = sizePx * 0.72;
          const rad = -angle * Math.PI / 180; // canvas y-down
          const drawAt = (cx, cy) => {
            c.save();
            c.translate(cx * s, (ph - cy) * s);
            c.rotate(rad);
            c.fillText(text, -tw / 2, th / 2);
            c.restore();
          };
          if (tiled) {
            const twPt = tw / s, thPt = th / s;
            const stepX = twPt + 110, stepY = Math.max(130, thPt + 110);
            const diag = Math.sqrt(pw * pw + ph * ph);
            for (let y = -diag * 0.1; y <= ph + diag * 0.1; y += stepY)
              for (let x = -diag * 0.1; x <= pw + diag * 0.1; x += stepX)
                drawAt(x + twPt / 2, y + thPt / 2);
          } else {
            const m = 46, twPt = tw / s, thPt = th / s;
            const box = PDCore.posXY(pos, pw, ph, Math.min(twPt, pw - 2 * m), thPt, m);
            drawAt(box.x + Math.min(twPt, pw - 2 * m) / 2, box.y + thPt / 2);
          }
        } else if (imgEl && imgEl.complete && imgEl.naturalWidth) {
          const iw = pw * scaleS.get() / 100;
          const ih = iw * imgEl.naturalHeight / imgEl.naturalWidth;
          const drawAt = (x, y) => c.drawImage(imgEl, x * s, (ph - y - ih) * s, iw * s, ih * s);
          if (tiled) {
            for (let y = -ih / 2; y <= ph; y += ih + 70)
              for (let x = -iw / 2; x <= pw; x += iw + 70) drawAt(x, y);
          } else {
            const box = PDCore.posXY(pos, pw, ph, iw, ih, 40);
            drawAt(box.x, box.y);
          }
        }
        c.globalAlpha = 1;
      }

      function indices() {
        if (!rangeInput.value.trim()) return null;
        return PDCore.parsePageSet(rangeInput.value, pages);
      }
      function update() {
        try {
          const idx = indices();
          rangeInput.classList.remove("bad");
          const k = idx ? idx.length : pages;
          bar.setSummary("Watermark on " + k + " page" + (k === 1 ? "" : "s"));
          bar.enable(mode === "text" ? true : !!imgRec);
        } catch (e) {
          rangeInput.classList.add("bad");
          bar.enable(false);
          bar.setSummary(e.message);
        }
      }
      update();

      function run() {
        let idx;
        try { idx = indices(); } catch (e) { toast(e.message, "err"); return; }
        const opts = { opacity: opacS.get() / 100, tile: tiled, pos, indices: idx };
        runJob(ctx, "Stamping", async prog => {
          prog.set(0.4, "Stamping pages");
          if (mode === "text")
            return await PDCore.addTextWatermark(bytesOf(rec), Object.assign(opts, {
              text: textInput.value || "WATERMARK", size: sizeS.get(), color: colorSw.get(), angle }));
          return await PDCore.addImageWatermark(bytesOf(rec), new Uint8Array(imgRec.buf.slice(0)), imgIsPng, Object.assign(opts, { scalePct: scaleS.get() }));
        }, bytes => ({
          files: [{ name: PDCore.baseName(rec.name) + "-watermarked.pdf", bytes, mime: "application/pdf" }],
          opts: { title: "Watermark added" },
        }));
      }
    });
  },
});

/* =============== PAGE NUMBERS =============== */
registerTool({
  id: "numbers", name: "Page numbers", icon: "numbers",
  desc: "Stamp numbers on every page",
  build(ctx) {
    singlePdfTool(ctx, {}, (rec, pages) => {
      const bar = actionBar(pages + " pages", "Add page numbers", run);
      ctx.setCleanup(() => bar.el.remove());
      document.body.append(bar.el);
      let pos = "bc", format = "n", margin = "md", size = 11;
      const preview = livePreview(rec);
      const posG = posGrid(pos, v => { pos = v; preview.redraw(); });
      const fmtSel = h("select", null,
        h("option", { value: "n" }, "1"),
        h("option", { value: "nt" }, "1 / " + pages),
        h("option", { value: "pn" }, "Page 1"),
        h("option", { value: "pnt" }, "Page 1 of " + pages));
      fmtSel.addEventListener("change", () => { format = fmtSel.value; preview.redraw(); });
      const sizeSeg = segmented([{ v: 9, label: "Small" }, { v: 11, label: "Normal" }, { v: 14, label: "Large" }], size, v => { size = v; preview.redraw(); });
      const marginSeg = segmented([{ v: "sm", label: "Tight" }, { v: "md", label: "Normal" }, { v: "lg", label: "Wide" }], margin, v => { margin = v; preview.redraw(); });
      const colorSw = swatches(["#4b4640", "#8a8377", "#1a1a1a"], "#4b4640", () => preview.redraw());
      const startField = h("input", { type: "number", value: 1, min: 0, style: "width:70px;padding:6px 9px;border:1px solid var(--line);border-radius:8px;background:var(--surface)" });
      const skipC = checkbox("Skip the first page (cover)", false, () => {});
      startField.addEventListener("input", () => preview.redraw());

      ctx.body.append(
        filePill(rec, pages + " pages", ctx.restart),
        h("div", { class: "preview-cols" },
          h("div", { class: "opts" },
            optSection("Position", h("div", { class: "opt-row" }, posG.el)),
            optSection("Format", h("div", { class: "opt-row" }, fmtSel, h("span", { class: "field" }, "Start at", startField))),
            optSection("Style", h("div", { class: "opt-row" }, sizeSeg.el, marginSeg.el, colorSw.el)),
            optSection("Options", h("div", { class: "opt-row" }, skipC.el))),
          preview.el));
      bar.enable(true);

      preview.setDraw((c, pw, ph, s) => {
        const start = parseInt(startField.value, 10) || 1;
        const text = PDCore.NUM_FORMATS[format](start, pages);
        const sizePx = size * s;
        c.font = sizePx + "px Helvetica, Arial, sans-serif";
        c.fillStyle = colorSw.get();
        const tw = c.measureText(text).width;
        const box = PDCore.posXY(pos, pw, ph, tw / s, size * 0.72, PDCore.MARGINS[margin]);
        c.fillText(text, box.x * s, (ph - box.y) * s);
      });

      function run() {
        runJob(ctx, "Numbering", async prog => {
          prog.set(0.5, "Stamping " + pages + " pages");
          return await PDCore.addPageNumbers(bytesOf(rec), {
            pos, format, margin, size,
            color: colorSw.get(),
            start: parseInt(startField.value, 10) || 1,
            skipFirst: skipC.get(),
          });
        }, bytes => ({
          files: [{ name: PDCore.baseName(rec.name) + "-numbered.pdf", bytes, mime: "application/pdf" }],
          opts: { title: "Page numbers added" },
        }));
      }
    });
  },
});

/* =============== IMAGES -> PDF =============== */
registerTool({
  id: "img2pdf", name: "Images to PDF", icon: "img2pdf", acceptsPdf: false,
  desc: "JPG or PNG pages into one PDF",
  build(ctx) {
    const imgs = []; // {rec, url}
    const list = h("div", { class: "filelist" });
    const bar = actionBar("", "Create PDF", run);
    ctx.setCleanup(() => { bar.el.remove(); imgs.forEach(i => URL.revokeObjectURL(i.url)); });
    document.body.append(bar.el);
    let pageSize = "a4", orient = "auto", marginPct = 3;
    const sizeSeg = segmented([{ v: "a4", label: "A4" }, { v: "letter", label: "Letter" }, { v: "fit", label: "Fit image" }], pageSize, v => { pageSize = v; orientSeg.el.style.opacity = v === "fit" ? "0.45" : "1"; });
    const orientSeg = segmented([{ v: "auto", label: "Auto" }, { v: "p", label: "Portrait" }, { v: "l", label: "Landscape" }], orient, v => { orient = v; });
    const marginSeg = segmented([{ v: 0, label: "None" }, { v: 3, label: "Small" }, { v: 8, label: "Wide" }], marginPct, v => { marginPct = v; });

    const drop = makeDrop({ accept: "image", multiple: true, big: "Drop images here", sub: "JPG, PNG, WebP, GIF or BMP. They'll become PDF pages in order.", onFiles: addImgs });
    const dropMore = makeDrop({ accept: "image", multiple: true, compact: true, big: "Add more images", sub: "", onFiles: addImgs });
    dropMore.classList.add("hidden");

    ctx.body.append(drop, dropMore, list,
      optSection("Page setup", h("div", { class: "opt-row" }, sizeSeg.el, orientSeg.el, marginSeg.el)));

    function addImgs(recs) {
      for (const rec of recs) imgs.push({ rec, url: URL.createObjectURL(new Blob([rec.buf])) });
      render();
    }
    function render() {
      list.innerHTML = "";
      imgs.forEach((im, i) => {
        list.append(h("div", { class: "fchip" },
          h("span", { class: "updown" },
            h("button", { title: "Move up", onclick: () => { if (i > 0) { imgs.splice(i - 1, 0, imgs.splice(i, 1)[0]); render(); } } }, "▲"),
            h("button", { title: "Move down", onclick: () => { if (i < imgs.length - 1) { imgs.splice(i + 1, 0, imgs.splice(i, 1)[0]); render(); } } }, "▼")),
          h("img", { src: im.url, style: "width:34px;height:34px;object-fit:cover;border-radius:6px;border:1px solid var(--line)" }),
          h("span", { class: "fname" }, im.rec.name),
          h("span", { class: "fmeta" }, PDCore.fmtBytes(im.rec.size)),
          h("button", { class: "iconbtn x", title: "Remove", onclick: () => { imgs.splice(i, 1); render(); } }, icon("close"))));
      });
      drop.classList.toggle("hidden", imgs.length > 0);
      dropMore.classList.toggle("hidden", imgs.length === 0);
      bar.setSummary(imgs.length ? imgs.length + " image" + (imgs.length === 1 ? "" : "s") + " → " + imgs.length + " pages" : "");
      bar.enable(imgs.length > 0);
    }

    async function toEmbeddable(rec) {
      const head = new Uint8Array(rec.buf.slice(0, 4));
      const isJpg = head[0] === 0xff && head[1] === 0xd8;
      const isPng = head[0] === 0x89 && head[1] === 0x50;
      if (isJpg || isPng) return { bytes: new Uint8Array(rec.buf.slice(0)), isPng };
      // decode via browser, re-encode as PNG
      const img = new Image();
      const url = URL.createObjectURL(new Blob([rec.buf]));
      try {
        await new Promise((res, rej) => { img.onload = res; img.onerror = () => rej(new Error(rec.name + ": this image format can't be decoded here")); img.src = url; });
        const c = document.createElement("canvas");
        c.width = img.naturalWidth; c.height = img.naturalHeight;
        c.getContext("2d").drawImage(img, 0, 0);
        const blob = await new Promise(r => c.toBlob(r, "image/png"));
        return { bytes: new Uint8Array(await blob.arrayBuffer()), isPng: true };
      } finally { URL.revokeObjectURL(url); }
    }

    function run() {
      const snapshot = imgs.slice();
      runJob(ctx, "Building PDF", async prog => {
        const prepared = [];
        for (let i = 0; i < snapshot.length; i++) {
          prog.set(i / (snapshot.length + 1), "Preparing " + snapshot[i].rec.name, (i + 1) + " / " + snapshot.length);
          prepared.push(await toEmbeddable(snapshot[i].rec));
        }
        prog.set(0.94, "Assembling PDF");
        return await PDCore.imagesToPdf(prepared, { pageSize, orient, marginPct });
      }, bytes => ({
        files: [{ name: (snapshot.length === 1 ? snapshot[0].rec.name.replace(/\.[^.]+$/, "") : "images") + ".pdf", bytes, mime: "application/pdf" }],
        opts: { title: "PDF created" },
      }));
    }
  },
});

/* =============== PDF -> IMAGES =============== */
registerTool({
  id: "pdf2img", name: "PDF to images", icon: "pdf2img",
  desc: "Export pages as PNG or JPG",
  build(ctx) {
    singlePdfTool(ctx, { needProbe: false }, async (rec) => {
      // probe with pdf.js for page count (handles encrypted-with-password too)
      let doc;
      try { doc = await openPdf(rec); } catch (e) { errorBack(ctx.body, new Error("Could not open this PDF."), ctx.restart); return; }
      const pages = doc.numPages;
      closePdf(doc);

      const bar = actionBar(pages + " pages", "Export images", run);
      ctx.setCleanup(() => bar.el.remove());
      document.body.append(bar.el);
      let format = "png", dpi = 150, outMode = "files";
      const qualS = slider(30, 95, 5, 80, v => v + "%", null);
      const qualRow = h("div", { class: "opt-row hidden" }, h("span", { class: "muted", style: "font-size:13px" }, "JPG quality"), qualS.el);
      const fmtSeg = segmented([{ v: "png", label: "PNG" }, { v: "jpeg", label: "JPG" }], format, v => { format = v; qualRow.classList.toggle("hidden", v !== "jpeg"); });
      const outSeg = segmented([{ v: "files", label: "One file per page" }, { v: "long", label: "Single long image" }], outMode, v => { outMode = v; });
      const dpiSeg = segmented([{ v: 72, label: "72 DPI · screen" }, { v: 150, label: "150 DPI · sharp" }, { v: 300, label: "300 DPI · print" }], dpi, v => { dpi = v; });
      const rangeInput = h("input", { class: "range", placeholder: "all pages · e.g. 1-3", style: "width:170px" });
      rangeInput.addEventListener("input", debounce(update, 250));

      ctx.body.append(
        filePill(rec, pages + " pages", ctx.restart),
        optSection("Format", h("div", { class: "opt-row" }, fmtSeg.el), h("div", { class: "opt-row", style: "margin-top:8px" }, outSeg.el), qualRow),
        optSection("Resolution", h("div", { class: "opt-row" }, dpiSeg.el)),
        optSection("Pages", h("div", { class: "opt-row" }, rangeInput)));
      update();

      function indices() {
        if (!rangeInput.value.trim()) return Array.from({ length: pages }, (_, i) => i);
        return PDCore.parsePageSet(rangeInput.value, pages);
      }
      function update() {
        try {
          const k = indices().length;
          rangeInput.classList.remove("bad");
          bar.setSummary(k + " page" + (k === 1 ? "" : "s") + " → " + k + " image" + (k === 1 ? "" : "s"));
          bar.enable(k > 0);
        } catch (e) {
          rangeInput.classList.add("bad");
          bar.setSummary(e.message);
          bar.enable(false);
        }
      }

      function run() {
        let idx;
        try { idx = indices(); } catch (e) { toast(e.message, "err"); return; }
        const base = PDCore.baseName(rec.name);
        const ext = format === "png" ? "png" : "jpg";
        runJob(ctx, "Exporting", async prog => {
          const d = await openPdf(rec);
          try {
            if (outMode === "long") {
              const canvases = [];
              let maxW = 0, totalH = 0;
              for (let k = 0; k < idx.length; k++) {
                prog.set(k / (idx.length + 1), "Rendering page " + (idx[k] + 1), (k + 1) + " / " + idx.length);
                const r = await renderPageToCanvas(d, idx[k] + 1, 0, { dpi });
                canvases.push(r.canvas);
                maxW = Math.max(maxW, r.canvas.width);
                totalH += r.canvas.height;
              }
              let scale = 1;
              if (totalH > 32000) scale = 32000 / totalH;
              const big = document.createElement("canvas");
              big.width = Math.round(maxW * scale);
              big.height = Math.round(totalH * scale);
              const bc = big.getContext("2d", { alpha: false });
              bc.fillStyle = "#fff"; bc.fillRect(0, 0, big.width, big.height);
              let yy = 0;
              for (const c of canvases) {
                bc.drawImage(c, Math.round((maxW - c.width) / 2 * scale), Math.round(yy), Math.round(c.width * scale), Math.round(c.height * scale));
                yy += c.height * scale;
                c.width = 1; c.height = 1;
              }
              prog.set(0.96, "Encoding image");
              const blob = await new Promise(res => big.toBlob(res, "image/" + format, format === "jpeg" ? qualS.get() / 100 : undefined));
              return { outs: [{ name: base + "-long." + ext, bytes: new Uint8Array(await blob.arrayBuffer()), mime: "image/" + format }], capped: scale < 1 };
            }
            const outs = [];
            let capped = false;
            for (let k = 0; k < idx.length; k++) {
              const pno = idx[k] + 1;
              prog.set(k / idx.length, "Rendering page " + pno, (k + 1) + " / " + idx.length);
              const r = await renderPageToCanvas(d, pno, 0, { dpi });
              capped = capped || r.capped;
              const blob = await new Promise(res => r.canvas.toBlob(res, "image/" + format, format === "jpeg" ? qualS.get() / 100 : undefined));
              outs.push({ name: base + "-p" + pno + "." + ext, bytes: new Uint8Array(await blob.arrayBuffer()), mime: "image/" + format });
              r.canvas.width = 1; r.canvas.height = 1;
            }
            return { outs, capped };
          } finally { closePdf(d); }
        }, res => ({
          files: res.outs,
          opts: {
            title: res.outs.length + " image" + (res.outs.length === 1 ? "" : "s") + " exported",
            zipName: base + "-images.zip",
            meta: res.capped ? "Some very large pages were capped at 8000px on the long side." : null,
          },
        }));
      }
    });
  },
});

/* =============== VIEWER (v3.5: one persistent pane per document tab) ===============
   Reader-grade viewing (search, text selection, print, read aloud) plus a right-hand
   page-thumbnail panel. Pages can be rotated or cropped from the thumbnails, from the
   reading pages (hover buttons / right-click) or from the toolbar; changes are kept in
   the tab's document (undo, Save) and every sidebar tool sees the edited file. */
Object.assign(ICONS, {
  rotr: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M19.5 12a7.5 7.5 0 1 1-2.2-5.3"/><path d="M19.8 3.8v4.5h-4.5"/></svg>',
  rotl: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4.5 12a7.5 7.5 0 1 0 2.2-5.3"/><path d="M4.2 3.8v4.5h4.5"/></svg>',
  rot180: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M5 9a7.5 7.5 0 0 1 14 0"/><path d="M19.5 4.5V9H15"/><path d="M19 15a7.5 7.5 0 0 1-14 0"/><path d="M4.5 19.5V15H9"/></svg>',
  sidebar: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3.5" y="4.5" width="17" height="15" rx="2"/><path d="M15 4.5v15"/><path d="M17.3 8h1M17.3 11h1M17.3 14h1"/></svg>',
  undo: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M9 7 4.5 11.5 9 16"/><path d="M5 11.5h9.5a5 5 0 0 1 0 10H12"/></svg>',
  redo: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M15 7l4.5 4.5L15 16"/><path d="M19 11.5H9.5a5 5 0 0 0 0 10H12"/></svg>',
  copy: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="8.5" y="8.5" width="11" height="11" rx="2"/><path d="M15.5 8.5V6a1.5 1.5 0 0 0-1.5-1.5H6A1.5 1.5 0 0 0 4.5 6v8A1.5 1.5 0 0 0 6 15.5h2.5"/></svg>',
  printer: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M7 9V4h10v5"/><rect x="3.5" y="9" width="17" height="8" rx="2"/><path d="M7 14h10v6H7z"/></svg>',
  selall: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="4" width="16" height="16" rx="2" stroke-dasharray="3 2.5"/><path d="m8.5 12 2.5 2.5 4.5-5"/></svg>',
});

const THUMB_W = 124;
const THUMBS_PREF = "atob.viewer.thumbs";
/* v3.6 side panel: which one is open ("" = closed) and its width, per viewer on this device */
const PANEL_PREF = "atob.viewer.panel", PANEL_W_PREF = "atob.viewer.panelw";
function panelPref() {
  if (isMobile()) return "";
  try {
    const v = localStorage.getItem(PANEL_PREF);
    if (v != null) return v;
    return localStorage.getItem(THUMBS_PREF) === "0" ? "" : "tools";     // v3.5 setting; v3.8 opens on Tools
  } catch (e) { return "tools"; }
}
function savePanelPref(p) { if (isMobile()) return; try { localStorage.setItem(PANEL_PREF, p || ""); } catch (e) {} }
function panelWidthPref() { try { const w = +localStorage.getItem(PANEL_W_PREF); return w >= 160 && w <= 480 ? w : 200; } catch (e) { return 200; } }
const VIEWER_PANELS = [
  { id: "tools", icon: "toolbox", label: "Tools" },
  { id: "pages", icon: "pages", label: "Pages" },
  { id: "history", icon: "history", label: "Edit history" },
  { id: "outline", icon: "bookmark", label: "Bookmarks" },
  { id: "attach", icon: "paperclip", label: "Attachments" },
  { id: "fields", icon: "forms", label: "Form fields" },
  { id: "comments", icon: "comment", label: "Comments" },
];
Object.assign(ICONS, {
  toolbox: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M14.7 6.3a4 4 0 0 0-5.2 5.2L4 17v3h3l5.5-5.5a4 4 0 0 0 5.2-5.2l-2.4 2.4-2.6-.6-.6-2.6z"/></svg>',
  history: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 12a8 8 0 1 0 2.4-5.7"/><path d="M4 4.5V9h4.5"/><path d="M12 8v4.5l3 2"/></svg>',
  compare: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3.5" y="4.5" width="7" height="15" rx="1.5"/><rect x="13.5" y="4.5" width="7" height="15" rx="1.5"/><path d="M12 2.5v19" stroke-dasharray="2 2"/></svg>',
  comment: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4.5 5.5h15v10h-8l-4.5 3.5v-3.5h-2.5z"/></svg>',
  a_highlight: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="m9 15 7.5-7.5 3 3L12 18H9z"/><path d="M4 21h8"/><path d="M14 10l3 3"/></svg>',
  a_underline: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M7 4v6a5 5 0 0 0 10 0V4"/><path d="M5 20h14"/></svg>',
  a_strike: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M16.5 7.5C16 5.5 14.3 4.5 12 4.5c-2.6 0-4.5 1.3-4.5 3.4 0 4.6 9 2.6 9 7.6 0 2.2-2 3.9-4.7 3.9-2.4 0-4.2-1.1-4.8-3.1"/><path d="M4 12h16"/></svg>',
  a_note: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M5 4h14v11l-5 5H5z"/><path d="M14 20v-5h5"/><path d="M8.5 9h7M8.5 12.5h4"/></svg>',
  a_box: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="4.5" y="6" width="15" height="12" rx="1"/></svg>',
  a_oval: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><ellipse cx="12" cy="12" rx="8" ry="6"/></svg>',
  a_line: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M5 19 19 5"/><path d="M12 5h7v7"/></svg>',
  a_ink: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M3.5 17c2.5-4 4-6 5.5-6s1 5 3 5 2.5-6 4.5-6 2 3 4 3"/></svg>',
  a_stamp: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M9.5 4h5l-1 7h-3z"/><path d="M5 14.5a3.5 3.5 0 0 1 3.5-3.5h7a3.5 3.5 0 0 1 3.5 3.5V16H5z"/><path d="M5 20h14"/></svg>',
  a_select: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M9 4h6M12 4v16M9 20h6"/></svg>',
  paperclip: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="m20 11.5-8.2 8.2a5 5 0 0 1-7.1-7.1l8.6-8.6a3.4 3.4 0 0 1 4.8 4.8l-8.6 8.6a1.7 1.7 0 0 1-2.4-2.4l7.9-7.9"/></svg>',
  info: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="8.5"/><path d="M12 11v5.5M12 7.6v.2"/></svg>',
  twisty: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m9 6 6 6-6 6"/></svg>',
});
const MOD_KEY = /Mac|iPhone|iPad/.test(navigator.platform || "") ? "⌘" : "Ctrl+";
const REDO_KEY = MOD_KEY === "⌘" ? "⇧⌘Z" : "Ctrl+Y";
const SAVEAS_KEY = MOD_KEY === "⌘" ? "⇧⌘S" : "Ctrl+Shift+S";
const lcFirst = s => s ? s.charAt(0).toLowerCase() + s.slice(1) : s;

registerTool({
  id: "view", name: "View a PDF", icon: "view",
  desc: "Read, search, select, print",
  build(ctx) {
    // an open document always shows in its own tab (see showView); this is the no-file entry
    singlePdfTool(ctx, { needProbe: false, big: "Drop a PDF to read" }, async rec => { openDocTab(rec); });
  },
});

async function buildViewer(ctx, rec) {
  const pane = ctx.body;
  const tab = ctx.tab;
  const isActive = () => ctx.isActive();
  pane.append(h("div", { class: "vloading" }, h("span", { class: "spin" }), "Opening " + rec.name + "…"));
  let doc;
  try { doc = await openPdf(rec); }
  catch (e) {
    if (tab.pane !== pane) return;
    pane.innerHTML = "";
    errorBack(pane, new Error("Could not open this PDF."), ctx.restart);
    return;
  }
  if (tab.pane !== pane) { closePdf(doc); return; }   // tab was closed while loading
  pane.innerHTML = "";
  const n = doc.numPages;
  let zoom = 0, fitWidth = true;
  const holders = [];
  let io = null, dead = false;
  const textCache = new Map();       // pageIdx -> textContent
  let matches = [], curMatch = -1, query = "";
  const meta = [];                    // pageIdx -> {w, h} display size at scale 1
  const pageVer = new Array(n).fill(0);   // bumped when a page's content changes (rotate/crop/undo)
  let curPage = 0;
  const first = await doc.getPage(1);
  const fv = first.getViewport({ scale: 1 });
  meta[0] = { w: fv.width, h: fv.height };

  const pageNum = h("input", { type: "number", min: 1, max: n, value: 1, "aria-label": "Page number" });
  const zoomLabel = h("span", { class: "zoomval" }, "fit");
  const pagesEl = h("div", { class: "viewer-pages" });
  const scroller = h("div", { class: "vscroll" }, pagesEl);

  /* search UI */
  const searchInput = h("input", { class: "pdfind", type: "text", placeholder: isMobile() ? "Find in document" : "Find  (" + MOD_KEY + "F)", "aria-label": "Find in document" });
  const matchInfo = h("span", { class: "pdfindinfo muted" }, "");
  const prevBtn = h("button", { class: "iconbtn", title: "Previous match (Shift+Enter)", onclick: () => matches.length && gotoMatch(curMatch - 1) }, icon("up"));
  const nextBtn = h("button", { class: "iconbtn", title: "Next match (Enter)", onclick: () => matches.length && gotoMatch(curMatch + 1) }, icon("down"));
  const printBtn = h("button", { class: "iconbtn vprint", title: "Print (" + MOD_KEY + "P)", "aria-label": "Print", onclick: doPrint }, icon("printer"));
  const listenBtn = h("button", { class: "iconbtn vlisten", title: "Read aloud", "aria-label": "Read aloud", onclick: () => toggleAudio() }, icon("headphones"));
  const readerBtn = h("button", { class: "iconbtn vreader", title: "Open in the reader (reflow, themes, bookmarks)", "aria-label": "Open in the reader", onclick: () => showView("read") }, icon("book"));
  const undoBtn = h("button", { class: "iconbtn vundo", title: "Undo (" + MOD_KEY + "Z)", "aria-label": "Undo", onclick: () => undo() }, icon("undo"));
  const redoBtn = h("button", { class: "iconbtn vredo", title: "Redo (" + REDO_KEY + ")", "aria-label": "Redo", onclick: () => redo() }, icon("redo"));
  const saveBtn = h("button", { class: "btn primary vsave", title: "Save (" + MOD_KEY + "S)", onclick: () => saveDocTab(tab) }, icon("download"), "Save");
  const commentBtn = h("button", { class: "iconbtn vcomment-btn", title: "Comment: highlight, notes, shapes, drawing, stamps", "aria-label": "Comment", onclick: () => toggleAnnotBar() }, icon("comment"));
  const thumbsBtn = h("button", { class: "iconbtn vthumbs-btn", title: "Side panel", "aria-label": "Show or hide the side panel", onclick: () => setPanel(panel ? "" : (lastPanel || "pages")) }, icon("sidebar"));
  const rotLBtn = h("button", { class: "iconbtn", title: "Rotate counter-clockwise", "aria-label": "Rotate counter-clockwise", onclick: () => rotatePages(targets(), -90) }, icon("rotl"));
  const rotRBtn = h("button", { class: "iconbtn", title: "Rotate clockwise", "aria-label": "Rotate clockwise", onclick: () => rotatePages(targets(), 90) }, icon("rotr"));
  const cropBtn = h("button", { class: "iconbtn", title: "Crop…", "aria-label": "Crop", onclick: () => { const t = targets(); cropDialog(t.includes(curPage) ? curPage : t[0], t); } }, icon("crop"));
  const sep = () => h("span", { class: "sep" });

  const barEl = h("div", { class: "viewer-bar" },
    h("span", { class: "pageinfo" }, "Page", pageNum, "of " + n),
    sep(),
    searchInput, prevBtn, nextBtn, matchInfo,
    h("span", { class: "vb-grow" }),
    h("span", { class: "vb-group vb-pageops" }, rotLBtn, rotRBtn, cropBtn),
    sep(),
    h("button", { class: "iconbtn vzoom", title: "Zoom out", onclick: () => setZoom((zoom || currentFit()) / 1.2, false) }, icon("minus")),
    zoomLabel,
    h("button", { class: "iconbtn vzoom", title: "Zoom in", onclick: () => setZoom((zoom || currentFit()) * 1.2, false) }, icon("plus")),
    h("button", { class: "btn secondary vfit", onclick: () => setZoom(0, true) }, "Fit"),
    sep(),
    listenBtn, readerBtn, printBtn, commentBtn, undoBtn, redoBtn, saveBtn, thumbsBtn);

  /* phone: header with back + file name, floating pill with a page scrubber and Edit */
  const paneHead = h("div", { class: "pane-head" },
    h("button", { class: "iconbtn back", title: "Back", "aria-label": "Back", onclick: () => showView("home") }, icon("back")),
    h("div", { class: "ph-text" }, h("div", { class: "ph-name" }, rec.name), h("div", { class: "ph-meta" }, n + " pages")),
    h("button", { class: "iconbtn ph-comment", title: "Comment", "aria-label": "Comment", onclick: () => toggleAnnotBar() }, icon("comment")),
    h("button", { class: "iconbtn ph-panels", title: "Pages and panels", "aria-label": "Show pages and panels", onclick: () => setPanel(panel ? "" : (lastPanel || "pages")) }, icon("pages")));
  const phName = paneHead.querySelector(".ph-name");
  const scrub = h("input", { type: "range", min: 1, max: n, step: 1, value: 1, "aria-label": "Page" });
  const scrubLbl = h("span", null, "Page 1");
  scrub.addEventListener("input", () => { scrubLbl.textContent = "Page " + scrub.value; });
  scrub.addEventListener("change", () => gotoPage(+scrub.value - 1));
  const pill = h("div", { class: "vpill" },
    h("button", { class: "iconbtn", title: "Reader", "aria-label": "Open in the reader", onclick: () => showView("read") }, icon("book")),
    h("button", { class: "iconbtn", title: "Read aloud", "aria-label": "Read aloud", onclick: () => toggleAudio() }, icon("headphones")),
    h("div", { class: "scrub" }, h("div", { class: "lbl" }, scrubLbl, h("span", null, String(n))), scrub),
    h("button", { class: "btn primary sm", onclick: () => showView("edit") }, icon("pen"), "Edit"));

  /* ---- thumbnails panel ---- */
  const sel = new Set();
  let anchor = 0;
  const selInfo = h("span", { class: "vt-count" }, n + (n === 1 ? " page" : " pages"));
  const thumbsList = h("div", { class: "vt-list", tabindex: "0", role: "listbox", "aria-multiselectable": "true", "aria-label": "Pages" });
  const thumbsEl = h("aside", { class: "vthumbs vpanel", "data-panel": "pages", "aria-label": "Page thumbnails" },
    h("div", { class: "vt-head" }, selInfo,
      h("span", { class: "vb-grow" }),
      h("button", { class: "iconbtn", title: "Rotate counter-clockwise", "aria-label": "Rotate selected pages counter-clockwise", onclick: () => rotatePages(targets(), -90) }, icon("rotl")),
      h("button", { class: "iconbtn", title: "Rotate clockwise", "aria-label": "Rotate selected pages clockwise", onclick: () => rotatePages(targets(), 90) }, icon("rotr")),
      h("button", { class: "iconbtn", title: "Crop…", "aria-label": "Crop selected pages", onclick: () => { const t = targets(); cropDialog(t[0], t); } }, icon("crop")),
      h("button", { class: "iconbtn vt-close", title: "Hide panel", "aria-label": "Hide panel", onclick: () => setPanel("") }, icon("close"))),
    thumbsList,
    h("div", { class: "vt-hint" }, isMobile() ? "Tap to go · long-press for rotate & crop" : "Click to go · " + MOD_KEY + "/Shift-click to select · right-click for rotate & crop"));
  const thumbItems = [];
  for (let i = 0; i < n; i++) {
    const it = h("div", { class: "vt-item", role: "option", "aria-selected": "false", "data-i": String(i), title: "Page " + (i + 1) },
      h("div", { class: "vt-img" }), h("div", { class: "vt-num" }, String(i + 1)));
    thumbItems.push(it);
    thumbsList.append(it);
  }
  /* ---- v3.6 side panels behind an icon rail: Pages, Bookmarks, Attachments, Form fields ---- */
  let panel = panelPref(), lastPanel = panel || "pages";
  const panelEls = { pages: thumbsEl }, panelBodies = {}, panelBuilt = {}, counts = {};
  const railBtns = {}, tabBtns = {};
  for (const P of VIEWER_PANELS) {
    railBtns[P.id] = h("button", { class: "iconbtn vrail-btn", "data-panel": P.id, title: P.label, "aria-label": P.label, onclick: () => setPanel(panel === P.id ? "" : P.id) },
      icon(P.icon), h("span", { class: "vbadge", "aria-hidden": "true" }));
    tabBtns[P.id] = h("button", { class: "vs-tab", "data-panel": P.id, title: P.label, "aria-label": P.label, onclick: () => setPanel(P.id) },
      icon(P.icon), h("span", { class: "vbadge", "aria-hidden": "true" }));
    if (P.id === "pages") continue;
    panelBodies[P.id] = h("div", { class: "vp-body" });
    panelEls[P.id] = h("aside", { class: "vpanel", "data-panel": P.id, "aria-label": P.label },
      h("div", { class: "vt-head vp-head" }, h("span", { class: "vp-title" }, P.label), h("span", { class: "vb-grow" }),
        P.id === "fields" ? h("button", { class: "btn secondary sm vp-fill", onclick: () => showView("forms") }, "Fill form") : null,
        h("button", { class: "iconbtn vt-close", title: "Hide panel", "aria-label": "Hide panel", onclick: () => setPanel("") }, icon("close"))),
      panelBodies[P.id]);
  }
  const resizer = h("div", { class: "vs-resize", title: "Drag to resize", "aria-hidden": "true" });
  const vside = h("div", { class: "vside", style: "width:" + panelWidthPref() + "px" }, resizer,
    h("div", { class: "vs-tabs" }, VIEWER_PANELS.map(P => tabBtns[P.id])),
    VIEWER_PANELS.map(P => panelEls[P.id]));
  const rail = h("nav", { class: "vrail", "aria-label": "Panels" }, VIEWER_PANELS.map(P => railBtns[P.id]));
  const vwrap = h("div", { class: "vwrap" + (panel ? " thumbs-open" : ""), "data-panel": panel }, scroller, vside, rail,
    h("div", { class: "vt-scrim", onclick: () => setPanel("") }));
  resizer.addEventListener("pointerdown", e => {
    if (isMobile()) return;
    e.preventDefault();
    const x0 = e.clientX, w0 = vside.getBoundingClientRect().width;
    resizer.setPointerCapture && resizer.setPointerCapture(e.pointerId);
    const mv = ev => { vside.style.width = Math.max(160, Math.min(480, w0 + (x0 - ev.clientX))) + "px"; };
    const up = () => {
      resizer.removeEventListener("pointermove", mv); resizer.removeEventListener("pointerup", up); resizer.removeEventListener("pointercancel", up);
      try { localStorage.setItem(PANEL_W_PREF, String(Math.round(vside.getBoundingClientRect().width))); } catch (err) {}
    };
    resizer.addEventListener("pointermove", mv); resizer.addEventListener("pointerup", up); resizer.addEventListener("pointercancel", up);
  });
  /* ---- v3.6 notices on open: one at a time, most important first ---- */
  const msgBar = h("div", { class: "vmsg hidden", role: "status" });
  const notices = [];
  function showNotice() {
    msgBar.innerHTML = "";
    const nt = notices[0];
    msgBar.classList.toggle("hidden", !nt);
    if (!nt) return;
    msgBar.dataset.notice = nt.id;
    msgBar.append(h("span", { class: "vmsg-ico" }, icon(nt.icon)), h("span", { class: "vmsg-text" }, nt.text),
      h("button", { class: "btn secondary sm vmsg-act", onclick: () => { nt.run(); } }, nt.action),
      h("button", { class: "iconbtn vmsg-x", title: "Dismiss", "aria-label": "Dismiss", onclick: () => { notices.shift(); showNotice(); } }, icon("close")));
  }
  pane.append(paneHead, barEl, msgBar, vwrap, pill);

  for (let i = 0; i < n; i++) {
    const holder = h("div", { class: "vpage", "data-i": String(i) });
    holders.push(holder);
    pagesEl.append(holder);
  }
  const pageTools = [];
  function pageChrome(i) {
    if (!pageTools[i]) {
      const b = (ic, title, fn) => h("button", { class: "iconbtn", title, "aria-label": title, onclick: e => { e.stopPropagation(); fn(); } }, icon(ic));
      pageTools[i] = h("div", { class: "vpage-tools" },
        b("rotl", "Rotate page " + (i + 1) + " counter-clockwise", () => rotatePages([i], -90)),
        b("rotr", "Rotate page " + (i + 1) + " clockwise", () => rotatePages([i], 90)),
        b("crop", "Crop page " + (i + 1) + "…", () => cropDialog(i, targetsFor(i))));
    }
    return pageTools[i];
  }

  function base() { return meta[0] || { w: fv.width, h: fv.height }; }
  function currentFit() {
    const w = scroller.clientWidth - 2 * parseFloat(getComputedStyle(pagesEl).paddingLeft || "24");
    return Math.max(0.2, Math.min(4, w / base().w));
  }
  function effZoom() { return fitWidth || !zoom ? currentFit() : zoom; }
  function sizeOf(i) { return meta[i] || base(); }
  /* per-page zoom: in "fit width" a page wider than page 1 (landscape, rotated) is fitted too */
  function zOf(i) {
    const z = effZoom();
    if (!fitWidth) return z;
    const m = sizeOf(i), b = base();
    return m.w > b.w + 0.5 ? z * b.w / m.w : z;
  }
  function sizeHolder(i) {
    const m = sizeOf(i), z = zOf(i);
    holders[i].style.width = m.w * z + "px";
    holders[i].style.height = m.h * z + "px";
  }
  function sizeThumb(i) {
    const m = sizeOf(i);
    const box = thumbItems[i].firstChild;
    box.style.width = THUMB_W + "px";
    box.style.height = Math.round(THUMB_W * m.h / m.w) + "px";
  }
  for (let i = 0; i < n; i++) sizeThumb(i);

  async function pageText(i) {
    if (!textCache.has(i)) {
      const p = await doc.getPage(i + 1);
      textCache.set(i, await p.getTextContent());
    }
    return textCache.get(i);
  }

  let laidW = 0;
  function layout() {
    if (!scroller.clientWidth) return;      // pane hidden; redo when shown
    laidW = scroller.clientWidth;
    zoomLabel.textContent = fitWidth ? "fit" : Math.round(effZoom() * 100) + "%";
    for (let i = 0; i < n; i++) {
      const holder = holders[i];
      holder.dataset.rendered = "";
      holder.innerHTML = "";
      holder.append(pageChrome(i));
      sizeHolder(i);
    }
    observe();
  }
  function observe() {
    if (io) io.disconnect();
    io = new IntersectionObserver(entries => {
      for (const en of entries) if (en.isIntersecting) renderHolder(+en.target.dataset.i);
    }, { root: scroller, rootMargin: "700px 0px" });
    holders.forEach(hd => io.observe(hd));
  }
  const rendering = new Set();
  async function renderHolder(i) {
    if (i < 0 || dead) return;
    const holder = holders[i];
    const ver = pageVer[i];
    let z = zOf(i);
    const key = ver + ":" + z.toFixed(3);
    if (holder.dataset.rendered === key || rendering.has(i)) return;
    rendering.add(i);
    const d = doc;
    let stale = false;
    try {
      const page = await d.getPage(i + 1);
      const bvp = page.getViewport({ scale: 1 });
      meta[i] = { w: bvp.width, h: bvp.height };
      z = zOf(i);
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const vp = page.getViewport({ scale: z * dpr });
      const cssVp = page.getViewport({ scale: z });
      const canvas = document.createElement("canvas");
      canvas.width = Math.round(vp.width); canvas.height = Math.round(vp.height);
      const cctx = canvas.getContext("2d", { alpha: false });
      cctx.fillStyle = "#fff"; cctx.fillRect(0, 0, canvas.width, canvas.height);
      await page.render({ canvasContext: cctx, viewport: vp }).promise;
      if (dead) { rendering.delete(i); return; }
      if (pageVer[i] !== ver) { stale = true; throw new Error("stale"); }
      holder.style.width = bvp.width * z + "px";
      holder.style.height = bvp.height * z + "px";
      holder.innerHTML = "";
      holder.append(canvas);
      holder._vp = cssVp;
      const hlL = h("div", { class: "hl-layer" });
      const ttsL = h("div", { class: "tts-layer" });
      const tl = h("div", { class: "textLayer" });
      tl.style.setProperty("--scale-factor", String(cssVp.scale));   // pdf.js sizes text spans from this
      holder.append(hlL, ttsL, tl, pageChrome(i));
      try {
        const tc = await pageText(i);
        const task = pdfjsLib.renderTextLayer({ textContent: tc, textContentSource: tc, container: tl, viewport: cssVp, textDivs: [] });
        if (task && task.promise) await task.promise;
      } catch (e) { /* text layer is best-effort */ }
      holder.dataset.rendered = ver + ":" + z.toFixed(3);
      drawHighlights(i);
      if (tts.state && tts.state.i === i) drawTts();
    } catch (e) { if (d !== doc) stale = true; /* else: page render failed */ }
    rendering.delete(i);
    if (dead || !holder.isConnected) return;
    // the page changed or zoom/resize happened while rendering: redo it now
    if (stale || Math.abs(z - zOf(i)) > 1e-6) renderHolder(i);
  }
  function setZoom(v, fit) {
    fitWidth = fit;
    zoom = fit ? 0 : Math.max(0.2, Math.min(4, v));
    const keep = curPage;
    layout();
    holders[keep].scrollIntoView({ block: "start" });
  }

  /* ---- thumbnails: lazy, sequential rendering ---- */
  const thumbVer = new Array(n).fill(-1);
  const tq = [];
  let tBusy = false;
  const tio = new IntersectionObserver(entries => {
    for (const en of entries) if (en.isIntersecting) queueThumb(+en.target.dataset.i);
  }, { root: thumbsList, rootMargin: "300px 0px" });
  thumbItems.forEach(t => tio.observe(t));
  function queueThumb(i) {
    if (thumbVer[i] === pageVer[i] || tq.includes(i)) return;
    tq.push(i);
    pumpThumbs();
  }
  async function pumpThumbs() {
    if (tBusy || dead) return;
    const i = tq.shift();
    if (i == null) return;
    tBusy = true;
    const ver = pageVer[i], d = doc;
    let retry = false;
    try {
      if (thumbVer[i] !== ver) {
        const page = await d.getPage(i + 1);
        const v1 = page.getViewport({ scale: 1 });
        meta[i] = { w: v1.width, h: v1.height };
        const dpr = Math.min(window.devicePixelRatio || 1, 2);
        const vp = page.getViewport({ scale: THUMB_W * dpr / v1.width });
        const c = document.createElement("canvas");
        c.width = Math.max(1, Math.round(vp.width)); c.height = Math.max(1, Math.round(vp.height));
        const cx = c.getContext("2d", { alpha: false });
        cx.fillStyle = "#fff"; cx.fillRect(0, 0, c.width, c.height);
        await page.render({ canvasContext: cx, viewport: vp }).promise;
        if (pageVer[i] !== ver) retry = true;
        else if (!dead) {
          const box = thumbItems[i].firstChild;
          sizeThumb(i);
          box.innerHTML = "";
          box.append(c);
          thumbVer[i] = ver;
        }
      }
    } catch (e) { if (d !== doc) retry = true; }
    tBusy = false;
    if (retry && !dead) { tio.unobserve(thumbItems[i]); tio.observe(thumbItems[i]); }
    if (!dead) pumpThumbs();
  }
  function thumbsOpen() { return panel === "pages"; }
  function setThumbs(on) { setPanel(on ? "pages" : ""); }
  function setPanel(name) {
    name = name || "";
    panel = name;
    if (name) lastPanel = name;
    vwrap.dataset.panel = name;
    vwrap.classList.toggle("thumbs-open", !!name);
    thumbsBtn.classList.toggle("on", !!name);
    thumbsBtn.setAttribute("aria-pressed", name ? "true" : "false");
    for (const id in railBtns) { railBtns[id].classList.toggle("on", id === name); railBtns[id].setAttribute("aria-pressed", id === name ? "true" : "false"); tabBtns[id].classList.toggle("on", id === name); }
    savePanelPref(name);
    if (name === "pages") requestAnimationFrame(() => revealThumb(curPage, "center"));
    else if (name) buildPanel(name);
  }
  function paintBadges() {
    for (const id in railBtns) {
      const has = id !== "pages" && counts[id] > 0;
      railBtns[id].classList.toggle("has", has);
      tabBtns[id].classList.toggle("has", has);
      const P = VIEWER_PANELS.find(x => x.id === id);
      railBtns[id].title = P.label + (has ? " (" + counts[id] + ")" : "");
    }
  }
  /* panel contents are built the first time a panel opens (and again after an edit) */
  async function buildPanel(name, force) {
    if (panelBuilt[name] && !force) return;
    panelBuilt[name] = true;
    const body = panelBodies[name];
    if (!body) return;
    body.innerHTML = "";
    body.append(h("div", { class: "vp-empty" }, h("span", { class: "spin" }), "Loading…"));
    try {
      if (name === "outline") await buildOutlinePanel(body);
      else if (name === "attach") await buildAttachPanel(body);
      else if (name === "fields") await buildFieldsPanel(body);
      else if (extraPanels[name]) await extraPanels[name](body);
    } catch (e) {
      body.innerHTML = "";
      body.append(h("div", { class: "vp-empty" }, "Couldn't read this: " + (e && e.message || e)));
      panelBuilt[name] = false;
    }
  }
  const extraPanels = {};
  async function buildOutlinePanel(body) {
    const tree = await pdfOutlineTree(doc);
    body.innerHTML = "";
    if (!tree.length) { body.append(h("div", { class: "vp-empty" }, "This document has no bookmarks.")); return; }
    const q = h("input", { class: "vp-search", type: "search", placeholder: "Filter bookmarks", "aria-label": "Filter bookmarks" });
    const box = h("div", { class: "ol-tree", role: "tree" });
    const open = new Set();
    tree.forEach((it, i) => { if (tree.length <= 12 && it.items.length) open.add(it); });
    const match = (it, needle) => !needle || it.title.toLowerCase().includes(needle) || it.items.some(c => match(c, needle));
    const draw = () => {
      const needle = q.value.trim().toLowerCase();
      box.innerHTML = "";
      const add = (it, depth, parent) => {
        if (!match(it, needle)) return;
        const kids = it.items.length > 0, expanded = kids && (open.has(it) || !!needle);
        const tw = kids ? h("button", { class: "ol-tw" + (expanded ? " open" : ""), "aria-label": expanded ? "Collapse" : "Expand", onclick: e => { e.stopPropagation(); if (open.has(it)) open.delete(it); else open.add(it); draw(); } }, icon("twisty")) : h("span", { class: "ol-tw none" });
        const row = h("div", { class: "ol-row", role: "treeitem", "aria-expanded": kids ? String(expanded) : null, style: "padding-left:" + (6 + depth * 14) + "px", title: it.title,
          onclick: () => { if (it.page != null) { gotoPage(it.page); box.querySelectorAll(".ol-row.on").forEach(r => r.classList.remove("on")); row.classList.add("on"); if (isMobile()) setPanel(""); } else if (kids) { if (open.has(it)) open.delete(it); else open.add(it); draw(); } } },
          tw, h("span", { class: "ol-t" }, it.title), it.page != null ? h("span", { class: "ol-p" }, String(it.page + 1)) : null);
        parent.append(row);
        if (expanded) it.items.forEach(c => add(c, depth + 1, parent));
      };
      tree.forEach(it => add(it, 0, box));
      if (!box.childNodes.length) box.append(h("div", { class: "vp-empty" }, "No bookmark matches “" + q.value.trim() + "”."));
    };
    q.addEventListener("input", draw);
    body.append(q, box);
    draw();
  }
  async function buildAttachPanel(body) {
    const att = await doc.getAttachments();
    body.innerHTML = "";
    const list = att ? Object.values(att) : [];
    if (!list.length) { body.append(h("div", { class: "vp-empty" }, "This document has no attached files.")); return; }
    for (const a of list) {
      const name = a.filename || "attachment", bytes = a.content || new Uint8Array(0);
      const isPdf = /\.pdf$/i.test(name);
      body.append(h("div", { class: "at-row" },
        icon("file", "at-ico"),
        h("div", { class: "at-text" }, h("div", { class: "at-name", title: name }, name), h("div", { class: "at-meta" }, PDCore.fmtBytes(bytes.length) + (a.description ? " · " + a.description : ""))),
        h("button", { class: "btn secondary sm", onclick: () => downloadBytes(name, bytes.slice(), isPdf ? "application/pdf" : "application/octet-stream") }, "Save"),
        isPdf ? h("button", { class: "btn secondary sm", onclick: () => { const c = bytes.slice(); openDocTab({ name, size: c.length, buf: c.buffer }); } }, "Open")
          : h("button", { class: "btn secondary sm", disabled: "", title: "AtoB PDF opens PDFs only. Save it, then open it with its own app." }, "Open")));
    }
  }
  async function buildFieldsPanel(body) {
    const rows = [];
    for (let i = 0; i < n; i++) {
      const pg = await doc.getPage(i + 1);
      const anns = await pg.getAnnotations({ intent: "display" });
      for (const a of anns) if (a.subtype === "Widget" && a.fieldName != null) rows.push({ i, a });
    }
    body.innerHTML = "";
    if (!rows.length) { body.append(h("div", { class: "vp-empty" }, "This document has no form fields.")); return; }
    const TYPE = a => a.fieldType === "Tx" ? "Text" : a.fieldType === "Ch" ? (a.combo ? "Drop-down" : "List") : a.fieldType === "Sig" ? "Signature"
      : a.checkBox ? "Checkbox" : a.radioButton ? "Option" : a.pushButton ? "Button" : "Field";
    let lastPage = -1;
    for (const { i, a } of rows) {
      if (i !== lastPage) { body.append(h("div", { class: "vp-group" }, "Page " + (i + 1))); lastPage = i; }
      let val = a.fieldValue;
      if (Array.isArray(val)) val = val.join(", ");
      if (a.checkBox || a.radioButton) val = val && val !== "Off" ? "✓ " + (a.radioButton ? (a.buttonValue || val) : "checked") : "–";
      body.append(h("button", { class: "fd-row", title: a.fieldName, onclick: () => flashRect(i, a.rect) },
        h("span", { class: "fd-type" }, TYPE(a)),
        h("span", { class: "fd-name" }, a.alternativeText || a.fieldName || "Untitled field"),
        h("span", { class: "fd-val" }, val == null || val === "" ? "empty" : String(val).slice(0, 60))));
    }
  }
  /* scroll to page i and outline a rect (PDF user space) for a moment */
  async function flashRect(i, rect) {
    gotoPage(i);
    try {
      const pg = await doc.getPage(i + 1);
      const vp = pg.getViewport({ scale: zOf(i) });
      const [x1, y1, x2, y2] = vp.convertToViewportRectangle(rect);
      const fl = h("div", { class: "vflash", style: "left:" + Math.min(x1, x2) + "px;top:" + Math.min(y1, y2) + "px;width:" + Math.abs(x2 - x1) + "px;height:" + Math.abs(y2 - y1) + "px" });
      holders[i].append(fl);
      setTimeout(() => fl.remove(), 1800);
      if (isMobile()) setPanel("");
    } catch (e) {}
  }
  setPanel(panel);
  function revealThumb(i, block) {
    if (!thumbsOpen() || !thumbItems[i]) return;
    const it = thumbItems[i], lr = thumbsList.getBoundingClientRect(), r = it.getBoundingClientRect();
    if (r.top < lr.top || r.bottom > lr.bottom) {
      const off = it.offsetTop - thumbsList.offsetTop;
      thumbsList.scrollTop = block === "center" ? off - (thumbsList.clientHeight - it.offsetHeight) / 2
        : (r.top < lr.top ? off - 8 : off - thumbsList.clientHeight + it.offsetHeight + 8);
    }
  }

  /* ---- selection (thumbnails) ---- */
  function paintSel() {
    thumbItems.forEach((it, i) => {
      const on = sel.has(i);
      it.classList.toggle("sel", on);
      it.setAttribute("aria-selected", on ? "true" : "false");
    });
    selInfo.textContent = sel.size > 1 ? sel.size + " selected" : n + (n === 1 ? " page" : " pages");
    selInfo.title = sel.size > 1 ? sel.size + " of " + n + " pages selected" : "";
  }
  function selectOnly(i) { sel.clear(); sel.add(i); anchor = i; paintSel(); }
  function selectAll() { sel.clear(); for (let i = 0; i < n; i++) sel.add(i); paintSel(); }
  /* pages an action applies to: the multi-selection, else the current page */
  function targets() { return sel.size ? Array.from(sel).sort((a, b) => a - b) : [curPage]; }
  function targetsFor(i) { return sel.has(i) && sel.size > 1 ? targets() : [i]; }
  thumbsList.addEventListener("click", e => {
    const it = e.target.closest(".vt-item");
    if (!it) return;
    const i = +it.dataset.i;
    if (e.shiftKey) {
      const [a, b] = anchor < i ? [anchor, i] : [i, anchor];
      if (!(e.ctrlKey || e.metaKey)) sel.clear();
      for (let k = a; k <= b; k++) sel.add(k);
      paintSel();
    } else if (e.ctrlKey || e.metaKey) {
      if (sel.has(i) && sel.size > 1) sel.delete(i); else sel.add(i);
      anchor = i;
      paintSel();
    } else {
      selectOnly(i);
      gotoPage(i);
      if (isMobile()) setPanel("");
    }
  });
  thumbsList.addEventListener("contextmenu", e => {
    const it = e.target.closest(".vt-item");
    if (!it) return;
    e.preventDefault();
    const i = +it.dataset.i;
    if (!sel.has(i)) selectOnly(i);
    pageMenu(e.clientX, e.clientY, i);
  });
  thumbsList.addEventListener("keydown", e => {
    const mod = e.ctrlKey || e.metaKey;
    if (mod && e.key.toLowerCase() === "a") { e.preventDefault(); selectAll(); return; }
    if (e.key === "Escape" && sel.size > 1) { e.preventDefault(); selectOnly(curPage); return; }
    if (e.key === "ArrowDown" || e.key === "ArrowUp" || e.key === "ArrowRight" || e.key === "ArrowLeft") {
      e.preventDefault();
      const d = e.key === "ArrowDown" || e.key === "ArrowRight" ? 1 : -1;
      const j = Math.max(0, Math.min(n - 1, (sel.size ? (e.shiftKey ? anchorEnd : Math.max(...sel)) : curPage) + d));
      if (e.shiftKey) { anchorEnd = j; sel.clear(); const [a, b] = anchor < j ? [anchor, j] : [j, anchor]; for (let k = a; k <= b; k++) sel.add(k); paintSel(); }
      else { selectOnly(j); anchorEnd = j; gotoPage(j); }
      revealThumb(j);
    }
    if (e.key === "ContextMenu" || (e.shiftKey && e.key === "F10")) {
      e.preventDefault();
      const i = targets()[0], r = thumbItems[i].getBoundingClientRect();
      pageMenu(r.left + 20, r.top + 20, i);
    }
  });
  let anchorEnd = 0;

  /* ---- context menu (thumbnails + reading pages) ---- */
  function pageMenu(x, y, i, extra) {
    const idx = targetsFor(i);
    const many = idx.length > 1;
    const dirty = tabDirty(tab);
    showCtxMenu(x, y, [
      ...(extra || []),
      { head: many ? idx.length + " pages selected" : "Page " + (i + 1) + " of " + n },
      { label: "Rotate clockwise", icon: "rotr", onClick: () => rotatePages(idx, 90) },
      { label: "Rotate counter-clockwise", icon: "rotl", onClick: () => rotatePages(idx, -90) },
      { label: "Rotate 180°", icon: "rot180", onClick: () => rotatePages(idx, 180) },
      "-",
      { label: many ? "Crop " + idx.length + " pages…" : "Crop page…", icon: "crop", onClick: () => cropDialog(i, idx) },
      "-",
      { label: "Select all pages", icon: "selall", kbd: MOD_KEY + "A", onClick: () => { selectAll(); if (!thumbsOpen()) setThumbs(true); } },
      { label: tab.hist.canUndo ? "Undo " + lcFirst(tab.hist.undoLabel) : "Undo", icon: "undo", kbd: MOD_KEY + "Z", disabled: !tab.hist.canUndo, onClick: () => undo() },
      { label: tab.hist.canRedo ? "Redo " + lcFirst(tab.hist.redoLabel) : "Redo", icon: "redo", kbd: REDO_KEY, disabled: !tab.hist.canRedo, onClick: () => redo() },
      { label: "Save", icon: "download", kbd: MOD_KEY + "S", disabled: !dirty && !!rec.path, onClick: () => saveDocTab(tab) },
      { label: "Save as…", icon: "download", kbd: SAVEAS_KEY, onClick: () => saveDocTab(tab, true) },
    ]);
  }
  pagesEl.addEventListener("contextmenu", e => {
    const holder = e.target.closest && e.target.closest(".vpage");
    if (!holder) return;
    const text = String(window.getSelection ? window.getSelection() : "").trim();
    if (isMobile() && e.target.closest(".textLayer")) return;   // phones: keep native text selection
    e.preventDefault();
    const i = +holder.dataset.i;
    if (!sel.has(i)) selectOnly(i);
    const extra = text ? [{ label: "Copy", icon: "copy", kbd: MOD_KEY + "C", onClick: () => copyText(text) }, "-"] : null;
    pageMenu(e.clientX, e.clientY, i, extra);
  });
  async function copyText(t) {
    try { await navigator.clipboard.writeText(t); toast("Copied"); }
    catch (e) { try { document.execCommand("copy"); toast("Copied"); } catch (e2) { toast("Couldn't copy", "err"); } }
  }

  /* ---- page edits: rotate / crop, with undo and Save ---- */
  let editBusy = false;
  function refreshEditUi() {
    const dirty = tabDirty(tab), hs = tab.hist;
    saveBtn.classList.toggle("hidden", !dirty);
    undoBtn.classList.toggle("hidden", !hs.canUndo && !hs.canRedo);
    undoBtn.disabled = !hs.canUndo;
    redoBtn.classList.toggle("hidden", !hs.canRedo);
    undoBtn.title = hs.canUndo ? "Undo " + lcFirst(hs.undoLabel) + " (" + MOD_KEY + "Z)" : "Nothing to undo";
    undoBtn.setAttribute("aria-label", hs.canUndo ? "Undo " + lcFirst(hs.undoLabel) : "Undo");
    redoBtn.title = hs.canRedo ? "Redo " + lcFirst(hs.redoLabel) + " (" + REDO_KEY + ")" : "Nothing to redo";
    redoBtn.setAttribute("aria-label", hs.canRedo ? "Redo " + lcFirst(hs.redoLabel) : "Redo");
    saveBtn.title = (rec.path ? "Save to " + rec.path : "Save (downloads a copy)") + " (" + MOD_KEY + "S)";
    pane.classList.toggle("dirty", dirty);
    phName.textContent = rec.name + (dirty ? " •" : "");
  }
  function setBusy(on) {
    editBusy = on;
    pane.classList.toggle("busy", on);
  }
  /* label = the step's name in the imperative ("Rotate page 2 clockwise"): it shows as
     "Undo rotate page 2 clockwise" on the button and "Rotated page 2 clockwise" in the toast */
  async function commit(label, idx, fn) {
    if (editBusy) return;
    setBusy(true);
    try {
      const out = await fn(bytesOf(rec));
      tab.hist.push(label, { buf: rec.buf, size: rec.size }, idx);
      rec.buf = out.buffer.slice(out.byteOffset, out.byteOffset + out.byteLength);
      rec.size = out.length;
      await reload(idx);
      afterEdit();
      toast(PDCore.pastTense(label));
    } catch (e) {
      toast("Couldn't change the pages: " + (e && e.message || e), "err");
    } finally { setBusy(false); }
  }
  async function undo() { return step("undo"); }
  async function redo() { return step("redo"); }
  async function step(dir) {
    if (editBusy || !(dir === "undo" ? tab.hist.canUndo : tab.hist.canRedo)) return;
    setBusy(true);
    try {
      const st = tab.hist[dir]({ buf: rec.buf, size: rec.size });
      rec.buf = st.buf; rec.size = st.size;
      await reload(st.idx);
      afterEdit();
      toast((dir === "undo" ? "Undone: " : "Redone: ") + lcFirst(st.label));
    } catch (e) { toast((dir === "undo" ? "Undo" : "Redo") + " failed: " + (e && e.message || e), "err"); }
    finally { setBusy(false); }
  }
  function afterEdit() {
    refreshEditUi();
    renderTabs();
    renderSideFile();
    commentsDirty();
    historyDirty();
    Recovery.soon();
  }
  function historyDirty() {
    counts.history = tab.hist.depth;
    paintBadges();
    if (panel === "history") buildPanel("history", true);
  }
  /* v3.8 History panel: jump to any step (several undos/redos, one redraw) */
  async function jumpTo(k) {
    if (editBusy) return;
    const hs = tab.hist;
    if (k === hs.depth) return;
    setBusy(true);
    try {
      let idx = [];
      while (hs.depth > k) { const st = hs.undo({ buf: rec.buf, size: rec.size }); rec.buf = st.buf; rec.size = st.size; idx = idx.concat(st.idx || []); }
      while (hs.depth < k && hs.canRedo) { const st = hs.redo({ buf: rec.buf, size: rec.size }); rec.buf = st.buf; rec.size = st.size; idx = idx.concat(st.idx || []); }
      await reload(null);
      afterEdit();
      toast(k === 0 ? "Back to the start" : "Went to step " + k);
    } catch (e) { toast("Couldn't go there: " + (e && e.message || e), "err"); }
    finally { setBusy(false); }
  }
  extraPanels.history = async body => {
    const hs = tab.hist;
    body.innerHTML = "";
    const steps = hs.undoStack.map(e => e.label).concat(hs.redoStack.slice().reverse().map(e => e.label));
    const list = h("ol", { class: "hist-list" });
    const row = (k, label, sub) => h("li", null, h("button", {
      class: "hist-row" + (k === hs.depth ? " cur" : "") + (k > hs.depth ? " future" : ""), "data-k": k,
      onclick: () => jumpTo(k) },
      h("span", { class: "hist-dot" }), h("span", { class: "grow" }, h("span", { class: "hist-lbl" }, label), sub ? h("span", { class: "hist-sub" }, sub) : null)));
    list.append(row(0, hs.undoStack.length + hs.redoStack.length >= hs.max ? "Earliest kept version" : "Opened file", rec.path ? "as on disk" : null));
    steps.forEach((l, i) => list.append(row(i + 1, l, i + 1 > hs.depth ? "undone · click to redo" : null)));
    body.append(
      h("div", { class: "hist-note" }, steps.length ? "Click a step to go back to it. Nothing is lost: steps after it stay available to redo until you make a new change." : "Changes you make here or in any tool (Edit, Sign, Watermark…) appear as steps you can jump between."),
      list,
      h("div", { class: "hist-acts" },
        h("button", { class: "btn secondary sm", disabled: !steps.length && !tab.recovered ? "" : null, onclick: () => openCompare(tab, curPage) }, icon("compare"), "Compare with original"),
        h("button", { class: "btn secondary sm", onclick: () => saveDocTab(tab, true) }, icon("download"), "Save a copy…")));
  };
  /* v3.8 Tools panel: every tool runs on this document, edits included */
  extraPanels.tools = async body => {
    body.innerHTML = "";
    const go = id => () => showView(id);
    const item = (ic, label, sub, onClick, cls) => h("button", { class: "tp-item" + (cls ? " " + cls : ""), onclick: onClick }, h("span", { class: "tp-ico" }, icon(ic)),
      h("span", { class: "grow" }, h("span", { class: "tp-name" }, label), sub ? h("span", { class: "tp-sub" }, sub) : null));
    const tool = (id, sub) => VIEWS[id] ? item(VIEWS[id].icon, VIEWS[id].name, sub || VIEWS[id].desc, go(id), "tp-" + id) : null;
    const sec = (title, ...items) => h("div", { class: "tp-sec" }, h("div", { class: "tp-head" }, title), items);
    body.append(
      h("div", { class: "tp-note" }, "Every tool works on this document with all your changes so far. Nothing touches the file on disk until you Save."),
      sec("Edit & sign", tool("edit", "Text, images, shapes, whiteout, signature"), tool("sign", "Draw, type or reuse a saved signature"),
        item("comment", "Comment", "Notes, highlights, stamps", () => setPanel("comments")), tool("forms")),
      sec("Pages", tool("organize", "Reorder, insert, duplicate"),
        item("rotr", "Rotate", "Selected pages clockwise", () => rotatePages(targets(), 90)),
        item("crop", "Crop", "Trim margins", () => { const t = targets(); cropDialog(t.includes(curPage) ? curPage : t[0], t); }),
        tool("delete"), tool("numbers"), tool("watermark")),
      sec("Improve", tool("ocr", "Make scanned pages searchable"), tool("compress"), tool("flatten"), tool("repair")),
      sec("Export", item("download", "Save", rec.path ? "Write over " + rec.name : "Download the edited PDF", () => saveDocTab(tab)),
        item("download", "Save as copy…", "Keep the original as it is", () => saveDocTab(tab, true)),
        item("flatten", "Save flattened copy", "Comments & form answers burned in", () => saveFlatCopy()),
        item("compare", "Compare with original", "Side by side, page by page", () => openCompare(tab, curPage)),
        item("printer", "Print", null, () => doPrint()),
        tool("toword", "Edited document to Word"), tool("toexcel"), tool("pdf2img")));
  };
  async function saveFlatCopy() {
    try {
      toast("Preparing flattened copy…");
      const mupdf = await loadMuPDF();
      const d = mupdfOpen(mupdf, bytesOf(rec));
      let out;
      try { d.bake(true, true); out = PDCore.mupdfSave(d, "garbage=compact"); } finally { try { d.destroy(); } catch (e) {} }
      downloadBytes(PDCore.baseName(rec.name) + "-flattened.pdf", out, "application/pdf");
    } catch (e) { toast("Couldn't flatten: " + (e && e.message || e), "err"); }
  }
  if (panel === "tools" || panel === "history") buildPanel(panel, true);
  function rotatePages(idx, delta) {
    if (!idx.length) return;
    const what = idx.length === 1 ? "page " + (idx[0] + 1) : idx.length + " pages";
    const how = delta === 180 ? "180°" : delta > 0 ? "clockwise" : "counter-clockwise";
    return commit("Rotate " + what + " " + how, idx, b => PDCore.rotatePdf(b, idx, delta));
  }
  /* swap in the edited bytes: reopen, then redraw only the pages that changed */
  async function reload(idx) {
    if (tts.ar) toggleAudio(false);
    const nd = await openPdf(rec);
    if (nd.numPages !== holders.length) {   // v3.8: a tool added/removed pages → rebuild the pane
      closePdf(nd);
      setTimeout(() => ctx.restart(), 0);
      return;
    }
    const old = doc;
    doc = nd;
    textCache.clear();
    tts.models.clear();
    if (tts.mdocP) { const p = tts.mdocP; tts.mdocP = null; p.then(md => { try { md && md.destroy(); } catch (e) {} }); }
    const set = idx && idx.length ? idx : holders.map((_, i) => i);
    for (const i of set) {
      try { const v = (await doc.getPage(i + 1)).getViewport({ scale: 1 }); meta[i] = { w: v.width, h: v.height }; } catch (e) {}
      pageVer[i]++;
    }
    closePdf(old);
    if (fitWidth && set.includes(0)) { layout(); }
    else {
      for (const i of set) {
        const hd = holders[i];
        hd.dataset.rendered = "";
        hd.innerHTML = "";
        hd.append(pageChrome(i));
        sizeHolder(i);
        if (io) { io.unobserve(hd); io.observe(hd); }
      }
    }
    for (const i of set) {
      sizeThumb(i);
      thumbItems[i].firstChild.innerHTML = "";
      tio.unobserve(thumbItems[i]); tio.observe(thumbItems[i]);
    }
    if (query) runSearch();
  }

  /* ---- crop dialog: drag a box (move / resize with handles) on the page ---- */
  async function cropDialog(i, idxSel) {
    if (editBusy) return;
    let page;
    try { page = await doc.getPage(i + 1); } catch (e) { return; }
    const v1 = page.getViewport({ scale: 1 });
    const W = v1.width, H = v1.height;
    const avail = Math.min(640, window.innerWidth * 0.94) - 48 - 36 - 4;   // modal width − its padding − stage padding
    const sc = Math.min(avail / W, window.innerHeight * 0.52 / H);
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const vp = page.getViewport({ scale: sc * dpr });
    const canvas = document.createElement("canvas");
    canvas.width = Math.round(vp.width); canvas.height = Math.round(vp.height);
    canvas.style.width = Math.round(W * sc) + "px"; canvas.style.height = Math.round(H * sc) + "px";
    const c2 = canvas.getContext("2d", { alpha: false });
    c2.fillStyle = "#fff"; c2.fillRect(0, 0, canvas.width, canvas.height);
    page.render({ canvasContext: c2, viewport: vp }).promise.catch(() => {});
    const full = { x: 0, y: 0, w: W, h: H };
    let box = Object.assign({}, full);
    const handles = ["nw", "n", "ne", "e", "se", "s", "sw", "w"].map(d => h("span", { class: "crop-h h-" + d, "data-d": d }));
    const boxEl = h("div", { class: "crop-box" }, handles);
    const stage = h("div", { class: "crop-stage", style: "width:" + Math.round(W * sc) + "px;height:" + Math.round(H * sc) + "px" }, canvas, boxEl);
    const readout = h("span", { class: "crop-read" });
    const opts = [{ v: "page", label: "Page " + (i + 1) }];
    if (idxSel.length > 1) opts.push({ v: "sel", label: idxSel.length + " selected" });
    if (n > 1) opts.push({ v: "all", label: "All " + n + " pages" });
    let scope = idxSel.length > 1 ? "sel" : "page";
    const scopeSeg = segmented(opts, scope, v => { scope = v; });
    let applyBtn = null;
    const isFull = () => box.x < 0.5 && box.y < 0.5 && box.w > W - 1 && box.h > H - 1;
    function paint() {
      const s = stage.getBoundingClientRect().width / W || sc;
      boxEl.style.left = box.x * s + "px"; boxEl.style.top = box.y * s + "px";
      boxEl.style.width = box.w * s + "px"; boxEl.style.height = box.h * s + "px";
      boxEl.classList.toggle("full", isFull());
      readout.textContent = isFull() ? "Drag on the page to choose the area to keep" : "Keeping " + Math.round(box.w) + " × " + Math.round(box.h) + " pt";
      if (applyBtn) applyBtn.disabled = isFull() || box.w < 12 || box.h < 12;
    }
    stage.addEventListener("pointerdown", e => {
      e.preventDefault();
      const r = stage.getBoundingClientRect();
      const s = r.width / W;
      const px = x => Math.max(0, Math.min(W, (x - r.left) / s));
      const py = y => Math.max(0, Math.min(H, (y - r.top) / s));
      const sx = px(e.clientX), sy = py(e.clientY);
      const d = e.target.dataset && e.target.dataset.d;
      const start = Object.assign({}, box);
      const mode = d ? "resize" : (!isFull() && e.target === boxEl ? "move" : "draw");
      try { stage.setPointerCapture(e.pointerId); } catch (err) {}
      const move = ev => {
        const x = px(ev.clientX), y = py(ev.clientY);
        if (mode === "draw") {
          box = { x: Math.min(sx, x), y: Math.min(sy, y), w: Math.abs(x - sx), h: Math.abs(y - sy) };
        } else if (mode === "move") {
          box.x = Math.max(0, Math.min(W - start.w, start.x + x - sx));
          box.y = Math.max(0, Math.min(H - start.h, start.y + y - sy));
        } else {
          let x0 = start.x, y0 = start.y, x1 = start.x + start.w, y1 = start.y + start.h;
          if (d.includes("w")) x0 = Math.min(x, x1 - 12);
          if (d.includes("e")) x1 = Math.max(x, x0 + 12);
          if (d.includes("n")) y0 = Math.min(y, y1 - 12);
          if (d.includes("s")) y1 = Math.max(y, y0 + 12);
          box = { x: x0, y: y0, w: x1 - x0, h: y1 - y0 };
        }
        paint();
      };
      const up = () => {
        stage.removeEventListener("pointermove", move);
        stage.removeEventListener("pointerup", up);
        stage.removeEventListener("pointercancel", up);
        if (box.w < 12 || box.h < 12) box = mode === "draw" ? Object.assign({}, full) : start;
        paint();
      };
      stage.addEventListener("pointermove", move);
      stage.addEventListener("pointerup", up);
      stage.addEventListener("pointercancel", up);
    });
    const body = h("div", { class: "crop-dlg" },
      h("div", { class: "crop-wrap" }, stage),
      h("div", { class: "crop-row" }, readout, h("button", { class: "textbtn", onclick: () => { box = Object.assign({}, full); paint(); } }, "Reset")),
      h("div", { class: "crop-row" }, h("span", { class: "crop-lbl" }, "Apply to"), scopeSeg.el),
      h("div", { class: "opt-note" }, "Content outside the box is hidden, not deleted. The same box is used on every chosen page. Undo brings the full page back."));
    showModal({
      title: "Crop", body, cls: "wide",
      actions: [
        { label: "Cancel", onClick: c => c() },
        { label: "Crop", primary: true, onClick: c => {
          if (isFull()) return;
          const idx = scope === "page" ? [i] : scope === "sel" ? idxSel.slice() : holders.map((_, k) => k);
          const b = Object.assign({}, box);
          c();
          commit("Crop " + (idx.length === 1 ? "page " + (idx[0] + 1) : idx.length + " pages"), idx, bytes => PDCore.cropPdf(bytes, b, idx));
        } },
      ],
    });
    const wrapEl = body.closest(".modal");
    applyBtn = wrapEl && wrapEl.querySelector(".mrow .btn.primary");
    requestAnimationFrame(paint);
  }


  /* ---- v3.7 comments: real PDF annotations (MuPDF), undoable like every other edit ----
     Text markup comes from a text selection (floating menu, or the markup tools); notes,
     boxes, ovals, lines, freehand ink and stamps are placed on the page. Coordinates are
     pdf.js viewport units at scale 1 = MuPDF page space. */
  const ANN_COLORS = [["Yellow", [1, 0.84, 0]], ["Green", [0.24, 0.72, 0.36]], ["Blue", [0.2, 0.5, 0.95]], ["Red", [0.88, 0.18, 0.16]], ["Purple", [0.58, 0.34, 0.86]]];
  const ANN_TOOLS = [
    ["select", "a_select", "Select text (then pick from the menu)"], ["highlight", "a_highlight", "Highlight text"], ["underline", "a_underline", "Underline text"], ["strikeout", "a_strike", "Strike out text"],
    ["note", "a_note", "Sticky note"], ["box", "a_box", "Box"], ["oval", "a_oval", "Oval"], ["line", "a_line", "Arrow"], ["ink", "a_ink", "Draw freehand"], ["stamp", "a_stamp", "Stamp"]];
  const STAMPS = ["Approved", "Paid", "Received", "Draft"];
  const annPrefs = (() => { try { return JSON.parse(localStorage.getItem("atob.annot") || "{}"); } catch (e) { return {}; } })();
  let annTool = "select", annStamp = annPrefs.stamp || "Approved";
  const annColor = { markup: annPrefs.markup != null ? annPrefs.markup : 0, shape: annPrefs.shape != null ? annPrefs.shape : 3 };
  const colorGroup = t => ["highlight", "underline", "strikeout", "select", "note"].includes(t) ? "markup" : "shape";
  const saveAnnPrefs = () => { try { localStorage.setItem("atob.annot", JSON.stringify({ markup: annColor.markup, shape: annColor.shape, stamp: annStamp })); } catch (e) {} };
  const annAuthor = () => { try { return localStorage.getItem("atob.author") || "AtoB PDF"; } catch (e) { return "AtoB PDF"; } };
  const annToolBtns = {};
  const swatches = h("span", { class: "va-swatches" });
  const stampSeg = h("span", { class: "va-stamps hidden" }, STAMPS.map(n => h("button", { class: "va-stamp" + (n === annStamp ? " on" : ""), "data-stamp": n, onclick: () => { annStamp = n; saveAnnPrefs(); stampSeg.querySelectorAll(".va-stamp").forEach(b => b.classList.toggle("on", b.dataset.stamp === n)); } }, n)));
  const annBar = h("div", { class: "vannot hidden", role: "toolbar", "aria-label": "Comment tools" },
    ANN_TOOLS.map(([id, ic, tip]) => (annToolBtns[id] = h("button", { class: "iconbtn va-tool", "data-tool": id, title: tip, "aria-label": tip, onclick: () => setAnnTool(id) }, icon(ic)))),
    h("span", { class: "sep" }), swatches, stampSeg, h("span", { class: "vb-grow" }),
    h("button", { class: "btn secondary sm va-done", onclick: () => toggleAnnotBar(false) }, "Done"));
  barEl.after(annBar);
  function paintSwatches() {
    const g = colorGroup(annTool);
    swatches.innerHTML = "";
    swatches.classList.toggle("hidden", annTool === "stamp");
    stampSeg.classList.toggle("hidden", annTool !== "stamp");
    ANN_COLORS.forEach(([name, c], i) => swatches.append(h("button", { class: "va-sw" + (annColor[g] === i ? " on" : ""), title: name, "aria-label": name,
      style: "--sw:rgb(" + c.map(v => Math.round(v * 255)).join(",") + ")", onclick: () => { annColor[g] = i; saveAnnPrefs(); paintSwatches(); } })));
  }
  function curColor(t) { return ANN_COLORS[annColor[colorGroup(t || annTool)]][1]; }
  function setAnnTool(id) {
    annTool = id;
    for (const k in annToolBtns) annToolBtns[k].classList.toggle("on", k === id);
    pagesEl.classList.toggle("drawing", ["note", "box", "oval", "line", "ink", "stamp"].includes(id));
    pagesEl.dataset.tool = id;
    paintSwatches();
  }
  function toggleAnnotBar(force) {
    const on = force != null ? force : annBar.classList.contains("hidden");
    annBar.classList.toggle("hidden", !on);
    commentBtn.classList.toggle("on", on);
    pane.querySelectorAll(".ph-comment").forEach(b => b.classList.toggle("on", on));
    setAnnTool(on ? annTool : "select");
    if (!on) pagesEl.classList.remove("drawing");
  }
  async function annotate(label, ops) {
    if (!ops.length) return;
    const pages = Array.from(new Set(ops.map(o => o.page)));
    const author = annAuthor();
    ops.forEach(o => { o.author = author; });
    await commit(label, pages, async b => PDCore.addAnnots(await loadMuPDF(), b, ops));
  }
  /* selection → per-page quads (page coordinates), lines merged */
  function selectionQuads() {
    const sl = window.getSelection && window.getSelection();
    if (!sl || sl.isCollapsed || !sl.rangeCount) return null;
    const range = sl.getRangeAt(0);
    if (!pagesEl.contains(range.commonAncestorContainer)) return null;
    const byPage = new Map();
    for (const r of Array.from(range.getClientRects())) {
      if (r.width < 1 || r.height < 1) continue;
      const cx = r.left + r.width / 2, cy = r.top + r.height / 2;
      const i = holders.findIndex(hd => { const b = hd.getBoundingClientRect(); return cx >= b.left && cx <= b.right && cy >= b.top && cy <= b.bottom; });
      if (i < 0) continue;
      const b = holders[i].getBoundingClientRect(), z = zOf(i);
      const box = { x0: (r.left - b.left) / z, y0: (r.top - b.top) / z, x1: (r.right - b.left) / z, y1: (r.bottom - b.top) / z };
      const list = byPage.get(i) || [];
      const vert = ((holders[i]._vp && holders[i]._vp.rotation) || 0) % 180 !== 0;
      const same = vert
        ? list.find(q => Math.abs(q.x0 - box.x0) < (box.x1 - box.x0) * 0.5 && Math.abs(q.x1 - box.x1) < (box.x1 - box.x0) * 0.5 && box.y0 <= q.y1 + 4 && box.y1 >= q.y0 - 4)
        : list.find(q => Math.abs(q.y0 - box.y0) < (box.y1 - box.y0) * 0.5 && Math.abs(q.y1 - box.y1) < (box.y1 - box.y0) * 0.5 && box.x0 <= q.x1 + 4 && box.x1 >= q.x0 - 4);
      if (same) { same.x0 = Math.min(same.x0, box.x0); same.x1 = Math.max(same.x1, box.x1); same.y0 = Math.min(same.y0, box.y0); same.y1 = Math.max(same.y1, box.y1); }
      else list.push(box);
      byPage.set(i, list);
    }
    if (!byPage.size) return null;
    return { text: String(sl).trim(), pages: Array.from(byPage.entries()).map(([page, boxes]) => ({ page, boxes: boxes.map(q => [q.x0, q.y0, q.x1, q.y1]), last: boxes[boxes.length - 1] })) };
  }
  async function markupSelection(kind) {
    const sq = selectionQuads();
    if (!sq) { toast("Select some text first"); return; }
    window.getSelection().removeAllRanges();
    hideSelMenu();
    const NAME = { highlight: "Highlight", underline: "Underline", strikeout: "Strike out" };
    const pgs = sq.pages.map(p => p.page + 1);
    await annotate(NAME[kind] + " text on page" + (pgs.length > 1 ? "s " + pgs.join(", ") : " " + pgs[0]),
      sq.pages.map(p => ({ page: p.page, type: kind, boxes: p.boxes, color: curColor(kind) })));
  }
  function askNote(title, initial) {
    return new Promise(resolve => {
      const ta = h("textarea", { class: "va-note-input", rows: 4, placeholder: "Write a comment", "aria-label": "Comment text" });
      ta.value = initial || "";
      const done = (v, c) => { c(); resolve(v); };
      showModal({ title, body: ta, onCancel: c => done(null, c),
        actions: [{ label: "Cancel", onClick: c => done(null, c) }, { label: "Save", primary: true, onClick: c => done(ta.value, c) }] });
      setTimeout(() => ta.focus(), 30);
    });
  }
  async function noteAt(page, x, y, preset) {
    const text = await askNote("Sticky note on page " + (page + 1), preset);
    if (text == null) return;
    await annotate("Add a note on page " + (page + 1), [{ page, type: "note", rect: [x - 10, y - 10, x + 10, y + 10], contents: text, color: curColor("note") }]);
  }
  /* floating menu over a text selection */
  const selMenu = h("div", { class: "vselmenu hidden", role: "menu" },
    h("button", { "data-act": "highlight", onclick: () => markupSelection("highlight") }, icon("a_highlight"), "Highlight"),
    h("button", { "data-act": "underline", title: "Underline", "aria-label": "Underline", onclick: () => markupSelection("underline") }, icon("a_underline")),
    h("button", { "data-act": "strikeout", title: "Strike out", "aria-label": "Strike out", onclick: () => markupSelection("strikeout") }, icon("a_strike")),
    h("button", { "data-act": "note", title: "Add a note", "aria-label": "Add a note", onclick: () => { const sq = selectionQuads(); if (!sq) return; const p = sq.pages[sq.pages.length - 1]; window.getSelection().removeAllRanges(); hideSelMenu(); noteAt(p.page, p.last.x1 + 12, p.last.y0 + 2); } }, icon("a_note")),
    h("button", { "data-act": "copy", title: "Copy", "aria-label": "Copy", onclick: () => { const t = String(window.getSelection() || "").trim(); hideSelMenu(); if (t) copyText(t); } }, icon("copy")));
  pane.append(selMenu);
  function hideSelMenu() { selMenu.classList.add("hidden"); }
  let selT = 0;
  const onSelChange = () => {
    clearTimeout(selT);
    selT = setTimeout(() => {
      if (!isActive() || editBusy) { hideSelMenu(); return; }
      const sq = selectionQuads();
      if (!sq || !sq.text) { hideSelMenu(); return; }
      if (["highlight", "underline", "strikeout"].includes(annTool) && !annBar.classList.contains("hidden")) { hideSelMenu(); return; }
      const r = window.getSelection().getRangeAt(0).getBoundingClientRect(), pr = pane.getBoundingClientRect();
      selMenu.classList.remove("hidden");
      const mw = selMenu.offsetWidth || 220, mh = selMenu.offsetHeight || 40;
      let top = r.top - pr.top - mh - 8;
      if (top < 60) top = r.bottom - pr.top + 8;
      selMenu.style.left = Math.max(6, Math.min(pr.width - mw - 6, r.left - pr.left + r.width / 2 - mw / 2)) + "px";
      selMenu.style.top = top + "px";
    }, isMobile() ? 450 : 180);
  };
  document.addEventListener("selectionchange", onSelChange);
  scroller.addEventListener("scroll", hideSelMenu, { passive: true });
  /* markup tools: select text, release → applied */
  pagesEl.addEventListener("pointerup", () => {
    if (annBar.classList.contains("hidden") || !["highlight", "underline", "strikeout"].includes(annTool)) return;
    setTimeout(() => { const sq = selectionQuads(); if (sq && sq.text) markupSelection(annTool); }, 30);
  });
  /* placing notes and stamps, drawing boxes, ovals, arrows and ink */
  let drawing = null;
  const SVGNS = "http://www.w3.org/2000/svg";
  function pagePoint(e) {
    const hd = e.target.closest && e.target.closest(".vpage");
    if (!hd) return null;
    const i = +hd.dataset.i, b = hd.getBoundingClientRect(), z = zOf(i);
    return { i, hd, z, x: (e.clientX - b.left) / z, y: (e.clientY - b.top) / z };
  }
  pagesEl.addEventListener("pointerdown", e => {
    if (!pagesEl.classList.contains("drawing") || e.button !== 0 || editBusy) return;
    if (e.target.closest(".vpage-tools")) return;
    const pt = pagePoint(e);
    if (!pt) return;
    e.preventDefault();
    if (annTool === "note") { noteAt(pt.i, pt.x, pt.y); return; }
    if (annTool === "stamp") {
      const w = 150, hh = 46;
      annotate("Stamp “" + annStamp + "” on page " + (pt.i + 1), [{ page: pt.i, type: "stamp", stamp: annStamp, rect: [pt.x - w / 2, pt.y - hh / 2, pt.x + w / 2, pt.y + hh / 2] }]);
      return;
    }
    const svg = document.createElementNS(SVGNS, "svg");
    svg.setAttribute("class", "va-preview");
    const c = curColor(), stroke = "rgb(" + c.map(v => Math.round(v * 255)).join(",") + ")";
    const shape = document.createElementNS(SVGNS, annTool === "box" ? "rect" : annTool === "oval" ? "ellipse" : annTool === "line" ? "line" : "polyline");
    shape.setAttribute("stroke", stroke); shape.setAttribute("stroke-width", "2"); shape.setAttribute("fill", "none");
    shape.setAttribute("stroke-linecap", "round"); shape.setAttribute("stroke-linejoin", "round");
    svg.append(shape);
    pt.hd.append(svg);
    drawing = { tool: annTool, i: pt.i, hd: pt.hd, z: pt.z, x0: pt.x, y0: pt.y, x1: pt.x, y1: pt.y, pts: [[pt.x, pt.y]], svg, shape, id: e.pointerId };
    try { pagesEl.setPointerCapture(e.pointerId); } catch (err) {}
  });
  pagesEl.addEventListener("pointermove", e => {
    if (!drawing || e.pointerId !== drawing.id) return;
    const b = drawing.hd.getBoundingClientRect(), z = drawing.z;
    const x = Math.max(0, Math.min(b.width / z, (e.clientX - b.left) / z)), y = Math.max(0, Math.min(b.height / z, (e.clientY - b.top) / z));
    drawing.x1 = x; drawing.y1 = y;
    const { shape, x0, y0 } = drawing;
    const S = v => String(v * z);
    if (drawing.tool === "box") { shape.setAttribute("x", S(Math.min(x0, x))); shape.setAttribute("y", S(Math.min(y0, y))); shape.setAttribute("width", S(Math.abs(x - x0))); shape.setAttribute("height", S(Math.abs(y - y0))); }
    else if (drawing.tool === "oval") { shape.setAttribute("cx", S((x0 + x) / 2)); shape.setAttribute("cy", S((y0 + y) / 2)); shape.setAttribute("rx", S(Math.abs(x - x0) / 2)); shape.setAttribute("ry", S(Math.abs(y - y0) / 2)); }
    else if (drawing.tool === "line") { shape.setAttribute("x1", S(x0)); shape.setAttribute("y1", S(y0)); shape.setAttribute("x2", S(x)); shape.setAttribute("y2", S(y)); }
    else { drawing.pts.push([x, y]); shape.setAttribute("points", drawing.pts.map(p => p[0] * z + "," + p[1] * z).join(" ")); }
  });
  const endDraw = e => {
    if (!drawing || (e && e.pointerId !== drawing.id)) return;
    const d = drawing;
    drawing = null;
    d.svg.remove();
    const w = Math.abs(d.x1 - d.x0), hh = Math.abs(d.y1 - d.y0);
    const c = curColor(d.tool), pg = " on page " + (d.i + 1);
    if (d.tool === "ink") {
      if (d.pts.length < 2) return;
      annotate("Draw" + pg, [{ page: d.i, type: "ink", ink: [d.pts], color: c, width: 2 }]);
    } else if (d.tool === "line") {
      if (Math.hypot(d.x1 - d.x0, d.y1 - d.y0) < 6) return;
      annotate("Add an arrow" + pg, [{ page: d.i, type: "line", line: [[d.x0, d.y0], [d.x1, d.y1]], arrow: true, color: c, width: 2 }]);
    } else {
      if (w < 6 || hh < 6) return;
      const rect = [Math.min(d.x0, d.x1), Math.min(d.y0, d.y1), Math.max(d.x0, d.x1), Math.max(d.y0, d.y1)];
      annotate((d.tool === "box" ? "Add a box" : "Add an oval") + pg, [{ page: d.i, type: d.tool, rect, color: c, width: 2 }]);
    }
  };
  pagesEl.addEventListener("pointerup", endDraw);
  pagesEl.addEventListener("pointercancel", e => { if (drawing && e.pointerId === drawing.id) { drawing.svg.remove(); drawing = null; } });
  setAnnTool("select");

  /* ---- Comments panel: every annotation in the file, from AtoB or any other app ---- */
  const KIND_LABEL = { highlight: "Highlight", underline: "Underline", strikeout: "Strikeout", note: "Note", freetext: "Text box", box: "Box", oval: "Oval", line: "Line", shape: "Shape", ink: "Drawing", stamp: "Stamp", file: "Attachment", redact: "Redaction", other: "Comment" };
  const FILTERS = [["all", "All"], ["marks", "Highlights & marks"], ["notes", "Notes"], ["shapes", "Shapes & drawings"], ["stamps", "Stamps"]];
  const inFilter = (f, k) => f === "all" || (f === "marks" && ["highlight", "underline", "strikeout"].includes(k)) || (f === "notes" && ["note", "freetext"].includes(k)) ||
    (f === "shapes" && ["box", "oval", "line", "shape", "ink"].includes(k)) || (f === "stamps" && k === "stamp");
  let commentFilter = "all", commentList = null;
  function commentsDirty() {
    commentList = null;
    if (panel === "comments") buildPanel("comments", true);
    countComments();
  }
  async function countComments() {
    const d = doc;
    let k = 0;
    try {
      for (let i = 0; i < Math.min(n, 300); i++) {
        const anns = await (await d.getPage(i + 1)).getAnnotations({ intent: "display" });
        k += anns.filter(a => !["Link", "Widget", "Popup"].includes(a.subtype) && a.annotationType !== 2 && a.annotationType !== 20 && a.annotationType !== 16).length;
        if (d !== doc || dead) return;
      }
    } catch (e) { return; }
    counts.comments = k;
    paintBadges();
  }
  extraPanels.comments = async body => {
    if (!commentList) commentList = PDCore.listAnnots(await loadMuPDF(), bytesOf(rec));
    body.innerHTML = "";
    counts.comments = commentList.length;
    paintBadges();
    const sel = h("select", { class: "vp-filter", "aria-label": "Show" }, FILTERS.map(([v, l]) => h("option", { value: v }, l)));
    sel.value = commentFilter;
    sel.addEventListener("change", () => { commentFilter = sel.value; extraPanels.comments(body); });
    const who = h("button", { class: "textbtn cm-who", title: "The name saved with your comments", onclick: async () => {
      const v = await askNote("Your name on new comments", annAuthor());
      if (v != null && v.trim()) { try { localStorage.setItem("atob.author", v.trim().slice(0, 60)); } catch (e) {} extraPanels.comments(body); }
    } }, "As: " + annAuthor());
    body.append(h("div", { class: "cm-top" }, sel, who));
    const shown = commentList.filter(c => inFilter(commentFilter, c.kind));
    if (!commentList.length) { body.append(h("div", { class: "vp-empty" }, "No comments yet. Select text to highlight it, or press the comment button for notes, shapes, drawing and stamps.")); return; }
    if (!shown.length) { body.append(h("div", { class: "vp-empty" }, "Nothing of this kind.")); return; }
    let lastPage = -1;
    for (const c of shown) {
      if (c.page !== lastPage) { body.append(h("div", { class: "vp-group" }, "Page " + (c.page + 1))); lastPage = c.page; }
      const col = c.color && c.color.length >= 3 ? "rgb(" + c.color.slice(0, 3).map(v => Math.round(v * 255)).join(",") + ")" : "var(--ink3)";
      const row = h("div", { class: "cm-row", "data-kind": c.kind },
        h("button", { class: "cm-main", onclick: () => flashBox(c.page, c.bounds) },
          h("span", { class: "cm-head" }, h("span", { class: "cm-dot", style: "background:" + col }), h("span", { class: "cm-kind" }, KIND_LABEL[c.kind] + (c.icon && c.kind === "stamp" ? " “" + c.icon + "”" : ""))),
          h("span", { class: "cm-meta" }, [c.author, c.modified ? relTime(c.modified) : ""].filter(Boolean).join(" · ")),
          c.contents ? h("span", { class: "cm-text" }, c.contents) : null),
        h("div", { class: "cm-acts" },
          h("button", { class: "textbtn", onclick: async () => {
            const v = await askNote((c.contents ? "Edit" : "Add") + " comment text", c.contents);
            if (v == null || v === c.contents) return;
            await commit("Edit a comment on page " + (c.page + 1), [c.page], async b => PDCore.changeAnnot(await loadMuPDF(), b, c, { contents: v }));
          } }, c.contents ? "Edit" : "Add text"),
          h("button", { class: "textbtn cm-del", onclick: () => commit("Delete a comment on page " + (c.page + 1), [c.page], async b => PDCore.changeAnnot(await loadMuPDF(), b, c, { delete: true })) }, "Delete")));
      body.append(row);
    }
  };
  /* bounds in page coordinates (top-left origin) */
  function flashBox(i, bb) {
    gotoPage(i);
    if (!bb) return;
    const z = zOf(i), pad = 3;
    const fl = h("div", { class: "vflash", style: "left:" + (bb[0] * z - pad) + "px;top:" + (bb[1] * z - pad) + "px;width:" + ((bb[2] - bb[0]) * z + pad * 2) + "px;height:" + ((bb[3] - bb[1]) * z + pad * 2) + "px" });
    holders[i].append(fl);
    setTimeout(() => fl.remove(), 1800);
    if (isMobile()) setPanel("");
  }

  /* ---- v3.7 document properties (Ctrl/⌘+D) ---- */
  async function showProps() {
    let info, mdEnc = "", perms = null, md = null;
    try { info = await PDCore.docInfo(bytesOf(rec)); } catch (e) { toast("Couldn't read this document's properties: " + (e && e.message || e), "err"); return; }
    try { md = await doc.getMetadata(); } catch (e) {}
    try { perms = await doc.getPermissions(); } catch (e) {}
    if (info.encrypted) {
      try { const mu = await loadMuPDF(); const d2 = mu.Document.openDocument(bytesOf(rec), "application/pdf"); try { mdEnc = d2.getMetaData ? (d2.getMetaData("encryption") || "") : ""; } finally { try { d2.destroy(); } catch (e) {} } } catch (e) {}
    }
    const pdfInfo = md && md.info || {};
    const val = k => info.encrypted ? (pdfInfo[k] || "") : info[k.toLowerCase()];
    const fld = (label, key, multi) => {
      const inp = h(multi ? "textarea" : "input", { class: "pp-in", "data-key": key, rows: multi ? 2 : null, "aria-label": label });
      inp.value = val(key) || "";
      if (info.encrypted) inp.disabled = true;
      return h("label", { class: "pp-field" }, h("span", null, label), inp);
    };
    const fmtDate = ms => ms ? new Date(ms).toLocaleString() : "—";
    const PF = pdfjsLib.PermissionFlag || {};
    const permRows = [["Printing", PF.PRINT], ["Copying text and images", PF.COPY], ["Changing the document", PF.MODIFY_CONTENTS], ["Comments", PF.MODIFY_ANNOTATIONS], ["Filling in forms", PF.FILL_INTERACTIVE_FORMS], ["Page assembly", PF.ASSEMBLE]];
    const row = (k, v) => h("div", { class: "pp-row" }, h("span", { class: "pp-k" }, k), h("span", { class: "pp-v" }, v));
    const fonts = info.fonts;
    const body = h("div", { class: "pp" },
      h("div", { class: "pp-sec" }, "Description"),
      fld("Title", "Title"), fld("Author", "Author"), fld("Subject", "Subject", true), fld("Keywords", "Keywords"),
      info.encrypted ? h("div", { class: "opt-note" }, "This PDF is encrypted. Unlock it to edit the description.") : null,
      h("div", { class: "pp-sec" }, "File"),
      row("File name", rec.name), rec.path ? row("Location", rec.path) : null,
      row("File size", PDCore.fmtBytes(rec.size)), row("PDF version", info.version || "—"),
      row("Pages", String(info.pageCount)), row("Page size", (info.size ? info.size.label : "—") + (info.sameSize ? "" : " (page 1; sizes vary)")),
      row("Created", fmtDate(info.created || (pdfInfo.CreationDate ? Date.parse(pdfInfo.CreationDate) : 0))), row("Modified", fmtDate(info.modified)),
      row("Application", info.creator || pdfInfo.Creator || "—"), row("PDF producer", info.producer || pdfInfo.Producer || "—"),
      h("div", { class: "pp-sec" }, "Security"),
      row("Encryption", info.encrypted ? (mdEnc || pdfInfo.EncryptFilterName || "Yes") : "None"),
      ...(Array.isArray(perms) ? permRows.map(([k, f]) => row(k, perms.includes(f) ? "Allowed" : "Not allowed")) : [row("Restrictions", "None")]),
      h("div", { class: "pp-sec" }, "Fonts (" + fonts.length + ")"),
      fonts.length ? h("div", { class: "pp-fonts" }, fonts.map(f => h("div", { class: "pp-font" },
        h("span", { class: "pp-fn" }, f.name), h("span", { class: "pp-ft" }, f.type + (f.subset ? " · subset" : "")),
        h("span", { class: "pp-fe" + (f.embedded ? " ok" : " no") }, f.embedded ? "Embedded" : "Not embedded")))) : h("div", { class: "opt-note" }, "No fonts: the pages are images or drawings only."));
    showModal({ title: "Document properties", body, cls: "wide props-dlg", actions: [
      { label: info.encrypted ? "Close" : "Cancel", onClick: c => c() },
      info.encrypted ? null : { label: "Save description", primary: true, onClick: c => {
        const get = k => body.querySelector('[data-key="' + k + '"]').value;
        const next = { title: get("Title"), author: get("Author"), subject: get("Subject"), keywords: get("Keywords") };
        c();
        if (next.title === (info.title || "") && next.author === (info.author || "") && next.subject === (info.subject || "") && next.keywords === (info.keywords || "")) return;
        commit("Edit document properties", [0], bytes => PDCore.setDocInfo(bytes, next));
      } },
    ].filter(Boolean) });
  }

  /* ---- search ---- */
  function drawHighlights(i) {
    const holder = holders[i];
    const hl = holder.querySelector(".hl-layer");
    if (!hl || !holder._vp) return;
    hl.innerHTML = "";
    if (!query || query.length < 2) return;
    const tc = textCache.get(i);
    if (!tc) return;
    const z = zOf(i);
    for (let mi = 0; mi < matches.length; mi++) {
      const m = matches[mi];
      if (m.page !== i) continue;
      const it = tc.items[m.item];
      if (!it) continue;
      const tx = pdfjsLib.Util.transform(holder._vp.transform, it.transform);
      const hgt = Math.hypot(tx[2], tx[3]) || 10;
      hl.append(h("div", {
        class: "hl" + (mi === curMatch ? " cur" : ""),
        style: "left:" + tx[4] + "px;top:" + (tx[5] - hgt) + "px;width:" + Math.max(4, it.width * z) + "px;height:" + hgt + "px",
      }));
    }
  }
  function refreshAllHighlights() { for (let i = 0; i < n; i++) if (holders[i].dataset.rendered) drawHighlights(i); }
  let searchSeq = 0;
  const runSearch = debounce(async () => {
    const seq = ++searchSeq;
    query = searchInput.value.trim().toLowerCase();
    matches = []; curMatch = -1;
    if (query.length < 2) { matchInfo.textContent = ""; refreshAllHighlights(); return; }
    matchInfo.textContent = "…";
    for (let i = 0; i < n; i++) {
      if (dead || seq !== searchSeq) return;
      const tc = await pageText(i);
      tc.items.forEach((it, k) => { if (it.str && it.str.toLowerCase().includes(query)) matches.push({ page: i, item: k }); });
    }
    if (seq !== searchSeq) return;
    matchInfo.textContent = matches.length ? "0 / " + matches.length : "0 found";
    refreshAllHighlights();
    if (matches.length) gotoMatch(0);
  }, 300);
  function gotoMatch(m) {
    if (!matches.length) return;
    curMatch = ((m % matches.length) + matches.length) % matches.length;
    matchInfo.textContent = (curMatch + 1) + " / " + matches.length;
    const mt = matches[curMatch];
    holders[mt.page].scrollIntoView({ block: "center", behavior: "smooth" });
    renderHolder(mt.page);
    refreshAllHighlights();
  }
  searchInput.addEventListener("input", runSearch);
  searchInput.addEventListener("keydown", e => {
    e.stopPropagation();
    if (e.key === "Enter") { e.preventDefault(); matches.length && gotoMatch(curMatch + (e.shiftKey ? -1 : 1)); }
    if (e.key === "Escape") { searchInput.value = ""; runSearch(); searchInput.blur(); }
  });
  const keyHandler = e => {
    if (!isActive() || document.querySelector(".modal-wrap")) return;
    const mod = e.ctrlKey || e.metaKey, k = e.key.toLowerCase();
    // Find / Print / Save / Undo …: app-wide commands in app-shared.js (registerCoreCommands → t.api)
    // Save / Save As / Undo / Redo: the app-wide shortcut handler in app-shared.js (appCommand → api.undo/redo)
  };
  document.addEventListener("keydown", keyHandler);

  /* ---- print ---- */
  let printing = false;
  async function doPrint() {
    if (printing) return;
    printing = true;
    printBtn.setAttribute("disabled", "");
    try {
      const cap = 200;
      const count = Math.min(n, cap);
      if (n > cap) toast("Printing the first " + cap + " pages");
      let box = document.getElementById("printbox");
      if (!box) { box = h("div", { id: "printbox" }); document.body.append(box); }
      box.innerHTML = "";
      toast("Preparing " + count + " page" + (count === 1 ? "" : "s") + " for printing…");
      for (let i = 1; i <= count && !dead; i++) {
        const r = await renderPageToCanvas(doc, i, 0, { dpi: 150 });
        const img = document.createElement("img");
        img.src = r.canvas.toDataURL("image/jpeg", 0.92);
        box.append(img);
        r.canvas.width = 1; r.canvas.height = 1;
      }
      if (dead) return;
      // large JPEG data URLs decode asynchronously; printing before that gives blank pages
      await Promise.all(Array.from(box.querySelectorAll("img"), im => im.decode ? im.decode().catch(() => {}) : null));
      if (dead) return;
      window.print();
      setTimeout(() => { box.innerHTML = ""; }, 3000);
    } finally {
      printing = false;
      printBtn.removeAttribute("disabled");
    }
  }

  /* ---- read aloud (v3.4) ---- */
  const tts = { ar: null, bar: null, state: null, models: new Map(), ocrLangs: null, ocrDeclined: false };
  const viewerHost = {
    pageCount: n,
    title: rec.name,
    async getPage(i) {
      if (tts.models.has(i)) return tts.models.get(i);
      if (!tts.mdocP) tts.mdocP = openMupdfForText(rec, n);
      const md = await tts.mdocP;
      let m = null;
      if (md && !dead) { try { m = mupdfPageModel(md, i); } catch (e) { m = null; } }
      if (!m) {
        const tc = await pageText(i);
        const page = await doc.getPage(i + 1);
        const pv = page.getViewport({ scale: 1 });
        m = finishModel(Object.assign(PDCore.buildPageText(pdfjsRuns(tc, pv)), { w: pv.width, h: pv.height, source: "pdfjs" }));
      }
      tts.models.set(i, m);
      return m;
    },
    async showPage(i) {
      holders[i].scrollIntoView({ block: "start", behavior: "smooth" });
      renderHolder(i);
    },
    highlight(i, sent, word) {
      const prev = tts.state;
      tts.state = sent ? { i, sent, word } : null;
      if (prev && prev.i !== i) { const l = holders[prev.i].querySelector(".tts-layer"); if (l) l.innerHTML = ""; }
      drawTts(true);
    },
    currentPage() { return curPage; },
    async needsOcr(i, m) {
      if (tts.ocrDeclined) return null;
      if (!tts.ocrLangs) {
        tts.ocrLangs = await offerOcr(m.quality.empty ? "scan" : "garbled", m.quality.hint);
        if (!tts.ocrLangs) { tts.ocrDeclined = true; return null; }
      }
      toast("Recognising page " + (i + 1) + "…", null, 2500);
      try {
        const om = await ocrPageModel(doc, i, tts.ocrLangs);
        tts.models.set(i, om);
        return om;
      } catch (e) { toast("OCR failed: " + (e && e.message || e), "err"); return null; }
    },
  };
  function drawTts(scrollTo) {
    const st = tts.state;
    if (!st) { holders.forEach(hd => { const l = hd.querySelector(".tts-layer"); if (l) l.innerHTML = ""; }); return; }
    const holder = holders[st.i];
    const layer = holder && holder.querySelector(".tts-layer");
    const m = tts.models.get(st.i);
    if (!layer || !m) return;
    const z = zOf(st.i);
    drawTtsBoxes(layer, m, st.sent, st.word, z);
    if (scrollTo && tts.ar && tts.ar.opts.autoTurn) {
      const box = layer.querySelector(".tts-sent");
      if (box) {
        const r = box.getBoundingClientRect();
        const sr = scroller.getBoundingClientRect();
        const bottomLimit = Math.min(sr.bottom, window.innerHeight - (tts.bar ? tts.bar.el.getBoundingClientRect().height + 30 : 40));
        if (r.top < sr.top || r.bottom > bottomLimit) box.scrollIntoView({ block: "center", behavior: "smooth" });
      }
    }
  }
  function toggleAudio(force) {
    const open = force != null ? force : !tts.ar;
    if (!open) {
      if (tts.ar) tts.ar.destroy();
      if (tts.bar) tts.bar.destroy();
      tts.ar = tts.bar = null; tts.state = null;
      drawTts();
      document.body.classList.remove("audio-on");
      listenBtn.classList.remove("on");
      return;
    }
    if (tts.ar) return;
    tts.ar = new AudioReader(viewerHost);
    tts.bar = audioBar(tts.ar, { onClose: () => toggleAudio(false), langs: () => Array.from(new Set(Array.from(tts.models.values()).map(m => m.lang).filter(Boolean))) });
    document.body.append(tts.bar.el);
    document.body.classList.add("audio-on");
    listenBtn.classList.add("on");
  }
  /* tap a word to start reading there */
  pagesEl.addEventListener("click", async e => {
    if (!tts.ar) return;
    const sl = window.getSelection && window.getSelection();
    if (sl && !sl.isCollapsed && String(sl).trim()) return;
    const holder = e.target.closest && e.target.closest(".vpage");
    if (!holder || e.target.closest(".vpage-tools")) return;
    const i = +holder.dataset.i;
    const r = holder.getBoundingClientRect(), z = zOf(i);
    const m = await viewerHost.getPage(i);
    if (!m || !m.text) { tts.ar.play(i, 0); return; }
    const off = PDCore.offsetAtPoint(m, (e.clientX - r.left) / z, (e.clientY - r.top) / z);
    tts.ar.play(i, PDCore.wordRangeAt(m.text, off).start);
  });
  const audioApi = { toggle: toggleAudio, get: () => tts };

  /* ---- current page tracking (from the scroll position) ---- */
  function gotoPage(i, smooth) {
    i = Math.max(0, Math.min(n - 1, i));
    holders[i].scrollIntoView({ behavior: smooth === false ? "auto" : "smooth", block: "start" });
    setCur(i);
  }
  function setCur(i) {
    if (i === curPage && thumbItems[i].classList.contains("cur")) return;
    if (thumbItems[curPage]) thumbItems[curPage].classList.remove("cur");
    curPage = i;
    thumbItems[i].classList.add("cur");
    pageNum.value = i + 1; scrub.value = i + 1; scrubLbl.textContent = "Page " + (i + 1);
    if (sel.size <= 1) selectOnly(i);
    revealThumb(i);
  }
  let scrollRaf = 0;
  scroller.addEventListener("scroll", () => {
    if (scrollRaf) return;
    scrollRaf = requestAnimationFrame(() => {
      scrollRaf = 0;
      const line = scroller.scrollTop + scroller.clientHeight * 0.3;
      let lo = 0, hi = n - 1;
      while (lo < hi) { const mid = (lo + hi + 1) >> 1; if (holders[mid].offsetTop <= line) lo = mid; else hi = mid - 1; }
      setCur(lo);
    });
  }, { passive: true });
  pageNum.addEventListener("change", () => gotoPage((parseInt(pageNum.value, 10) || 1) - 1));

  /* keep "fit width" fitted when the pane resizes (window, thumbnails panel) */
  let rT;
  const ro = new ResizeObserver(() => {
    if (!scroller.clientWidth || scroller.clientWidth === laidW) return;
    clearTimeout(rT);
    rT = setTimeout(() => { if (fitWidth) { const keep = curPage; layout(); holders[keep].scrollIntoView({ block: "start" }); } else laidW = scroller.clientWidth; }, 120);
  });
  ro.observe(scroller);

  /* fill in every page's size in the background so placeholders and thumbnails are right */
  (async () => {
    for (let i = 1; i < n && !dead; i++) {
      if (meta[i]) continue;
      try {
        const v = (await doc.getPage(i + 1)).getViewport({ scale: 1 });
        if (meta[i]) continue;
        meta[i] = { w: v.width, h: v.height };
        if (!holders[i].dataset.rendered && laidW) sizeHolder(i);
        sizeThumb(i);
      } catch (e) { /* doc swapped or closed */ }
    }
  })();

  ctx.setApi({
    onShow() {
      window.__viewerAudio = audioApi;
      if (scroller.clientWidth && scroller.clientWidth !== laidW) { const keep = curPage; layout(); holders[keep].scrollIntoView({ block: "start" }); }
      refreshEditUi();
    },
    onHide() {
      toggleAudio(false);
      if (isMobile()) setPanel("");
    },
    onSaved() { refreshEditUi(); historyDirty(); },
    /* v3.8: the document's bytes changed outside the viewer (a tool applied its result) */
    async refresh() {
      if (dead) return;
      try { await reload(null); afterEdit(); } catch (e) { ctx.restart(); }
    },
    undo, redo,
    /* v3.6 commands (palette / shortcuts) */
    find() { searchInput.focus(); searchInput.select(); },
    print: () => doPrint(),
    gotoPage: i => gotoPage(i),
    gotoPrompt() {
      const inp = h("input", { type: "number", min: 1, max: n, value: curPage + 1, "aria-label": "Page number" });
      const go = c => { const v = parseInt(inp.value, 10); if (v >= 1 && v <= n) { c(); gotoPage(v - 1); } else toast("Enter a page from 1 to " + n, "err"); };
      const close = showModal({ title: "Go to page", body: h("div", null, h("p", null, "Page 1 to " + n), inp), actions: [{ label: "Cancel", onClick: c => c() }, { label: "Go", primary: true, onClick: go }] });
      inp.addEventListener("keydown", e => { if (e.key === "Enter") go(close); });
      setTimeout(() => { inp.focus(); inp.select(); }, 30);
    },
    rotate: delta => rotatePages(targets(), delta),
    crop() { const t = targets(); cropDialog(t.includes(curPage) ? curPage : t[0], t); },
    selectAll() { selectAll(); if (!thumbsOpen()) setPanel("pages"); },
    listen: () => toggleAudio(),
    setPanel: name => setPanel(name),
    panel: () => panel,
    counts: () => Object.assign({}, counts),
    notices: () => notices.map(x => x.id),
    comment: on => toggleAnnotBar(on),
    props: () => showProps(),
    annotTool: id => { toggleAnnotBar(true); setAnnTool(id); },
    markup: kind => markupSelection(kind),
  });
  ctx.setCleanup(() => {
    dead = true;
    clearTimeout(rT);
    ro.disconnect();
    toggleAudio(false);
    releaseOcrWorker();
    if (tts.mdocP) tts.mdocP.then(d => { try { d && d.destroy(); } catch (e) {} });
    if (window.__viewerAudio === audioApi) window.__viewerAudio = null;
    document.removeEventListener("keydown", keyHandler);
    document.removeEventListener("selectionchange", onSelChange);
    tio.disconnect();
    if (io) io.disconnect();
    closePdf(doc);
    const box = document.getElementById("printbox");
    if (box) box.innerHTML = "";
  });
  refreshEditUi();
  if (isActive()) window.__viewerAudio = audioApi;
  layout();
  setCur(0);
  /* v3.6: what's inside (badges on the rail) and what to suggest (notices) */
  (async () => {
    const d = doc;
    const [ol, att, fo, md, perms, tc0] = await Promise.all([
      d.getOutline().catch(() => null), d.getAttachments().catch(() => null), d.getFieldObjects().catch(() => null),
      d.getMetadata().catch(() => null), d.getPermissions().catch(() => null), pageText(0).catch(() => null)]);
    if (dead) return;
    counts.outline = ol ? ol.length : 0;
    counts.attach = att ? Object.keys(att).length : 0;
    counts.fields = fo ? Object.values(fo).filter(arr => Array.isArray(arr) && arr.some(x => x && x.type)).length : 0;   // terminal fields only, not name-path parents
    paintBadges();
    const PF = pdfjsLib.PermissionFlag || { PRINT: 4, MODIFY_CONTENTS: 8, COPY: 16 };
    const encrypted = !!(md && md.info && md.info.EncryptFilterName);
    const limits = Array.isArray(perms) ? [!perms.includes(PF.PRINT) && "printing", !perms.includes(PF.COPY) && "copying", !perms.includes(PF.MODIFY_CONTENTS) && "editing"].filter(Boolean) : [];
    if (encrypted || limits.length)
      notices.push({ id: "lock", icon: "lock", text: limits.length ? "This PDF is protected: " + (limits.length > 1 ? limits.slice(0, -1).join(", ") + " and " + limits[limits.length - 1] + " are" : limits[0] + " is") + " restricted." : "This PDF is password-protected.", action: "Unlock", run: () => showView("unlock") });
    if (counts.fields) notices.push({ id: "form", icon: "forms", text: "This document has " + counts.fields + " form field" + (counts.fields === 1 ? "" : "s") + ".", action: "Fill this form", run: () => showView("forms") });
    let scanLike = false;
    if (tc0 && !tc0.items.some(it => it.str && it.str.trim())) {       // no text: a scan only if the page draws an image
      try {
        const ops = await (await d.getPage(1)).getOperatorList();
        const O = pdfjsLib.OPS;
        scanLike = ops.fnArray.some(f => f === O.paintImageXObject || f === O.paintInlineImageXObject || f === O.paintImageMaskXObject || f === O.paintJpegXObject);
      } catch (e) {}
    }
    if (dead) return;
    if (scanLike) notices.push({ id: "scan", icon: "ocr", text: "This looks like a scan, so its text can't be searched or copied.", action: "Make it searchable (OCR)", run: () => showView("ocr") });
    if (counts.attach) notices.push({ id: "attach", icon: "paperclip", text: "This PDF has " + counts.attach + " attached file" + (counts.attach === 1 ? "" : "s") + ".", action: "Show attachments", run: () => { setPanel("attach"); notices.splice(notices.findIndex(x => x.id === "attach"), 1); showNotice(); } });
    showNotice();
    countComments();
    if (panel && panel !== "pages") buildPanel(panel, true);
  })();
}
