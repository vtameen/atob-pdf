/* AtoB PDF Phase 3 — Edit workspace (Acrobat-style editing) */
"use strict";

Object.assign(ICONS, {
  edit: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 4H6a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-6"/><path d="M18.4 3.6a2 2 0 0 1 2.8 2.8L13 14.6 9 15.4l.8-4z"/></svg>',
  cursor: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M5 3.5 19 10l-6 2-3.5 5.5z"/></svg>',
  edittext: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M5 5V3.8h9V5M9.5 3.8V15M8 15h3"/><path d="M18.7 12.3a1.6 1.6 0 0 1 2.3 2.3L15.5 20l-3 .7.7-3z"/></svg>',
  addtext: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 6V4h11v2M9.5 4v14M7.5 18h4"/><path d="M18 12v8M14 16h8"/></svg>',
  eraser: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="m8 19-4.5-4.5a1.5 1.5 0 0 1 0-2.1l8-8a1.5 1.5 0 0 1 2.1 0l6.9 6.9a1.5 1.5 0 0 1 0 2.1L15 19z"/><path d="M8 19h13"/><path d="m8.5 8.5 7 7"/></svg>',
  marker: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="m9 15-4.8 4.8M9.5 8.5 15 3l6 6-5.5 5.5a3.9 3.9 0 0 1-5.5-5.5z"/><path d="M3 21h7" opacity="0.6"/></svg>',
  redactblk: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><rect x="4" y="9" width="16" height="6.5" rx="1" fill="currentColor" stroke="none"/><path d="M4 4.5h16M4 19.5h16" opacity="0.5"/></svg>',
  shape_rect: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="4" y="6" width="16" height="12" rx="1.5"/></svg>',
  shape_ellipse: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><ellipse cx="12" cy="12" rx="8.5" ry="6"/></svg>',
  shape_line: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M5 19 19 5"/><path d="M13 5h6v6"/></svg>',
  note: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 6a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2h-7l-5 4v-4H6a2 2 0 0 1-2-2z"/><path d="M8 9h8M8 12.5h5"/></svg>',
  undo: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M8 5 4 9l4 4"/><path d="M4 9h10a6 6 0 0 1 0 12h-3"/></svg>',
  redo: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="m16 5 4 4-4 4"/><path d="M20 9H10a6 6 0 0 0 0 12h3"/></svg>',
});

const NOTE_SVG = '<svg viewBox="0 0 24 24" width="100%" height="100%"><path d="M3 5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2h-8l-5.5 4.5V17H5a2 2 0 0 1-2-2z" fill="#f5c33b" stroke="#8a6a14" stroke-width="1.2"/><path d="M7 8h10M7 11.5h7" stroke="#7a5c10" stroke-width="1.4" stroke-linecap="round" fill="none"/></svg>';

registerTool({
  id: "edit", name: "Edit", icon: "edit",
  desc: "Text, images, shapes & notes",
  hint: "The full editor. Whiteout, retype, annotate.",
  build(ctx) {
    singlePdfTool(ctx, {}, (rec, pages) => buildEditor(ctx, rec, pages));
  },
});

async function buildEditor(ctx, rec, pageCount) {
  /* ---------- state ---------- */
  const opsByPage = new Map();          // pageIdx -> [op]
  const stextCache = new Map();         // pageIdx -> {lines, images}
  const undoStack = [], redoStack = [];
  let cur = 0, zoomMode = "fit", zoomVal = 1, mode = "select", selId = null;
  let pendingImage = null;              // awaiting placement
  let mupdfDoc = null, destroyed = false;
  const defaults = {
    size: 14, color: "#1a1a1a", family: "sans", bold: false, italic: false,
    stroke: "#c0392b", strokeW: 2, fill: null, opacity: 1, arrow: false,
    hlColor: "#ffe066", hlOpacity: 0.4,
  };
  const uid = () => "o" + Math.random().toString(36).slice(2, 9);
  const getOps = i => { if (!opsByPage.has(i)) opsByPage.set(i, []); return opsByPage.get(i); };
  const selOp = () => getOps(cur).find(o => o.id === selId) || null;
  window.__edState = () => JSON.stringify({
    mode, selId, cur, undo: undoStack.length,
    ops: getOps(cur).map(o => ({ t: o.type, x: Math.round(o.x || 0), y: Math.round(o.y || 0), txt: (o.text || "").slice(0, 20) })),
    dom: { obj: objLayer.childElementCount, txt: objLayer.querySelectorAll(".textobj").length },
  });

  const doc = await openPdf(rec);
  const first = await doc.getPage(1);
  let pageW = first.getViewport({ scale: 1 }).width;
  let pageH = first.getViewport({ scale: 1 }).height;

  /* ---------- DOM scaffold ---------- */
  const canvas = document.createElement("canvas");
  canvas.className = "pagecanvas";
  const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute("class", "ed-svg");
  svg.style.pointerEvents = "none";
  const objLayer = h("div", { class: "ed-layer" });
  const hitLayer = h("div", { class: "ed-layer hidden" });
  const uiLayer = h("div", { class: "ed-layer", style: "pointer-events:none" });
  const stage = h("div", { class: "ed-stage" }, canvas, svg, objLayer, hitLayer, uiLayer);
  const stageWrap = h("div", { class: "ed-stagewrap" }, stage);
  const propsRow = h("div", { class: "ed-props" });
  const hint = h("div", { class: "ed-hint" }, "");
  const pageInput = h("input", { type: "number", min: 1, max: pageCount, value: 1 });
  const zoomLabel = h("span", { style: "min-width:38px;text-align:center" }, "fit");

  const MODE_LABELS = { select: "Select", edittext: "Retype", addtext: "Text", whiteout: "Whiteout", highlight: "Highlight", redact: "Redact", image: "Image", rect: "Box", ellipse: "Oval", line: "Line", note: "Note" };
  const MODES = [
    ["select", "cursor", "Select & move"],
    ["edittext", "edittext", "Edit existing text"],
    ["addtext", "addtext", "Add text"],
    ["whiteout", "eraser", "Whiteout"],
    ["highlight", "marker", "Highlight"],
    ["redact", "redactblk", "Redact (black out permanently)"],
    ["image", "image", "Insert image"],
    ["rect", "shape_rect", "Rectangle"],
    ["ellipse", "shape_ellipse", "Ellipse"],
    ["line", "shape_line", "Line / arrow"],
    ["note", "note", "Sticky note"],
  ];
  const modeBtns = new Map();
  const HINTS = {
    select: "Click an object to select. Drag to move, corners to resize, Delete to remove. Double-click text to edit.",
    edittext: "Original text lines are outlined. Click a line to retype it. Click an image to remove it.",
    addtext: "Click anywhere on the page to add text.",
    whiteout: "Drag a box to cover content with white.",
    highlight: "Drag across text to highlight.",
    redact: "Drag over content to black it out permanently. The underlying text and image data is truly removed on apply.",
    image: "Choose an image, then click the page to place it.",
    rect: "Drag to draw a rectangle.",
    ellipse: "Drag to draw an ellipse.",
    line: "Drag from start to end. Toggle the arrowhead in the bar above.",
    note: "Click to pin a comment. It becomes a real PDF note other viewers can read.",
  };

  const imgInput = h("input", { type: "file", accept: "image/*,.png,.jpg,.jpeg,.webp", style: "display:none" });
  imgInput.addEventListener("change", async () => {
    const f = imgInput.files[0];
    imgInput.value = "";
    if (!f) { setMode("select"); return; }
    const r = await readFileRec(f);
    const head = new Uint8Array(r.buf.slice(0, 2));
    const isJpg = head[0] === 0xff && head[1] === 0xd8;
    let bytes, isPng = !isJpg, w0, h0;
    const url = URL.createObjectURL(new Blob([r.buf]));
    const img = new Image();
    try {
      await new Promise((res, rej) => { img.onload = res; img.onerror = () => rej(new Error("Can't decode this image")); img.src = url; });
      w0 = img.naturalWidth; h0 = img.naturalHeight;
      if (isJpg || (head[0] === 0x89 && head[1] === 0x50)) bytes = new Uint8Array(r.buf.slice(0));
      else { // transcode webp etc -> png
        const c = document.createElement("canvas");
        c.width = w0; c.height = h0;
        c.getContext("2d").drawImage(img, 0, 0);
        const blob = await new Promise(res => c.toBlob(res, "image/png"));
        bytes = new Uint8Array(await blob.arrayBuffer());
        isPng = true;
      }
      pendingImage = { bytes, isPng, w: w0, h: h0 };
      setHint("Now click on the page where the image should go.");
    } catch (e) { toast(e.message, "err"); setMode("select"); }
    finally { URL.revokeObjectURL(url); }
  });

  function setHint(t) { hint.textContent = t; }
  function setMode(m) {
    mode = m;
    modeBtns.forEach((b, bm) => b.classList.toggle("on", bm === m));
    hitLayer.classList.toggle("hidden", m !== "edittext");
    if (m === "edittext") ensureStext();
    if (m === "image" && !pendingImage) imgInput.click();
    if (m !== "image") pendingImage = null;
    select(null);
    setHint(HINTS[m] || "");
    stage.style.cursor = m === "select" ? "default" : (m === "addtext" || m === "note" || m === "image") ? "copy" : "crosshair";
    rebuildProps();
  }

  /* ---------- toolbar ---------- */
  const modeBar = h("div", { class: "ed-modes" });
  const toolbar = h("div", { class: "ed-toolbar" }, modeBar);
  for (const [m, ic, tip] of MODES) {
    const b = h("button", { class: "ed-tool", title: tip, onclick: () => setMode(m) }, icon(ic), h("span", { class: "lbl" }, MODE_LABELS[m] || tip));
    modeBtns.set(m, b);
    modeBar.append(b);
  }
  const undoBtn = h("button", { class: "ed-tool", title: "Undo (Ctrl+Z)", onclick: () => undo() }, icon("undo"));
  const redoBtn = h("button", { class: "ed-tool", title: "Redo (Ctrl+Shift+Z)", onclick: () => redo() }, icon("redo"));
  toolbar.append(
    h("span", { class: "sep" }), undoBtn, redoBtn,
    h("span", { class: "spacer" }),
    h("div", { class: "ed-pageinfo" },
      h("button", { class: "ed-tool", title: "Previous page", onclick: () => goPage(cur - 1) }, icon("back")),
      pageInput, h("span", null, "/ " + pageCount),
      h("button", { class: "ed-tool", title: "Next page", style: "transform:rotate(180deg)", onclick: () => goPage(cur + 1) }, icon("back"))),
    h("span", { class: "sep" }),
    h("button", { class: "ed-tool", title: "Zoom out", onclick: () => setZoom(zoomVal / 1.2) }, icon("minus")),
    zoomLabel,
    h("button", { class: "ed-tool", title: "Zoom in", onclick: () => setZoom(zoomVal * 1.2) }, icon("plus")),
    h("button", { class: "btn secondary", style: "height:32px;padding:0 10px;font-size:12px", onclick: () => { zoomMode = "fit"; layout(); } }, "Fit"),
    h("span", { class: "sep" }),
    h("button", { class: "btn primary ed-apply", style: "height:34px", onclick: applyAll }, isMobile() ? "Done" : "Apply & download"));
  pageInput.addEventListener("change", () => goPage((parseInt(pageInput.value, 10) || 1) - 1));

  ctx.body.append(
    filePill(rec, pageCount + " pages · " + PDCore.fmtBytes(rec.size), ctx.restart),
    toolbar, propsRow, hint, stageWrap);

  /* ---------- undo / redo ---------- */
  function snapshot() { return { page: cur, ops: getOps(cur).map(o => ({ ...o })) }; }
  function pushUndo() { undoStack.push(snapshot()); if (undoStack.length > 60) undoStack.shift(); redoStack.length = 0; syncUndoBtns(); }
  function restore(s) { opsByPage.set(s.page, s.ops.map(o => ({ ...o }))); if (s.page !== cur) goPage(s.page); else renderObjects(); }
  function undo() { if (!undoStack.length) return; redoStack.push(snapshot()); restore(undoStack.pop()); syncUndoBtns(); }
  function redo() { if (!redoStack.length) return; undoStack.push(snapshot()); restore(redoStack.pop()); syncUndoBtns(); }
  function syncUndoBtns() { undoBtn.disabled = !undoStack.length; redoBtn.disabled = !redoStack.length; }
  syncUndoBtns();

  /* ---------- rendering ---------- */
  async function renderPage() {
    const page = await doc.getPage(cur + 1);
    const vp1 = page.getViewport({ scale: 1 });
    pageW = vp1.width; pageH = vp1.height;
    if (zoomMode === "fit") {
      const avail = stageWrap.clientWidth - 2 * parseFloat(getComputedStyle(stageWrap).paddingLeft || "24");
      zoomVal = Math.max(0.25, Math.min(3, avail / pageW));
    }
    const z = zoomVal;
    zoomLabel.textContent = zoomMode === "fit" ? "fit" : Math.round(z * 100) + "%";
    stage.style.width = pageW * z + "px";
    stage.style.height = pageH * z + "px";
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const vp = page.getViewport({ scale: z * dpr });
    canvas.width = Math.round(vp.width); canvas.height = Math.round(vp.height);
    const c2 = canvas.getContext("2d", { alpha: false });
    c2.fillStyle = "#fff"; c2.fillRect(0, 0, canvas.width, canvas.height);
    await page.render({ canvasContext: c2, viewport: vp }).promise;
    svg.setAttribute("viewBox", "0 0 " + pageW + " " + pageH);
    renderObjects();
    renderHitboxes();
  }
  function setZoom(v) { zoomMode = "manual"; zoomVal = Math.max(0.25, Math.min(3, v)); layout(); }
  function layout() { renderPage(); }
  function goPage(i) {
    i = Math.max(0, Math.min(pageCount - 1, i));
    if (i === cur) { pageInput.value = cur + 1; return; }
    cur = i; pageInput.value = i + 1; select(null);
    renderPage();
    if (mode === "edittext") ensureStext();
  }

  const FAMS = { sans: "Helvetica, Arial, sans-serif", serif: "Georgia, 'Times New Roman', serif", mono: "'Courier New', monospace" };
  function renderObjects() {
    const z = zoomVal;
    objLayer.innerHTML = "";
    while (svg.firstChild) svg.removeChild(svg.firstChild);
    uiLayer.innerHTML = "";
    for (const op of getOps(cur)) {
      if (["rect", "ellipse", "line"].includes(op.type)) { renderShape(op); continue; }
      let el = null;
      if (op.type === "whiteout") {
        el = h("div", { class: "ed-obj whiteout selectable" });
        if (op.color && op.color !== "#ffffff") el.style.background = op.color;
        box(el, op, z);
      } else if (op.type === "highlight") {
        el = h("div", { class: "ed-obj highlight selectable" });
        el.style.background = op.color; el.style.opacity = op.opacity;
        box(el, op, z);
      } else if (op.type === "redact") {
        el = h("div", { class: "ed-obj redactbox selectable" });
        box(el, op, z);
      } else if (op.type === "imgdelete") {
        el = h("div", { class: "ed-obj imgdel selectable" }, h("span", null, "image removed"));
        box(el, op, z);
      } else if (op.type === "image") {
        el = h("div", { class: "ed-obj selectable" });
        if (!op._url) op._url = URL.createObjectURL(new Blob([op.bytes]));
        el.append(h("img", { src: op._url }));
        box(el, op, z);
      } else if (op.type === "text" || op.type === "editline") {
        el = h("div", { class: "ed-obj textobj" });
        el.textContent = op.text;
        el.style.fontFamily = FAMS[op.family] || FAMS.sans;
        el.style.fontSize = op.size * z + "px";
        el.style.fontWeight = op.bold ? "700" : "400";
        el.style.fontStyle = op.italic ? "italic" : "normal";
        el.style.color = op.color || "#1a1a1a";
        el.style.left = op.x * z + "px";
        if (op.type === "editline") {
          const cover = h("div", { class: "ed-obj whiteout" });
          box(cover, op.orig, z);
          objLayer.append(cover);
          el.style.top = (op.baseline - op.size * 0.82) * z + "px";
          el.style.whiteSpace = "nowrap";
        } else {
          el.style.top = op.y * z + "px";
        }
      } else if (op.type === "note") {
        el = h("div", { class: "ed-obj ed-note-ico selectable", html: NOTE_SVG });
        el.style.left = op.x * z + "px"; el.style.top = op.y * z + "px";
        el.style.width = 22 * z + "px"; el.style.height = 22 * z + "px";
      }
      if (!el) continue;
      el.dataset.opid = op.id;
      if (op.id === selId) el.classList.add("sel");
      wireObject(el, op);
      objLayer.append(el);
    }
    renderHandles();
  }
  function box(el, o, z) {
    el.style.left = o.x * z + "px"; el.style.top = o.y * z + "px";
    el.style.width = Math.max(2, o.w * z) + "px"; el.style.height = Math.max(2, o.h * z) + "px";
  }
  function renderShape(op) {
    const NS = "http://www.w3.org/2000/svg";
    let s;
    if (op.type === "rect") {
      s = document.createElementNS(NS, "rect");
      s.setAttribute("x", op.x); s.setAttribute("y", op.y);
      s.setAttribute("width", op.w); s.setAttribute("height", op.h);
    } else if (op.type === "ellipse") {
      s = document.createElementNS(NS, "ellipse");
      s.setAttribute("cx", op.x + op.w / 2); s.setAttribute("cy", op.y + op.h / 2);
      s.setAttribute("rx", op.w / 2); s.setAttribute("ry", op.h / 2);
    } else {
      s = document.createElementNS(NS, "g");
      const ln = document.createElementNS(NS, "line");
      ln.setAttribute("x1", op.x1); ln.setAttribute("y1", op.y1);
      ln.setAttribute("x2", op.x2); ln.setAttribute("y2", op.y2);
      ln.setAttribute("stroke", op.stroke); ln.setAttribute("stroke-width", op.strokeW);
      ln.setAttribute("stroke-linecap", "round");
      s.append(ln);
      if (op.arrow) {
        const ang = Math.atan2(op.y2 - op.y1, op.x2 - op.x1);
        const len = Math.max(8, op.strokeW * 4);
        for (const da of [Math.PI * 5 / 6, -Math.PI * 5 / 6]) {
          const hd = document.createElementNS(NS, "line");
          hd.setAttribute("x1", op.x2); hd.setAttribute("y1", op.y2);
          hd.setAttribute("x2", op.x2 + len * Math.cos(ang + da));
          hd.setAttribute("y2", op.y2 + len * Math.sin(ang + da));
          hd.setAttribute("stroke", op.stroke); hd.setAttribute("stroke-width", op.strokeW);
          hd.setAttribute("stroke-linecap", "round");
          s.append(hd);
        }
      }
    }
    if (op.type !== "line") {
      s.setAttribute("stroke", op.stroke); s.setAttribute("stroke-width", op.strokeW);
      s.setAttribute("fill", op.fill || "none");
    }
    s.setAttribute("opacity", op.opacity != null ? op.opacity : 1);
    s.style.pointerEvents = "stroke";
    if (op.fill && op.type !== "line") s.style.pointerEvents = "auto";
    s.style.cursor = "move";
    s.dataset.opid = op.id;
    s.addEventListener("pointerdown", e => { if (mode === "select") { e.stopPropagation(); select(op.id); dragMove(e, op); } });
    if (op.id === selId) s.setAttribute("stroke-dasharray", "4 3");
    svg.append(s);
  }

  /* selection handles */
  function renderHandles() {
    const op = selOp();
    uiLayer.querySelectorAll(".ed-handle").forEach(e => e.remove());
    if (!op) return;
    const z = zoomVal;
    const mk = (cls, x, y, cb) => {
      const hd = h("div", { class: "ed-handle " + cls, style: "left:" + (x * z - 5) + "px;top:" + (y * z - 5) + "px;pointer-events:auto" });
      hd.addEventListener("pointerdown", e => { e.stopPropagation(); e.preventDefault(); cb(e); });
      uiLayer.append(hd);
    };
    if (["whiteout", "highlight", "redact", "image", "rect", "ellipse", "imgdelete"].includes(op.type)) {
      const corners = [["nw", 0, 0], ["ne", 1, 0], ["sw", 0, 1], ["se", 1, 1]];
      for (const [cls, fx, fy] of corners)
        mk(cls, op.x + fx * op.w, op.y + fy * op.h, e => dragResize(e, op, fx, fy));
    } else if (op.type === "line") {
      mk("se", op.x1, op.y1, e => dragPoint(e, op, "x1", "y1"));
      mk("se", op.x2, op.y2, e => dragPoint(e, op, "x2", "y2"));
    }
  }

  /* ---------- pointer plumbing ---------- */
  function stagePt(e) {
    const r = stage.getBoundingClientRect();
    return { x: (e.clientX - r.left) / zoomVal, y: (e.clientY - r.top) / zoomVal };
  }
  function trackDrag(onMove, onUp) {
    const mv = e => onMove(e);
    const up = e => { window.removeEventListener("pointermove", mv); window.removeEventListener("pointerup", up); onUp && onUp(e); };
    window.addEventListener("pointermove", mv);
    window.addEventListener("pointerup", up);
  }
  function dragMove(e0, op) {
    const start = stagePt(e0);
    const orig = { ...op };
    let moved = false;
    trackDrag(e => {
      const p = stagePt(e);
      const dx = p.x - start.x, dy = p.y - start.y;
      if (!moved && Math.hypot(dx, dy) > 2) { pushUndo(); moved = true; }
      if (!moved) return;
      if (op.type === "line") {
        op.x1 = orig.x1 + dx; op.y1 = orig.y1 + dy;
        op.x2 = orig.x2 + dx; op.y2 = orig.y2 + dy;
      } else if (op.type === "editline") {
        op.x = orig.x + dx; op.baseline = orig.baseline + dy;
      } else {
        op.x = orig.x + dx; op.y = orig.y + dy;
      }
      renderObjects();
    });
  }
  function dragResize(e0, op, fx, fy) {
    const orig = { ...op };
    const start = stagePt(e0);
    pushUndo();
    trackDrag(e => {
      const p = stagePt(e);
      const dx = p.x - start.x, dy = p.y - start.y;
      let x = orig.x, y = orig.y, w = orig.w, hh = orig.h;
      if (fx === 0) { x = orig.x + dx; w = orig.w - dx; } else w = orig.w + dx;
      if (fy === 0) { y = orig.y + dy; hh = orig.h - dy; } else hh = orig.h + dy;
      if (w < 6) w = 6; if (hh < 6) hh = 6;
      if (op.type === "image" && orig.w > 0) hh = w * orig.h / orig.w; // keep AR
      op.x = x; op.y = y; op.w = w; op.h = hh;
      renderObjects();
    });
  }
  function dragPoint(e0, op, kx, ky) {
    pushUndo();
    trackDrag(e => {
      const p = stagePt(e);
      op[kx] = p.x; op[ky] = p.y;
      renderObjects();
    });
  }
  function wireObject(el, op) {
    el.addEventListener("pointerdown", e => {
      if (window.PD_DEBUG && typeof UILOG !== "undefined") UILOG.push("objpd:" + mode + ":" + op.type + ":" + el.isConnected);
      if (mode !== "select" || el.isContentEditable) return;
      e.stopPropagation();
      select(op.id);
      dragMove(e, op);
    });
    if (op.type === "text" || op.type === "editline") {
      el.addEventListener("dblclick", e => { e.stopPropagation(); startTextEdit(op); });
    }
    if (op.type === "note") {
      el.addEventListener("dblclick", e => { e.stopPropagation(); openNotePopover(op); });
    }
  }
  function select(id) {
    selId = id;
    objLayer.querySelectorAll(".ed-obj").forEach(e => e.classList.toggle("sel", e.dataset.opid === id));
    renderObjects();
    rebuildProps();
  }

  /* stage-level interactions per mode */
  stage.addEventListener("pointerdown", e => {
    if (e.target.closest(".ed-handle") || e.target.closest(".ed-popover")) return;
    const p = stagePt(e);
    if (mode === "select") { select(null); return; }
    if (mode === "addtext") {
      e.preventDefault();
      pushUndo();
      const op = { id: uid(), type: "text", x: p.x, y: p.y - defaults.size * 0.6, size: defaults.size, color: defaults.color, family: defaults.family, bold: defaults.bold, italic: defaults.italic, text: "" };
      getOps(cur).push(op);
      renderObjects();
      window.addEventListener("pointerup", () => setTimeout(() => startTextEdit(op), 0), { once: true });
      return;
    }
    if (mode === "note") {
      pushUndo();
      const op = { id: uid(), type: "note", x: p.x - 11, y: p.y - 11, text: "" };
      getOps(cur).push(op);
      renderObjects();
      openNotePopover(op);
      setMode("select");
      return;
    }
    if (mode === "image") {
      if (!pendingImage) { imgInput.click(); return; }
      pushUndo();
      const w = Math.min(pageW * 0.4, pendingImage.w * 0.75);
      const hh = w * pendingImage.h / pendingImage.w;
      const op = { id: uid(), type: "image", x: p.x - w / 2, y: p.y - hh / 2, w, h: hh, bytes: pendingImage.bytes, isPng: pendingImage.isPng };
      getOps(cur).push(op);
      pendingImage = null;
      setMode("select");
      select(op.id);
      return;
    }
    if (["whiteout", "highlight", "redact", "rect", "ellipse", "line"].includes(mode)) {
      e.preventDefault();
      rubberDraw(p);
    }
  });

  function rubberDraw(start) {
    const z = zoomVal;
    const band = h("div", { class: "ed-rubber" });
    uiLayer.append(band);
    let cend = start;
    trackDrag(e => {
      cend = stagePt(e);
      const x = Math.min(start.x, cend.x), y = Math.min(start.y, cend.y);
      const w = Math.abs(cend.x - start.x), hh = Math.abs(cend.y - start.y);
      if (mode === "line") {
        band.style.left = Math.min(start.x, cend.x) * z + "px";
        band.style.top = Math.min(start.y, cend.y) * z + "px";
        band.style.width = w * z + "px"; band.style.height = hh * z + "px";
        band.style.borderStyle = "solid"; band.style.background = "none";
      } else {
        band.style.left = x * z + "px"; band.style.top = y * z + "px";
        band.style.width = w * z + "px"; band.style.height = hh * z + "px";
      }
    }, () => {
      band.remove();
      const x = Math.min(start.x, cend.x), y = Math.min(start.y, cend.y);
      const w = Math.abs(cend.x - start.x), hh = Math.abs(cend.y - start.y);
      if (mode === "line") {
        if (Math.hypot(cend.x - start.x, cend.y - start.y) < 6) return;
        pushUndo();
        getOps(cur).push({ id: uid(), type: "line", x1: start.x, y1: start.y, x2: cend.x, y2: cend.y, stroke: defaults.stroke, strokeW: defaults.strokeW, opacity: defaults.opacity, arrow: defaults.arrow });
      } else {
        if (w < 5 || hh < 4) return;
        pushUndo();
        if (mode === "whiteout") getOps(cur).push({ id: uid(), type: "whiteout", x, y, w, h: hh, color: "#ffffff" });
        else if (mode === "redact") getOps(cur).push({ id: uid(), type: "redact", x, y, w, h: hh });
        else if (mode === "highlight") getOps(cur).push({ id: uid(), type: "highlight", x, y, w, h: hh, color: defaults.hlColor, opacity: defaults.hlOpacity });
        else getOps(cur).push({ id: uid(), type: mode, x, y, w, h: hh, stroke: defaults.stroke, strokeW: defaults.strokeW, fill: defaults.fill, opacity: defaults.opacity });
      }
      renderObjects();
    });
  }

  /* ---------- inline text editing ----------
     Text is captured on EVERY input event, never only at blur: blur can be
     swallowed by focus quirks (iframes, clicking straight onto a toolbar),
     which used to lose the typed text entirely. */
  function startTextEdit(op) {
    renderObjects();
    const el = objLayer.querySelector('[data-opid="' + op.id + '"]');
    if (!el) return;
    const before = op.text;
    pushUndo();
    try { el.contentEditable = "plaintext-only"; } catch (err) { el.contentEditable = "true"; }
    if (!el.isContentEditable) el.contentEditable = "true";
    el.focus();
    try { const s = window.getSelection(); s.selectAllChildren(el); } catch (err) {}
    const read = () => (op.type === "editline" ? el.textContent.replace(/\n/g, " ") : el.innerText).replace(/\u00a0/g, " ");
    const onInput = () => { op.text = read(); };
    let done = false;
    const finish = restore => {
      if (done) return;
      done = true;
      el.removeEventListener("input", onInput);
      el.removeEventListener("blur", onBlur);
      el.contentEditable = "false";
      op.text = restore ? before : read();
      if (op.type === "text" && !String(op.text).trim()) {
        opsByPage.set(cur, getOps(cur).filter(o => o.id !== op.id));
        if (selId === op.id) selId = null;
      }
      if (op.type === "editline" && !String(op.text).trim()) op.text = " ";
      renderObjects();
      rebuildProps();
    };
    const onBlur = () => finish(false);
    el.addEventListener("input", onInput);
    el.addEventListener("blur", onBlur);
    el.addEventListener("keydown", e => {
      e.stopPropagation();
      if (e.key === "Escape") finish(true);
      if (e.key === "Enter" && op.type === "editline") { e.preventDefault(); finish(false); }
    });
  }

  /* ---------- note popover ---------- */
  function openNotePopover(op) {
    document.querySelectorAll(".ed-popover").forEach(e => e.remove());
    const z = zoomVal;
    const ta = h("textarea", { placeholder: "Write your comment" });
    ta.value = op.text || "";
    const pop = h("div", { class: "ed-popover" }, ta,
      h("div", { class: "row" },
        h("button", { class: "btn secondary", style: "height:28px;padding:0 10px;font-size:12px", onclick: () => { pop.remove(); if (!op.text) removeOp(op.id); } }, "Cancel"),
        h("button", { class: "btn primary", style: "height:28px;padding:0 10px;font-size:12px", onclick: () => { pushUndo(); op.text = ta.value; pop.remove(); if (!op.text.trim()) removeOp(op.id); } }, "Save")));
    pop.style.left = Math.min(op.x * z + 26 * z, stage.clientWidth - 240) + "px";
    pop.style.top = Math.max(4, op.y * z - 10) + "px";
    stage.append(pop);
    setTimeout(() => ta.focus(), 30);
  }
  function removeOp(id) {
    opsByPage.set(cur, getOps(cur).filter(o => o.id !== id));
    if (selId === id) selId = null;
    renderObjects();
    rebuildProps();
  }

  /* ---------- structured text (edit-text mode) ---------- */
  async function ensureStext() {
    if (stextCache.has(cur)) { renderHitboxes(); return; }
    setHint("Reading page text structure…");
    try {
      const mupdf = await loadMuPDF();
      if (!mupdfDoc) mupdfDoc = mupdfOpen(mupdf, bytesOf(rec));
      const page = mupdfDoc.loadPage(cur);
      const json = JSON.parse(page.toStructuredText("preserve-images").asJSON());
      stextCache.set(cur, PDCore.parseStext(json));
      setHint(HINTS.edittext);
    } catch (e) {
      stextCache.set(cur, { lines: [], images: [] });
      setHint("Couldn't read text structure on this page. You can still use whiteout + add text.");
    }
    renderHitboxes();
  }
  function renderHitboxes() {
    hitLayer.innerHTML = "";
    if (mode !== "edittext" || !stextCache.has(cur)) return;
    const z = zoomVal;
    const { lines, images } = stextCache.get(cur);
    for (const ln of lines) {
      const hb = h("div", { class: "ed-hit", title: "Click to retype this line" });
      hb.style.left = ln.x * z + "px"; hb.style.top = ln.y * z + "px";
      hb.style.width = ln.w * z + "px"; hb.style.height = ln.h * z + "px";
      hb.addEventListener("click", () => {
        const existing = getOps(cur).find(o => o.type === "editline" && o.orig && o.orig.x === ln.x && o.orig.y === ln.y);
        if (existing) { setMode("select"); select(existing.id); startTextEdit(existing); return; }
        pushUndo();
        const op = { id: uid(), type: "editline", x: ln.x, baseline: ln.baseline, size: ln.size,
          color: "#1a1a1a", family: ln.family, bold: ln.bold, italic: ln.italic,
          text: ln.text, orig: { x: ln.x, y: ln.y, w: ln.w, h: ln.h } };
        getOps(cur).push(op);
        setMode("select");
        select(op.id);
        startTextEdit(op);
      });
      hitLayer.append(hb);
    }
    for (const im of images) {
      const hb = h("div", { class: "ed-hit imghit", title: "Click to remove this image" });
      hb.style.left = im.x * z + "px"; hb.style.top = im.y * z + "px";
      hb.style.width = im.w * z + "px"; hb.style.height = im.h * z + "px";
      hb.addEventListener("click", () => {
        pushUndo();
        getOps(cur).push({ id: uid(), type: "imgdelete", x: im.x, y: im.y, w: im.w, h: im.h });
        setMode("select");
        renderObjects();
        toast("Image marked for removal. Use Insert image to place a replacement.");
      });
      hitLayer.append(hb);
    }
  }

  /* ---------- properties row ---------- */
  function rebuildProps() {
    propsRow.innerHTML = "";
    const op = selOp();
    const kind = op ? op.type : mode;
    const apply = fn => { if (op) { pushUndo(); fn(op); renderObjects(); rebuildProps(); } };
    const addSw = (colors, cval, cb) => {
      const sw = swatches(colors, cval, v => cb(v));
      propsRow.append(sw.el);
      return sw;
    };
    if (["text", "editline", "addtext"].includes(kind)) {
      const size = h("input", { class: "num", type: "number", min: 6, max: 96, value: op ? op.size : defaults.size });
      size.addEventListener("change", () => { const v = Math.max(6, Math.min(96, +size.value || 14)); op ? apply(o => o.size = v) : (defaults.size = v); });
      const fam = h("select", null,
        h("option", { value: "sans" }, "Sans"), h("option", { value: "serif" }, "Serif"), h("option", { value: "mono" }, "Mono"));
      fam.value = op ? op.family : defaults.family;
      fam.addEventListener("change", () => op ? apply(o => o.family = fam.value) : (defaults.family = fam.value));
      const bB = h("button", { class: "bi" + ((op ? op.bold : defaults.bold) ? " on" : ""), style: "font-weight:700", onclick: () => op ? apply(o => o.bold = !o.bold) : (defaults.bold = !defaults.bold, rebuildProps()) }, "B");
      const bI = h("button", { class: "bi" + ((op ? op.italic : defaults.italic) ? " on" : ""), style: "font-style:italic", onclick: () => op ? apply(o => o.italic = !o.italic) : (defaults.italic = !defaults.italic, rebuildProps()) }, "I");
      propsRow.append(h("span", null, "Size"), size, fam, bB, bI);
      addSw(["#1a1a1a", "#c0392b", "#2c4a6e", "#3d7a4f"], op ? op.color : defaults.color, v => op ? apply(o => o.color = v) : (defaults.color = v));
    } else if (["rect", "ellipse", "line"].includes(kind)) {
      addSw(["#c0392b", "#2c4a6e", "#3d7a4f", "#1a1a1a"], op ? op.stroke : defaults.stroke, v => op ? apply(o => o.stroke = v) : (defaults.stroke = v));
      const wsel = h("select", null, [1, 2, 3, 5].map(v => h("option", { value: v }, v + " pt")));
      wsel.value = op ? op.strokeW : defaults.strokeW;
      wsel.addEventListener("change", () => op ? apply(o => o.strokeW = +wsel.value) : (defaults.strokeW = +wsel.value));
      propsRow.append(h("span", null, "Stroke"), wsel);
      if (kind === "line") {
        const ac = checkbox("Arrowhead", op ? op.arrow : defaults.arrow, v => op ? apply(o => o.arrow = v) : (defaults.arrow = v));
        propsRow.append(ac.el);
      } else {
        const fc = checkbox("Fill", !!(op ? op.fill : defaults.fill), v => {
          const val = v ? "#f6e3c0" : null;
          op ? apply(o => o.fill = val) : (defaults.fill = val);
        });
        propsRow.append(fc.el);
      }
    } else if (kind === "highlight") {
      addSw(["#ffe066", "#a6f2b0", "#ffb3d9", "#a7d8ff"], op ? op.color : defaults.hlColor, v => op ? apply(o => o.color = v) : (defaults.hlColor = v));
    } else if (kind === "note" && op) {
      propsRow.append(h("button", { class: "btn secondary", style: "height:28px;padding:0 10px;font-size:12px", onclick: () => openNotePopover(op) }, "Edit comment"));
    }
    if (op) {
      propsRow.append(
        h("span", { style: "flex:0 0 6px" }),
        h("button", { class: "btn secondary", style: "height:28px;padding:0 10px;font-size:12px;color:var(--err)", onclick: () => { pushUndo(); removeOp(op.id); } }, "Delete"));
    }
  }

  /* ---------- keyboard ---------- */
  const keyHandler = e => {
    if (!currentView || currentView.id !== "edit") return;
    const editing = document.activeElement && (document.activeElement.isContentEditable || /INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName));
    if ((e.key === "Delete" || e.key === "Backspace") && selId && !editing) { e.preventDefault(); pushUndo(); removeOp(selId); }
    if (e.key === "Escape" && !editing) { select(null); setMode("select"); }
    if ((e.ctrlKey || e.metaKey) && !editing) {
      if (e.key.toLowerCase() === "z" && !e.shiftKey) { e.preventDefault(); undo(); }
      else if ((e.key.toLowerCase() === "z" && e.shiftKey) || e.key.toLowerCase() === "y") { e.preventDefault(); redo(); }
    }
  };
  document.addEventListener("keydown", keyHandler);

  let resizeT;
  const onResize = () => { if (zoomMode === "fit") { clearTimeout(resizeT); resizeT = setTimeout(layout, 200); } };
  window.addEventListener("resize", onResize);

  ctx.setCleanup(() => {
    destroyed = true;
    document.removeEventListener("keydown", keyHandler);
    window.removeEventListener("resize", onResize);
    closePdf(doc);
    try { if (mupdfDoc) mupdfDoc.destroy(); } catch (e) {}
    for (const ops of opsByPage.values()) for (const o of ops) if (o._url) { try { URL.revokeObjectURL(o._url); } catch (e) {} }
  });

  /* ---------- apply ---------- */
  function applyAll() {
    const pageOps = [];
    const regions = [];
    let total = 0;
    for (const [idx, ops] of opsByPage) {
      if (!ops.length) continue;
      total += ops.length;
      pageOps.push({ pageIdx: idx, ops });
      const textRects = ops.filter(o => o.type === "editline" && o.orig).map(o => o.orig);
      const imgRects = ops.filter(o => o.type === "imgdelete").map(o => ({ x: o.x, y: o.y, w: o.w, h: o.h }));
      const blackRects = ops.filter(o => o.type === "redact").map(o => ({ x: o.x, y: o.y, w: o.w, h: o.h }));
      if (textRects.length) regions.push({ pageIdx: idx, rects: textRects, mode: "text" });
      if (imgRects.length) regions.push({ pageIdx: idx, rects: imgRects, mode: "image" });
      if (blackRects.length) regions.push({ pageIdx: idx, rects: blackRects, mode: "black" });
    }
    if (!total) { toast("Nothing to apply yet. Make some edits first."); return; }
    runJob(ctx, "Applying edits", async prog => {
      let bytes = bytesOf(rec);
      if (regions.length) {
        prog.set(0.1, "Loading edit engine (one-time)");
        const mupdf = await loadMuPDF();
        prog.set(0.35, "Removing original text and images");
        bytes = PDCore.redactRegions(mupdf, bytes, regions);
      }
      prog.set(0.65, "Drawing " + total + " edit" + (total === 1 ? "" : "s"));
      const res = await PDCore.applyOverlay(bytes, pageOps);
      return res;
    }, res => {
      if (res.problems.length) toast(res.problems.length + " item(s) skipped: " + res.problems[0], "err", 6000);
      return {
        files: [{ name: PDCore.baseName(rec.name) + "-edited.pdf", bytes: res.bytes, mime: "application/pdf" }],
        opts: {
          title: "Edits applied",
          meta: res.problems.length ? res.problems.length + " item(s) skipped (non-Latin text needs Phase 2 fonts — see message)" : total + " edit" + (total === 1 ? "" : "s") + " burned into the PDF",
        },
      };
    });
  }

  setMode("select");
  await renderPage();
}
