/* AtoB PDF v3.4 — Kindle-style reader.
   Two modes over one text model (MuPDF structured text, pdf.js fallback, OCR
   for scans / legacy fonts): the original page, or reflowed text laid out in
   CSS columns. Positions, bookmarks, highlights and notes are anchored to
   {page, char offset} in that model, so they survive mode and font changes. */
"use strict";

Object.assign(ICONS, {
  book: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 5.5A1.5 1.5 0 0 1 5.5 4H11v15H5.5A1.5 1.5 0 0 0 4 20.5z"/><path d="M20 5.5A1.5 1.5 0 0 0 18.5 4H13v15h5.5a1.5 1.5 0 0 1 1.5 1.5z"/></svg>',
  toc: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M9 6h11M9 12h11M9 18h11"/><circle cx="4.5" cy="6" r="1.1" fill="currentColor"/><circle cx="4.5" cy="12" r="1.1" fill="currentColor"/><circle cx="4.5" cy="18" r="1.1" fill="currentColor"/></svg>',
  aa: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M3 18 8 6l5 12M4.8 14h6.4"/><path d="M14.5 18l3.2-8 3.3 8M15.6 15.3h4.3"/></svg>',
  bookmark: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"><path d="M6.5 3.5h11v17l-5.5-4-5.5 4z"/></svg>',
  bookmarkfill: '<svg viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"><path d="M6.5 3.5h11v17l-5.5-4-5.5 4z"/></svg>',
  note: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M5 4h14v11l-5 5H5z"/><path d="M14 20v-5h5M8.5 9h7M8.5 12.5h4"/></svg>',
  copy: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"><rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5.5A1.5 1.5 0 0 0 14.5 4h-9A1.5 1.5 0 0 0 4 5.5v9A1.5 1.5 0 0 0 5.5 16H8"/></svg>',
});

const KR_PREFS_KEY = "atob.reader.prefs";
const KR_DEFAULTS = { mode: "page", theme: "white", font: "serif", size: 19, line: 1.6, margin: "md", justify: true, bright: 1, anim: "slide", twoPage: "auto" };
const KR_THEMES = { white: "White", sepia: "Sepia", dark: "Dark", black: "Black" };
const KR_FONTS = {
  serif: { label: "Serif", css: 'Charter, "Iowan Old Style", Georgia, Cambria, "Noto Serif", "Times New Roman", serif' },
  sans: { label: "Sans", css: '-apple-system, "Segoe UI Variable Text", "Segoe UI", Roboto, "Noto Sans", Helvetica, Arial, sans-serif' },
  humanist: { label: "Humanist", css: 'Optima, Candara, "Gill Sans", "Trebuchet MS", "Noto Sans", sans-serif' },
  mono: { label: "Mono", css: 'ui-monospace, "SF Mono", Menlo, Consolas, "Noto Sans Mono", monospace' },
};
/* system fonts that cover Arabic, Urdu, Hindi, Malayalam and Tamil on Windows,
   macOS/iOS and Android — appended after the chosen family so every script has
   a shaped fallback without bundling fonts */
const KR_SCRIPT_FALLBACK = '"Noto Naskh Arabic", "Geeza Pro", "Segoe UI", Tahoma, "Noto Sans Devanagari", "Kohinoor Devanagari", Mangal, ' +
  '"Noto Sans Malayalam", "Malayalam Sangam MN", Kartika, Manjari, "Noto Sans Tamil", "Tamil Sangam MN", Latha, "Nirmala UI", sans-serif';
const KR_HL = { y: { label: "Yellow", c: "#f5d547" }, g: { label: "Green", c: "#7ed08b" }, b: { label: "Blue", c: "#7fb6f0" }, p: { label: "Pink", c: "#f29bc0" } };

/* ---- per-file store (IndexedDB) ---- */
function readerDB() {
  return new Promise((resolve, reject) => {
    if (!window.indexedDB) return reject(new Error("no idb"));
    const req = indexedDB.open("atobpdf-reader", 1);
    req.onupgradeneeded = () => { req.result.createObjectStore("books", { keyPath: "hash" }); };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}
async function bookGet(hash) {
  try {
    const db = await readerDB();
    return await new Promise(res => { const r = db.transaction("books").objectStore("books").get(hash); r.onsuccess = () => res(r.result || null); r.onerror = () => res(null); });
  } catch (e) { return null; }
}
async function bookPut(rec) {
  try { const db = await readerDB(); const tx = db.transaction("books", "readwrite"); tx.objectStore("books").put(rec); await idbDone(tx); } catch (e) {}
}

function krId() { return Date.now().toString(36) + Math.random().toString(36).slice(2, 6); }

/* fold for search: lower-case, strip Arabic harakat & tatweel; keeps an index map */
function foldForSearch(s) {
  let out = "";
  const map = [];
  for (let i = 0; i < s.length; i++) {
    const c = s[i];
    if (/[ً-ٰٟـۖ-ۭ]/.test(c)) continue;
    const l = c.toLowerCase();
    for (let k = 0; k < l.length; k++) { out += l[k]; map.push(i); }
  }
  map.push(s.length);
  return { s: out, map };
}

registerTool({
  id: "read", name: "Reader", icon: "book",
  desc: "Kindle-style reading, reflow & read aloud",
  hint: "Themes, fonts, bookmarks, highlights, audio",
  build(ctx) {
    singlePdfTool(ctx, { needProbe: false, big: "Drop a PDF to read" }, async rec => {
      let doc;
      try { doc = await openPdf(rec); } catch (e) { errorBack(ctx.body, new Error("Could not open this PDF."), ctx.restart); return; }
      const n = doc.numPages;
      const hash = PDCore.hashBytes(bytesOf(rec));
      const prefs = Object.assign({}, KR_DEFAULTS, lsGet(KR_PREFS_KEY, {}));
      const savePrefs = () => lsSet(KR_PREFS_KEY, prefs);
      let book = (await bookGet(hash)) || { hash, name: rec.name, pages: n, pos: null, bookmarks: [], highlights: [], ocr: {} };
      book.name = rec.name; book.pages = n;
      if (!book.ocr) book.ocr = {};
      const persist = debounce(() => { book.updated = Date.now(); bookPut(book); }, 400);
      let dead = false;

      /* ================= text models ================= */
      const models = new Map();
      let mdoc = null, source = "pdfjs";
      const mupdfReady = (async () => {
        if (!(ASSETS().mupdfWasm)) return;
        try {
          const mupdf = await loadMuPDF();
          const d = mupdf.Document.openDocument(bytesOf(rec), "application/pdf");
          if (d.needsPassword && d.needsPassword()) return;
          if (d.countPages() !== n) return;
          mdoc = d; source = "mupdf";
        } catch (e) { /* pdf.js fallback */ }
      })();
      async function getModel(i) {
        if (models.has(i)) return models.get(i);
        await mupdfReady;
        if (dead) return finishModel(Object.assign(PDCore.buildPageText([]), { w: 595, h: 842, source: "none" }));
        let m = null;
        const saved = book.ocr[i];
        if (saved && saved.runs) {
          m = finishModel(Object.assign(PDCore.buildPageText(saved.runs, { fixOrder: false, ocr: true }), { w: saved.w, h: saved.h, source: "ocr", ocrLangs: saved.langs }));
        } else if (mdoc) {
          try { m = mupdfPageModel(mdoc, i); } catch (e) { m = null; }
        }
        if (!m) { try { m = await pdfjsPageModel(doc, i); } catch (e) { m = finishModel(Object.assign(PDCore.buildPageText([]), { w: 595, h: 842, source: "none" })); } }
        models.set(i, m);
        return m;
      }
      let ocrLangs = null, ocrDeclined = false;
      async function ocrPage(i, askReason, hint) {
        if (!ocrLangs) {
          if (ocrDeclined) return null;
          ocrLangs = await offerOcr(askReason || "scan", hint);
          if (!ocrLangs) { ocrDeclined = true; return null; }
        }
        try {
          const om = await ocrPageModel(doc, i, ocrLangs);
          models.set(i, om);
          book.ocr[i] = { langs: ocrLangs, w: om.w, h: om.h, runs: (om.srcRuns || []).map(r => ({ str: r.str, x: +r.x.toFixed(1), y: +r.y.toFixed(1), w: +r.w.toFixed(1), h: +r.h.toFixed(1), eol: r.eol })) };
          persist();
          if (mode === "reflow") rerenderReflowPage(i);
          else if (spreadPages().includes(i)) renderSpread(false);
          return om;
        } catch (e) { toast("OCR failed: " + (e && e.message || e), "err"); return null; }
      }
      /* ================= DOM ================= */
      const root = h("div", { class: "kr", "data-theme": prefs.theme, tabindex: "-1" });
      const stage = h("div", { class: "kr-stage" });
      const dim = h("div", { class: "kr-dim" });
      const titleEl = h("div", { class: "kr-title" }, rec.name.replace(/\.pdf$/i, ""));
      const bmBtn = h("button", { class: "iconbtn kr-bm", title: "Bookmark this page", "aria-label": "Bookmark" }, icon("bookmark"));
      const listenBtn = h("button", { class: "iconbtn", title: "Read aloud", "aria-label": "Read aloud" }, icon("headphones"));
      const top = h("div", { class: "kr-top" },
        h("button", { class: "iconbtn", title: "Close reader", "aria-label": "Close reader", onclick: () => showView(isMobile() ? "home" : "view") }, icon("back")),
        titleEl,
        h("span", { class: "grow" }),
        h("button", { class: "iconbtn", title: "Contents, bookmarks & notes", "aria-label": "Contents", onclick: () => openNav("toc") }, icon("toc")),
        h("button", { class: "iconbtn", title: "Search (Ctrl+F)", "aria-label": "Search", onclick: () => openSearch() }, icon("search")),
        h("button", { class: "iconbtn", title: "Reading settings", "aria-label": "Reading settings", onclick: () => openSettings() }, icon("aa")),
        bmBtn, listenBtn);
      const progTxt = h("div", { class: "kr-prog" });
      const scrub = h("input", { type: "range", min: 1, max: n, step: 1, value: 1, "aria-label": "Go to page" });
      const pageLbl = h("button", { class: "kr-pagelbl", title: "Go to page", onclick: () => gotoPrompt() });
      const modeSeg = segmented([{ v: "page", label: "Page" }, { v: "reflow", label: "Reflow" }], prefs.mode, v => setMode(v));
      const bottom = h("div", { class: "kr-bottom" },
        h("div", { class: "kr-brow" }, pageLbl, scrub, modeSeg.el),
        progTxt);
      const ribbon = h("div", { class: "kr-ribbon hidden" }, icon("bookmarkfill"));
      const loading = h("div", { class: "kr-loading hidden" }, h("div", { class: "kr-spin" }), h("div", { class: "kr-load-t" }, "Preparing text…"), h("div", { class: "kr-load-bar" }, h("i")));
      const banner = h("div", { class: "kr-banner hidden" });
      root.append(stage, ribbon, top, bottom, banner, loading, dim);
      document.body.append(root);
      document.body.classList.add("kr-open");
      ctx.body.append(h("div", { class: "kr-placeholder muted" }, "Reading " + rec.name));
      const setLoading = (on, text, frac) => {
        loading.classList.toggle("hidden", !on);
        if (text) loading.querySelector(".kr-load-t").textContent = text;
        loading.querySelector(".kr-load-bar i").style.width = Math.round((frac || 0) * 100) + "%";
      };

      /* ================= state ================= */
      let mode = prefs.mode === "reflow" ? "reflow" : "page";
      let loc = { page: 0, off: 0 };               // anchor
      let chrome = true;
      let dir = "ltr";                              // page-turn direction (rtl for Arabic/Urdu books)
      const stageSize = () => { const r = stage.getBoundingClientRect(); return { w: Math.max(200, r.width), h: Math.max(200, r.height) }; };
      const twoUp = () => {
        if (prefs.twoPage === "off") return false;
        const s = stageSize();
        return s.w > s.h * 1.15 && s.w >= 760;
      };
      function applyLook() {
        root.dataset.theme = prefs.theme;
        root.style.setProperty("--kr-font", KR_FONTS[prefs.font] ? KR_FONTS[prefs.font].css : KR_FONTS.serif.css);
        root.style.setProperty("--kr-fallback", KR_SCRIPT_FALLBACK);
        root.style.setProperty("--kr-size", prefs.size + "px");
        root.style.setProperty("--kr-line", prefs.line);
        root.style.setProperty("--kr-margin", { sm: "4%", md: "8%", lg: "13%" }[prefs.margin] || "8%");
        root.classList.toggle("justify", !!prefs.justify);
        root.dataset.anim = prefs.anim;
        dim.style.opacity = String(Math.max(0, Math.min(0.8, (1 - prefs.bright) * 0.9)));
      }
      applyLook();
      function setChrome(on) { chrome = on; root.classList.toggle("chrome-off", !on); if (!on) closePanels(); }

      /* ================= PAGE MODE ================= */
      const pageCache = new Map();   // page -> {canvas, scale}
      let spreadEl = null;
      function spreadPages(p) {
        p = p == null ? loc.page : p;
        if (!twoUp()) return [p];
        const a = p - (p % 2);
        return a + 1 < n ? [a, a + 1] : [a];
      }
      async function renderPageEl(i, fitW, fitH) {
        const page = await doc.getPage(i + 1);
        const vp1 = page.getViewport({ scale: 1 });
        const s = Math.min(fitW / vp1.width, fitH / vp1.height);
        const dpr = Math.min(window.devicePixelRatio || 1, 2);
        const key = i + "@" + s.toFixed(3);
        let canvas = pageCache.get(key);
        if (!canvas) {
          const vp = page.getViewport({ scale: s * dpr });
          canvas = document.createElement("canvas");
          canvas.width = Math.round(vp.width); canvas.height = Math.round(vp.height);
          const c2 = canvas.getContext("2d", { alpha: false });
          c2.fillStyle = "#fff"; c2.fillRect(0, 0, canvas.width, canvas.height);
          await page.render({ canvasContext: c2, viewport: vp }).promise;
          pageCache.set(key, canvas);
          if (pageCache.size > 6) pageCache.delete(pageCache.keys().next().value);
        }
        const w = vp1.width * s, hh = vp1.height * s;
        const el = h("div", { class: "kr-pg", "data-pg": i, style: "width:" + w + "px;height:" + hh + "px" });
        // the cached canvas stays offscreen; the DOM gets a copy (a canvas can only live in one place)
        const shown = document.createElement("canvas");
        shown.width = canvas.width; shown.height = canvas.height;
        shown.getContext("2d").drawImage(canvas, 0, 0);
        shown.style.width = w + "px"; shown.style.height = hh + "px";
        const hl = h("div", { class: "kr-hl" }), ttsL = h("div", { class: "tts-layer" }), tl = h("div", { class: "kr-tl" });
        el.append(shown, hl, ttsL, tl);
        el._scale = s;
        const m = await getModel(i);
        el._model = m;
        buildTextLayer(tl, m, i, s);
        drawPageHighlights(el);
        return el;
      }
      const measureCtx = document.createElement("canvas").getContext("2d");
      function buildTextLayer(tl, m, i, s) {
        tl.innerHTML = "";
        for (const r of m.runs) {
          const str = m.text.slice(r.start, r.end);
          if (!str) continue;
          const fs = Math.max(4, r.h * s * 0.88);
          measureCtx.font = fs + "px sans-serif";
          const natural = measureCtx.measureText(str).width || 1;
          const sp = h("span", { "data-pg": i, "data-o": r.start, dir: r.rtl ? "rtl" : "ltr",
            style: "left:" + (r.x * s) + "px;top:" + (r.y * s) + "px;font-size:" + fs + "px;transform:scaleX(" + Math.max(0.2, Math.min(4, (r.w * s) / natural)) + ")" }, str);
          tl.append(sp);
        }
      }
      function drawPageHighlights(el) {
        const hl = el.querySelector(".kr-hl");
        const i = +el.dataset.pg, s = el._scale, m = el._model;
        if (!hl || !m) return;
        hl.innerHTML = "";
        for (const x of book.highlights) {
          if (x.page !== i) continue;
          for (const b of PDCore.boxesForRange(m, x.start, x.end))
            hl.append(h("div", { class: "kr-hlbox c-" + x.color + (x.note ? " has-note" : ""), "data-id": x.id,
              style: "left:" + (b.x * s) + "px;top:" + (b.y * s) + "px;width:" + (b.w * s) + "px;height:" + (b.h * s) + "px" }));
        }
        if (findHit && findHit.page === i)
          for (const b of PDCore.boxesForRange(m, findHit.start, findHit.end))
            hl.append(h("div", { class: "kr-hlbox find", style: "left:" + (b.x * s) + "px;top:" + (b.y * s) + "px;width:" + (b.w * s) + "px;height:" + (b.h * s) + "px" }));
      }
      let renderSeq = 0;
      async function buildSpread(p) {
        const pages = spreadPages(p);
        const sz = stageSize();
        const padX = isMobile() ? 8 : 28, padY = isMobile() ? 10 : 22;
        const fitW = (sz.w - padX * 2 - (pages.length - 1) * 4) / pages.length, fitH = sz.h - padY * 2;
        const els = [];
        for (const i of pages) els.push(await renderPageEl(i, fitW, fitH));
        if (dir === "rtl") els.reverse();
        const sp = h("div", { class: "kr-spread" + (pages.length > 1 ? " two" : "") }, els);
        sp._pages = pages;
        return sp;
      }
      async function renderSpread(animateDir) {
        try { await renderSpreadInner(animateDir); }
        catch (e) { if (!dead) toast("Could not show page " + (loc.page + 1) + ": " + (e && e.message || e), "err"); }
      }
      async function renderSpreadInner(animateDir) {
        const seq = ++renderSeq;
        const sp = await buildSpread(loc.page);
        if (seq !== renderSeq || dead || mode !== "page") return;
        const old = spreadEl;
        spreadEl = sp;
        stage.append(sp);
        if (old && animateDir && prefs.anim !== "none" && !window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
          await animateTurn(old, sp, animateDir);
        }
        if (old && old.parentNode) old.remove();
        stage.querySelectorAll(".kr-spread").forEach(e => { if (e !== spreadEl) e.remove(); });
        afterMove();
        redrawTts();
      }
      /* dir: +1 forward, -1 back (visual direction flips for RTL books) */
      function animateTurn(oldEl, newEl, d) {
        const vis = dir === "rtl" ? -d : d;
        return new Promise(resolve => {
          const dur = 300;
          if (prefs.anim === "curl") {
            newEl.style.zIndex = "1"; oldEl.style.zIndex = "2";
            oldEl.classList.add("curl");
            oldEl.style.transformOrigin = vis > 0 ? "left center" : "right center";
            const shade = h("div", { class: "kr-curlshade" + (vis > 0 ? "" : " rev") });
            oldEl.append(shade);
            oldEl.animate([{ transform: "perspective(1800px) rotateY(0deg)" }, { transform: "perspective(1800px) rotateY(" + (vis > 0 ? -105 : 105) + "deg)" }],
              { duration: dur + 120, easing: "cubic-bezier(0.4,0.1,0.3,1)" }).finished.then(resolve, resolve);
            shade.animate([{ opacity: 0 }, { opacity: 1 }], { duration: dur + 120 });
          } else {
            const w = stage.getBoundingClientRect().width;
            oldEl.animate([{ transform: "translateX(0)" }, { transform: "translateX(" + (-vis * w) + "px)" }], { duration: dur, easing: "cubic-bezier(0.22,1,0.36,1)" });
            newEl.animate([{ transform: "translateX(" + (vis * w) + "px)" }, { transform: "translateX(0)" }], { duration: dur, easing: "cubic-bezier(0.22,1,0.36,1)" }).finished.then(resolve, resolve);
          }
        });
      }

      /* ================= REFLOW MODE ================= */
      const flow = h("div", { class: "kr-flow" });
      const cols = h("div", { class: "kr-cols" });
      flow.append(cols);
      let flowBuilt = false, flowScreen = 0, flowScreens = 1, flowStep = 1;
      const pageSpans = new Map();   // page -> [span...] (segments in order)
      let allSpans = [];
      async function extractAll(label) {
        const need = [];
        for (let i = 0; i < n; i++) if (!models.has(i)) need.push(i);
        if (!need.length) return true;
        setLoading(true, label || "Preparing text…", 0);
        let k = 0;
        for (const i of need) {
          if (dead) return false;
          await getModel(i);
          k++;
          if (k % 4 === 0 || k === need.length) {
            setLoading(true, (label || "Preparing text…") + "  " + k + " / " + need.length, k / need.length);
            await new Promise(r => setTimeout(r, 0));
          }
        }
        setLoading(false);
        return true;
      }
      function paraEls(i, m) {
        const out = [];
        if (!m.text.trim() || m.quality.garbled || m.quality.empty) {
          const why = m.quality.garbled && !m.quality.empty ? "The text on page " + (i + 1) + " uses a legacy font and can't be shown as text."
            : "Page " + (i + 1) + " has no text layer (a scan or an image).";
          const box = h("div", { class: "kr-missing", "data-pg": i },
            h("div", null, why),
            h("div", { class: "kr-mrow" },
              h("button", { class: "btn secondary sm", onclick: e => { e.stopPropagation(); ocrPage(i, m.quality.empty ? "scan" : "garbled", m.quality.hint); } }, "Read with OCR"),
              h("button", { class: "btn secondary sm", onclick: e => { e.stopPropagation(); loc = { page: i, off: 0 }; setMode("page"); } }, "View page")));
          out.push(box);
          return out;
        }
        const bounds = m.sentences.map(s => s.start);
        m.paras.forEach((p, pi) => {
          const segs = [];
          let starts = bounds.filter(b => b > p.start && b < p.end);
          starts = [p.start].concat(starts);
          for (let k = 0; k < starts.length; k++) {
            const a = starts[k], b = k + 1 < starts.length ? starts[k + 1] : p.end;
            segs.push(h("span", { class: "ks", "data-pg": i, "data-o": a }, m.text.slice(a, b)));
          }
          const tag = p.heading ? "h3" : "p";
          const el = h(tag, { class: "kr-p" + (p.heading ? " kr-h" : ""), "data-pg": i, dir: "auto", lang: p.lang ? (PDCore.LANG_INFO[p.lang] || {}).bcp || "" : "" }, segs);
          if (pi === 0 && i > 0 && !p.heading) {
            const prev = models.get(i - 1);
            const prevText = prev && prev.text.trim();
            if (prevText && !/[.!?:؟।۔"'”)]$/.test(prevText) && /^[a-z\u00DF-\u00FF]/.test(m.text.slice(p.start, p.start + 1))) el.classList.add("cont");
          }
          out.push(el);
        });
        return out;
      }
      async function buildFlow() {
        const ok = await extractAll();
        if (!ok || dead) return false;
        cols.innerHTML = "";
        pageSpans.clear();
        for (let i = 0; i < n; i++) {
          const wrap = h("div", { class: "kr-pgwrap", "data-pg": i }, paraEls(i, models.get(i)));
          cols.append(wrap);
        }
        cols.append(h("span", { class: "kr-end" }));
        indexSpans();
        decideDir();
        flowBuilt = true;
        return true;
      }
      function indexSpans() {
        pageSpans.clear();
        allSpans = Array.from(cols.querySelectorAll("span.ks"));
        for (const s of allSpans) {
          const p = +s.dataset.pg;
          if (!pageSpans.has(p)) pageSpans.set(p, []);
          pageSpans.get(p).push(s);
        }
      }
      function rerenderReflowPage(i) {
        const wrap = cols.querySelector('.kr-pgwrap[data-pg="' + i + '"]');
        if (!wrap) return;
        wrap.innerHTML = "";
        wrap.append(...paraEls(i, models.get(i)));
        indexSpans();
        layoutFlow(true);
        refreshHighlightsFlow();
      }
      function decideDir() {
        let rtl = 0, ltr = 0;
        for (const m of models.values()) { const w = m.words || 0; if (m.dir === "rtl") rtl += w; else ltr += w; }
        dir = rtl > ltr * 2 ? "rtl" : "ltr";   // mixed books keep left-to-right page turns
        root.classList.toggle("rtl-book", dir === "rtl");
        cols.style.direction = dir;
      }
      function layoutFlow(keep) {
        const sz = stageSize();
        const two = twoUp();
        const G = Math.round(Math.max(24, sz.w * 0.06));
        const pad = parseFloat(getComputedStyle(root).getPropertyValue("--kr-margin")) || 8;
        const side = Math.round(sz.w * pad / 100);
        const W = Math.max(160, sz.w - side * 2);
        const H = Math.max(160, sz.h - (isMobile() ? 44 : 64));
        const colW = two ? (W - G) / 2 : W;
        flow.style.left = side + "px"; flow.style.width = W + "px";
        flow.style.top = (isMobile() ? 18 : 28) + "px"; flow.style.height = H + "px";
        cols.style.width = W + "px"; cols.style.height = H + "px";
        cols.style.columnWidth = colW + "px"; cols.style.columnGap = G + "px";
        cols.style.columnCount = "auto";
        flowStep = W + G;
        const endEl = cols.querySelector(".kr-end");
        flowScreens = endEl ? screenOf(endEl) + 1 : 1;
        if (keep) gotoLoc(loc, 0);
      }
      function relX(el) {
        const r = (el.getClientRects && el.getClientRects()[0]) || el.getBoundingClientRect();
        const c = cols.getBoundingClientRect();
        return dir === "rtl" ? (c.right - r.right) : (r.left - c.left);
      }
      function screenOf(el) { return Math.max(0, Math.floor((relX(el) + 2) / flowStep)); }
      function showScreen(k, animateDir) {
        k = Math.max(0, Math.min(flowScreens - 1, k));
        const prev = flowScreen;
        flowScreen = k;
        const x = (dir === "rtl" ? 1 : -1) * k * flowStep;
        const anim = animateDir && prefs.anim !== "none" && prev !== k && !window.matchMedia("(prefers-reduced-motion: reduce)").matches;
        if (anim && prefs.anim === "curl") {
          // curl in reflow: snapshot-free fold effect on the flow box
          flow.animate([{ transform: "perspective(1600px) rotateY(0)", opacity: 1 }, { transform: "perspective(1600px) rotateY(" + ((dir === "rtl" ? -animateDir : animateDir) > 0 ? -18 : 18) + "deg)", opacity: 0.25 }],
            { duration: 150, easing: "ease-in" }).finished.then(() => {
            cols.style.transform = "translateX(" + x + "px)";
            flow.animate([{ transform: "perspective(1600px) rotateY(" + ((dir === "rtl" ? -animateDir : animateDir) > 0 ? 18 : -18) + "deg)", opacity: 0.25 }, { transform: "none", opacity: 1 }], { duration: 170, easing: "ease-out" });
          }, () => {});
        } else if (anim) {
          cols.style.transition = "transform 280ms cubic-bezier(0.22,1,0.36,1)";
          cols.style.transform = "translateX(" + x + "px)";
          setTimeout(() => { cols.style.transition = ""; }, 300);
        } else {
          cols.style.transition = "";
          cols.style.transform = "translateX(" + x + "px)";
        }
        loc = locOfScreen(k);
        afterMove();
      }
      function locOfScreen(k) {
        if (!allSpans.length) {
          const box = Array.from(cols.querySelectorAll(".kr-missing")).find(b => screenOf(b) >= k);
          return { page: box ? +box.dataset.pg : 0, off: 0 };
        }
        // first span whose start lies on screen k (binary search: spans are in reading order)
        let lo = 0, hi = allSpans.length - 1, ans = allSpans.length - 1;
        while (lo <= hi) {
          const mid = (lo + hi) >> 1;
          if (screenOf(allSpans[mid]) >= k) { ans = mid; hi = mid - 1; } else lo = mid + 1;
        }
        const s = allSpans[ans];
        // a page with no text (scan placeholder) that sits before this span on the same screen
        const miss = Array.from(cols.querySelectorAll(".kr-missing")).find(b => screenOf(b) === k && +b.dataset.pg < +s.dataset.pg);
        if (miss) return { page: +miss.dataset.pg, off: 0 };
        return { page: +s.dataset.pg, off: +s.dataset.o };
      }
      function spanAt(page, off) {
        const list = pageSpans.get(page);
        if (!list || !list.length) return null;
        let best = list[0];
        for (const s of list) { if (+s.dataset.o <= off) best = s; else break; }
        return best;
      }
      function gotoLoc(l, animateDir) {
        loc = { page: Math.max(0, Math.min(n - 1, l.page)), off: l.off || 0 };
        if (mode === "reflow") {
          let el = spanAt(loc.page, loc.off);
          if (!el) {
            el = cols.querySelector('.kr-pgwrap[data-pg="' + loc.page + '"] .kr-missing');
            if (!el) { for (let p = loc.page + 1; p < n && !el; p++) el = spanAt(p, 0); }
          }
          const k = el ? screenOf(el) : 0;
          const keepLoc = loc;
          showScreen(k, animateDir);
          loc = keepLoc;   // keep the exact anchor, not the screen's first span
          afterMove();
        } else {
          renderSpread(animateDir);
        }
      }
      function domPos(page, off) {
        const s = spanAt(page, off);
        if (!s || !s.firstChild) return null;
        const t = s.firstChild;
        return { node: t, offset: Math.max(0, Math.min(t.length, off - +s.dataset.o)) };
      }
      function rangeFor(page, start, end) {
        const a = domPos(page, start), b = domPos(page, end);
        if (!a || !b) return null;
        const r = document.createRange();
        try { r.setStart(a.node, a.offset); r.setEnd(b.node, b.offset); } catch (e) { return null; }
        return r;
      }
      const HL_API = !!(window.CSS && CSS.highlights && window.Highlight);
      function refreshHighlightsFlow() {
        if (!HL_API) return;
        for (const c of Object.keys(KR_HL)) {
          const ranges = book.highlights.filter(x => x.color === c).map(x => rangeFor(x.page, x.start, x.end)).filter(Boolean);
          CSS.highlights.set("kr-" + c, new Highlight(...ranges));
        }
        const fr = findHit ? rangeFor(findHit.page, findHit.start, findHit.end) : null;
        CSS.highlights.set("kr-find", fr ? new Highlight(fr) : new Highlight());
      }
      function clearFlowHighlights() {
        if (!HL_API) return;
        for (const k of ["kr-y", "kr-g", "kr-b", "kr-p", "kr-find", "kr-tts-s", "kr-tts-w"]) CSS.highlights.delete(k);
      }

      /* ================= navigation ================= */
      function afterMove() {
        scrub.value = loc.page + 1;
        pageLbl.textContent = "Page " + (loc.page + 1) + " of " + n;
        updateProgress();
        updateBookmarkState();
        book.pos = { page: loc.page, off: loc.off, mode };
        persist();
      }
      function next() { move(1); }
      function prev() { move(-1); }
      function move(d) {
        if (mode === "reflow") {
          const k = flowScreen + d;
          if (k < 0 || k >= flowScreens) return;
          showScreen(k, d);
        } else {
          const pages = spreadPages();
          const target = d > 0 ? pages[pages.length - 1] + 1 : pages[0] - 1;
          if (target < 0 || target >= n) return;
          loc = { page: d > 0 ? target : spreadPages(target)[0], off: 0 };
          renderSpread(d);
        }
        if (chrome && !panelOpen()) setChrome(false);
      }
      async function setMode(m) {
        if (m === mode && (m === "page" ? spreadEl : flowBuilt)) return;
        mode = m;
        prefs.mode = m; savePrefs();
        modeSeg.set(m);
        root.classList.toggle("mode-reflow", m === "reflow");
        if (m === "reflow") {
          stage.querySelectorAll(".kr-spread").forEach(e => e.remove());
          spreadEl = null;
          if (!flow.parentNode) stage.append(flow);
          if (!flowBuilt && !(await buildFlow())) return;
          layoutFlow(false);
          refreshHighlightsFlow();
          gotoLoc(loc, 0);
        } else {
          flow.remove();
          clearFlowHighlights();
          await renderSpread(0);
        }
        redrawTts();
      }
      function updateProgress() {
        let before = 0, total = 0, known = 0, pagesKnown = 0;
        for (let i = 0; i < n; i++) {
          const m = models.get(i);
          if (!m) continue;
          pagesKnown++;
          total += m.words;
          if (i < loc.page) before += m.words;
          else if (i === loc.page && m.text.length) before += m.words * Math.min(1, loc.off / m.text.length);
        }
        let pct, left;
        const wpm = audio && audio.ar && audio.ar.playing ? 150 * audio.ar.rate : 230;
        if (pagesKnown === n && total > 0) { pct = before / total; left = (total - before) / wpm; }
        else {
          pct = n > 1 ? loc.page / (n - 1) : 1;
          const avg = pagesKnown ? total / pagesKnown : 250;
          left = (n - loc.page) * avg / wpm;
        }
        progTxt.textContent = Math.round(pct * 100) + "%" + (left > 0 ? " · " + PDCore.fmtDuration(left) + " left in book" : "");
      }
      scrub.addEventListener("input", () => { pageLbl.textContent = "Page " + scrub.value + " of " + n; });
      scrub.addEventListener("change", () => { gotoLoc({ page: +scrub.value - 1, off: 0 }, 0); });
      function gotoPrompt() {
        const input = h("input", { type: "number", min: 1, max: n, value: loc.page + 1, style: "width:100%" });
        const close = showModal({ title: "Go to page", body: h("div", null, h("p", null, "1 – " + n), input), actions: [
          { label: "Cancel", onClick: c => c() },
          { label: "Go", primary: true, onClick: c => { c(); gotoLoc({ page: (parseInt(input.value, 10) || 1) - 1, off: 0 }, 0); } }] });
        input.addEventListener("keydown", e => { if (e.key === "Enter") { close(); gotoLoc({ page: (parseInt(input.value, 10) || 1) - 1, off: 0 }, 0); } });
        setTimeout(() => { input.focus(); input.select(); }, 30);
      }

      /* ---- taps, swipes, keys ---- */
      let pd = null;
      stage.addEventListener("pointerdown", e => {
        if (e.button && e.button !== 0) return;
        pd = { x: e.clientX, y: e.clientY, t: Date.now(), id: e.pointerId, target: e.target };
      });
      stage.addEventListener("pointerup", e => {
        if (!pd || pd.id !== e.pointerId) return;
        const dx = e.clientX - pd.x, dy = e.clientY - pd.y, dt = Date.now() - pd.t;
        const target = pd.target;
        pd = null;
        const sel = window.getSelection();
        if (sel && !sel.isCollapsed && String(sel).trim()) return;           // text selection → menu handles it
        if (Math.abs(dx) > 45 && Math.abs(dx) > Math.abs(dy) * 1.4 && dt < 800) {
          const forward = dx < 0;
          (dir === "rtl" ? !forward : forward) ? next() : prev();
          return;
        }
        if (Math.abs(dx) > 10 || Math.abs(dy) > 10 || dt > 600) return;
        if (target && target.closest && target.closest("button, .kr-selmenu, .kr-missing")) return;
        // tap on a highlight → its menu
        const hb = target && target.closest && target.closest(".kr-hlbox[data-id]");
        if (hb) { showHighlightMenu(book.highlights.find(x => x.id === hb.dataset.id), e.clientX, e.clientY); return; }
        if (mode === "reflow" && HL_API) { const hit = highlightAtPoint(e.clientX, e.clientY); if (hit) { showHighlightMenu(hit, e.clientX, e.clientY); return; } }
        // player open + tap on text → read from that word
        if (audio.ar && target && target.closest && target.closest("[data-o]")) {
          const pos = posFromPoint(e.clientX, e.clientY);
          if (pos) { const m = models.get(pos.page); audio.ar.play(pos.page, m ? PDCore.wordRangeAt(m.text, pos.off).start : pos.off); return; }
        }
        const r = stage.getBoundingClientRect();
        const fx = (e.clientX - r.left) / r.width;
        if (fx < 0.28) (dir === "rtl" ? next : prev)();
        else if (fx > 0.72) (dir === "rtl" ? prev : next)();
        else setChrome(!chrome);
      });
      const keyHandler = e => {
        if (!document.body.contains(root)) return;
        if (e.target && (/INPUT|TEXTAREA|SELECT/.test(e.target.tagName) || e.target.isContentEditable)) return;
        if (document.querySelector(".modal-wrap")) return;
        const k = e.key;
        if (k === "ArrowRight" || k === "PageDown" || (k === " " && !audio.ar)) { e.preventDefault(); (dir === "rtl" && k === "ArrowRight") ? prev() : next(); }
        else if (k === "ArrowLeft" || k === "PageUp") { e.preventDefault(); (dir === "rtl" && k === "ArrowLeft") ? next() : prev(); }
        else if (k === "Escape") { if (panelOpen()) closePanels(); else setChrome(!chrome); }
        else if ((e.ctrlKey || e.metaKey) && k.toLowerCase() === "f") { e.preventDefault(); openSearch(); }
      };
      document.addEventListener("keydown", keyHandler);
      let rsT;
      const onResize = () => {
        clearTimeout(rsT);
        rsT = setTimeout(() => {
          if (dead) return;
          pageCache.clear();
          if (mode === "reflow" && flowBuilt) { layoutFlow(true); refreshHighlightsFlow(); }
          else renderSpread(0);
        }, 180);
      };
      window.addEventListener("resize", onResize);

      /* ---- selection → highlight / note / copy / listen ---- */
      function posFromNode(node, offset) {
        const el = node && (node.nodeType === 3 ? node.parentElement : node);
        const sp = el && el.closest && el.closest("[data-o]");
        if (!sp || !root.contains(sp)) return null;
        const base = +sp.dataset.o;
        const len = sp.textContent.length;
        const o = node.nodeType === 3 ? offset : (offset > 0 ? len : 0);
        return { page: +sp.dataset.pg, off: base + Math.min(len, o) };
      }
      function posFromPoint(x, y) {
        let node = null, off = 0;
        if (document.caretRangeFromPoint) { const r = document.caretRangeFromPoint(x, y); if (r) { node = r.startContainer; off = r.startOffset; } }
        else if (document.caretPositionFromPoint) { const p = document.caretPositionFromPoint(x, y); if (p) { node = p.offsetNode; off = p.offset; } }
        if (node) { const p = posFromNode(node, off); if (p) return p; }
        // page mode fallback: geometry
        const pg = document.elementsFromPoint(x, y).find(el => el.classList && el.classList.contains("kr-pg"));
        if (pg && pg._model) { const r = pg.getBoundingClientRect(); return { page: +pg.dataset.pg, off: PDCore.offsetAtPoint(pg._model, (x - r.left) / pg._scale, (y - r.top) / pg._scale) }; }
        return null;
      }
      function highlightAtPoint(x, y) {
        const p = posFromPoint(x, y);
        if (!p) return null;
        return book.highlights.find(hh => hh.page === p.page && p.off >= hh.start && p.off < hh.end) || null;
      }
      const selMenu = h("div", { class: "kr-selmenu hidden", role: "toolbar" });
      root.append(selMenu);
      let selTimer = null;
      const onSel = () => {
        clearTimeout(selTimer);
        selTimer = setTimeout(() => {
          if (dead) return;
          const sel = window.getSelection();
          if (!sel || sel.isCollapsed || !String(sel).trim()) { if (!selMenu.dataset.hl) hideSelMenu(); return; }
          const r0 = sel.getRangeAt(0);
          if (!root.contains(r0.commonAncestorContainer)) return;
          let a = posFromNode(r0.startContainer, r0.startOffset), b = posFromNode(r0.endContainer, r0.endOffset);
          if (!a || !b) return;
          if (b.page < a.page || (b.page === a.page && b.off < a.off)) [a, b] = [b, a];
          const rect = r0.getBoundingClientRect();
          showSelMenu({ a, b, text: String(sel).trim() }, rect);
        }, 220);
      };
      document.addEventListener("selectionchange", onSel);
      function hideSelMenu() { selMenu.classList.add("hidden"); selMenu.dataset.hl = ""; }
      function placeMenu(x, y) {
        const rr = root.getBoundingClientRect();
        selMenu.classList.remove("hidden");
        const w = selMenu.offsetWidth || 260, hh = selMenu.offsetHeight || 44;
        const left = Math.max(8, Math.min(rr.width - w - 8, x - w / 2));
        const topPos = y - hh - 12 < 60 ? y + 28 : y - hh - 12;
        selMenu.style.left = left + "px"; selMenu.style.top = topPos + "px";
      }
      function showSelMenu(s, rect) {
        selMenu.innerHTML = "";
        selMenu.dataset.hl = "";
        const add = color => {
          const parts = splitAcrossPages(s.a, s.b);
          for (const p of parts) book.highlights.push({ id: krId(), page: p.page, start: p.start, end: p.end, color, note: "", text: textOf(p), at: Date.now() });
          persist();
          window.getSelection().removeAllRanges();
          hideSelMenu();
          refreshHighlights();
        };
        for (const c of Object.keys(KR_HL))
          selMenu.append(h("button", { class: "kr-dot c-" + c, title: KR_HL[c].label + " highlight", "aria-label": KR_HL[c].label + " highlight", onclick: () => add(c) }));
        selMenu.append(
          h("span", { class: "kr-sep" }),
          h("button", { class: "iconbtn", title: "Add note", "aria-label": "Add note", onclick: () => {
            const parts = splitAcrossPages(s.a, s.b);
            window.getSelection().removeAllRanges();
            hideSelMenu();
            editNote(null, txt => {
              parts.forEach((p, k) => book.highlights.push({ id: krId(), page: p.page, start: p.start, end: p.end, color: "y", note: k === 0 ? txt : "", text: textOf(p), at: Date.now() }));
              persist(); refreshHighlights();
            });
          } }, icon("note")),
          h("button", { class: "iconbtn", title: "Copy", "aria-label": "Copy", onclick: () => { copyText(s.text); hideSelMenu(); } }, icon("copy")),
          h("button", { class: "iconbtn", title: "Read aloud from here", "aria-label": "Read aloud from here", onclick: () => { hideSelMenu(); window.getSelection().removeAllRanges(); openAudio(true); audio.ar.play(s.a.page, s.a.off); } }, icon("headphones")));
        const rr = root.getBoundingClientRect();
        placeMenu(rect.left + rect.width / 2 - rr.left, rect.top - rr.top);
      }
      function showHighlightMenu(hl, x, y) {
        if (!hl) return;
        selMenu.innerHTML = "";
        selMenu.dataset.hl = hl.id;
        for (const c of Object.keys(KR_HL))
          selMenu.append(h("button", { class: "kr-dot c-" + c + (hl.color === c ? " on" : ""), title: KR_HL[c].label, "aria-label": KR_HL[c].label, onclick: () => { hl.color = c; persist(); refreshHighlights(); hideSelMenu(); } }));
        selMenu.append(h("span", { class: "kr-sep" }),
          h("button", { class: "iconbtn", title: hl.note ? "Edit note" : "Add note", "aria-label": "Note", onclick: () => { hideSelMenu(); editNote(hl.note, t => { hl.note = t; persist(); refreshHighlights(); }); } }, icon("note")),
          h("button", { class: "iconbtn", title: "Copy", "aria-label": "Copy", onclick: () => { copyText(hl.text); hideSelMenu(); } }, icon("copy")),
          h("button", { class: "iconbtn", title: "Remove highlight", "aria-label": "Remove highlight", onclick: () => { book.highlights = book.highlights.filter(x => x.id !== hl.id); persist(); refreshHighlights(); hideSelMenu(); } }, icon("trash")));
        const rr = root.getBoundingClientRect();
        placeMenu(x - rr.left, y - rr.top);
        if (hl.note) toast(hl.note.length > 120 ? hl.note.slice(0, 117) + "…" : hl.note, null, 4000);
      }
      function splitAcrossPages(a, b) {
        if (a.page === b.page) return [{ page: a.page, start: a.off, end: b.off }];
        const out = [];
        for (let p = a.page; p <= b.page; p++) {
          const m = models.get(p);
          if (!m) continue;
          out.push({ page: p, start: p === a.page ? a.off : 0, end: p === b.page ? b.off : m.text.length });
        }
        return out.filter(x => x.end > x.start);
      }
      function textOf(p) { const m = models.get(p.page); return m ? m.text.slice(p.start, p.end) : ""; }
      function copyText(t) {
        (navigator.clipboard && navigator.clipboard.writeText ? navigator.clipboard.writeText(t) : Promise.reject())
          .then(() => toast("Copied")).catch(() => { try { const ta = h("textarea", null, t); document.body.append(ta); ta.select(); document.execCommand("copy"); ta.remove(); toast("Copied"); } catch (e) {} });
      }
      function editNote(initial, onSave) {
        const ta = h("textarea", { class: "kr-notearea", placeholder: "Write a note…", rows: "5" }, initial || "");
        showModal({ title: initial ? "Edit note" : "Add note", body: ta, actions: [
          { label: "Cancel", onClick: c => c() },
          { label: "Save", primary: true, onClick: c => { c(); onSave(ta.value.trim()); } }] });
        setTimeout(() => ta.focus(), 40);
      }
      function refreshHighlights() {
        if (mode === "reflow") refreshHighlightsFlow();
        else stage.querySelectorAll(".kr-pg").forEach(drawPageHighlights);
      }

      /* ---- bookmarks ---- */
      function bookmarkHere() {
        if (mode === "page") { const pages = spreadPages(); return book.bookmarks.find(b => pages.includes(b.page)); }
        const endLoc = flowScreen + 1 < flowScreens ? locOfScreen(flowScreen + 1) : { page: n, off: 0 };
        return book.bookmarks.find(b => (b.page > loc.page || (b.page === loc.page && b.off >= loc.off)) && (b.page < endLoc.page || (b.page === endLoc.page && b.off < endLoc.off)));
      }
      function updateBookmarkState() {
        const hit = bookmarkHere();
        bmBtn.innerHTML = ""; bmBtn.append(icon(hit ? "bookmarkfill" : "bookmark"));
        bmBtn.classList.toggle("on", !!hit);
        ribbon.classList.toggle("hidden", !hit);
      }
      bmBtn.addEventListener("click", async () => {
        const hit = bookmarkHere();
        if (hit) { book.bookmarks = book.bookmarks.filter(b => b !== hit); toast("Bookmark removed"); }
        else {
          const m = await getModel(loc.page);
          const snippet = m.text.slice(loc.off, loc.off + 90).replace(/\s+/g, " ").trim();
          book.bookmarks.push({ id: krId(), page: loc.page, off: loc.off, label: snippet, at: Date.now() });
          toast("Bookmarked page " + (loc.page + 1));
        }
        persist(); updateBookmarkState();
      });

      /* ================= panels ================= */
      let panel = null;
      function panelOpen() { return !!panel; }
      function closePanels() { if (panel) { panel.remove(); panel = null; } }
      function openPanel(cls, title, content, opts) {
        closePanels();
        panel = h("div", { class: "kr-panel " + cls },
          h("div", { class: "kr-phead" }, h("div", { class: "kr-ptitle" }, title), opts && opts.headExtra, h("button", { class: "iconbtn", title: "Close", "aria-label": "Close", onclick: closePanels }, icon("close"))),
          h("div", { class: "kr-pbody" }, content));
        root.append(panel);
        return panel;
      }
      function openSettings() {
        const themeRow = h("div", { class: "kr-themes" }, Object.keys(KR_THEMES).map(t =>
          h("button", { class: "kr-theme t-" + t + (prefs.theme === t ? " on" : ""), onclick: () => { prefs.theme = t; savePrefs(); applyLook(); openSettings(); } }, KR_THEMES[t])));
        const fontSeg = segmented(Object.keys(KR_FONTS).map(k => ({ v: k, label: KR_FONTS[k].label })), prefs.font, v => { prefs.font = v; savePrefs(); applyLook(); relayout(); });
        const sizeVal = h("span", { class: "kr-sizeval" }, String(prefs.size));
        const sizeRow = h("div", { class: "kr-size" },
          h("button", { class: "btn secondary sm", "aria-label": "Smaller text", onclick: () => { prefs.size = Math.max(12, prefs.size - 1); sizeVal.textContent = prefs.size; savePrefs(); applyLook(); relayout(); } }, "A−"),
          sizeVal,
          h("button", { class: "btn secondary sm", "aria-label": "Larger text", onclick: () => { prefs.size = Math.min(40, prefs.size + 1); sizeVal.textContent = prefs.size; savePrefs(); applyLook(); relayout(); } }, "A+"));
        const lineSeg = segmented([{ v: 1.3, label: "Tight" }, { v: 1.6, label: "Normal" }, { v: 1.9, label: "Relaxed" }, { v: 2.2, label: "Loose" }], prefs.line, v => { prefs.line = v; savePrefs(); applyLook(); relayout(); });
        const marSeg = segmented([{ v: "sm", label: "Narrow" }, { v: "md", label: "Medium" }, { v: "lg", label: "Wide" }], prefs.margin, v => { prefs.margin = v; savePrefs(); applyLook(); relayout(); });
        const justC = checkbox("Justify text", prefs.justify, v => { prefs.justify = v; savePrefs(); applyLook(); relayout(); });
        const brightS = slider(0.2, 1, 0.05, prefs.bright, v => Math.round(v * 100) + "%", v => { prefs.bright = v; savePrefs(); applyLook(); });
        const animSeg = segmented([{ v: "slide", label: "Slide" }, { v: "curl", label: "Page curl" }, { v: "none", label: "None" }], prefs.anim, v => { prefs.anim = v; savePrefs(); applyLook(); });
        const twoSeg = segmented([{ v: "auto", label: "Two pages in landscape" }, { v: "off", label: "Always one" }], prefs.twoPage, v => { prefs.twoPage = v; savePrefs(); pageCache.clear(); relayout(true); });
        const mSeg = segmented([{ v: "page", label: "Original page" }, { v: "reflow", label: "Reflow text" }], mode, v => { closePanels(); setMode(v); });
        const row = (label, el, cls) => h("div", { class: "kr-srow" + (cls ? " " + cls : "") }, h("div", { class: "kr-slabel" }, label), el);
        openPanel("kr-settings", "Reading settings", h("div", null,
          row("View", mSeg.el),
          row("Theme", themeRow),
          row("Brightness", brightS.el),
          row("Font", fontSeg.el, "flow-only"),
          row("Text size", sizeRow, "flow-only"),
          row("Line spacing", lineSeg.el, "flow-only"),
          row("Margins", marSeg.el, "flow-only"),
          row("", justC.el, "flow-only"),
          row("Page turn", animSeg.el),
          row("Layout", twoSeg.el),
          mode === "page" ? h("div", { class: "opt-note" }, "Font, size, spacing and margins apply to Reflow view.") : null));
      }
      function relayout(pagesToo) {
        if (mode === "reflow" && flowBuilt) { layoutFlow(true); refreshHighlightsFlow(); redrawTts(); }
        else if (pagesToo) renderSpread(0);
      }

      /* contents / bookmarks / notes */
      let outlineCache = null;
      async function loadOutline() {
        if (outlineCache) return outlineCache;
        const out = [];
        try {
          const ol = await doc.getOutline();
          const walk = async (items, depth) => {
            for (const it of items || []) {
              let page = null;
              try {
                let dest = it.dest;
                if (typeof dest === "string") dest = await doc.getDestination(dest);
                if (Array.isArray(dest) && dest[0]) page = typeof dest[0] === "number" ? dest[0] : await doc.getPageIndex(dest[0]);
              } catch (e) {}
              out.push({ title: it.title || "(untitled)", page, depth });
              if (it.items && it.items.length && depth < 4) await walk(it.items, depth + 1);
            }
          };
          await walk(ol, 0);
        } catch (e) {}
        outlineCache = out;
        return out;
      }
      async function openNav(tab) {
        const tabs = segmented([{ v: "toc", label: "Contents" }, { v: "bm", label: "Bookmarks" }, { v: "notes", label: "Notes" }], tab, v => openNav(v));
        const body = h("div", { class: "kr-list" }, h("div", { class: "kr-empty" }, "Loading…"));
        const exportBtn = tab === "notes" ? h("button", { class: "textbtn", onclick: exportNotes }, "Export") : null;
        openPanel("kr-nav", "", h("div", null, h("div", { class: "kr-tabs" }, tabs.el, exportBtn), body));
        body.innerHTML = "";
        if (tab === "toc") {
          const ol = await loadOutline();
          if (ol.length) {
            for (const it of ol) body.append(h("button", { class: "kr-item d" + it.depth + (it.page === loc.page ? " cur" : ""), disabled: it.page == null ? "" : null, onclick: () => { closePanels(); gotoLoc({ page: it.page, off: 0 }, 0); } },
              h("span", { class: "kr-it" }, it.title), h("span", { class: "kr-ip" }, it.page != null ? String(it.page + 1) : "")));
          } else {
            const heads = [];
            for (const [i, m] of Array.from(models.entries()).sort((a, b) => a[0] - b[0]))
              for (const p of m.paras) if (p.heading) heads.push({ page: i, off: p.start, title: m.text.slice(p.start, p.end) });
            if (heads.length) {
              body.append(h("div", { class: "kr-empty" }, "This PDF has no table of contents. Headings found in the text:"));
              for (const it of heads.slice(0, 300)) body.append(h("button", { class: "kr-item", onclick: () => { closePanels(); gotoLoc({ page: it.page, off: it.off }, 0); } },
                h("span", { class: "kr-it", dir: "auto" }, it.title), h("span", { class: "kr-ip" }, String(it.page + 1))));
            } else body.append(h("div", { class: "kr-empty" }, "This PDF has no table of contents." + (mode === "page" ? " Switch to Reflow to detect headings." : "")));
          }
        } else if (tab === "bm") {
          const list = book.bookmarks.slice().sort((a, b) => a.page - b.page || a.off - b.off);
          if (!list.length) body.append(h("div", { class: "kr-empty" }, "No bookmarks yet. Tap the ribbon icon at the top to bookmark a page."));
          for (const b of list) body.append(h("div", { class: "kr-item row" },
            h("button", { class: "kr-igo", onclick: () => { closePanels(); gotoLoc({ page: b.page, off: b.off }, 0); } },
              h("span", { class: "kr-ip" }, "p. " + (b.page + 1)), h("span", { class: "kr-it", dir: "auto" }, b.label || "Page " + (b.page + 1))),
            h("button", { class: "iconbtn", title: "Delete bookmark", "aria-label": "Delete bookmark", onclick: () => { book.bookmarks = book.bookmarks.filter(x => x !== b); persist(); updateBookmarkState(); openNav("bm"); } }, icon("trash"))));
        } else {
          const list = book.highlights.slice().sort((a, b) => a.page - b.page || a.start - b.start);
          if (!list.length) body.append(h("div", { class: "kr-empty" }, "Select text to highlight it in one of four colours or attach a note."));
          for (const x of list) body.append(h("div", { class: "kr-item row note" },
            h("button", { class: "kr-igo", onclick: () => { closePanels(); gotoLoc({ page: x.page, off: x.start }, 0); } },
              h("span", { class: "kr-swatch c-" + x.color }),
              h("span", { class: "kr-nt" }, h("span", { class: "kr-q", dir: "auto" }, x.text.length > 220 ? x.text.slice(0, 217) + "…" : x.text), x.note ? h("span", { class: "kr-n", dir: "auto" }, x.note) : null),
              h("span", { class: "kr-ip" }, "p. " + (x.page + 1))),
            h("button", { class: "iconbtn", title: "Edit note", "aria-label": "Edit note", onclick: () => editNote(x.note, t => { x.note = t; persist(); openNav("notes"); refreshHighlights(); }) }, icon("note")),
            h("button", { class: "iconbtn", title: "Delete", "aria-label": "Delete", onclick: () => { book.highlights = book.highlights.filter(y => y !== x); persist(); refreshHighlights(); openNav("notes"); } }, icon("trash"))));
        }
      }
      function exportNotes() {
        const list = book.highlights.slice().sort((a, b) => a.page - b.page || a.start - b.start);
        if (!list.length) { toast("No highlights or notes to export yet"); return; }
        const lines = ["# Notes — " + rec.name, "", "Exported " + new Date().toLocaleString() + " from AtoB PDF", ""];
        let lastPage = -1;
        for (const x of list) {
          if (x.page !== lastPage) { lines.push("## Page " + (x.page + 1), ""); lastPage = x.page; }
          lines.push("> " + x.text.replace(/\n+/g, " ") + "  ", "*" + KR_HL[x.color].label + " highlight*", "");
          if (x.note) lines.push(x.note, "");
        }
        if (book.bookmarks.length) {
          lines.push("## Bookmarks", "");
          for (const b of book.bookmarks.slice().sort((a, c) => a.page - c.page)) lines.push("- Page " + (b.page + 1) + (b.label ? ": " + b.label : ""));
        }
        const bytes = new TextEncoder().encode(lines.join("\n") + "\n");
        const name = PDCore.baseName(rec.name) + "-notes.md";
        if (canShareFiles() && window.AndroidBridge) shareFile(name, bytes, "text/markdown", "any");
        else { downloadBytes(name, bytes, "text/markdown"); toast("Notes exported as " + name); }
      }

      /* search */
      let findHit = null, findTimer = null;
      function openSearch() {
        const input = h("input", { type: "search", class: "kr-search", placeholder: "Search this book", "aria-label": "Search", autocomplete: "off", dir: "auto" });
        const info = h("div", { class: "kr-sinfo" });
        const list = h("div", { class: "kr-list" });
        openPanel("kr-searchp", "Search", h("div", null, input, info, list));
        let seq = 0;
        input.addEventListener("input", debounce(async () => {
          const my = ++seq;
          const q = input.value.trim();
          list.innerHTML = ""; info.textContent = "";
          if (q.length < 2) return;
          const fq = foldForSearch(PDCore.normalizeText(q)).s;
          let count = 0;
          for (let i = 0; i < n; i++) {
            if (my !== seq || dead) return;
            if (!models.has(i)) { info.textContent = "Searching page " + (i + 1) + " of " + n + "…"; await getModel(i); if (i % 5 === 0) await new Promise(r => setTimeout(r, 0)); }
            const m = models.get(i);
            const f = foldForSearch(m.text);
            let at = f.s.indexOf(fq);
            while (at >= 0 && count < 500) {
              const start = f.map[at], end = f.map[Math.min(f.map.length - 1, at + fq.length)];
              const a = Math.max(0, start - 50), b = Math.min(m.text.length, end + 70);
              list.append(h("button", { class: "kr-item res", onclick: () => { findHit = { page: i, start, end }; closePanels(); gotoLoc({ page: i, off: start }, 0); refreshHighlights(); clearTimeout(findTimer); findTimer = setTimeout(() => { findHit = null; refreshHighlights(); }, 6000); } },
                h("span", { class: "kr-it", dir: "auto" }, (a > 0 ? "…" : "") + m.text.slice(a, start), h("mark", null, m.text.slice(start, end)), m.text.slice(end, b) + (b < m.text.length ? "…" : "")),
                h("span", { class: "kr-ip" }, String(i + 1))));
              count++;
              at = f.s.indexOf(fq, at + Math.max(1, fq.length));
            }
          }
          info.textContent = count ? count + (count >= 500 ? "+" : "") + " result" + (count === 1 ? "" : "s") : "No results";
        }, 300));
        setTimeout(() => input.focus(), 40);
      }

      /* ================= audio ================= */
      const audio = { ar: null, bar: null, st: null };
      const readerHost = {
        pageCount: n,
        title: rec.name.replace(/\.pdf$/i, ""),
        getPage: i => getModel(i),
        async showPage(i) {
          if (mode === "page") { if (!spreadPages().includes(i)) { loc = { page: i, off: 0 }; await renderSpread(1); } }
          else { const el = spanAt(i, 0); if (el && screenOf(el) !== flowScreen) { const keep = { page: i, off: 0 }; showScreen(screenOf(el), 1); loc = keep; afterMove(); } }
        },
        highlight(i, sent, word) { audio.st = sent ? { i, sent, word } : null; redrawTts(true); },
        currentPage: () => loc.page,
        async needsOcr(i, m) { return await ocrPage(i, m.quality.empty ? "scan" : "garbled", m.quality.hint); },
      };
      function redrawTts(follow) {
        const st = audio.st;
        if (mode === "reflow") {
          if (!HL_API) {
            cols.querySelectorAll(".ks.tts").forEach(s => s.classList.remove("tts"));
            if (st) { const s = spanAt(st.i, st.sent.start); if (s) s.classList.add("tts"); }
          } else {
            const sr = st ? rangeFor(st.i, st.sent.start, st.sent.end) : null;
            const wr = st && st.word ? rangeFor(st.i, st.word.start, st.word.end) : null;
            CSS.highlights.set("kr-tts-s", sr ? new Highlight(sr) : new Highlight());
            CSS.highlights.set("kr-tts-w", wr ? new Highlight(wr) : new Highlight());
          }
          if (follow && st && audio.ar && audio.ar.opts.autoTurn) {
            const s = spanAt(st.i, st.word ? st.word.start : st.sent.start);
            if (s) {
              let k = screenOf(s);
              if (st.word) { const wr = rangeFor(st.i, st.word.start, st.word.end); if (wr) { const rr = wr.getClientRects()[0]; if (rr) { const c = cols.getBoundingClientRect(); const x = dir === "rtl" ? c.right - rr.right : rr.left - c.left; k = Math.floor((x + 2) / flowStep); } } }
              if (k !== flowScreen) { const keep = { page: st.i, off: st.sent.start }; showScreen(k, k > flowScreen ? 1 : -1); loc = keep; afterMove(); }
            }
          }
        } else {
          stage.querySelectorAll(".kr-pg").forEach(pg => {
            const layer = pg.querySelector(".tts-layer");
            if (!st || +pg.dataset.pg !== st.i) { if (layer) layer.innerHTML = ""; return; }
            drawTtsBoxes(layer, pg._model, st.sent, st.word, pg._scale);
          });
        }
      }
      function openAudio(force) {
        const open = force != null ? force : !audio.ar;
        if (!open) {
          if (audio.ar) audio.ar.destroy();
          if (audio.bar) audio.bar.destroy();
          audio.ar = audio.bar = null; audio.st = null;
          redrawTts();
          root.classList.remove("audio-on");
          listenBtn.classList.remove("on");
          return;
        }
        if (audio.ar) return;
        audio.ar = new AudioReader(readerHost);
        audio.bar = audioBar(audio.ar, { cls: "in-reader", onClose: () => openAudio(false), langs: () => Array.from(new Set(Array.from(models.values()).map(m => m.lang).filter(Boolean))) });
        root.append(audio.bar.el);
        root.classList.add("audio-on");
        listenBtn.classList.add("on");
        audio.ar.on(() => updateProgress());
      }
      listenBtn.addEventListener("click", async () => {
        if (audio.ar) { openAudio(false); return; }
        openAudio(true);
        // scanned first page? offer OCR before anything plays
        const m = await getModel(loc.page);
        if (m && (m.quality.empty || m.quality.garbled) && m.source !== "ocr") await ocrPage(loc.page, m.quality.empty ? "scan" : "garbled", m.quality.hint);
      });

      /* ================= doc-level checks (legacy fonts / scans) ================= */
      async function checkDoc() {
        await mupdfReady;
        const sample = [];
        for (let i = 0; i < Math.min(n, 6); i++) sample.push(await getModel(i));
        const bad = sample.filter(m => (m.quality.empty || m.quality.garbled) && m.source !== "ocr");
        if (dead || !bad.length || bad.length < Math.ceil(sample.length / 2)) return;
        const hint = (bad.find(m => m.quality.hint) || {}).quality;
        const scans = bad.filter(m => m.quality.empty).length >= bad.length / 2;
        banner.innerHTML = "";
        banner.append(
          h("span", null, scans ? "This looks like a scanned document — there's no text to reflow or read aloud." :
            "This PDF uses a legacy font" + (hint && hint.hint ? " (" + PDCore.LANG_INFO[hint.hint].name + ")" : "") + ", so its text comes out garbled."),
          h("button", { class: "btn primary sm", onclick: async () => {
            banner.classList.add("hidden");
            ocrLangs = await offerOcr(scans ? "scan" : "garbled", hint && hint.hint);
            if (!ocrLangs) return;
            ocrDeclined = false;
            await ocrRange(loc.page, Math.min(n, loc.page + 3));
          } }, "Read with OCR"),
          h("button", { class: "iconbtn", "aria-label": "Dismiss", onclick: () => banner.classList.add("hidden") }, icon("close")));
        banner.classList.remove("hidden");
      }
      async function ocrRange(a, b) {
        for (let i = a; i < b && !dead; i++) {
          const m = await getModel(i);
          if (m.source === "ocr" || !(m.quality.empty || m.quality.garbled)) continue;
          setLoading(true, "Recognising page " + (i + 1) + "…", (i - a) / (b - a));
          await ocrPage(i);
        }
        setLoading(false);
      }

      /* ================= start ================= */
      const saved = book.pos;
      if (saved && saved.page < n) loc = { page: saved.page, off: saved.off || 0 };
      root.classList.toggle("mode-reflow", mode === "reflow");
      if (mode === "reflow") { mode = "page"; await setMode("reflow"); }
      else await renderSpread(0);
      if (saved && (saved.page > 0 || saved.off > 0)) toast("Resumed at page " + (loc.page + 1));
      // decide page-turn direction from the first pages' language
      (async () => {
        await mupdfReady;
        for (let i = 0; i < Math.min(n, 3) && !dead; i++) await getModel(i);
        if (dead) return;
        if (mode === "page") { const before = dir; decideDir(); if (dir !== before) renderSpread(0); }
        await checkDoc();
        if (!dead) updateProgress();
      })().catch(() => {});
      setTimeout(() => { if (!dead && !panelOpen()) setChrome(false); }, 3500);
      root.focus();

      window.__reader = { get: () => ({ mode, loc, flowScreen, flowScreens, dir, book, models, audio, prefs }), setMode, next, prev, gotoLoc, openAudio, openNav, openSearch, openSettings, getModel, refreshHighlights };
      ctx.setCleanup(() => {
        dead = true;
        openAudio(false);
        clearFlowHighlights();
        document.removeEventListener("keydown", keyHandler);
        document.removeEventListener("selectionchange", onSel);
        window.removeEventListener("resize", onResize);
        book.updated = Date.now(); bookPut(book);
        root.remove();
        document.body.classList.remove("kr-open");
        pageCache.clear();
        try { if (mdoc) mdoc.destroy(); } catch (e) {}
        closePdf(doc);
        releaseOcrWorker();
        window.__reader = null;
      });
    });
  },
});

/* Android back button / Esc handling: close the top-most layer first */
window.__atobBack = () => {
  const sheet = document.querySelector(".sheet-wrap");
  if (sheet) { sheet.click(); return true; }
  const modal = document.querySelector(".modal-wrap");
  if (modal) { modal.remove(); return true; }
  const panel = document.querySelector(".kr-panel");
  if (panel) { panel.remove(); return true; }
  const abPanel = document.querySelector(".ab-panel:not(.hidden)");
  if (abPanel) { abPanel.classList.add("hidden"); return true; }
  if (currentView && currentView.id !== "mhome" && currentView.id !== "welcome") {
    showView(currentView.id === "read" && !isMobile() ? "view" : "home");
    return true;
  }
  return false;
};
